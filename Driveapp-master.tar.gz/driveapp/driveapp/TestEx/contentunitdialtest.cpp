#include <QVBoxLayout>
#include "contentunitdialtest.h"
#include "../DriveApp/customWidget/contentUnitDial/contentunitdial.h"

ContentUnitDialTest::ContentUnitDialTest(QWidget *parent) : QWidget(parent)
{
    this->resize(800,480);
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    ContentUnitDial *dial = new ContentUnitDial(this);
    baseVbLayout->addWidget(dial);
}

