#include <QVBoxLayout>
#include "speeddialtest.h"
#include "../DriveApp/customWidget/carSpeedDial/carspeeddial.h"

SpeedDialTest::SpeedDialTest(QWidget *parent) : QWidget(parent)
{
    this->resize(800,480);
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    CarSpeedDial *dial = new CarSpeedDial(this);
    baseVbLayout->addWidget(dial);
}

