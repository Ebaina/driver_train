#ifndef CONTENTUNITDIALTEST_H
#define CONTENTUNITDIALTEST_H

#include <QWidget>

class ContentUnitDialTest : public QWidget
{
    Q_OBJECT
public:
    explicit ContentUnitDialTest(QWidget *parent = 0);

signals:

public slots:
};

#endif // CONTENTUNITDIALTEST_H
