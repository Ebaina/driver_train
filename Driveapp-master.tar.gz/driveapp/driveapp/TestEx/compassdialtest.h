#ifndef COMPASSDIALTEST_H
#define COMPASSDIALTEST_H

#include <QWidget>

class CompassDialTest : public QWidget
{
    Q_OBJECT
public:
    explicit CompassDialTest(QWidget *parent = 0);

signals:

public slots:
};

#endif // COMPASSDIALTEST_H
