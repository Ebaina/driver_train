#ifndef SPEEDDIALTEST_H
#define SPEEDDIALTEST_H

#include <QWidget>

class SpeedDialTest : public QWidget
{
    Q_OBJECT
public:
    explicit SpeedDialTest(QWidget *parent = 0);

signals:

public slots:
};

#endif // SPEEDDIALTEST_H
