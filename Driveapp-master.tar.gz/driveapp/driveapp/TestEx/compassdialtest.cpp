#include <QVBoxLayout>
#include "compassdialtest.h"
#include "../DriveApp/customWidget/compassDial/compassdial.h"

CompassDialTest::CompassDialTest(QWidget *parent) : QWidget(parent)
{
    this->resize(800,480);
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    CompassDial *dial = new CompassDial(this);
    baseVbLayout->addWidget(dial);
}

