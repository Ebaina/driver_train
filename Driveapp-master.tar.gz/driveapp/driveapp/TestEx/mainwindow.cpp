#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "speeddialtest.h"
#include "compassdialtest.h"
#include "contentunitdialtest.h"



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_dialTest = NULL;
    m_compassDialTest = NULL;
    m_contentUnitDialTest = NULL;
}

MainWindow::~MainWindow()
{

    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    m_dialTest = new SpeedDialTest;
    m_dialTest->show();
}

void MainWindow::on_pushButton_2_clicked()
{
    m_compassDialTest = new CompassDialTest;
    m_compassDialTest->show();
}

void MainWindow::on_pushButton_3_clicked()
{
    m_contentUnitDialTest = new ContentUnitDialTest;
    m_contentUnitDialTest->show();
}
