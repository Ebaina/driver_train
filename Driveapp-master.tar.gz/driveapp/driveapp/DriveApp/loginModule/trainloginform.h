﻿#ifndef TRAINLOGINFORM_H
#define TRAINLOGINFORM_H
#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"
#include "confirmmessagedialog.h"
#include "messagebox.h"

class LoginHandler;
class ConfirmMessageDialog;
class Messagebox;
class TrainLoginForm : public BaseWidget
{
    Q_OBJECT
public:
    enum LoginState{
        LOGIN_FAILED = 0,
        LOGIN_SUCCESS
    };

    enum LogoutState{
        LOGOUT_FAILED = 0,
        LOGOUT_SUCCESS
    };

    enum NetState{
        NET_SUCCESS = 0,
        NET_FAILED
    };

    explicit TrainLoginForm(QWidget *parent = 0);
    ~TrainLoginForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();



private:
    QStackedWidget *m_mainStackWidget;
    bool m_autoJumpFlag;

    /***UI start ***/
    QToolButton *m_coachBtn;
    QToolButton *m_studentBtn;
    QToolButton *m_managerBtn;
    QPushButton *m_displayBtn;
    QToolButton *m_shutdownBtn;
    /***UI end***/

    LoginHandler *m_loginHandler;

    ConfirmMessageDialog *m_netDlg;
    ConfirmMessageDialog *m_netConnectOKDlg;
    ConfirmMessageDialog *m_IdentiftyConnectDlg;
    ConfirmMessageDialog *m_IdentiftyOKDlg;

    void drawUI();

    void initConnect();

    void showCoachInfoForm(UI_CoachLogin_Up &coachInfo);

    void showLearnerInfoForm(UI_LearnerLogin_Up &learnerInfo);

    void updateCoachLoginState(bool isLogin,bool isCoachPic);

    void updateLearnerLoginState(bool isLogin,bool isLearnerPic);

    void onStartNetConnect(unsigned char netIsonline);

    void onNetConnectOK();

    void onIdentifyConnect();

    void onIdentifyOK();

    bool autoJumpFlag() const;
    void setAutoJumpFlag(bool autoJumpFlag);

 signals:
    void next_signal();

private slots:
    void onEndTrainBtnClicked(bool clicked);

    void onshowAdminLoginForm(bool clicked);

    void onDisplayBtnClicked(bool clicked);

    void onUpdateNetAck(unsigned char netIsonline);

    void onUpdateIdentifyAck(unsigned char IsIdentify);

    void onConfirmDlgFinished();

    void onConnectOKFinished();

    void onIdenConFinished();

    void onIdentiftyOKFinished();

    void onUpdateCoachLoginAck(unsigned char loginState);

    void onUpdateCoachLoginInfo(UI_CoachLogin_Up coachInfo);

    void onUpdateCoachLogoutAck(unsigned char logoutState);

    void onUpdateLearnerLoginAck(unsigned char loginState);

    void onUpdateLearnerLoginInfo(UI_LearnerLogin_Up learnerInfo);

    void onUpdateLearnerLogoutAck(unsigned char logoutState);

    void onTimeout();

    /***PC DEBUG***/
    void onCoachBtnClicked(bool clicked);

    void onLearnerBtnClicked(bool clicked);
    /***PC DEBUG END***/
};

#endif // TRAINLOGINFORM_H

