﻿#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QTimer>
#include "loginhintform.h"
#include "trainloginform.h"
#include "widgetcollector.h"

LoginHintForm::LoginHintForm(wis_u16 type,QWidget *parent) :
    BaseWidget(parent),
    m_type(type),
    m_mainStackWidget(NULL)
{
    setObjectName(QString("loginHintForm"));

    drawUI();
}


wis_u16 LoginHintForm::type()
{
    return m_type;
}

void LoginHintForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void LoginHintForm::updateContent()
{
    setAutoJumpFlag(true);
    QTimer::singleShot(1000, this, SLOT(onTimeout()));
}

bool LoginHintForm::autoJumpFlag() const
{
    return m_autoJumpFlag;
}

void LoginHintForm::setAutoJumpFlag(bool autoJumpFlag)
{
    m_autoJumpFlag = autoJumpFlag;
}

void LoginHintForm::drawUI()
{
    switch(m_type){
    case WIS_UI_ENUM::COACH_LOGIN_SUCCESS_HINT_FORM:
        drawCoachLoginSuccessHintForm();
        break;
    case WIS_UI_ENUM::COACH_LOGIN_FAILED_HINT_FORM:
        drawCoachLoginFailedHintForm();
        break;
    case WIS_UI_ENUM::LEARNER_LOGIN_FAILED_HINT_FORM:
        drawLearnerLoginFailedHintForm();
        break;
    default:
        break;
    }
}

void LoginHintForm::drawCoachLoginSuccessHintForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 118, 0, 142);
    baseVbLayout->setSpacing(61);
    QLabel *lbOne = new QLabel(this);

    lbOne->setText(tr("教练登录成功"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

    QPushButton *ensureBtn = new QPushButton(tr("确认"),this);
    ensureBtn->setObjectName(QString("coachEnsureBtn"));
    ensureBtn->setVisible(false);
    baseVbLayout->addWidget(ensureBtn);

    connect(ensureBtn, SIGNAL(clicked(bool)), this, SLOT(onCoachLoginSuccessEnsureBtnClicked(bool)));
}

void LoginHintForm::drawCoachLoginFailedHintForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 118, 0, 142);
    baseVbLayout->setSpacing(61);
    QLabel *lbOne = new QLabel(this);

    lbOne->setText(tr("教练登录失败"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

    QPushButton *backBtn = new QPushButton(tr("返回"),this);
    backBtn->setObjectName(QString("coachBackBtn"));
    baseVbLayout->addWidget(backBtn);

    connect(backBtn,SIGNAL(clicked(bool)),this,SLOT(onLearnerLoginFailedBackBtnClicked(bool)));
}

void LoginHintForm::drawLearnerLoginFailedHintForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 118, 0, 142);
    baseVbLayout->setSpacing(61);
    QLabel *lbOne = new QLabel(this);

    lbOne->setText(tr("学员登录失败"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

    QPushButton *backBtn = new QPushButton(tr("返回"),this);
    backBtn->setObjectName(QString("learnerBackBtn"));
    baseVbLayout->addWidget(backBtn);

    connect(backBtn, SIGNAL(clicked(bool)), this,SLOT(onLearnerLoginFailedBackBtnClicked(bool)));
}

void LoginHintForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void LoginHintForm::onCoachLoginSuccessEnsureBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    setAutoJumpFlag(false);
    showTrainLoginForm();
}

void LoginHintForm::onCoachLoginFailedBackBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    setAutoJumpFlag(false);
    showTrainLoginForm();
}

void LoginHintForm::onLearnerLoginFailedBackBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    setAutoJumpFlag(false);
    showTrainLoginForm();
}

void LoginHintForm::onTimeout()
{
    if(autoJumpFlag() == false)
        return;
    showTrainLoginForm();
}

