﻿#ifndef ADMINLOGINFORM_H
#define ADMINLOGINFORM_H

#include <QObject>
#include <QLineEdit>
#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"
#include "confirmmessagedialog.h"
class AdminLoginForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit AdminLoginForm(QWidget *parent  = 0);
    ~AdminLoginForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();
private:
    QStackedWidget *m_mainStackWidget;

    /***UI start***/
    QLineEdit *m_userInputLe;
    QLineEdit *m_passwdInputLe;
    QPushButton *m_ensureBtn;
    QPushButton *m_backBtn;
    QToolButton *m_homeBtn;
    QToolButton *m_pointBtn;
    /***UI end***/
    ConfirmMessageDialog *m_versionDlg;
    ConfirmMessageDialog *m_pointDlg;

    void drawUI();

    void showTrainLoginForm();

    void showSettingForm();

    void initConnect();

private slots:
    void onBackBtnClicked(bool clicked);
    void onConfirmDlgFinished();
    void VersionShow();
    void PointShow();
    void RunPointShow();
    void onEnsureBtnClicked(bool clicked);
};

#endif // ADMINLOGINFORM_H
