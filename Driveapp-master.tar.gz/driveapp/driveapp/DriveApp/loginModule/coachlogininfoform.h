#ifndef COACHLOGININFOFORM_H
#define COACHLOGININFOFORM_H

#include <QToolButton>
#include <QLineEdit>
#include "basewidget.h"

class CoachLoginInfoForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit CoachLoginInfoForm(QWidget *parent = 0);

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

    void setCoachInfo(const UI_CoachLogin_Up &coachInfo);

private:
    QStackedWidget *m_mainStackWidget;

    bool m_fingerVerified;

    /***UI start***/
    QLineEdit *m_coachNoLe;
    QLineEdit *m_coachIDCardLe;
    QLineEdit *m_driveCarType;
    QToolButton *m_homeBtn;
    /***UI end***/
    void drawUI();

    void initConnect();

    void showTrainLoginForm();

    void showLoginRetHintForm(wis_u16 type);

private slots:
    void onFingerTimeout();

    void onUpdateCoachFingerAck(unsigned char state);

    void ontmpshowForm();
};

#endif // COACHLOGININFOFORM_H
