#ifndef LOGINHINTFORM_H
#define LOGINHINTFORM_H

#include <QObject>
#include "basewidget.h"

class LoginHintForm : public BaseWidget
{
    Q_OBJECT
public:
    LoginHintForm(wis_u16 type,QWidget *parent = 0);

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();



private:
    wis_u16 m_type;
    QStackedWidget *m_mainStackWidget;
    bool m_autoJumpFlag;

    void drawUI();

    /**
  *@brief   coach login success hint
 */
    void drawCoachLoginSuccessHintForm();

    /**
  *@brief  coach login failed hint
 */
    void drawCoachLoginFailedHintForm();

    /**
  *@brief   learner login failed hint
 */
    void drawLearnerLoginFailedHintForm();

    void showTrainLoginForm();

    bool autoJumpFlag() const;
    void setAutoJumpFlag(bool autoJumpFlag);

private slots:
    void onCoachLoginSuccessEnsureBtnClicked(bool clicked);

    void onCoachLoginFailedBackBtnClicked(bool clicked);

    void onLearnerLoginFailedBackBtnClicked(bool clicked);

    void onTimeout();
};

#endif // LOGINHINTFORM_H
