﻿#ifndef TRAINLOGOUTFORM_H
#define TRAINLOGOUTFORM_H

#include <QToolButton>
#include <QPushButton>
#include "basewidget.h"
#include "confirmmessagedialog.h"

class TrainLogoutForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit TrainLogoutForm(QWidget *parent = 0);
    ~TrainLogoutForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();


private:
    QStackedWidget *m_mainStackWidget;

    int paytype;

    //UI
    QToolButton *m_coachBtn;
    QToolButton *m_studentBtn;
    QToolButton *m_homeBtn;
    QToolButton *m_shutBtn;
    QPushButton *m_displayBtn;
    ConfirmMessageDialog *m_exitDlg;

    void drawUI();

    void showTrainLoginForm();

    void updateCoachLoginState(bool isLogin);

    void updateLearnerLoginState(bool isLogin);

private slots:
    void onUpdateLogoutAck(unsigned char state);

    void onShutBtnClicked();

    void onExitBtnClicked(bool clicked);

    void onConfirmDlgFinished(int ret);

    void onHomeBtnClicked(bool clicked);

    void onLearnerBtnClicked();

};

#endif // TRAINLOGOUTFORM_H
