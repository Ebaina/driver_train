﻿#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QtDebug>
#include "trainlogoutform.h"
#include "trainloginform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "reportlearnrecform.h"
#include "appglobal.h"

TrainLogoutForm::TrainLogoutForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    m_exitDlg = NULL;
    this->setObjectName("trainLogoutForm");

    drawUI();

    connect(HandlerManager::instance()->getLoginHandler(), SIGNAL(sigLogoutAck(unsigned char)), this, SLOT(onUpdateLogoutAck(unsigned char)));
    connect(m_shutBtn, SIGNAL(clicked(bool)), this, SLOT(onExitBtnClicked(bool)));
    connect(m_homeBtn, SIGNAL(clicked(bool)), this, SLOT(onHomeBtnClicked(bool)));
}

TrainLogoutForm::~TrainLogoutForm()
{

}

wis_u16 TrainLogoutForm::type()
{
    return WIS_UI_ENUM::TRAIN_LOGOUT_FORM;
}

void TrainLogoutForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void TrainLogoutForm::updateContent()
{
#ifdef nuc970_4_8
    LoginHandler *loginHandler = HandlerManager::instance()->getLoginHandler();
    loginHandler->openLogoutSwipe();
    loginHandler->closeSwipe();
    paytype = loginHandler->is_paytype();
    bool cIsLogin = loginHandler->coachIsLogin();
    updateCoachLoginState(cIsLogin);
    bool lIsLogin = loginHandler->learnerIsLogin();
    updateLearnerLoginState(lIsLogin);
#endif
}

void TrainLogoutForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(30,30,30,30);
    baseVbLayout->setSpacing(0);

    QLabel *lbTitle = new QLabel(tr("教练学员登出界面"),this);
    lbTitle->setAlignment(Qt::AlignCenter);
    lbTitle->setStyleSheet(QString("font-size:36px;color:#5da1de;text-align:center;"));
    lbTitle->setContentsMargins(0,0,0,0);
    baseVbLayout->addWidget(lbTitle);


    QHBoxLayout *midHbLayout = new QHBoxLayout();
    midHbLayout->setContentsMargins(0,28,0,0);
    midHbLayout->setSpacing(56);

    m_coachBtn = new QToolButton(this);
    m_coachBtn->setObjectName(QString("coachLogoutBtn"));
    m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_logouted.png\")"));
    midHbLayout->addStretch();
    midHbLayout->addWidget(m_coachBtn);
    m_studentBtn = new QToolButton(this);
    m_studentBtn->setObjectName(QString("studentLogoutBtn"));
    m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_logouted.png\")"));
    midHbLayout->addWidget(m_studentBtn);
    midHbLayout->addStretch();

    baseVbLayout->addLayout(midHbLayout);
    baseVbLayout->setAlignment(midHbLayout,Qt::AlignHCenter);

    QHBoxLayout *bottomHbLayout = new QHBoxLayout();
    bottomHbLayout->setContentsMargins(0,20,0,0);
    m_shutBtn = new QToolButton(this);
    m_shutBtn->setObjectName("exitBtn");
    m_shutBtn->setIcon(QIcon(":/resource/image/exit.png"));
    bottomHbLayout->addWidget(m_shutBtn);
    bottomHbLayout->addStretch();

    m_homeBtn = new QToolButton(this);
    m_homeBtn->setObjectName("homeBtn");
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home.png"));
    bottomHbLayout->addWidget(m_homeBtn);
    bottomHbLayout->setAlignment(m_homeBtn,Qt::AlignRight);
    baseVbLayout->addLayout(bottomHbLayout);


#ifdef WIS_UI_DEBUG
    connect(m_studentBtn, SIGNAL(clicked()), this, SLOT(onLearnerBtnClicked()));
#endif
}

void TrainLogoutForm::showTrainLoginForm()
{
    HandlerManager::instance()->getLoginHandler()->closeLogoutSwipe();

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }
    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void TrainLogoutForm::updateCoachLoginState(bool isLogin)
{
    if(isLogin)
    {
        m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_unlogout.png\")"));
    }
    else
    {
         m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_logouted.png\")"));      
    }
}

void TrainLogoutForm::updateLearnerLoginState(bool isLogin)
{
    if(isLogin)
    {
        m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_unlogout.png\")"));
    }
    else
    {
         m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_logouted.png\")"));
    }
}

void TrainLogoutForm::onUpdateLogoutAck(unsigned char state)
{
    switch(state){
    case UI_HEADER::LT_TIMEOUT:{
        showTrainLoginForm();
    }
        break;
    case UI_HEADER::LT_COACH:{
        m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_logouted.png\")"));
    }
        break;
    case UI_HEADER::LT_LEARNER:{
        m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_logouted.png\")"));

        //        跳转到学时记录的那一个页面
        if(paytype == 2)     //付费方式：1先学后付，2先付后学
       {
           sleep(1);
           onLearnerBtnClicked();
       }
    }
        break;
    default:
        break;
    }
}

void TrainLogoutForm::onShutBtnClicked()
{
    HandlerManager::instance()->getLoginHandler()->rebootSystem();
}

void TrainLogoutForm::onExitBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    if(m_exitDlg == NULL){
        m_exitDlg = new ConfirmMessageDialog;
        m_exitDlg->setTest(tr("是否强制退出!!!"));
        connect(m_exitDlg, SIGNAL(sigOk()), this, SLOT(onShutBtnClicked()));
        connect(m_exitDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished(int)));
    }
    m_exitDlg->showFullScreen();
}

void TrainLogoutForm::onConfirmDlgFinished(int ret)
{
    (void)ret;
    qDebug() << "finished";
    m_exitDlg = NULL;
}

void TrainLogoutForm::onHomeBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showTrainLoginForm();
}

void TrainLogoutForm::onLearnerBtnClicked()
{
    HandlerManager::instance()->getLoginHandler()->closeLogoutSwipe();
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::REPORT_LEARN_REC_FORM);
    ReportLearnRecForm *recForm = NULL;
    if(!bw){
        recForm = new ReportLearnRecForm();
        recForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::REPORT_LEARN_REC_FORM,recForm);
        m_mainStackWidget->addWidget(recForm);

    }else{
        recForm = static_cast<ReportLearnRecForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(recForm);
    recForm->updateContent();
}

