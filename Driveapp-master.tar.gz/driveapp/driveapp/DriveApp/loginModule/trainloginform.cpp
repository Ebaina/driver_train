#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QDebug>
#include <QTimer>
#include "trainloginform.h"
#include "adminloginform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "coachlogininfoform.h"
#include "learnerlogininfoform.h"
#include "traindisplayform.h"
#include "trainlogoutform.h"
#include "public.h"
 int flagconnect = 0;
 int flagOK =0;
 int flagidentify = 0;
 int flagclose1 = 0;
 int flagclose2 = 0;
 int flagclose3 = 0;
 int flagnetOK = 0;
 int flagIdenOK = 0;

TrainLoginForm::TrainLoginForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_loginHandler(HandlerManager::instance()->getLoginHandler())
{
    m_netDlg = NULL;
    m_netConnectOKDlg = NULL;
    m_IdentiftyConnectDlg = NULL;
    m_IdentiftyOKDlg = NULL;
    this->setObjectName(QString("trainLoginForm"));
    drawUI();

    initConnect();
    setAutoJumpFlag(false);
}

TrainLoginForm::~TrainLoginForm()
{
    if(m_netDlg)
    {
        delete m_netDlg;
        m_netDlg = NULL;
    }
    if(m_netConnectOKDlg)
    {
        delete m_netConnectOKDlg;
        m_netConnectOKDlg = NULL;
    }
}

wis_u16 TrainLoginForm::type()
{
    return WIS_UI_ENUM::TRAIN_LOGIN_FORM;
}

void TrainLoginForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;

}

void TrainLoginForm::updateContent()
{

#ifdef nuc970_4_8
    m_loginHandler->openSwipe();
    bool cIsLogin = m_loginHandler->coachIsLogin();
    bool cIsLPic = m_loginHandler->coachIsPic();
    updateCoachLoginState(cIsLogin,cIsLPic);
    bool lIsLogin = m_loginHandler->learnerIsLogin();
    bool lIsPic = m_loginHandler->learnerIsPic();
    updateLearnerLoginState(lIsLogin,lIsPic);
    if(cIsLogin && lIsLogin){
        m_displayBtn->setEnabled(true);
        setAutoJumpFlag(true);
        QTimer::singleShot(2000,this,SLOT(onTimeout()));
    }else{
        setAutoJumpFlag(false);
        m_displayBtn->setEnabled(false);
    }

#endif
}

bool TrainLoginForm::autoJumpFlag() const
{
    return m_autoJumpFlag;
}

void TrainLoginForm::setAutoJumpFlag(bool autoJumpFlag)
{
    m_autoJumpFlag = autoJumpFlag;
}

void TrainLoginForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(30,30,30,30);
    baseVbLayout->setSpacing(0);
    QLabel *lbTitle = new QLabel(tr("驾校培训计时终端"),this);
    lbTitle->setAlignment(Qt::AlignCenter);
    lbTitle->setStyleSheet(QString("font-size:36px;color:#5da1de;text-align:center;"));
    lbTitle->setContentsMargins(0,0,0,0);
    baseVbLayout->addWidget(lbTitle);

    QHBoxLayout *midHbLayout = new QHBoxLayout();
    midHbLayout->setContentsMargins(0,28,0,0);
    midHbLayout->setSpacing(56);
    m_coachBtn = new QToolButton(this);
    m_coachBtn->setObjectName(QString("coachLoginBtn"));
    m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_unlogin.png\")"));
    midHbLayout->addStretch();
    midHbLayout->addWidget(m_coachBtn);
    m_studentBtn = new QToolButton(this);
    m_studentBtn->setObjectName(QString("studentLoginBtn"));
    m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_unlogin.png\")"));
    midHbLayout->addWidget(m_studentBtn);
    midHbLayout->addStretch();

    baseVbLayout->addLayout(midHbLayout);
    baseVbLayout->setAlignment(midHbLayout,Qt::AlignHCenter);

    QHBoxLayout *bottomHbLayout = new QHBoxLayout();
    bottomHbLayout->setContentsMargins(0,20,0,0);
    m_managerBtn = new QToolButton();
    m_managerBtn->setObjectName(QString("managerBtn"));
    m_managerBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/manager_login.png"));
    bottomHbLayout->addWidget(m_managerBtn);
    bottomHbLayout->addStretch();
    m_displayBtn = new QPushButton(tr("显示界面"),this);
    m_displayBtn->setObjectName(QString("displayBtn"));
//    m_displayBtn->setVisible(false);
    bottomHbLayout->addWidget(m_displayBtn);
    bottomHbLayout->addStretch();
    m_shutdownBtn = new QToolButton(this);
    m_shutdownBtn->setObjectName(QString("exitBtn"));
    m_shutdownBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/exit.png"));
    bottomHbLayout->addWidget(m_shutdownBtn);

    baseVbLayout->addLayout(bottomHbLayout);
}

void TrainLoginForm::initConnect()
{
    connect(m_loginHandler, SIGNAL(sigUpdateNetConnectAck(unsigned char)), this, SLOT(onUpdateNetAck(unsigned char)));
    connect(m_loginHandler, SIGNAL(sigUpdateIdentifyConnectAck(unsigned char)), this, SLOT(onUpdateIdentifyAck(unsigned char)));
    connect(m_managerBtn, SIGNAL(clicked(bool)), this, SLOT(onshowAdminLoginForm(bool)));
    connect(m_loginHandler, SIGNAL(sigUpdateCoachLoginAck(unsigned char)), this, SLOT(onUpdateCoachLoginAck(unsigned char)));
    connect(m_loginHandler, SIGNAL(sigUpdateCoachLogoutAck(unsigned char)),this,SLOT(onUpdateCoachLogoutAck(unsigned char)));
    connect(m_loginHandler, SIGNAL(sigUpdateLearnerLoginAck(unsigned char)),this,SLOT(onUpdateLearnerLoginAck(unsigned char)));
    connect(m_loginHandler,SIGNAL(sigUpdateLearnerLogoutAck(unsigned char)),this,SLOT(onUpdateLearnerLogoutAck(unsigned char)));
    connect(m_displayBtn, SIGNAL(clicked(bool)), this, SLOT(onDisplayBtnClicked(bool)));
    connect(m_loginHandler, SIGNAL(sigCoachLoginInfo(UI_CoachLogin_Up)), this, SLOT(onUpdateCoachLoginInfo(UI_CoachLogin_Up)));
    connect(m_loginHandler, SIGNAL(sigLearnerLoginInfo(UI_LearnerLogin_Up)), this, SLOT(onUpdateLearnerLoginInfo(UI_LearnerLogin_Up)));
    connect(m_shutdownBtn, SIGNAL(clicked(bool)), this, SLOT(onEndTrainBtnClicked(bool)));

    /***UI_PC DEBUG***/
//#ifdef WIS_UI_DEBUG
    connect(m_coachBtn,SIGNAL(clicked(bool)),this,SLOT(onCoachBtnClicked(bool)));
    connect(m_studentBtn,SIGNAL(clicked(bool)),this,SLOT(onLearnerBtnClicked(bool)));
//#endif
    /***UI_PC DEBUG END***/
}

void TrainLoginForm::showCoachInfoForm(UI_CoachLogin_Up &coachInfo)
{
#ifdef nuc970_4_8
    m_loginHandler->closeSwipe();
#endif
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::COACH_LOGIN_INFO_FORM);
    CoachLoginInfoForm *coachInfoForm = NULL;
    if(!bw){
        coachInfoForm = new CoachLoginInfoForm();
        coachInfoForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::COACH_LOGIN_INFO_FORM,coachInfoForm);
        m_mainStackWidget->addWidget(coachInfoForm);

    }else{
        coachInfoForm = static_cast<CoachLoginInfoForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(coachInfoForm);
    coachInfoForm->setCoachInfo(coachInfo);
    coachInfoForm->updateContent();
}

void TrainLoginForm::onEndTrainBtnClicked(bool clicked)
{
    m_loginHandler->closeSwipe();
    Q_UNUSED(clicked)

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGOUT_FORM);
    TrainLogoutForm *logoutForm = NULL;
    if(!bw){
        logoutForm = new TrainLogoutForm();
        logoutForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM,logoutForm);
        m_mainStackWidget->addWidget(logoutForm);

    }else{
        logoutForm = static_cast<TrainLogoutForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(logoutForm);
    logoutForm->updateContent();
}

void TrainLoginForm::showLearnerInfoForm(UI_LearnerLogin_Up &learnerInfo)
{
#ifdef nuc970_4_8
    m_loginHandler->closeSwipe();
#endif
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::LEARNER_LOGIN_INFO_FORM);
    LearnerLoginInfoForm *leaenerInfoForm = NULL;
    if(!bw){
        leaenerInfoForm = new LearnerLoginInfoForm();
        leaenerInfoForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::LEARNER_LOGIN_INFO_FORM,leaenerInfoForm);
        m_mainStackWidget->addWidget(leaenerInfoForm);

    }else{
        leaenerInfoForm = static_cast<LearnerLoginInfoForm*>(bw);
    }
    m_mainStackWidget->setCurrentWidget(leaenerInfoForm);
    leaenerInfoForm->setLearnerInfo(learnerInfo);
    leaenerInfoForm->updateContent();
}

void TrainLoginForm::updateCoachLoginState(bool isLogin,bool isCoachPic)
{
    UI_CoachPhotonameSet photonameset;
    QString str_photo = "border-image:url(../../mnt/mmcblk0p1/headphoto/" ;
    photonameset = HandlerManager::instance()->getLoginHandler()->getcoachphotonameInfo();
    if(isLogin){
        QString coachphotoname = QString((char*)photonameset.CoachPhoto);
        str_photo.append(coachphotoname.mid(0,20));
        str_photo.append(")");
        if(isCoachPic)
        {
            m_coachBtn->setStyleSheet(str_photo);
        }
        else
        {
            m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_logined.png\")"));
        }
    }
    else
    {
         m_coachBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/coach_unlogin.png\")"));
    }
}

void TrainLoginForm::updateLearnerLoginState(bool isLogin,bool isLearnerPic)
{
    UI_LearnerPhotonameSet photonameset;
    QString str_photo = "border-image:url(../../mnt/mmcblk0p1/headphoto/" ;
    photonameset = HandlerManager::instance()->getLoginHandler()->getlearnerphotonameInfo();
    if(isLogin){
        QString learnerphotoname = QString((char*)photonameset.LearnerPhoto);
        str_photo.append(learnerphotoname.mid(0,20));
        str_photo.append(")");
        if(isLearnerPic)
        {
            m_studentBtn->setStyleSheet(str_photo);
        }
        else
        {
            m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_logined.png\")"));
        }
    }
    else
    {
        m_studentBtn->setStyleSheet(QString("border-image:url(\":/login_module_img/resource/image/loginModuleImg/student_unlogin.png\")"));
    }
}

void TrainLoginForm::onshowAdminLoginForm(bool clicked)
{
    Q_UNUSED(clicked)

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::ADMIN_LOGIN_FORM);
    AdminLoginForm *adminLoginForm = NULL;
    if(!bw){
        adminLoginForm = new AdminLoginForm();
        adminLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::ADMIN_LOGIN_FORM,adminLoginForm);
        m_mainStackWidget->addWidget(adminLoginForm);

    }else{
        adminLoginForm = static_cast<AdminLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(adminLoginForm);
    adminLoginForm->updateContent();
}

void TrainLoginForm::onStartNetConnect(unsigned char netIsonline)
{
#ifdef nuc970_4_8
    m_loginHandler->closeSwipe();
#endif
    if(m_netDlg == NULL){
        m_netDlg = new ConfirmMessageDialog;
        m_netDlg->setAttribute(Qt::WA_DeleteOnClose,false);
        m_netDlg->setTest(tr("网络正在连接..."));
        m_netDlg->m_cancelBtn->setVisible(false);
        m_netDlg->m_okBtn->setVisible(false);
        connect(m_netDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished()));
    }
#ifdef nuc970_4_8
    m_netDlg->showFullScreen();
#else
    this->setMaximumSize(800,480);
    this->resize(800,480);
#endif
}

void TrainLoginForm::onNetConnectOK()
{
    m_loginHandler->openSwipe();
    if(m_netConnectOKDlg == NULL){

        m_netConnectOKDlg = new ConfirmMessageDialog;
        m_netConnectOKDlg->setAttribute(Qt::WA_DeleteOnClose,false);
        m_netConnectOKDlg->setTest(tr("网络连接成功"));
        m_netConnectOKDlg->m_cancelBtn->setVisible(false);
        m_netConnectOKDlg->m_okBtn->setVisible(false);
//     connect(m_netConnectOKDlg, SIGNAL(sigOk()), this, SLOT(onConnectOKFinished()));
//     connect(m_netConnectOKDlg, SIGNAL(finished(int)), this, SLOT(onConnectOKFinished()));
    }
#ifdef nuc970_4_8
    m_netConnectOKDlg->showFullScreen();
#endif
}

void TrainLoginForm::onIdentifyConnect()
{
    if(m_IdentiftyConnectDlg == NULL){
        m_IdentiftyConnectDlg = new ConfirmMessageDialog;
        m_IdentiftyConnectDlg->setTest(tr("鉴权连接..."));
        m_IdentiftyConnectDlg->m_okBtn->setVisible(false);
        m_IdentiftyConnectDlg->m_cancelBtn->setVisible(false);
        connect(m_IdentiftyConnectDlg, SIGNAL(finished(int)), this, SLOT(onIdenConFinished()));
    }
#ifdef nuc970_4_8
    m_IdentiftyConnectDlg->showFullScreen();
#endif
}

void TrainLoginForm::onIdentifyOK()
{
    m_loginHandler->openSwipe();

    if(m_IdentiftyOKDlg == NULL){
        m_IdentiftyOKDlg = new ConfirmMessageDialog;
        m_IdentiftyOKDlg->setTest(tr("鉴权成功"));
        m_IdentiftyOKDlg->m_cancelBtn->setVisible(false);
//        connect(m_IdentiftyOKDlg, SIGNAL(sigOk()), this, SLOT(onIdentiftyOKFinished()));
//        connect(m_IdentiftyOKDlg, SIGNAL(finished(int)), this, SLOT(onIdentiftyOKFinished()));
    }
#ifdef nuc970_4_8
    m_IdentiftyOKDlg->showFullScreen();
#endif
}

void TrainLoginForm :: onUpdateNetAck(unsigned char netIsonline)
{
    if(flagconnect == 0)
    {
        if((netIsonline == 1)||(netIsonline == 2)){
            onStartNetConnect(netIsonline);
            flagconnect++;
            flagOK++;
        }else if(netIsonline == TrainLoginForm::NET_SUCCESS){
            onNetConnectOK();
            QTimer::singleShot(2000,this,SLOT(onConnectOKFinished()));
            flagconnect++;
            flagnetOK++;
            return;
        }
    }
    if(flagOK == 1)
    {
        if(netIsonline == TrainLoginForm::NET_SUCCESS)
        {
            m_netDlg->close();
            onNetConnectOK();
            QTimer::singleShot(2000,this,SLOT(onConnectOKFinished()));
            flagnetOK++;
            flagOK =0;
        }
    }
}

void TrainLoginForm :: onUpdateIdentifyAck(unsigned char IsIdentify)
{
    if(flagnetOK == 1)
    {
        if(flagclose2 == 0)
        {
            m_netConnectOKDlg->close();
//            delete m_netConnectOKDlg;
        }
        if(flagidentify == 0)
        {
            if(IsIdentify == 1)
            {
                onIdentifyOK();
                QTimer::singleShot(2000,this,SLOT(onIdentiftyOKFinished()));
                flagidentify++;
            }
            else if(IsIdentify == 0)
            {
                onIdentifyConnect();
                flagidentify++;
                flagIdenOK++;
            }
       if(flagIdenOK == 1)
        {
             if(IsIdentify == 1)
                {
                 if(flagclose3 == 0)
                 {
                     m_IdentiftyConnectDlg->close();
                 }
                 onIdentifyOK();
                 QTimer::singleShot(2000,this,SLOT(onIdentiftyOKFinished()));
                  flagIdenOK =0;
                }
            }
        }
    }

}

void TrainLoginForm::onConfirmDlgFinished()
{
    m_netDlg->close();
}
void TrainLoginForm::onConnectOKFinished()
{
    m_netConnectOKDlg ->close();
}
void TrainLoginForm::onIdenConFinished()
{    
    m_IdentiftyConnectDlg = NULL;
}
void TrainLoginForm::onIdentiftyOKFinished()
{
    m_IdentiftyOKDlg ->close();
}

void TrainLoginForm::onDisplayBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
#ifdef nuc970_4_8
    m_loginHandler->closeSwipe();
#endif
    setAutoJumpFlag(false);

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM);
    TrainDisplayForm *displayFom = NULL;
    if(!bw){
        displayFom = new TrainDisplayForm();
        displayFom->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM,displayFom);
        m_mainStackWidget->addWidget(displayFom);

    }else{
        displayFom = static_cast<TrainDisplayForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(displayFom);
    displayFom->updateContent();
}

void TrainLoginForm::onUpdateCoachLoginAck(unsigned char loginState)
{
    qDebug() << "in onUpdateCoachLoginAck: loginState = " << loginState;
    if(loginState == TrainLoginForm::LOGIN_SUCCESS){
//        showCoachInfoForm();
    }else if(loginState == TrainLoginForm::LOGOUT_FAILED){

    }
}

void TrainLoginForm::onUpdateCoachLoginInfo(UI_CoachLogin_Up coachInfo)
{
    if(m_mainStackWidget->currentWidget() != WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM)){
        return;
    }
    showCoachInfoForm(coachInfo);
}

void TrainLoginForm::onUpdateCoachLogoutAck(unsigned char logoutState)
{

}

void TrainLoginForm::onUpdateLearnerLoginAck(unsigned char loginState)
{

}

void TrainLoginForm::onUpdateLearnerLoginInfo(UI_LearnerLogin_Up learnerInfo)
{
    qDebug() << "UI____>onUpdateLearnerLoginInfo";
//    if(m_mainStackWidget->currentWidget() != WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM)){
//       qDebug()  << "UI------> return false";
//        return;
//    }
    showLearnerInfoForm(learnerInfo);
}

void TrainLoginForm::onUpdateLearnerLogoutAck(unsigned char logoutState)
{

}

void TrainLoginForm::onTimeout()
{
    m_loginHandler->closeSwipe();

    if(autoJumpFlag() == false)
        return;

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM);
    TrainDisplayForm *displayFom = NULL;
    if(!bw){
        displayFom = new TrainDisplayForm();
        displayFom->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM,displayFom);
        m_mainStackWidget->addWidget(displayFom);

    }else{
        displayFom = static_cast<TrainDisplayForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(displayFom);
    displayFom->updateContent();
}

void TrainLoginForm::onCoachBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
#ifdef nuc970_4_8
    m_loginHandler->closeSwipe();
#endif
    UI_CoachLogin_Up coachInfo;
    memset((char*)&coachInfo,0,sizeof(UI_CoachLogin_Up));
    showCoachInfoForm(coachInfo);
}

void TrainLoginForm::onLearnerBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
#ifdef nuc970_4_8
    m_loginHandler->closeSwipe();
#endif
    UI_LearnerLogin_Up learnerInfo;
    memset((char*)&learnerInfo,0,sizeof(UI_LearnerLogin_Up));
    showLearnerInfoForm(learnerInfo);
}
