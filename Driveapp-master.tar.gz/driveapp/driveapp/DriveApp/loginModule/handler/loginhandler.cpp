#include <QMetaType>
#include "loginhandler.h"
#include "handlermanager.h"
#include <QDebug>

LoginHandler::LoginHandler(QObject *parent) :
    QObject(parent)
{
    qRegisterMetaType<UI_CoachLogin_Up>("UI_CoachLogin_Up");
    qRegisterMetaType<UI_LearnerLogin_Up>("UI_LearnerLogin_Up");
    qRegisterMetaType<UI_Learner_Info>("UI_Learner_Info");

#ifdef nuc970_4_8
    m_funcInterface = NULL;
    m_funcInterface = HandlerManager::instance()->getFuncInterface();
#endif
}

LoginHandler::~LoginHandler()
{

}

void LoginHandler::updateCoachLoginAckState(unsigned char loginState)
{
    emit sigUpdateCoachLoginAck(loginState);
}

void LoginHandler::updateCoachLogoutAckState(unsigned char logoutState)
{
    emit sigUpdateCoachLogoutAck(logoutState);
}

void LoginHandler::updateLearnerLoginAckState(unsigned char loginState)
{
    emit sigUpdateLearnerLoginAck(loginState);
}

void LoginHandler::updateLearnerLogoutAckState(unsigned char logoutState)
{
    emit sigUpdateLearnerLogoutAck(logoutState);
}

void LoginHandler :: updateNetAckState(unsigned char status)
{
    emit sigUpdateNetConnectAck(status);
}

void LoginHandler :: updateIdentifyAckState(unsigned char status)
{
    emit sigUpdateIdentifyConnectAck(status);
}

void LoginHandler::coachLogin(UI_CoachLogin_Up loginInfo)
{
    emit sigCoachLoginInfo(loginInfo);
}

void LoginHandler::learnerLogin(UI_LearnerLogin_Up loginInfo)
{
    qDebug() << "UI>>>>>learner info " << loginInfo.cardtype;
    qDebug() << loginInfo.cardtype;
    qDebug() << QString((char*)loginInfo.coachid).left(16);
    qDebug() << QString((char*)loginInfo.learnerdentityid).left(16);
    qDebug() << QString((char*)loginInfo.learnerid).left(16);

    qDebug() << "UI end >>> learnerInfo";
    emit sigLearnerLoginInfo(loginInfo);
}

void LoginHandler::learnerUpdateInfo(UI_Learner_Info info)
{
    emit sigUpdateLearnerInfo(info);
}

void LoginHandler::learnerFingerprintAck(unsigned char status, UI_Learner_Info learnerInfo)
{
    emit sigLearnerFingerAck(status, learnerInfo);
}

void LoginHandler::coachFingerprintAck(unsigned char status)
{
    emit sigCoachFingerAck(status);
}

void LoginHandler::logoutAck(unsigned char state)
{
    emit sigLogoutAck(state);
}

CoachLogin_Up LoginHandler::getCoachLoginInfo()
{
    CoachLogin_Up loginInfo;
    /***+++++++++++to do ++++++***/
    memset((char*)&loginInfo,0,sizeof(CoachLogin_Up));
    return loginInfo;
}

UI_CoachPhotonameSet  LoginHandler::getcoachphotonameInfo()
{
    UI_CoachPhotonameSet info;
#ifdef nuc970_4_8
    (void)info;
//    return m_funcInterface->get_coachphotoname_info();
#endif
}

UI_LearnerPhotonameSet LoginHandler::getlearnerphotonameInfo()
{
    UI_LearnerPhotonameSet info;
#ifdef nuc970_4_8
    (void)info;
//    return m_funcInterface->get_learnerphotoname_info();
#endif
}
UI_Learner_record  LoginHandler::getRecordInfo()
{
    UI_Learner_record info;
#ifdef nuc970_4_8
    (void)info;
//    return m_funcInterface->get_record_info();
#endif
}

void LoginHandler::openSwipe()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return;
    }
//    m_funcInterface->open_swipe();
#endif
}

void LoginHandler::closeSwipe()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return;
    }
//    m_funcInterface->close_swipe();
#endif
}

void LoginHandler::openLogoutSwipe()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return;
    }
//    m_funcInterface->open_logout_swipe();
#endif
}

void LoginHandler::closeLogoutSwipe()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return;
    }
//    m_funcInterface->close_logout_swipe();
#endif
}

void LoginHandler::rebootSystem()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return;
    }
//    m_funcInterface->reboot_system();
#endif
}

void LoginHandler::resetLoginState()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return;
    }
//    m_funcInterface->reset_loginstate();
#endif
}

bool LoginHandler::coachIsLogin()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return false;
    }
//    m_funcInterface->is_Coach_Login(this);
#else
    return false;
#endif
}

bool LoginHandler::learnerIsLogin()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return false;
    }
//    m_funcInterface->is_Learner_Login(this);
#else
    return false;
#endif
}

bool LoginHandler::coachIsPic()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return false;
    }
//    m_funcInterface->is_Coach_Pic();
#else
    return false;
#endif
}

bool LoginHandler::learnerIsPic()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL){
        return false;
    }
//    m_funcInterface->is_Learner_Pic();
#else
    return false;
#endif
}


void LoginHandler::setSubjectID(int value)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return;
//    m_funcInterface->set_subjectID(value);
#else
    (void)value;
#endif
}

int LoginHandler::is_paytype()
{
//    if(m_funcInterface == NULL)
        return 0;
//    m_funcInterface->get_paytype();
}
