﻿#ifndef LOGINHANDLER_H
#define LOGINHANDLER_H

#include <QObject>
#include "logininterface.h"
#include "datastructdef.h"

using namespace WIS_UI;

class Ui_Interface;
class LoginHandler : public QObject, public LoginInterface
{
    Q_OBJECT
public:
    explicit LoginHandler(QObject *parent = 0);
    ~LoginHandler();

    /********    callback    ***/
    /**
  *@brief    callback coach login ack
  *@param [in]      loginState
  *                           1:登录成功
  *                           0:登录失败
  */
    void updateCoachLoginAckState(unsigned char loginState);

    /**
  *@brief callback   coach logout ack
  * @param [in]  logoutState
  *                         1:登出成功
  *                         0:登出失败
  */
    void updateCoachLogoutAckState(unsigned char logoutState);


    /**
  *@brief  callback learner login ack
  *@param [in]      loginState
  *                           1:登录成功
  *                           0:登录失败
  */
    void updateLearnerLoginAckState(unsigned char loginState);

    /**
  *@brief   call back learner logout ack
  * @param [in]  logoutState
  *                         1:登出成功
  *                         0:登出失败
  */
    void updateLearnerLogoutAckState(unsigned char logoutState);

    /**
  *@brief   coach login info
 */
    void coachLogin(UI_CoachLogin_Up loginInfo);

    void updateNetAckState(unsigned char status);

    void updateIdentifyAckState(unsigned char status);

    void learnerLogin(UI_LearnerLogin_Up loginInfo);

    void learnerUpdateInfo(UI_Learner_Info info);

    void learnerFingerprintAck(unsigned char status, UI_Learner_Info learnerInfo);

    void coachFingerprintAck(unsigned char status );

    void logoutAck(unsigned char state);

    CoachLogin_Up getCoachLoginInfo();

    UI_CoachPhotonameSet  getcoachphotonameInfo();

    UI_LearnerPhotonameSet getlearnerphotonameInfo();

    UI_Learner_record getRecordInfo();

    void openSwipe();

    void closeSwipe();

    void openLogoutSwipe();

    void closeLogoutSwipe();

    void rebootSystem();

    //debug tmp
    void resetLoginState();

public:
    bool coachIsLogin();

    bool learnerIsLogin();

    bool coachIsPic();

    bool learnerIsPic();

    void setSubjectID(int value);

    int  is_paytype();


signals:
    void sigUpdateNetConnectAck(unsigned char  state);
    void sigUpdateIdentifyConnectAck(unsigned char  state);
    void sigUpdateCoachLoginAck(unsigned char state);
    void sigUpdateCoachLogoutAck(unsigned char state);
    void sigUpdateLearnerLoginAck(unsigned char state);
    void sigUpdateLearnerLogoutAck(unsigned char state);
    void sigCoachLoginInfo(UI_CoachLogin_Up loginInfo);
    void sigLearnerLoginInfo(UI_LearnerLogin_Up loginInfo);
    void sigUpdateLearnerInfo(UI_Learner_Info info);
    void sigLearnerFingerAck(unsigned char state, UI_Learner_Info learnerInfo);
    void sigCoachFingerAck(unsigned char state);
    void sigLogoutAck(unsigned char state);

private:
#ifdef nuc970_4_8
    Ui_Interface *m_funcInterface;
#endif
};

#endif // LOGINHANDLER_H
