﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include "reportlearnrecform.h"
#include "trainaccountform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "QTimer"
#include "QTextCodec"

ReportLearnRecForm::ReportLearnRecForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    this->setObjectName("reportLearnRecForm");
    drawUI();

    initData();

    connect(m_ensureBtn, SIGNAL(clicked()), this, SLOT(onEnsureBtnClicked()));
//    QTimer::singleShot(6000, this, SLOT(onEnsureBtnClicked()));
}

ReportLearnRecForm::~ReportLearnRecForm()
{

}

wis_u16 ReportLearnRecForm::type()
{
    return WIS_UI_ENUM::REPORT_LEARN_REC_FORM;
}

void ReportLearnRecForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void ReportLearnRecForm::updateContent()
{
    UI_Learner_record learner_record;
    learner_record = HandlerManager::instance()->getLoginHandler()->getRecordInfo();
    QTextCodec *codec = QTextCodec::codecForName("GBK");
    QString mm1 = codec->toUnicode((const char*)learner_record.Leaner_name);
    m_learnTimeRecIdLe->setText(mm1);
    m_learnerIdLe->setText(QString((char*)learner_record.learnerid).left(16));
    m_coachIdLe->setText(QString((char*)learner_record.coachid).left(16));
    m_subjectIdLe->setText(QString::number(learner_record.lesson_id));
    m_recCreateTimeLe->setText(QString((char*)learner_record.record_time).left(32));
    m_trainSubjectLe->setText(m_subjectMap.value(subID));
//    m_trainSubjectLe->setText(m_subjectMap.value(learner_record.subjectId));
//    m_maxSpeedLe->setText(QString::number(learner_record.max_speed));
//    m_mileLe->setText(QString::number(learner_record.milage));
}

void ReportLearnRecForm::initData()
{
    m_subjectMap.insert(UI_HEADER::TSI_11, tr("基础驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_12, tr("场地驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_13, tr("综合驾驶及考核"));
    m_subjectMap.insert(UI_HEADER::TSI_21, tr("跟车行驶"));
    m_subjectMap.insert(UI_HEADER::TSI_22, tr("变更车道"));
    m_subjectMap.insert(UI_HEADER::TSI_23, tr("靠边停车"));
    m_subjectMap.insert(UI_HEADER::TSI_24, tr("掉头"));
    m_subjectMap.insert(UI_HEADER::TSI_25, tr("通过路口"));
    m_subjectMap.insert(UI_HEADER::TSI_26, tr("通过人行横道"));
    m_subjectMap.insert(UI_HEADER::TSI_27, tr("通过学校区域"));
    m_subjectMap.insert(UI_HEADER::TSI_28, tr("通过公共汽车站"));
    m_subjectMap.insert(UI_HEADER::TSI_29, tr("会车"));
    m_subjectMap.insert(UI_HEADER::TSI_30, tr("超车"));
    m_subjectMap.insert(UI_HEADER::TSI_31, tr("夜间驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_32, tr("恶劣条件下的驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_33, tr("山区道路驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_34, tr("高速公路驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_35, tr("行驶路线选择"));
}

void ReportLearnRecForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(30,30,30,25);
    baseVbLayout->setSpacing(20);

    QHBoxLayout *contentLayout = new QHBoxLayout;
    contentLayout->setSpacing(20);
    contentLayout->setContentsMargins(0,0,0,0);
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName(QString("leftFrame"));
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    leftGridLayout->setHorizontalSpacing(30);
    leftGridLayout->setVerticalSpacing(5);
    leftGridLayout->setContentsMargins(20,21,20,21);
    QLabel *lb = new QLabel("学员姓名",this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb, 0,0,1,1);
    m_learnTimeRecIdLe = new QLineEdit(this);
    m_learnTimeRecIdLe->setReadOnly(true);
    m_learnTimeRecIdLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    leftGridLayout->addWidget(m_learnTimeRecIdLe,0,1,1,1);
    QLabel *lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,1,0,1,2);

    lb = new QLabel(tr("学员编号"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb, 2,0,1,1);
    m_learnerIdLe = new QLineEdit(this);
    m_learnerIdLe->setReadOnly(true);
    m_learnerIdLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    leftGridLayout->addWidget(m_learnerIdLe,2,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,3,0,1,2);

    lb = new QLabel(tr("教练编号"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb, 4,0,1,1);
    m_coachIdLe = new QLineEdit(this);
    m_coachIdLe->setReadOnly(true);
    m_coachIdLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    leftGridLayout->addWidget(m_coachIdLe,4,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,5,0,1,2);

    lb = new QLabel(tr("课堂ID"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb,6,0,1,1);
    m_subjectIdLe = new QLineEdit(this);
    m_subjectIdLe->setReadOnly(true);
    m_subjectIdLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    leftGridLayout->addWidget(m_subjectIdLe,6,1,1,1);

    contentLayout->addWidget(leftFrame);

    /***right input frame area***/
    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName(tr("rightFrame"));
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    rightGridLayout->setHorizontalSpacing(30);
    rightGridLayout->setVerticalSpacing(5);
    rightGridLayout->setContentsMargins(20,21,20,21);
    lb = new QLabel(tr("训练结束时间"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,0,0,1,1);
    m_recCreateTimeLe = new QLineEdit(this);
    m_recCreateTimeLe->setReadOnly(true);
    m_recCreateTimeLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    rightGridLayout->addWidget(m_recCreateTimeLe,0,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,1,0,1,2);

    lb = new QLabel(tr("培训课程"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,2,0,1,1);
    m_trainSubjectLe = new QLineEdit(this);
    m_trainSubjectLe->setReadOnly(true);
    m_trainSubjectLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    rightGridLayout->addWidget(m_trainSubjectLe,2,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,3,0,1,2);

    lb = new QLabel(tr("最大速度"));
    lb->setVisible(false);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,4,0,1,1);
    m_maxSpeedLe = new QLineEdit(this);
    m_maxSpeedLe->setReadOnly(true);
    m_maxSpeedLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    rightGridLayout->addWidget(m_maxSpeedLe,4,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,5,0,1,3);

    lb = new QLabel(tr("里程"));
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    lb->setVisible(false);
    rightGridLayout->addWidget(lb,6,0,1,1);
    m_mileLe = new QLineEdit(this);
    m_mileLe->setReadOnly(true);
    m_mileLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    rightGridLayout->addWidget(m_mileLe,6,1,1,1);

    contentLayout->addWidget(rightFrame);
    baseVbLayout->addLayout(contentLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout();
    m_ensureBtn = new QPushButton(tr("确认"),this);
    m_ensureBtn->setObjectName("ensureBtn");
//    m_ensureBtn->setVisible(false);
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_ensureBtn);
    bottomBtnLayout->addStretch();
    baseVbLayout->addLayout(bottomBtnLayout);

}

void ReportLearnRecForm::onEnsureBtnClicked()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_ACCOUNT_FORM);
    TrainAccountForm *accountForm = NULL;
    if(!bw){
        accountForm = new TrainAccountForm;
        accountForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_ACCOUNT_FORM,accountForm);
        m_mainStackWidget->addWidget(accountForm);

    }else{
        accountForm = static_cast<TrainAccountForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(accountForm);
    accountForm->updateContent();
}

