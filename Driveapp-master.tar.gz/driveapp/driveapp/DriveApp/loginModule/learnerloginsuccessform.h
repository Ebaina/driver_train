#ifndef LEARNERLOGINSUCCESSFORM_H
#define LEARNERLOGINSUCCESSFORM_H

#include <QObject>
#include <QLineEdit>
#include <QPushButton>
#include "basewidget.h"

class LearnerLoginSuccessForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit LearnerLoginSuccessForm(QWidget *parent = 0);
    ~LearnerLoginSuccessForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

    void setLearnerInfo(const UI_Learner_Info &learnerInfo);

private:
    QStackedWidget *m_mainStackWidget;

    /***UI Start***/
    QLineEdit *m_learnerNoLe;
    QLineEdit *m_totalLearnTime;
    QLineEdit *m_passedLearnTime;
    QLineEdit *m_totalLearnMileage;
    QLineEdit *m_passedLearnMileageLe;
    QPushButton *m_ensureBtn;
    /***UI end***/
    bool m_autoJumpFlag;                                //timeout jump to other form

    void drawUI();

    void initConnect();

    void showTrainLoginForm();

    bool autoJumpFlag() const;
    void setAutoJumpFlag(bool autoJumpFlag);

private slots:
    void onEnsureBtnClicked(bool clicked);

    void onTimeout();
};

#endif // LEARNERLOGINSUCCESSFORM_H
