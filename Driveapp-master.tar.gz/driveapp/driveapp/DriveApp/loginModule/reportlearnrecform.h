﻿#ifndef REPORTLEARNRECFORM_H
#define REPORTLEARNRECFORM_H

#include <QPushButton>
#include <QLineEdit>
#include "basewidget.h"

class ReportLearnRecForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit ReportLearnRecForm(QWidget *parent = 0);
    ~ReportLearnRecForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    QMap<int,QString> m_subjectMap;

    void updateContent();

    void initData();

private:
    QStackedWidget *m_mainStackWidget;

    //ui widgets
    QLineEdit *m_learnTimeRecIdLe;      //学时记录编号
    QLineEdit *m_learnerIdLe;
    QLineEdit *m_coachIdLe;
    QLineEdit *m_subjectIdLe;
    QLineEdit *m_recCreateTimeLe;
    QLineEdit *m_trainSubjectLe;
    QLineEdit *m_maxSpeedLe;
    QLineEdit *m_mileLe;
    QPushButton *m_ensureBtn;

    void drawUI();

private slots:
    void onEnsureBtnClicked();
};

#endif // REPORTLEARNRECFORM_H
