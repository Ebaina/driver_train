﻿#ifndef LEARNERLOGININFOFORM_H
#define LEARNERLOGININFOFORM_H

#include <QObject>
#include <QLineEdit>
#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"

class TextListView;
class LearnerLoginInfoForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit LearnerLoginInfoForm(QWidget *parent = 0);
    ~LearnerLoginInfoForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

    void setLearnerInfo(UI_LearnerLogin_Up learnerInfo);

private:
    QStackedWidget *m_mainStackWidget;

    /***UI start***/
    QLineEdit *m_learnerNoLe;
    QPushButton *m_paperTypeBtn;
    QLineEdit *m_paperIDLe;
    QPushButton *m_driveCarTypeBtn;
    QPushButton *m_trainSubjectBtn;
    QLineEdit *m_curCoachNoLe;

    QToolButton *m_homeBtn;

    TextListView *m_paperTypeListView;
    TextListView *m_subjectListView;
    /***UI end***/
    bool m_fingerVerified;

    QMap<int,QString> m_subjectMap;

    void drawUI();

    void initData();

    void initConnect();

    void showLoginSuccessForm(UI_Learner_Info &learnerInfo);

    void showLoginFailedForm();

private slots:
    void onPaperTypeBtnClicked(bool clicked);

    void onPaperTypeListViewClicked(int index, QString value);

    void onFingerVerifyTimeout();

    void onFingerPrintAck(unsigned char state, UI_Learner_Info learnerInfo);

    void onTrainSubjectBtnClicked();

    void onTrainSubjectChanged(int index, QString value);
};

#endif // LEARNERLOGININFOFORM_H
