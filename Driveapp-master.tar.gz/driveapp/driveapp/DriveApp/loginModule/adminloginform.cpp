#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QFrame>
#include <QGridLayout>
#include "adminloginform.h"
#include "trainloginform.h"
#include "widgetcollector.h"
#include "settingmgrform.h"

AdminLoginForm::AdminLoginForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_versionDlg(NULL),
    m_pointDlg(NULL)
{
    this->setObjectName(QString("adminLoginForm"));
    drawUI();

    initConnect();
}

AdminLoginForm::~AdminLoginForm()
{

}

wis_u16 AdminLoginForm::type()
{
    return WIS_UI_ENUM::ADMIN_LOGIN_FORM;
}

void AdminLoginForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void AdminLoginForm::updateContent()
{

}

void AdminLoginForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
     baseVbLayout->setContentsMargins(0,25,0,30);
     baseVbLayout->setSpacing(30);

    QHBoxLayout *titleLayout = new QHBoxLayout();
    QToolButton *imgBtn = new QToolButton(this);
    imgBtn->setObjectName("imgBtn");
    imgBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/admin_icon.png"));

    QLabel *titleLb = new QLabel(tr("管理员登入"),this);
    titleLb->setContentsMargins(0,0,0,0);
    titleLb->setStyleSheet(QString("text-align:left;margin-left:38px;font-size:46px;color:#ffffff;"));
    titleLayout->addStretch();
    titleLayout->addWidget(imgBtn);
    titleLayout->addWidget(titleLb);
    titleLayout->addStretch();
    titleLayout->setContentsMargins(0,0,0,0);

    baseVbLayout->addLayout(titleLayout);

    QFrame *inputFrame = new QFrame(this);
    inputFrame->setObjectName(QString("inputFrame"));
    inputFrame->setStyleSheet(QString("background-color:#ffffff;min-width"));
    QGridLayout *inputFrameLayout = new QGridLayout(inputFrame);
    inputFrameLayout->setContentsMargins(30,0,30,0);
    inputFrameLayout->setHorizontalSpacing(15);
    QLabel *lb = new QLabel(this);
    QPixmap userPixmap;
    userPixmap.load(":/login_module_img/resource/image/loginModuleImg/user.png");
    lb->setPixmap(userPixmap);
    inputFrameLayout->addWidget(lb, 0,0,1,1);
    lb = new QLabel(tr("用户"),this);
    lb->setStyleSheet("text-align:center;font-size:22px;color:#666666;");
    inputFrameLayout->addWidget(lb, 0, 1, 1, 1);
    m_userInputLe = new QLineEdit(this);
//    m_userInputLe->setReadOnly(true);
    m_userInputLe->setStyleSheet("border:none;font-size:22px;color:#666666;");
    m_userInputLe->setPlaceholderText(tr("请填写账号"));
    inputFrameLayout->addWidget(m_userInputLe,0,2,1,1);

    lb = new QLabel(tr(""),this);
    lb->setStyleSheet("min-height:1px;max-height:1px; border:none; background-color: #d9d2e9;");
    inputFrameLayout->addWidget(lb, 1, 0, 1, 3);

    lb = new QLabel(this);
    QPixmap passwdPixmap;
    passwdPixmap.load(":/login_module_img/resource/image/loginModuleImg/passwd.png");
    lb->setPixmap(passwdPixmap);
    inputFrameLayout->addWidget(lb, 2, 0, 1, 1);
    lb = new QLabel(tr("密码"),this);
    lb->setStyleSheet("text-align:center;font-size:22px;color:#666666;");
    inputFrameLayout->addWidget(lb, 2, 1, 1, 1);
    m_passwdInputLe = new QLineEdit(this);
//    m_passwdInputLe->setReadOnly(true);
    m_passwdInputLe->setStyleSheet("border:none;font-size:22px;color:#666666;");
    m_passwdInputLe->setPlaceholderText(tr("请填写密码"));
    inputFrameLayout->addWidget(m_passwdInputLe, 2, 2, 1, 1);
    baseVbLayout->addStretch();
    baseVbLayout->addWidget(inputFrame);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_ensureBtn = new QPushButton(tr("确认"),this);
    m_ensureBtn->setObjectName(QString("ensureBtn"));
    m_backBtn = new QPushButton(tr("返回"),this);
    m_backBtn->setObjectName(QString("backBtn"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_ensureBtn);
    bottomBtnLayout->addWidget(m_backBtn);
    bottomBtnLayout->addStretch();

    baseVbLayout->addLayout(bottomBtnLayout);
    baseVbLayout->setAlignment(inputFrame,Qt::AlignHCenter);

    QHBoxLayout *bottomHbLayout = new QHBoxLayout();
    bottomHbLayout->setContentsMargins(0,20,0,0);
    m_pointBtn = new QToolButton(this);
    m_pointBtn->setObjectName(QString("pointBtn"));
    m_pointBtn->setIcon(QIcon(":/resource/image/point.png"));
    bottomHbLayout->addWidget(m_pointBtn);
    bottomHbLayout->addStretch();

    m_homeBtn = new QToolButton(this);
    m_homeBtn->setObjectName(QString("homeBtn"));
    m_homeBtn->setIcon(QIcon(":/resource/image/version.png"));
    bottomHbLayout->addWidget(m_homeBtn);
    bottomHbLayout->setAlignment(m_homeBtn, Qt::AlignRight);
    baseVbLayout->addLayout(bottomHbLayout);
}

void AdminLoginForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void AdminLoginForm::showSettingForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_MGR_FORM);
    SettingMgrForm *setForm = NULL;
    if(!bw){
        setForm = new SettingMgrForm();
        setForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_MGR_FORM,setForm);
        m_mainStackWidget->addWidget(setForm);

    }else{
        setForm = static_cast<SettingMgrForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(setForm);
    setForm->updateContent();
}

void AdminLoginForm::initConnect()
{
    connect(m_backBtn, SIGNAL(clicked(bool)), this, SLOT(onBackBtnClicked(bool)));
    connect(m_ensureBtn, SIGNAL(clicked(bool)), this, SLOT(onEnsureBtnClicked(bool)));
    connect(m_homeBtn, SIGNAL(clicked(bool)), this, SLOT(VersionShow()));
    connect(m_pointBtn, SIGNAL(clicked(bool)), this, SLOT(PointShow()));

}

void AdminLoginForm::PointShow()
{
    if(m_pointDlg == NULL)
    {
        m_pointDlg = new ConfirmMessageDialog;
        m_pointDlg->setTest(tr("是否进行校准!!!"));
        connect(m_pointDlg, SIGNAL(sigOk()), this, SLOT(RunPointShow()));
        connect(m_pointDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished()));
    }
//#ifdef nuc970_4_8
    m_pointDlg->showFullScreen();
//#else
//    this->setMaximumSize(800,480);
//    this->resize(800,480);
//#endif
}

void AdminLoginForm::RunPointShow()
{
    system("killall update");
    usleep(500000);
    system("/usr/local/tslib/bin/ts_calibrate");
    usleep(100000);
    system("killall DriveApp");
}

void AdminLoginForm::VersionShow()
{
    if(m_versionDlg == NULL){
        m_versionDlg = new ConfirmMessageDialog;
        m_versionDlg->setTest(tr("固件版本：1.7.5 \nMCU版本：1.0.0"));
        m_versionDlg->m_cancelBtn->setVisible(false);
        m_versionDlg->m_okBtn->setVisible(false);
        connect(m_versionDlg, SIGNAL(sigOk()), this, SLOT(onConfirmDlgFinished()));
        connect(m_versionDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished()));
    }
//#ifdef nuc970_4_8
    m_versionDlg->showFullScreen();
//#else
//    this->setMaximumSize(800,480);
//    this->resize(800,480);
//#endif
}

void AdminLoginForm::onConfirmDlgFinished()
{
    m_versionDlg = NULL;
    m_pointDlg = NULL;
}
void AdminLoginForm::onBackBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showTrainLoginForm();
}

void AdminLoginForm::onEnsureBtnClicked(bool clicked)
{
    QString a;
    QString b;
     a = m_userInputLe->text();
     b = m_passwdInputLe->text();
     qDebug("%s", qPrintable( a ) );
     qDebug("%s", qPrintable( b ) );
//     if((a=="root")&&(b=="1234"))
//     {
//         Q_UNUSED(clicked)
         showSettingForm();
//     }
}

