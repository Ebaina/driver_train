#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include "learnerloginsuccessform.h"
#include "trainloginform.h"
#include "widgetcollector.h"
#include "QTimer"

LearnerLoginSuccessForm::LearnerLoginSuccessForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_autoJumpFlag(true)
{
    this->setObjectName(QString("learnerLoginSuccessForm"));
    drawUI();

    initConnect();
}

LearnerLoginSuccessForm::~LearnerLoginSuccessForm()
{

}

wis_u16 LearnerLoginSuccessForm::type()
{
    return WIS_UI_ENUM::LEARNER_LOGIN_SUCCESS_HINT_FORM;
}

void LearnerLoginSuccessForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void LearnerLoginSuccessForm::updateContent()
{
    setAutoJumpFlag(true);
    QTimer::singleShot(5000, this, SLOT(onTimeout()));
}

void LearnerLoginSuccessForm::setLearnerInfo(const UI_Learner_Info &learnerInfo)
{
#ifdef  nuc970_4_8
    m_learnerNoLe->setText(QString((char*)learnerInfo.learnerid).left(16));
//    m_totalLearnTime->setText(QString::number(learnerInfo.maintraintime));
//    m_passedLearnTime->setText(QString::number(learnerInfo.finishtime));
    m_totalLearnMileage->setText(QString::number(learnerInfo.maintrainmile));
//    m_passedLearnMileageLe->setText(QString::number(learnerInfo.finishmile));
#else
    (void)learnerInfo;
#endif

}

bool LearnerLoginSuccessForm::autoJumpFlag() const
{
    return m_autoJumpFlag;
}

void LearnerLoginSuccessForm::setAutoJumpFlag(bool autoJumpFlag)
{
    m_autoJumpFlag = autoJumpFlag;
}

void LearnerLoginSuccessForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(20,25,20,30);
    baseVbLayout->setSpacing(30);

    QLabel *lb = new QLabel(tr("学员登录成功"),this);
    lb->setAlignment(Qt::AlignCenter);
    lb->setStyleSheet(QString("text-align:center;font-weight:bold;font-size:60px;color:#ffffff;"));

    baseVbLayout->addWidget(lb);

    QHBoxLayout *midLayout = new QHBoxLayout();
    midLayout->setContentsMargins(0,0,0,0);
    midLayout->setSpacing(20);
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName(QString("leftFrame"));
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    leftGridLayout->setContentsMargins(20,20,20,20);
    leftGridLayout->setHorizontalSpacing(15);
    leftGridLayout->setVerticalSpacing(20);
    lb = new QLabel(tr("学员编号"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_learnerNoLe = new QLineEdit(this);
    m_learnerNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    m_learnerNoLe->setReadOnly(true);
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_learnerNoLe,0, 1, 1, 1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb,1,0,1,2);

//    lb = new QLabel(tr("总培训学时"),this);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_totalLearnTime = new QLineEdit(this);
    m_totalLearnTime->setProperty("class",QVariant("rightContentLineEdit"));
    m_totalLearnTime->setReadOnly(true);
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_totalLearnTime);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb,3,0,1,2);

//    lb = new QLabel(tr("已完成学时"),this);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_passedLearnTime = new QLineEdit(this);
    m_passedLearnTime->setReadOnly(true);
    m_passedLearnTime->setProperty("class",QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb,4,0,1,1);
    leftGridLayout->addWidget(m_passedLearnTime,4,1,1,1);

    midLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName(QString("rightFrame"));
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    rightGridLayout->setContentsMargins(20,20,20,20);
    rightGridLayout->setHorizontalSpacing(15);
    rightGridLayout->setVerticalSpacing(20);
    lb = new QLabel(tr("总培训里程"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_totalLearnMileage = new QLineEdit(this);
    m_totalLearnMileage->setProperty("class",QVariant("rightContentLineEdit"));
    m_totalLearnMileage->setReadOnly(true);
    rightGridLayout->addWidget(lb,0,0,1,1);
    rightGridLayout->addWidget(m_totalLearnMileage,0,1,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb,1,0,1,2);

//    lb = new QLabel(tr("已完成里程"),this);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_passedLearnMileageLe = new QLineEdit(this);
    m_passedLearnMileageLe->setProperty("class",QVariant("rightContentLineEdit"));
    m_passedLearnMileageLe->setReadOnly(true);
    rightGridLayout->addWidget(lb, 2,0,1,1);
    rightGridLayout->addWidget(m_passedLearnMileageLe,2,1,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb,3,0,1,2);

    QLineEdit *leEmpty = new QLineEdit(this);
    leEmpty->setProperty("class",QVariant("rightContentLineEdit"));
    leEmpty->setReadOnly(true);
    rightGridLayout->addWidget(leEmpty,4,0,1,2);

    midLayout->addWidget(rightFrame);

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(midLayout);
    baseVbLayout->addStretch();


    m_ensureBtn  = new QPushButton(tr("确认"),this);
    m_ensureBtn->setObjectName(QString("ensureBtn"));
    m_ensureBtn->setVisible(false);
    baseVbLayout->addWidget(m_ensureBtn);
    baseVbLayout->setAlignment(m_ensureBtn, Qt::AlignHCenter);
}

void LearnerLoginSuccessForm::initConnect()
{
    connect(m_ensureBtn, SIGNAL(clicked(bool)), this, SLOT(onEnsureBtnClicked(bool)));
}

void LearnerLoginSuccessForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void LearnerLoginSuccessForm::onEnsureBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    setAutoJumpFlag(false);
    showTrainLoginForm();
}

void LearnerLoginSuccessForm::onTimeout()
{
    if(autoJumpFlag() == false)
            return;
        showTrainLoginForm();
}

