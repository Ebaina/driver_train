#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include <QTimer>
#include "learnerlogininfoform.h"
#include "textlistview.h"
#include "learnerloginsuccessform.h"
#include "widgetcollector.h"
#include "commondatamgr.h"
#include "loginhintform.h"
#include "handlermanager.h"

LearnerLoginInfoForm::LearnerLoginInfoForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_paperTypeListView(NULL),
    m_subjectListView(NULL),
    m_fingerVerified(false)
{
    this->setObjectName(QString("learnerLoginInfoForm"));

    drawUI();

    initConnect();

    initData();
}

LearnerLoginInfoForm::~LearnerLoginInfoForm()
{
    if(m_paperTypeListView != NULL){
        delete m_paperTypeListView;
        m_paperTypeListView = NULL;
    }
    if(m_subjectListView != NULL){
        delete m_subjectListView;
        m_subjectListView = NULL;
    }
}

wis_u16 LearnerLoginInfoForm::type()
{
    return WIS_UI_ENUM::LEARNER_LOGIN_INFO_FORM;
}

void LearnerLoginInfoForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void LearnerLoginInfoForm::updateContent()
{
#ifndef nuc970_4_8
    QTimer::singleShot(8000, this, SLOT(onFingerVerifyTimeout()));
#endif
}

void LearnerLoginInfoForm::setLearnerInfo(UI_LearnerLogin_Up learnerInfo)
{
    m_learnerNoLe->setText(QString((char*)learnerInfo.learnerid).left(16));
    m_paperTypeBtn->setText(CommonDataMgr::getCardTypeValue(learnerInfo.cardtype));
    m_paperIDLe->setText(QString((char*)learnerInfo.learnerdentityid).left(16));
    m_curCoachNoLe->setText(QString((char*)learnerInfo.coachid).left(16));
//    m_driveCarTypeBtn->setText(CommonDataMgr::getCarTypeValue(learnerInfo.trancar_type));
    m_driveCarTypeBtn->setText(QString((char*)learnerInfo.trancar_type).left(2));    
    m_trainSubjectBtn->setWhatsThis(QString::number(learnerInfo.subjectId, 10));
    m_trainSubjectBtn->setText(m_subjectMap.value(learnerInfo.subjectId));   
}

void LearnerLoginInfoForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(20,25,20,30);
    baseVbLayout->setSpacing(30);

    QHBoxLayout *titleLayout = new QHBoxLayout();
    QToolButton *imgBtn = new QToolButton(this);
    imgBtn->setObjectName(QString("imgBtn"));
    imgBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/learner_icon.png"));
    QLabel *lb = new QLabel(tr("学员登录"),this);
    lb->setContentsMargins(0,0,0,0);
    lb->setStyleSheet(QString("text-align:left;margin-left:38px;font-size:46px;color:#ffffff;"));
    titleLayout->addStretch();
    titleLayout->addWidget(imgBtn);
    titleLayout->addWidget(lb);
    titleLayout->addStretch();
    titleLayout->setContentsMargins(0,0,0,0);
    titleLayout->setSpacing(0);

    baseVbLayout->addLayout(titleLayout);

    QHBoxLayout *midLayout = new QHBoxLayout();
    midLayout->setContentsMargins(0,0,0,0);
    midLayout->setSpacing(20);
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName(QString("leftFrame"));
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    leftGridLayout->setContentsMargins(20,20,20,20);
    leftGridLayout->setHorizontalSpacing(15);
    leftGridLayout->setVerticalSpacing(20);
    lb = new QLabel(tr("学员编号"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_learnerNoLe = new QLineEdit(this);
    m_learnerNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    m_learnerNoLe->setReadOnly(true);
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_learnerNoLe,0, 1, 1, 1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb,1,0,1,2);

    lb = new QLabel(tr("学员证件类型"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_paperTypeBtn = new QPushButton(this);
    m_paperTypeBtn->setProperty("class",QVariant("showTextBtn"));
//    m_paperTypeBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/down.png"));
    m_paperTypeBtn->setLayoutDirection(Qt::RightToLeft);
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_paperTypeBtn);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb,3,0,1,2);

    lb = new QLabel(tr("学员证件号"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_paperIDLe = new QLineEdit(this);
    m_paperIDLe->setProperty("class",QVariant("rightContentLineEdit"));
    m_paperIDLe->setReadOnly(true);
    leftGridLayout->addWidget(lb,4,0,1,1);
    leftGridLayout->addWidget(m_paperIDLe,4,1,1,1);

    midLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName(QString("rightFrame"));
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    rightGridLayout->setContentsMargins(20,20,20,20);
    rightGridLayout->setHorizontalSpacing(15);
    rightGridLayout->setVerticalSpacing(20);
    lb = new QLabel(tr("培训车型"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_driveCarTypeBtn = new QPushButton(this);
    m_driveCarTypeBtn->setProperty("class",QVariant("showTextBtn"));
//    m_driveCarTypeBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/down.png"));
    m_driveCarTypeBtn->setLayoutDirection(Qt::RightToLeft);
    rightGridLayout->addWidget(lb,0,0,1,1);
    rightGridLayout->addWidget(m_driveCarTypeBtn,0,1,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb,1,0,1,2);

    lb = new QLabel(tr("当前教练编号"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_curCoachNoLe = new QLineEdit(this);
    m_curCoachNoLe->setReadOnly(true);
    m_curCoachNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2,0,1,1);
    rightGridLayout->addWidget(m_curCoachNoLe,2,1,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb,3,0,1,2);

    lb = new QLabel(tr("培训课程"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_trainSubjectBtn = new QPushButton(this);
    m_trainSubjectBtn->setProperty("class",QVariant("showTextBtn"));
    m_trainSubjectBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/down.png"));
    m_trainSubjectBtn->setLayoutDirection(Qt::RightToLeft);
    rightGridLayout->addWidget(lb,4,0,1,1);
    rightGridLayout->addWidget(m_trainSubjectBtn,4,1,1,1);

    midLayout->addWidget(rightFrame);

    baseVbLayout->addLayout(midLayout);
    baseVbLayout->addStretch();

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_homeBtn = new QToolButton(this);
    m_homeBtn->setObjectName(QString("homeBtn"));
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home_white.png"));
//    m_homeBtn->setVisible(false);
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_homeBtn);

    baseVbLayout->addLayout(bottomBtnLayout);

}

void LearnerLoginInfoForm::initData()
{
    m_subjectMap.insert(UI_HEADER::TSI_11, tr("基础驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_12, tr("场地驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_13, tr("综合驾驶及考核"));
    m_subjectMap.insert(UI_HEADER::TSI_21, tr("跟车行驶"));
    m_subjectMap.insert(UI_HEADER::TSI_22, tr("变更车道"));
    m_subjectMap.insert(UI_HEADER::TSI_23, tr("靠边停车"));
    m_subjectMap.insert(UI_HEADER::TSI_24, tr("掉头"));
    m_subjectMap.insert(UI_HEADER::TSI_25, tr("通过路口"));
    m_subjectMap.insert(UI_HEADER::TSI_26, tr("通过人行横道"));
    m_subjectMap.insert(UI_HEADER::TSI_27, tr("通过学校区域"));
    m_subjectMap.insert(UI_HEADER::TSI_28, tr("通过公共汽车站"));
    m_subjectMap.insert(UI_HEADER::TSI_29, tr("会车"));
    m_subjectMap.insert(UI_HEADER::TSI_30, tr("超车"));
    m_subjectMap.insert(UI_HEADER::TSI_31, tr("夜间驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_32, tr("恶劣条件下的驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_33, tr("山区道路驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_34, tr("高速公路驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_35, tr("行驶路线选择"));
}

void LearnerLoginInfoForm::initConnect()
{
    connect(m_paperTypeBtn,SIGNAL(clicked(bool)),this,SLOT(onPaperTypeBtnClicked(bool)));
    connect(HandlerManager::instance()->getLoginHandler(), SIGNAL(sigLearnerFingerAck(unsigned char,UI_Learner_Info)), this, SLOT(onFingerPrintAck(unsigned char,UI_Learner_Info)));
    connect(m_trainSubjectBtn, SIGNAL(clicked()), this, SLOT(onTrainSubjectBtnClicked()));
    /*********ui  page -------**************/
    connect(m_homeBtn,SIGNAL(clicked()),this,SLOT(onFingerVerifyTimeout()));
}

void LearnerLoginInfoForm::showLoginSuccessForm(UI_Learner_Info &learnerInfo)
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::LEARNER_LOGIN_SUCCESS_HINT_FORM);
    LearnerLoginSuccessForm *successForm = NULL;
    if(!bw){
        successForm = new LearnerLoginSuccessForm();
        successForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::LEARNER_LOGIN_SUCCESS_HINT_FORM,successForm);
        m_mainStackWidget->addWidget(successForm);

    }else{
        successForm = static_cast<LearnerLoginSuccessForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(successForm);
    successForm->setLearnerInfo(learnerInfo);
    successForm->updateContent();
}

void LearnerLoginInfoForm::showLoginFailedForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::LEARNER_LOGIN_FAILED_HINT_FORM);
    LoginHintForm *failedForm = NULL;
    if(!bw){
        failedForm = new LoginHintForm(WIS_UI_ENUM::LEARNER_LOGIN_FAILED_HINT_FORM);
        failedForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::LEARNER_LOGIN_FAILED_HINT_FORM,failedForm);
        m_mainStackWidget->addWidget(failedForm);

    }else{
        failedForm = static_cast<LoginHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(failedForm);
    failedForm->updateContent();
}

void LearnerLoginInfoForm::onPaperTypeBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    if(m_paperTypeListView == NULL){
        m_paperTypeListView = new TextListView;
        m_paperTypeListView->setObjectName(QString("paperTypeListView"));
        connect(m_paperTypeListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onPaperTypeListViewClicked(int,QString)));
    }

    QStringList typeList;
    typeList << "身份证" ;                    //<< "学员证";
    m_paperTypeListView->setTextModel(typeList);
    m_paperTypeListView->showView();
}

void LearnerLoginInfoForm::onPaperTypeListViewClicked(int index, QString value)
{
    if(index == m_paperTypeBtn->whatsThis().toInt())
        return;
    m_paperTypeBtn->setText(value);
    m_paperTypeBtn->setWhatsThis(QString::number(index));
}

void LearnerLoginInfoForm::onFingerVerifyTimeout()
{
    UI_Learner_Info info;
    memset((char*)&info, 0, sizeof(UI_Learner_Info));
    //show learner login failed form
    showLoginSuccessForm(info);

}

void LearnerLoginInfoForm::onFingerPrintAck(unsigned char state, UI_Learner_Info learnerInfo)
{
    UI_Learner_Info lInfo = learnerInfo;
    if(state == UI_HEADER::FP_SUCCESS){
        showLoginSuccessForm(lInfo);
    }else if(UI_HEADER::FP_FALURE == state){
         showLoginFailedForm();
    }else{
         showLoginFailedForm();
    }
}

void LearnerLoginInfoForm::onTrainSubjectBtnClicked()
{
    if(m_subjectListView == NULL){
        m_subjectListView = new TextListView;
        m_subjectListView->setObjectName(QString("subjectChooseListView"));
        connect(m_subjectListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onTrainSubjectChanged(int,QString)));
    }

    m_subjectListView->setTextModel(m_subjectMap);
    m_subjectListView->showView();
}

void LearnerLoginInfoForm::onTrainSubjectChanged(int index, QString value)
{
    m_trainSubjectBtn->setText(value);
    m_trainSubjectBtn->setWhatsThis(QString::number(index, 10));
    subID = index;
    HandlerManager::instance()->getLoginHandler()->setSubjectID((int)subID);
}

