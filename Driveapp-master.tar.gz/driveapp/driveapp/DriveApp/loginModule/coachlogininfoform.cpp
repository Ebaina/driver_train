#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QTimer>
#include "coachlogininfoform.h"
#include "handlermanager.h"
#include "widgetcollector.h"
#include "trainloginform.h"
#include "loginhintform.h"


CoachLoginInfoForm::CoachLoginInfoForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_fingerVerified(false)
{
    this->setObjectName(QString("coachLoginInfoForm"));
    drawUI();

    initConnect();

}

wis_u16 CoachLoginInfoForm::type()
{
    return WIS_UI_ENUM::COACH_LOGIN_INFO_FORM;
}

void CoachLoginInfoForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void CoachLoginInfoForm::updateContent()
{
#ifndef nuc970_4_8
    QTimer::singleShot(8000,this,SLOT(onFingerTimeout()));
#endif
}

void CoachLoginInfoForm::setCoachInfo(const UI_CoachLogin_Up &coachInfo)
{
    m_coachNoLe->setText(QString((char*)coachInfo.coachid).left(16));
    m_coachIDCardLe->setText(QString((char*)coachInfo.coachdentityid).left(18));
    m_driveCarType->setText(QString((char*)coachInfo.traincartype).left(2));
}

void CoachLoginInfoForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0,25,0,30);
    baseVbLayout->setSpacing(30);

    QHBoxLayout *titleLayout = new QHBoxLayout();
    QToolButton *imgBtn = new QToolButton(this);
    imgBtn->setObjectName(QString("imgBtn"));
    imgBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/coach_icon.png"));
    QLabel *lb = new QLabel(tr("教练登录"),this);
    lb->setContentsMargins(0,0,0,0);
    lb->setStyleSheet(QString("text-align:left;margin-left:38px;font-size:46px;color:#ffffff;"));
    titleLayout->addStretch();
    titleLayout->addWidget(imgBtn);
    titleLayout->addWidget(lb);
    titleLayout->addStretch();
    titleLayout->setContentsMargins(0,0,0,0);


    baseVbLayout->addLayout(titleLayout);

    QFrame *coachInfoFrame = new QFrame(this);
    coachInfoFrame->setObjectName(QString("coachInfoFrame"));
    QGridLayout *frameLayout = new QGridLayout(coachInfoFrame);
    lb = new QLabel(tr("教练员编号"),this);
    lb->setStyleSheet(QString("text-align:left;font-size:18px;color:#666666"));
    m_coachNoLe = new QLineEdit(this);
    m_coachNoLe->setReadOnly(true);
    m_coachNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    frameLayout->addWidget(lb, 0, 0, 1,1);
    frameLayout->addWidget(m_coachNoLe, 0, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    frameLayout->addWidget(lb,1,0,1,2);

    lb = new QLabel(tr("教练员身份证号"),this);
    lb->setStyleSheet(QString("text-align:left;font-size:18px;color:#666666"));
    m_coachIDCardLe = new QLineEdit(this);
    m_coachIDCardLe->setReadOnly(true);
    m_coachIDCardLe->setProperty("class",QVariant("rightContentLineEdit"));
    frameLayout->addWidget(lb,2,0,1,1);
    frameLayout->addWidget(m_coachIDCardLe,2,1,1,1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    frameLayout->addWidget(lb,3,0,1,2);

    lb = new QLabel(tr("准驾车型"),this);
    lb->setStyleSheet(QString("text-align:left;font-size:18px;color:#666666"));
    m_driveCarType = new QLineEdit(this);
    m_driveCarType->setReadOnly(true);
    m_driveCarType->setProperty("class",QVariant("rightContentLineEdit"));
    frameLayout->addWidget(lb,4,0,1,1);
    frameLayout->addWidget(m_driveCarType,4,1,1,1);

//    baseVbLayout->addStretch();
    baseVbLayout->addWidget(coachInfoFrame);
    baseVbLayout->setAlignment(coachInfoFrame,Qt::AlignHCenter);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout();
    m_homeBtn = new QToolButton(this);
    m_homeBtn->setObjectName(QString("homeBtn"));
//    m_homeBtn->setVisible(false);
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home.png"));
    bottomBtnLayout->addStretch();

    bottomBtnLayout->addWidget(m_homeBtn);

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(bottomBtnLayout);
}

void CoachLoginInfoForm::initConnect()
{
    connect(HandlerManager::instance()->getLoginHandler(), SIGNAL(sigCoachFingerAck(unsigned char)), this, SLOT(onUpdateCoachFingerAck(unsigned char)));

    /*********ui  page -------**************/
    connect(m_homeBtn,SIGNAL(clicked()),this,SLOT(ontmpshowForm()));
}

void CoachLoginInfoForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void CoachLoginInfoForm::showLoginRetHintForm(wis_u16 type)
{
    BaseWidget *bw = WidgetCollector::getWidget(type);
    LoginHintForm *hintForm = NULL;
    if(!bw){
        hintForm = new LoginHintForm(type);
        hintForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(type,hintForm);
        m_mainStackWidget->addWidget(hintForm);

    }else{
        hintForm = static_cast<LoginHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(hintForm);
    hintForm->updateContent();
}

void CoachLoginInfoForm::onFingerTimeout()
{
    if(!m_fingerVerified){               //jump to login form intime
        showLoginRetHintForm(WIS_UI_ENUM::COACH_LOGIN_FAILED_HINT_FORM);
    }
}

void CoachLoginInfoForm::onUpdateCoachFingerAck(unsigned char state)
{
    switch(state){
    case UI_HEADER::FP_FALURE:
    {
        showLoginRetHintForm(WIS_UI_ENUM::COACH_LOGIN_FAILED_HINT_FORM);
    }
        break;
    case UI_HEADER::FP_SUCCESS:
    {
        showLoginRetHintForm(WIS_UI_ENUM::COACH_LOGIN_SUCCESS_HINT_FORM);
    }
        break;
    case UI_HEADER::FP_TIMEOUT:
    {
         showLoginRetHintForm(WIS_UI_ENUM::COACH_LOGIN_FAILED_HINT_FORM);
    }
        break;
    default:
        break;
    }
}

void CoachLoginInfoForm::ontmpshowForm()
{
    showLoginRetHintForm(WIS_UI_ENUM::COACH_LOGIN_SUCCESS_HINT_FORM);
}

