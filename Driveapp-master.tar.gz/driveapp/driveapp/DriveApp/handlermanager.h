﻿#ifndef HANDLERMANAGER_H
#define HANDLERMANAGER_H

#include <QObject>
#include "settingModule/handler/settinghandler.h"
#include "loginModule/handler/loginhandler.h"
#include "displayModule/handler/displayhandler.h"
#include "payModule/handler/payhandler.h"
#include "statusreporthandler.h"
#include "ui_interface.h"

extern int subID ;

class HandlerManager    : public QObject
{
public:
    static HandlerManager* instance();
    SettingHandler* getSettingHandler();

    LoginHandler* getLoginHandler();

    StatusReportHandler* getStatusReportHandler();

    DisplayHandler* getDisplayHandler();

    PayHandler *getPayHandler();
#ifdef nuc970_4_8
    Ui_Interface* getFuncInterface();
#endif
private:
    SettingHandler *m_settingHandler;
    LoginHandler *m_loginHandler;
    StatusReportHandler *m_statusReportHandler;
    DisplayHandler *m_displayHandler;
    PayHandler *m_payHandler;
#ifdef nuc970_4_8
    Ui_Interface *m_funcInterface;
#endif

private:
    HandlerManager(QObject *parent = 0);
    HandlerManager(const HandlerManager &);
    HandlerManager & operator=  (const HandlerManager &);
    ~HandlerManager();
};

#endif // HANDLERMANAGER_H

