﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QToolButton>
#include <QStackedWidget>
#include <QLabel>
#include <QTimer>

const int STATUSBTN_SIZE = 44;

class MainForm : public QWidget
{
    Q_OBJECT

public:
    MainForm(QWidget *parent = 0);
    ~MainForm();

private:
    /**绘制界面*/
    void initSize();
    void drawUI();
    void initConnect();
private:
    QToolButton *m_tbUrgentAlert;             //紧急报警
    QToolButton *m_tbSpeedAlert;              //超速报警
    QToolButton *m_tbTiredDrive;               //疲劳驾驶
    QToolButton *m_tbGNSS;                       //GNSS故障
    QToolButton *m_tbPower;                     //电源故障
    QToolButton *m_tbTTS;                          // TTS故障
    QToolButton *m_tbCar;                          //车辆故障
    QToolButton *m_tbCamera;                  //摄像故障
    QToolButton *m_tbPlate;                      //平台故障
    QToolButton *m_tbNet;                      //网络故障
    QToolButton *m_tbUpdate;                      //程序升级
    QToolButton *m_tbGPS;                        //GPS
    QToolButton *m_tbMobile;                   //34G信号
    QLabel *m_lbTime;
    QStackedWidget *m_mainStackWidget;
    /******/
    QTimer *m_clockTimer;

private:
    /**
  *@brief  the mainStackWidget show first widget
 */
    void showFirstForm();
    /**
  *@brief       is registered or not
  *@return    true: registered      false: not registered
  */
    bool isRegistered();

    int pageflag();

    void showRegForm();

    void showTrainLoginForm();

    void showDisplayForm();

    void showCoachLoginForm();

private slots:
    void onTimeSlot();

    void onUpdateLocatedState(unsigned char state);

    void onUpdateMobileSignal(unsigned char state);

    void onUpdateUrgentAlertState(unsigned char state);

    void onUpdateSpeedAlertState(unsigned char state);

    void onUpdateTiredDriveState(unsigned char state);

    void onUpdateGNSSFaultState(unsigned char state);

    void onUpdatePowerFaultState(unsigned char state);

    void onUpdateTTSFaultState(unsigned char state);

    void onUpdateCarFaultState(unsigned char state);

    void onUpdateNetState(unsigned char state);

    void onUpdateNetToPlateState(unsigned char state);

    void onUpdateCameraFaultState(unsigned char state);

    void onUpdateVersionState(unsigned char state);
};

#endif // WIDGET_H
