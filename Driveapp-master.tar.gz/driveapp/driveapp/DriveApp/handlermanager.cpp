﻿#include "handlermanager.h"

int subID = 11;

HandlerManager *HandlerManager::instance()
{
    static HandlerManager handlerManager;
    return &handlerManager;
}

SettingHandler *HandlerManager::getSettingHandler()
{
   if(m_settingHandler == NULL){
       m_settingHandler = new SettingHandler(this);
   }
   return m_settingHandler;
}

LoginHandler *HandlerManager::getLoginHandler()
{
    if(m_loginHandler == NULL){
        m_loginHandler = new LoginHandler(this);
    }
    return m_loginHandler;
}

StatusReportHandler *HandlerManager::getStatusReportHandler()
{
    if(m_statusReportHandler == NULL){
        m_statusReportHandler = new StatusReportHandler(this);
    }
    return m_statusReportHandler;
}

DisplayHandler *HandlerManager::getDisplayHandler()
{
    if(m_displayHandler == NULL){
        m_displayHandler = new DisplayHandler(this);
    }
    return m_displayHandler;
}

PayHandler *HandlerManager::getPayHandler()
{
    if(m_payHandler == NULL){
        m_payHandler = new PayHandler(this);
    }
    return m_payHandler;
}

#ifdef nuc970_4_8
Ui_Interface *HandlerManager::getFuncInterface()
{
    if(m_funcInterface == NULL)
        m_funcInterface = new Ui_Interface;

    return m_funcInterface;
}
#endif

HandlerManager::HandlerManager(QObject *parent) :
    QObject(parent)
{
    m_settingHandler = NULL;
    m_loginHandler = NULL;
    m_statusReportHandler = NULL;
    m_displayHandler = NULL;
    m_payHandler = NULL;
#ifdef nuc970_4_8
    m_funcInterface = NULL;
#endif
}

HandlerManager::~HandlerManager()
{
    if(m_settingHandler != NULL){
        delete m_settingHandler;
        m_settingHandler = NULL;
    }

    if(m_loginHandler != NULL){
        delete m_loginHandler;
        m_loginHandler = NULL;
    }

    if(m_statusReportHandler != NULL){
        delete m_statusReportHandler;
        m_statusReportHandler = NULL;
    }

    if(m_displayHandler != NULL){
        delete m_displayHandler;
        m_displayHandler = NULL;
    }

    if(m_payHandler != NULL){
        delete m_payHandler;
        m_payHandler = NULL;
    }

#ifdef nuc970_4_8
    if(m_funcInterface != NULL){
        delete m_funcInterface;
        m_funcInterface = NULL;
    }
#endif
}
