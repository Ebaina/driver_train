﻿#include <QStyleOption>
#include <QPainter>
#include <QVBoxLayout>
#include <QFrame>
#include <QGridLayout>
#include <QLabel>
#include <QDebug>
#include "poscardpaydlg.h"
#include "handlermanager.h"

#ifdef WIS_DEBUG
#include <QTimer>
#endif

PosCardPayDlg::PosCardPayDlg(QWidget *parent) :
    QDialog(parent)
{
    this->setWindowFlags(Qt::FramelessWindowHint);

    this->setAttribute(Qt::WA_TranslucentBackground,true);

    drawUI();

    connect(HandlerManager::instance()->getPayHandler(), SIGNAL(sigPosCardPayAck(unsigned char)), this, SLOT(onCardPayAck(unsigned char)));
}

void PosCardPayDlg::updateContent()
{
    //这里请求开启刷卡支付
    if(!HandlerManager::instance()->getPayHandler()->requestPoscardPay()){
        qDebug() << "request poscard pay failed";
    }

#ifdef WIS_DEBUG
//    QTimer::singleShot(3000, this, SLOT(testSigPayRet()));
#endif
}

void PosCardPayDlg::paintEvent(QPaintEvent *)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);

    p.fillRect(this->rect(),QColor(0,0,0,80));
}

void PosCardPayDlg::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    QFrame *centerFrame = new QFrame(this);
    centerFrame->setObjectName("centerFrame");
    QVBoxLayout *frameLayout = new QVBoxLayout(centerFrame);
    frameLayout->setContentsMargins(0,20,0,20);
    QLabel *lb = new QLabel(tr("请刷卡进行学费支付"));
    lb->setAlignment(Qt::AlignCenter);
    lb->setStyleSheet(QString("font-size:24px; font-weight: bold; color: #000000; text-align: center;"));
    m_cancelBtn = new QPushButton(tr("取消"));
    m_cancelBtn->setObjectName("cancelBtn");
    frameLayout->addStretch();
    frameLayout->addWidget(lb);
    frameLayout->addStretch();
    frameLayout->addWidget(m_cancelBtn);
    frameLayout->setAlignment(m_cancelBtn, Qt::AlignHCenter);
    baseVbLayout->addStretch();
    baseVbLayout->addWidget(centerFrame);
    baseVbLayout->addStretch();
    baseVbLayout->setAlignment(centerFrame, Qt::AlignHCenter);

    connect(m_cancelBtn, SIGNAL(clicked()), this, SLOT(onCancelBtnClicked()));

}

void PosCardPayDlg::onCancelBtnClicked()
{
    if(!HandlerManager::instance()->getPayHandler()->requestCancelPoscardPay()){
        qDebug() << "request cancel_poscard failed";
        return;
    }
    this->close();
}

void PosCardPayDlg::onCardPayAck(unsigned char ack)
{
    switch(ack){
    case UI_HEADER::PCP_TIMEOUUT:{
        this->close();
    }
        break;
    case UI_HEADER::PCP_FAILED:{
        this->close();
    }
    break;
    case UI_HEADER::PCP_SUCCESS:{
        this->close();
        emit sigPayRet(true);
    }
        break;
    default:
        break;

    }
}

void PosCardPayDlg::testSigPayRet()
{
    this->close();
    emit sigPayRet(true);
}

