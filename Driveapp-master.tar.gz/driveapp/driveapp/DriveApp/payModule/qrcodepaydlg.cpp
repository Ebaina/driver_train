﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QDebug>
#include <QStyleOption>
#include <QPainter>
#include "qrcodepaydlg.h"
#include "handlermanager.h"

QRCodePayDlg::QRCodePayDlg(QWidget *parent) :
    QDialog(parent)
{
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground,true);
    this->setAttribute(Qt::WA_DeleteOnClose,true);

}

QRCodePayDlg::~QRCodePayDlg()
{

}

void QRCodePayDlg::updateContent()
{
    drawUI();
}

void QRCodePayDlg::paintEvent(QPaintEvent *)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);

    p.fillRect(this->rect(),QColor(0,0,0,80));
}

void QRCodePayDlg::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setSpacing(40);

    QPixmap qrpayPix;
    qrpayPix.load("post.jpg");   //   :/resource/image/kedu.jpg
    m_qrCodeLb = new QLabel(this);
    m_qrCodeLb->setPixmap(qrpayPix);
    m_qrCodeLb->setAlignment(Qt::AlignCenter);
    baseVbLayout->addStretch();
    baseVbLayout->addWidget(m_qrCodeLb);

    m_okBtn = new QPushButton(tr("确认"), this);
    m_okBtn->setObjectName(QString("okBtn"));
    QHBoxLayout *btnLayout = new QHBoxLayout;
    btnLayout->setSpacing(10);
    btnLayout->addStretch();
    btnLayout->addWidget(m_okBtn);
    m_cancelBtn = new QPushButton(tr("返回"), this);
    m_cancelBtn->setObjectName(QString("cancelBtn"));
    btnLayout->addWidget(m_cancelBtn);
    btnLayout->addStretch();

    baseVbLayout->addLayout(btnLayout);
    baseVbLayout->addStretch();

    connect(m_okBtn, SIGNAL(clicked()), this, SLOT(onOkBtnClicked()));
    connect(m_cancelBtn, SIGNAL(clicked()), this, SLOT(onCancelBtnClicked()));
}

void QRCodePayDlg::onOkBtnClicked()
{
    emit sigOk();
    this->close();
}

void QRCodePayDlg::onCancelBtnClicked()
{
    emit sigCancel();
    this->close();
}



