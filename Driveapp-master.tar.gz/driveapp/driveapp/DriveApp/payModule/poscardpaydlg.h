﻿#ifndef POSCARDPAYDLG_H
#define POSCARDPAYDLG_H

#include <QDialog>
#include <QPaintEvent>
#include <QPushButton>

class PosCardPayDlg : public QDialog
{
    Q_OBJECT
public:
    explicit PosCardPayDlg(QWidget *parent = 0);

    void updateContent();

protected:
    void paintEvent(QPaintEvent *);

private:
    QPushButton *m_cancelBtn;
    void drawUI();

private slots:
    void onCancelBtnClicked();

    void onCardPayAck(unsigned char ack);

    //UI test
    void testSigPayRet();

signals:
    void sigPayRet(bool ret);
};

#endif // POSCARDPAYDLG_H
