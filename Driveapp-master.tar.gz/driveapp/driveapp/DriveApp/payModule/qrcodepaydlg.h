﻿#ifndef QRCODEPAYDLG_H
#define QRCODEPAYDLG_H

#include <QDialog>
#include <QWidget>
#include <QLabel>
#include <QPixmap>
#include <QImage>
#include <QPushButton>
#include <QPaintEvent>

class QRCodePayDlg : public QDialog
{
    Q_OBJECT
public:
    explicit QRCodePayDlg(QWidget *parent = 0);
    ~QRCodePayDlg();

    void updateContent();

    void drawUI();
protected:
    void paintEvent(QPaintEvent *);

private:
    //UI
    QLabel *m_qrCodeLb;
    QPushButton *m_cancelBtn;
    QPushButton *m_okBtn;


signals:
    void sigOk();
    void sigCancel();

private slots:

    void onCancelBtnClicked();

    void onOkBtnClicked();

};

#endif // QRCODEPAYDLG_H
