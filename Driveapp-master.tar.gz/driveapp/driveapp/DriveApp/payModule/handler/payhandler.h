﻿#ifndef PAYHANDLER_H
#define PAYHANDLER_H

#include <QObject>
#include "payinterface.h"


using namespace WIS_UI;

class Ui_Interface;
class PayHandler : public QObject , public PayInterface
{
    Q_OBJECT
public:
    explicit PayHandler(QObject *parent = 0);
    ~PayHandler();

    //callback
    void responseTrainTimeCost(UI_TrainTimeCost timeCost);

    void responsePoscardPayAck(unsigned char ack);

    void responseQRCodeData(const unsigned char * data, int size, const char * format = 0);

    void responseQRCodePayAck(unsigned char ack);

    //public ways
    bool requestTrainTimeCost();

    bool requestPoscardPay();

    bool requestCancelPoscardPay();

    UI_TrainTimeCost requestQRCodePay();

    bool requestCancelQRCodePay();

signals:
    void sigRespTrainTimeCost(UI_TrainTimeCost timeCost);

    void sigPosCardPayAck(unsigned char ack);

    void sigRespQRCodeData(const unsigned char * data, int size, const char * format);

    void sigRespQrCodePayAck(unsigned char ack);

public slots:
    //TEST
    void testSigRespQrCodePayAck();

private:
#ifdef nuc970_4_8
    Ui_Interface *m_funcInterface;
#endif
};

#endif // PAYHANDLER_H
