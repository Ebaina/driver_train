#include "payhandler.h"
#include "handlermanager.h"

#ifdef WIS_DEBUG
#include <QFile>
#include <QTimer>
#endif

PayHandler::PayHandler(QObject *parent) : QObject(parent)
{
#ifdef nuc970_4_8
    m_funcInterface = NULL;
    m_funcInterface = HandlerManager::instance()->getFuncInterface();
#endif
}

PayHandler::~PayHandler()
{

}

void PayHandler::responseTrainTimeCost(UI_TrainTimeCost timeCost)
{
    emit sigRespTrainTimeCost(timeCost);
}

void PayHandler::responsePoscardPayAck(unsigned char ack)
{
    emit sigPosCardPayAck(ack);
}

void PayHandler::responseQRCodeData(const unsigned char *data, int size, const char *format)
{
    emit sigRespQRCodeData(data, size, format);
}

void PayHandler::responseQRCodePayAck(unsigned char ack)
{
    emit sigRespQrCodePayAck(ack);
}

bool PayHandler::requestTrainTimeCost()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
    return m_funcInterface->request_train_time_and_cost();
#else
    return true;
#endif
}



bool PayHandler::requestPoscardPay()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
    return m_funcInterface->request_poscard_pay();
#else
    return true;
#endif
}

bool PayHandler::requestCancelPoscardPay()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
    return m_funcInterface->request_cancel_poscard_pay();
#else
    return true;
#endif
}

UI_TrainTimeCost PayHandler::requestQRCodePay()
{
    UI_TrainTimeCost info;
#ifdef nuc970_4_8
    (void)info;
    return m_funcInterface->request_qrcode_data();
#else
#ifdef WIS_DEBUG
    QFile qrFile(":/resource/image/qrcode.png");
    if(qrFile.open(QFile::ReadOnly)){
        QByteArray ba = qrFile.readAll();
        emit sigRespQRCodeData((unsigned char*)ba.data(), ba.size(), "png");
        qrFile.close();
    }
//    QTimer::singleShot(3000, this, SLOT(testSigRespQrCodePayAck()));
#endif
//    return true;
#endif
}

bool PayHandler::requestCancelQRCodePay()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
    return m_funcInterface->request_cancel_qrcode_pay();
#else
    return true;
#endif
}

void PayHandler::testSigRespQrCodePayAck()
{
    emit sigRespQrCodePayAck(UI_HEADER::QRP_SUCCESS);
}

