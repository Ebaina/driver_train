﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QDebug>
#include <QApplication>
#include <QDesktopWidget>
#include "trainaccountform.h"
#include "handlermanager.h"
#include "trainloginform.h"
#include "widgetcollector.h"
TrainAccountForm::TrainAccountForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_posDlg(NULL),
    m_DownPayDlg(NULL),
    m_qrCodeDlg(NULL)
{
    drawUI();

    connect(m_offlinePayBtn, SIGNAL(clicked()), this, SLOT(onDownPayClicked()));
    connect(m_qrCodePayBtn, SIGNAL(clicked()), this, SLOT(onQRCodePayBtnClicked()));
}

TrainAccountForm::~TrainAccountForm()
{
    if(m_qrCodeDlg != NULL){
        delete m_qrCodeDlg;
        m_qrCodeDlg = NULL;
    }
}

wis_u16 TrainAccountForm::type()
{
    return WIS_UI_ENUM::TRAIN_ACCOUNT_FORM;
}

void TrainAccountForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void TrainAccountForm::updateContent()
{
      //在这里请求训练消费数据
    QRWidget qrwidget;
    UI_TrainTimeCost qrcode_info;
    qrcode_info = HandlerManager::instance()->getPayHandler()->requestQRCodePay();
    m_curTrainTimeEdit->setText(QString::number(qrcode_info.trainTime).append("分钟"));
    m_curTrainCostEdit->setText(QString::number(qrcode_info.trainCost,'f',2).append("元"));
    QString qrcode_str = "driving://payserver?stunum=";
    qrcode_str.append(QString((char*)qrcode_info.learnerid));
    qrcode_str.append("&devnum=");
    qrcode_str.append(QString((char*)qrcode_info.devicenum));
    qrcode_str.append("&classid=");
    qrcode_str.append(QString::number(qrcode_info.classid));
    qrcode_str.append("&fee_count=");
    qrcode_str.append(QString::number(qrcode_info.fee_count));
    qrcode_str.append("&subjcode=");
    qrcode_str.append(QString((char*)qrcode_info.subjcode));
//    printf("qrcode_str = %s\n",qrcode_str.toStdString().c_str());
    qrwidget.setString(qrcode_str);    //"driving://payserver?stunum=12345&devnum=12345&classid=12345&fee_count=12345&subjcode=12345"
    qrwidget.saveImage("post.jpg",200);
}

void TrainAccountForm::drawUI()
{
    QVBoxLayout *BaseVbLayout = new QVBoxLayout(this);
    BaseVbLayout->setContentsMargins(0,0,0,0);
    BaseVbLayout->setSpacing(0);

    QFrame *topFrame = new QFrame(this);
    topFrame->setObjectName(QString("topFrame"));
    QGridLayout *topGridLayout = new QGridLayout(topFrame);
    topGridLayout->setContentsMargins(30,30,30,30);
    topGridLayout->setHorizontalSpacing(10);
    QLabel *lb = new QLabel(tr("本次学车学时:"), this);
    lb->setProperty("class", QVariant("leftNameLb"));
    m_curTrainTimeLb = new QLabel(this);
    m_curTrainTimeLb->setProperty("class", QVariant("rightValueLb"));
    topGridLayout->addWidget(lb, 0, 0, 1, 1);
//    topGridLayout->addWidget(m_curTrainTimeLb, 0, 1, 1, 1);
    m_curTrainTimeEdit = new QLineEdit(this);
    m_curTrainTimeEdit->setReadOnly(true);
    m_curTrainTimeEdit->setText("0 分钟");
    m_curTrainTimeEdit->setStyleSheet("background-color: transparent;color : white;");
    m_curTrainTimeEdit->setProperty("class",QVariant(QString("rightContentLineEdit")));
    topGridLayout->addWidget(m_curTrainTimeEdit,0,1,1,1);


    lb = new QLabel(tr("本次学车消费:"),this);
    lb->setProperty("class", QVariant("leftNameLb"));
    m_curTrainCostLb = new QLabel(this);
    m_curTrainCostLb->setProperty("class", QVariant("rightValueLb"));
    topGridLayout->addWidget(lb, 1, 0, 1, 1);
//    topGridLayout->addWidget(m_curTrainCostLb, 1, 1, 1, 1);
    m_curTrainCostEdit = new QLineEdit(this);
    m_curTrainCostEdit->setReadOnly(true);
    m_curTrainCostEdit->setText("0  元");
    m_curTrainCostEdit->setStyleSheet("background-color: transparent;color : white;");
    m_curTrainCostEdit->setProperty("class",QVariant(QString("rightContentLineEdit")));
    topGridLayout->addWidget(m_curTrainCostEdit,1,1,1,1);

    BaseVbLayout->addWidget(topFrame);

    QFrame *bottomFrame = new QFrame(this);
    bottomFrame->setObjectName(QString("bottomFrame"));
    QGridLayout *bottomLayout = new QGridLayout(bottomFrame);
    lb = new QLabel(tr("支付方式："),this);
    lb->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
    lb->setStyleSheet(QString("font-size:24px;color:#5da1de;text-align:left"));
    bottomLayout->addWidget(lb, 0, 0, 1, 3);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    bottomLayout->addWidget(lb,1,0,1,1);
    m_offlinePayBtn = new QPushButton(tr("线下支付"), this);
    m_offlinePayBtn->setIcon(QIcon(":/resource/image/payModule/cash.png"));
    m_offlinePayBtn->setProperty("class", QVariant("payBtn"));
    bottomLayout->addWidget(m_offlinePayBtn, 1, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    bottomLayout->addWidget(lb,1,2,1,1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    bottomLayout->addWidget(lb,1,3,1,1);
//    m_posCardPayBtn = new QPushButton(tr("刷卡支付"), this);
//    m_posCardPayBtn->setProperty("class", QVariant("payBtn"));
//    m_posCardPayBtn->setVisible(false);
//    m_posCardPayBtn->setIcon(QIcon(":/resource/image/payModule/postCard.png"));
    m_qrCodePayBtn = new QPushButton(tr("二维码支付"), this);
    m_qrCodePayBtn->setProperty("class", QVariant("payBtn"));
    m_qrCodePayBtn->setIcon(QIcon(":/resource/image/payModule/qrCode.png"));
    bottomLayout->addWidget(m_qrCodePayBtn, 1,4, 1, 1);
//    bottomLayout->addWidget(m_posCardPayBtn, 1, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    bottomLayout->addWidget(lb,1,5,1,1);
    bottomLayout->setContentsMargins(30,20,30,30);
    BaseVbLayout->addWidget(bottomFrame);

}

void TrainAccountForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void TrainAccountForm::onDownPayClicked()
{
    if(m_DownPayDlg == NULL){
        m_DownPayDlg = new ConfirmMessageDialog;
        m_DownPayDlg->setTest(tr("是否确认线下支付"));
        connect(m_DownPayDlg, SIGNAL(sigOk()), this, SLOT(onConfirmDlgDown()));
        connect(m_DownPayDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished()));
    }
#ifdef nuc970_4_8
    m_DownPayDlg->showFullScreen();
#endif
}

void TrainAccountForm::onQRCodePayBtnClicked()
{
    if(m_qrCodeDlg == NULL){
        m_qrCodeDlg = new QRCodePayDlg;
        connect(m_qrCodeDlg, SIGNAL(sigOk()), this, SLOT(onConfirmDlgDown()));
        connect(m_qrCodeDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished()));
    }
    m_qrCodeDlg->updateContent();
#ifdef nuc970_4_8
    m_qrCodeDlg->showFullScreen();
#else
    m_qrCodeDlg->resize(800, 480);
    m_qrCodeDlg->exec();
#endif
}

void TrainAccountForm::onConfirmDlgDown()
{
    showTrainLoginForm();
}
void TrainAccountForm::onConfirmDlgFinished()
{
    m_DownPayDlg = NULL;
    m_qrCodeDlg = NULL;
}


