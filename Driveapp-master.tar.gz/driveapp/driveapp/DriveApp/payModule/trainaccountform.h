﻿#ifndef TRAINACCOUNTFORM_H
#define TRAINACCOUNTFORM_H

#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include "basewidget.h"
#include "poscardpaydlg.h"
#include "qrcodepaydlg.h"
#include "confirmmessagedialog.h"
#include "qrwidget.h"
class QRWidget;
class TrainAccountForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit TrainAccountForm(QWidget *parent = 0);
    ~TrainAccountForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();



private:
    QStackedWidget *m_mainStackWidget;

    //UI
    QLabel *m_curTrainTimeLb;
    QLabel *m_curTrainCostLb;
    QLineEdit *m_curTrainTimeEdit;
    QLineEdit *m_curTrainCostEdit;
    QPushButton *m_offlinePayBtn;
    QPushButton *m_posCardPayBtn;
    QPushButton *m_qrCodePayBtn;

    PosCardPayDlg *m_posDlg;
    QRCodePayDlg *m_qrCodeDlg;
    ConfirmMessageDialog *m_DownPayDlg;

    void drawUI();

    void showTrainLoginForm();

private slots:

    void onConfirmDlgDown();

    void onConfirmDlgFinished();

    void onDownPayClicked();

    void onQRCodePayBtnClicked();

};

#endif // TRAINACCOUNTFORM_H
