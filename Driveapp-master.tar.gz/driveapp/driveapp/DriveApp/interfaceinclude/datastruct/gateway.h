﻿#ifndef _GATEWAY_H_
#define _GATEWAY_H_
#include "tcpclient.h"
#include "cJSON.h"
#include "wis_fifo.h"

//#define ServerIP  "192.168.100.105"   // 发送的IP地址
//#define ServerPort  8900

#define CMD_REGISTER  "register"


class sp_gateway : public nTcp_Client,public Wisfifo
{
public:
    sp_gateway() {}
    ~sp_gateway() {}

private:
    char token[16];     //
    void format_data();


public:
    void format_register();

    int sp_gateway_register(char *setid,char *sn,char *usr,char *ps);

    static void Data_Proc(char *buf,int len,void *param);

    int ini_net();

    void int_cmd_list();

    int Get_ACK();
};
#endif
