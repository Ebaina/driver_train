﻿#ifndef _FRAME_WORK_
#define _FRAME_WORK_
#include  "Event.h"
#include  "Thread.h"
#include  "execoach.h"
#include  "exelearner.h"
#include  "exeidentitycheck.h"
#include  "exephototake.h"
#include  "exephotoupload.h"
#include  "exepositionreport.h"
#include  "exeReg.h"
#include  "exeUnresister.h"
#include  "exesetterminaldata.h"
#include  "cmd_pipe.h"
#include  "cmdbeatheart.h"
#include  "gateway.h"
#include  "common_response_ack.h"
#include  "Event.h"
#include  "Thread.h"
#include "exeAuthority.h"
#include "exeterminalcontrol.h"
#include "exedatapass.h"
#include "exerequestpackageagain.h"
#include "logininterface.h"
#include "settinginterface.h"

class DeviceFramework
{
public:

    DeviceFramework() {}
    //==========================================
    CmdBeatHeart          *p_CmdBeat;  //心跳信息  0002
    CmdReg                     *p_CmdReg;//注册   0100
    exeUnResister              *p_CmdUnregister;//注销  0003
    Cmd_common           *p_down_common;  //通用应答  0001
    exeAuthority             * p_CmdAuthority;//鉴权   0102
    exePositionReport             * p_CmdPositionReport;//位置上报0200
    exeSearchTerminalData           * p_exeSearchTerminalData;//查询指定终端参数应答  0104
    exeSearchPosition          *p_exesearchpositionreport;      //位置信息查询应答   0201
    exeDatapass                 *p_exedatapass;    //数据上行透传
    exeCoachLogin             * p_exeCoachLogin;//教练登陆    0101
    exeCoachLogout             *p_exeCoachLogout; //教练登出   0102
    exeLearnerLogin            *p_exeLearnerLogin; //学员登入   0201
    exeLearnerLogout           *p_exeLearnerLogout; //学员登出   0202
    exeAskReportTrainRecord            *p_exeAskReportTrainRecord; //命令上报学时记录    0205
    exeAsktakephotonow            *p_exeAsktakephotonow; //立即拍照应答   0301
    exeReportTrainRecord            *p_exeReportTrainRecord ; //上报学时记录   0203
    exeSearchphoto                *p_exeSearchphoto;   //查询照片应答   0302
    exeSearchphotoresult            *p_exeSearchphotoresult; //上报照片查询结果   0303
    exeUploadphotodata            *p_exeUploadphotodata; //上传照片数据包  0306
    exeUploadselectphoto            *p_exeUploadselectphoto; //上传指定照片   0304
    exeUploadphotoinit            *p_exeUploadphotoinit; //照片上传初始化   0305
    exeSetterminalappdata      *p_exeSetterminalappdata; //设置终端应用参数应答   0501
    exeSetforbidtrain                *p_exeSetforbidtrain;   //设置禁训状态应答    0502
    exeSearchterminalappdata   *p_exeSearchterminalappdata;   //查询终端应用参数应答   0503
    exeAskIdentityCheck         *p_exeAskIdentityCheck; //请求身份验证     0401
    exeAskunifynum               *p_exeAskunifynum;  //请求统一编号信息   0402

    /*解析包部分*/
    exerequestpackageagain    *p_exerequestpackageagain;  //补传分包请求
    exeSetTerminalData             *p_exesetterminaldata;//设置终端参数
    exeTerminalDataControl     *p_exeterminaldatacontrol; //终端控制
    exeSearchSelectTerminalData  *p_exesearchselectterminaldata; //查询终端指定参数


public:
    void do_init_net(char* ip,int port);  //初始化网关

    void do_init_cmd(); //初始化cmd,cmdpp

    void do_register(stRegInfo mInfo, WIS_UI::SettingInterface *settingHandler);//注册     0100
    void reg_ack(stRecvCmdPiPe  strevdata);//注册应答  8100

    void do_unregister();//注销  0003

    void do_authority(shark_authority_up mInfo);//鉴权信息  0102

    void do_beatheart(); //心跳信息  0002

    void do_requestpakageagain(stRecvCmdPiPe  strevdata);   //补传分包请求 8003

    void do_common_response(common_Info mInfo);  //终端通用回复  0001
    void do_common_response_ack(stRecvCmdPiPe  strevdata);    //平台通用回复  8001

    void do_set_terminaldata(stRecvCmdPiPe  strevdata);   //设置终端参数  8103
    void do_search_terminaldata(stRecvCmdPiPe  strevdata);   //查询终端参数  8104

    void do_search_select_terminaldata(SearchTerminalParamAck mInfo); //查询指定终端参数应答   0104
    void do_search_select_terminaldata_ack(stRecvCmdPiPe  strevdata); //查询指定终端参数   8106

    void do_report_position(PositionReport_up mInfo);   //位置信息汇报  0200

    void do_terminal_control(stRecvCmdPiPe  strevdata);   //终端控制  8105

    void do_search_position(PositionSearch mInfo);  //位置信息查询应答   0201
    void do_search_position_ack(stRecvCmdPiPe  strevdata);   //位置信息查询  8201

    void do_track_temp_position(stRecvCmdPiPe  strevdata);  //临时位置跟踪控制   8202

    void do_transmit_transparently_down(stRecvCmdPiPe  strevdata);   //数据下行透传   8900
    int do_transmit_transparently_packge(wis_u16 transferid,wis_u16 extraproperty,void* contentdata,wis_u32 len,wis_u8 output[512]);   //数据上行透传  0900

    void do_coachlogin(CoachLogin_Up mInfo);//教练登陆  0101
    void do_coachlogin_ack(stRecvCmdPiPe  strevdata);//教练登陆应答  8101

    void do_coachlogout(CoachLogout_Up mInfo);//教练登出   0102
    void do_coachlogout_ack(stRecvCmdPiPe  strevdata);//教练登出应答  8102


    void do_learnerlogin(LearnerLogin_Up mInfo);//学员登陆   0201
    void do_learnerlogin_ack(stRecvCmdPiPe  strevdata);//学员登陆应答  8201

    void do_learnerlogout(LearnerLogout_Up mInfo);//学员登出  0202
    void do_learnerlogout_ack(stRecvCmdPiPe  strevdata);//学员登出应答  8202

    void do_reportrain_record(ReportLearnMessage_Up mInfo);  //上报学时记录  0203

    void do_ask_reportrain_record(AskReportLearnMessage_Up mInfo);//命令上报学时记录应答  0205
    void do_ask_reportrain_record_ack(stRecvCmdPiPe  strevdata);//命令上报学时记录  8205

    void do_takephoto_now(Asktakephotonow_Up mInfo);//立即拍照应答  0301
    void do_takephoto_now_ack(stRecvCmdPiPe  strevdata);//立即拍照  8301

    void do_searchphoto(Searchphoto_Up mInfo);//查询照片应答   0302
    void do_searchphoto_ack(stRecvCmdPiPe  strevdata);//查询照片   8302

    void do_upload_searchphoto_result(Searchphotoresult_UP mInfo);//上报查询照片结果应答  0303
    void do_upload_searchphoto_result_ack(stRecvCmdPiPe  strevdata);//上报查询照片结果   8303

    void do_upload_selectphoto_ack(stRecvCmdPiPe  strevdata);//上传指定照片  8304
    void do_upload_selectphoto(Uploadselectphoto_Up mInfo);//上传指定照片应答  0304

    void do_upload_photo_init(Uploadphotoinit_Up mInfo);//上报照片初始化应答   0305
    void do_upload_photo_init_ack(stRecvCmdPiPe  strevdata);//上报照片初始化  8305

    void do_upload_photo_data(Uploadphotodata_Up mInfo);//上报照片数据  0306

    void do_set_terminal_app_data_ack(stRecvCmdPiPe  strevdata);// 设置终端应用参数 8501
    void do_set_terminal_app_data(Setterminalappdata_Up mInfo);//设置终端应用参数应答   0501

    void do_set_forbidtrain_app_ack(stRecvCmdPiPe  strevdata);// 设置禁训状态  8502
    void do_set_forbidtrain_app(Setforbidtrain_Up mInfo);//设置禁训状态应答  0502

    void do_search_terminal_app_data(Searchterminalappdata_Up mInfo);//查询计时终端应用参数应答   0503
    void do_search_terminal_app_data_ack(stRecvCmdPiPe  strevdata); //查询计时终端应用参数  8503

    void do_ask_identity_check(Identitycheckdata_Up mInfo);//身份请求认证信息应答  8401
    void do_ask_identity_check_ack(stRecvCmdPiPe  strevdata); //身份请求认证信息  0401

     void do_ask_unifynum(Asknifynum_Up mInfo);//请求统一编号信息应答  8402
     void do_ask_unifynum_ack(stRecvCmdPiPe  strevdata);//请求统一编号信息    0402

};
#endif
