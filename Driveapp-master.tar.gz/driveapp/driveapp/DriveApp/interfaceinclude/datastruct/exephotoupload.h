﻿#ifndef EXEPHOTOUPLOAD_H
#define EXEPHOTOUPLOAD_H
#include "stdtype.h"
#include "CmdBase.h"
#include "exedatapass.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/

/****************************
*A.4.2.3.5　上报照片查询结果
*透传消息ID：0x0303
*应答属性：0x01
*客户端上报服务器端查询照片的结果，上报照片查询结果消息数据格式见表B.49。
*************************************
*表A.49　上报照片查询结果消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	是否上报结束	BYTE	0：否，1：是
*   如果查询结果尚未发完，则为0x00
*1	符合条件的照片总数	BYTE	总数n，为0则无后续字段
*2	此次发送的照片数目	BYTE	数目m
*3	照片编号1	BYTE[10]
*13	照片编号2	BYTE[10]
    ……
13+m*10	照片编号m	BYTE[10]
*************************************************/
#define CMD_T2P_SEARCHPHOTORESULT_UP 0x0303
typedef struct Searchphotoresult_UP{
wis_u8 uploadendflag;//0	是否上报结束	BYTE	0：否，1：是
wis_u8 matchphotosize;//1	符合条件的照片总数	BYTE	总数n，为0则无后续字段
wis_u8 sendphotonumber;//2	此次发送的照片数目	BYTE	数目m
wis_u8 photonum1[10];//3	照片编号1	BYTE[10]
wis_u8 photonum2[10];//13	照片编号2	BYTE[10]
 }__attribute__((packed, aligned(1))) Searchphotoresult_UP;


/*
A.4.2.3.6　上报照片查询结果应答
透传消息ID：0x8303
服务器端使用该消息应答客户端的上报照片查询结果消息，客户端应等待收到服务器端的该应答消息后再发下一数据包。上报照片查询结果应答消息数据格式见表B.50。
表A.50　上报照片查询结果应答消息数据格式
起始字节	字段	数据类型	描述及要求
0	应答代码	BYTE	0：默认应答
********************1：停止上报，终端收到“停止上报”应答后则停止查询结果的上报。
注：透传消息ID0x0303和0x8303消息的作业序号应和0x8302和0x0302的一致。
*************************************************/
#define CMD_P2T_SEARCHPHOTORESULT_DOWN 0x8303
typedef struct Searchphotoresult_Down{
wis_u8 ackdata;//0	应答代码	BYTE	0：默认应答
 }__attribute__((packed, aligned(1))) Searchphotoresult_Down;


/*******************************
*A.4.2.3.7　上传指定照片
*透传消息ID：0x8304
*应答属性：0x01
*服务器端下发上传指定照片消息请求客户端上传指定的照片，上传指定照片消息数据格式见表B.51。
*************************************
*表A.51　上传指定照片消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
*************************************************/
#define CMD_P2T_UPSELECTPHOTO_DOWN 0x8304
typedef struct Uploadselectphoto_Down{
wis_u8 photonum[10];//0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
}__attribute__((packed, aligned(1))) Uploadselectphoto_Down;



/*
*A.4.2.3.8　上传指定照片应答
*透传消息ID：0x0304
*客户端使用该消息应答服务器端下发的上传指定照片消息，应答后使用透传消息ID0x0305和0x0306开始实际数据的上报，上传指定照片应答消息数据格式见表B.52。
*表A.52　上传指定照片应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	应答代码	BYTE	0：找到照片，稍候上传
*1：没有该照片
*************************************************/
#define CMD_T2P_UPLOADSELECTPHOTO_UP 0x0304
typedef struct Uploadselectphoto_Up{
wis_u8 ackdata; //0	应答代码	BYTE	0：找到照片，稍候上传
 }__attribute__((packed, aligned(1))) Uploadselectphoto_Up;

/******************************
*A.4.2.3.9　照片上传初始化
*透传消息ID：0x0305
*应答属性：0x01
*客户端在开始照片数据包上传前使用该消息将照片相关信息上传服务器端，照片上传初始化消息数据格式见表B.53。
*************************************
*表A.53　照片上传初始化消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
*10	学员或教练员编号	BYTE [16]	统一编号
*26	上传模式	BYTE	1：自动请求上传；
*129：终端主动拍照上传；
*255：停止拍摄并上传图片
*27	摄像头通道号	BYTE	0：自动
* ****************1~255 表示通道号
*28	图片尺寸	BYTE	0x01：320×240；
********************0x02：640×480；
********************0x03：800×600；
********************0x04：1024×768；
********************0x05：176×144[Qcif]；
********************0x06：352×288[Cif]；
********************0x07：704×288[HALF D1]；
********************0x08：704×576[D1]；
*注：终端若不支持系统要求的分辨率，则取最接近的分辨率拍摄并上传
*29	发起图片的事件类型	BYTE	发起图片的事件类型，定义如下：
**********0：中心查询的图片；
**********1：紧急报警主动上传的图片；
**********2：关车门后达到指定车速主动上传的图片；
**********3：侧翻报警主动上传的图片；
**********4：上客；
**********5：定时拍照；
**********6：进区域；
**********7：出区域；
**********8：事故疑点(紧急刹车)；
**********9：开车门；
*17：学员登录拍照；
*18：学员登出拍照；
*19：学员培训过程中拍照；
*20：教练员登录拍照；
*21：教练员登出拍照
*30	总包数	WORD
*32	照片数据大小	DWORD
*36	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
*40	附加GNSS数据包	BYTE[328]	照片拍摄时的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
*78	人脸识别置信度	BYTE	0-100，数值越大置信度越高
*************************************************/
#define CMD_T2P_UPLOADPHOTOINIT_UP 0x0305
typedef struct Uploadphotoinit_Up{
wis_u8 photonum[10]; //0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
wis_u8 learnerorcoachid[16]; //10	学员或教练员编号	BYTE [16]	统一编号
wis_u8 uploadmode; //26	上传模式	BYTE	1：自动请求上传；
wis_u8 camerachannel; //27	摄像头通道号	BYTE	0：自动
wis_u8 photosize; //28	图片尺寸	BYTE	0x01：320×240；
wis_u8 photoeventtype; //29	发起图片的事件类型	BYTE	发起图片的事件类型，定义如下：
wis_u16 packgesize; //30	总包数	WORD
wis_u32 photodatasize; //32	照片数据大小	DWORD
wis_u32 lessonid; //36	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
wis_u8  addgnssdata[38]; //40	附加GNSS数据包	BYTE[38]	照片拍摄时的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
wis_u8  faceidentifyreliability; //78	人脸识别置信度	BYTE	0-100，数值越大置信度越高
 }__attribute__((packed, aligned(1))) Uploadphotoinit_Up;


/*
A.4.2.3.10　照片上传初始化应答
*透传消息ID：0x8305
*服务器端使用此消息应答客户端的照片上传初始化消息，照片上传初始化应答消息数据格式见表B.54。
*表A.54　照片上传初始化应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	应答代码	BYTE	0：接受上传
*255：拒绝上传，终端收到“拒绝上传”应答后则停止此照片的上传。
*************************************************/
 #define CMD_P2T_UPLOADPHOTOINIT_DOWN 0x8305
typedef struct Uploadphotoinit_Down{
    wis_u8 ackdata; //0	应答代码	BYTE	0：接受上传
}__attribute__((packed, aligned(1))) Uploadphotoinit_Down;



/*A.4.2.3.11　上传照片数据包
*透传消息ID：0x0306
*应答属性：0x01
*客户端使用此消息上传照片的数据，上传照片数据包消息数据格式见表B.55。
*/
/**************************************
*表A.55　上传照片数据包消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
*10	照片数据	BYTE[n]	不大于768字节的数据内容n=照片大小
*************************************************/
#define CMD_T2P_UPLOADPHOTODATA_UP 0x0306
typedef struct Uploadphotodata_Up{
wis_u8 photonum; //0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
wis_u8 photo[768]; //  10	照片数据	BYTE[n]	不大于768字节的数据内容n=照片大小
}__attribute__((packed, aligned(1))) Uploadphotodata_Up;



class exeSearchphotoresult : public BaseCmd
{
public:
    exeSearchphotoresult(sp_gateway *m):BaseCmd(m){
        m_CmdName = "searchphotoresult";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};



class exeUploadselectphoto: public BaseCmd
{
public:
    exeUploadselectphoto(sp_gateway *m):BaseCmd(m){
        m_CmdName = "uploadselectphoto";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};



class exeUploadphotoinit: public BaseCmd
{
public:
    exeUploadphotoinit(sp_gateway *m):BaseCmd(m){
        m_CmdName = "uploadphotoinit";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};


class exeUploadphotodata: public BaseCmd
{
public:
    exeUploadphotodata(sp_gateway *m):BaseCmd(m){
        m_CmdName = "uploadphotodata";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};





#endif // EXEPHOTOUPLOAD_H
