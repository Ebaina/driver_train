#ifndef CAN_H
#define CAN_H

#ifdef __cplusplus
extern "C" {
#endif

/*
    函数说明: 初始化can口,同时启动can设备
    参数说明:
             name: can设备名,can0,can1
             baudrate: 波特率设置
    返回值:
             成功返回设备句柄
             失败返回-1
*/
int init_can( const char* name, int baudrate );

/*
    函数说明: 反初始化can口,停止can设备
    参数说明:
             name: can设备名,can0,can1
             fd: 打开的can句柄
    返回值:
             无
*/
void uinit_can( const char *name, int fd );

/*
    函数说明: 发送can数据
    参数说明:
      输入参数
             fd: can设备句柄
             data: 待发送数据
             len: 数据长度
             id: can ID
             extended: 扩展帧标志
             rtr: 远程请求标志
    返回值:
             成功返回发送的长度
             失败返回-1
*/
int can_send( int fd, const char* data, int len, int id, int extended, int rtr );

/*
    函数说明: 接收can数据
    参数说明:
      输入参数:
             fd: can设备句柄
      输出参数:
             data: 待待接收的数据
             len: 数据长度
             id: can ID
             extended: 扩展帧标志
             rtr: 远程请求标志
    返回值:
             成功返回0
             失败返回-1
*/
int can_read( int fd, char* data, int *len, int *id, int *extended, int *rtr );
#ifdef __cplusplus
}
#endif



#endif // CAN_H

