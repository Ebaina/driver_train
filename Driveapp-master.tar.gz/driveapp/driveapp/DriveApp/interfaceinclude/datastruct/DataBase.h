#ifndef __DATABASE_H__
#define __DATABASE_H__
#include "stdtype.h"
#include <iostream>
#include <vector>


/**
 *  \class   SqlResult_S
 *  \brief  SQL��ѯ����ṹ�� 
 */
typedef struct{
    int m_columns;  /**< sql��ѯ����ִ�������(�ֶ���) */
    std::vector<std::string> m_resultStrVect;   /**< ��ѯ����� */
}SqlResult_S;

/**
 *  \file   DataBase.h   
 *  \class  DataBase
 *  \brief  ���ݿ������.
 */

class DataBase{
public:
    virtual bool open(std::string dbName)=0;
    virtual bool connect(std::string user, std::string passwd)=0;
    virtual bool close()=0;
    virtual bool exec(const std::string& sql,SqlResult_S* result=NULL)=0;
    virtual bool insertBlob(const std::string& sql,std::string bindVarName,char* buf, int len)=0;
    virtual bool selectBlob(const std::string& sql,std::string bindVarName,char* buf, int& len)=0;
};

#endif

