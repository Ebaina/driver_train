﻿#ifndef _MANAGER_EXE_
#define _MANAGER_EXE_

#include<iostream>
#include<list>
#include"CmdBase.h"


using namespace std;
typedef void* pExe ;

extern vector<pExe> p_list;

void * find_exe(unsigned short cmd);   //找到一个命令对象

void   save_exe(void * ptr);

void   remove_exe(unsigned short cmd);  //删除一个命令对象
#endif
