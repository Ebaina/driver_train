#ifndef LOGININTERFACE_H
#define LOGININTERFACE_H

namespace WIS_UI{

class LoginInterface
{
public:
    explicit LoginInterface() {}
   ~ LoginInterface(){}

    /**
  *@brief    callback coach login ack
  *@param [in]      loginState
  *                           1:登录成功
  *                           0:登录失败
  */
    virtual void updateCoachLoginAckState(unsigned char loginState) = 0;

    /**
  *@brief callback   coach logout ack
  * @param [in]  logoutState
  *                         1:登出成功
  *                         0:登出失败
  */
    virtual void updateCoachLogoutAckState(unsigned char logoutState) = 0;


    /**
  *@brief  callback learner login ack
  *@param [in]      loginState
  *                           1:登录成功
  *                           0:登录失败
  */
    virtual void updateLearnerLoginAckState(unsigned char loginState) = 0;

    /**
  *@brief   call back learner logout ack
  * @param [in]  logoutState
  *                         1:登出成功
  *                         0:登出失败
  */
    virtual void updateLearnerLogoutAckState(unsigned char logoutState) = 0;


};

}
#endif // LOGININTERFACE_H

