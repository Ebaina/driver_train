﻿#ifndef APP_GLOBL
#define APP_GLOBL
#include  "framework.h"
#include  <string.h>
#include <stdio.h>
#include <stdlib.h>
#include  "execoach.h"
#include  "exelearner.h"
#include  "exeidentitycheck.h"
#include  "exephototake.h"
#include  "exephotoupload.h"
#include  "exepositionreport.h"
#include  "exeReg.h"
#include  "exeUnresister.h"
#include  "exesetterminaldata.h"
#include  "cmd_pipe.h"
#include  "cmdbeatheart.h"
#include  "gateway.h"
#include  "common_response_ack.h"
#include  "Thread.h"
#include  "exeAuthority.h"
#include  "main_event_manager.h"
#include  "public.h"
#include  "ManagerExe.h"
#include  "dictionary.h"
#include  "iniparser.h"
#include  "ui_structs.h"
#include "minmea.h"
#define MAX_SNAP_NUM 100
class DeviceFramework;
extern DeviceFramework  appcon;
extern sp_gateway appGateway;
extern CmdPP m_CmdProcessTask;
extern stRegInfo sreginfo;
extern CoachLogin_Up coachup_info;
extern LearnerLogin_Up learnerup_info;
extern LearnerLogin_down learner_login_info;
extern CommunicateMainSet commu_info;
extern NetMainSet net_info;
extern ReportMainSet report_info;
extern ListenMainSet  monitor_info;
extern ViewthresholdMainSet  videolisten_info;
extern OtherMainSet other_info;
extern  string  phone_num ;
extern  wis_u8 TerminalLoginStatus ;
extern  minmea_sentence_gga gga_frame;
extern  minmea_sentence_rmc rmc_frame;
extern  PositionReport_up positionReport_up;


#endif // APP_GLOBL

