#ifndef COMMUNICATESTM32_H
#define COMMUNICATESTM32_H
#include "Thread.h"
#include "uart.h"
#include "Mutex.h"

//和STM32通信接口

 extern  void parseUpdata(char * data ,int length);

class CommunicateStm32
{
    public:
    CommunicateStm32();
    ~CommunicateStm32();
    void Init_Data();

    void sendDowndata(int commid);\
};

#endif // COMMUNICATESTM32_H
