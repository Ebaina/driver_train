/******************************************************************************
*******************************************************************************/
#ifndef __CRTCFACADE_H__
#define __CRTCFACADE_H__
#include  "stdtype.h"

/**
 *  \class  RtcTime_S
 *  \brief  时间结构体      
 */
typedef struct
{
    unsigned int m_second;   /**< 秒 */
     unsigned int  m_minute;   /**< 分 */
     unsigned int  m_hour;     /**< 时 */
     unsigned int  m_date;     /**< 日 */
     unsigned int  m_month;    /**< 月 */
     unsigned int  m_year;     /**< 年 */
}RtcTime_S;

/**
 *  \file   RtcFacade.h   
 *  \class  RtcFacade
 *  \brief  实时时钟设备类	
 */
class RtcFacade{
public:
    /**
     *  \brief  获取RtcFacade单例
     *  \param  void
     *  \return RtcFacade* 
     *  \note   none
     */
    static RtcFacade* getInstance()
    {
        static RtcFacade instance;
        return &instance;
    }
    ~RtcFacade();
    void showTime(RtcTime_S rtcTime);   /* 打印RTC时间 */
    int readTime(RtcTime_S& rtcTime);/* 读取RTC时间 */
    int writeTime(RtcTime_S rtcTime);/* 改写RTC时间 */
private:
    RtcFacade();
};
#endif
