﻿/*
wis_u8      单个字节
wis_u16		两个字节
wis_u32		四个字节
*/

#ifndef UI_STRUCTS
#define UI_STRUCTS
#include "stdtype.h"
#include "stdio.h"
#include <string>

#define  STRDATA_LENGTH   32
#define  PLATE_LEN   9
#define  DENTITYID_LEN    18
#define  ID_LEN   16
#define  TRAINCARTYPE_LEN  2
#define MANUFACTURERID_LEN  5
#define DEVICETYPE_LEN    20
#define PHOTONAME_LEN 20
#define  DEVICESN_LEN  7
#define  IMEI_len    15
using namespace std;
namespace UI_HEADER {
enum CardType{  //证件类型
   CT_IDCARD,//身份证
   CT_PASSPORT,//护照
   CT_OFFICER_CARD,//军官证
   CT_LIVING_CARD//居住证
};
 enum LicenseColor {//车牌颜色
     LC_BLUE=1,
     LC_YELLOW,
     LC_BLACK,
     LC_WHITE,
     LC_GREEN,
     LC_OTHER=9
 };


 enum FingerprintAckStatus{
      FP_FALURE,
      FP_SUCCESS,
      FP_TIMEOUT
 };

 enum CarType {//培训车型
      A1,A2,A3,B1,B2,C1,C2,C3,C4,C5,D,E,F,M,N,P
 };
 enum LocationReportType {// 位置汇报策略：0:定时回报   1：定距汇报   2：定时和定距汇报
   LR_TIME_REPORT=0,//从
   LR_MILE_REPORT,//
   LR_MILE_TIME_REPORT
    };

 enum LocationReportStatus {//位置汇报方案：0：根据ACC状态  1：根据登入状态和ACC状态
   BY_ACC_STATUS=0,//从
   BY_ACC_LOGIN_STATUS
    };
 enum PhotoQuality {//图像质量：1，2，3，4，5，6，7，8，9，10
    P1=1,P2,P3,P4,P5,P6,P7,P8,P9,P10=10
    };
 enum PhoneAnswerType {// 终端电话接听策略：0：自动接听  1：ACC ON 时自动接听，OFF时手动接听
    AUTO_ANSWER=0, ACC_ANSWER=1 ,OFF_ANSWER=2
    };
 enum RegisterStatus {
    REG_S1=1,     //正在连接中心
     REG_S2,        //连接中心成功
     REG_S3,        //等待接收中心验证
     REG_S4,        //中心验证成功
     REG_S5,        //中心验证失败
     REG_S6,        //正在保存注册信息
     REG_S7,        //信息保存成功
     REG_S8,        //成功
     REG_S9         //刷卡超时
    };

 enum RetState{
     RS_NO = 0,
     RS_YES
 };

 enum MobileSignalValue{
     M_SIGNAL0,
     M_SIGNAL1,
     M_SIGNAL2,
     M_SIGNAL3,
     M_SIGNAL4,
 };

 //教练或学员登出
 enum LogoutType{
     LT_TIMEOUT = 0,
     LT_COACH,
     LT_LEARNER
 };

 //HXQ APPEND
 //coach star
 enum CoachStarRange{
     CSR_1 = 1,
     CSR_2,
     CSR_3,
     CSR_4,
     CSR_5
 };

 enum TrainSubjectType{
     TST_1 = 1,
     TST_2,
     TST_3,
     TST_4
 };

 //位置汇报策略
 enum ReportStrategyType{
     RST_TIME = 0,
     RST_DIST,
     RST_TIME_DIST
 };

 //位置汇报方案
 enum PostReportSchemeType{
    PRST_ACC_STATE = 0,
    PRST_LOGIN_ACC_STATE
 };

 //终端电话接听策略
 enum TerminalPhoneRecvWay{
     TPRW_AUTO = 0,      //自动
     TPRW_MANUAL       //手动
 };

 //支付相关
 //刷卡支付
enum PosCardPayAckState{
    PCP_TIMEOUUT = 0,
    PCP_FAILED,
    PCP_SUCCESS
};

//二维码支付
enum QRCodePayAckState{
    QRP_TIMEOUT = 0,
    QRP_FAILED,
    QRP_SUCCESS
};

//培训课程
enum TrainSubjectId{
    TSI_11 = 11,          //基础驾驶
    TSI_12,                  //场地驾驶
    TSI_13,                  //综合驾驶及考核
    TSI_21 = 21,          //跟车行驶
    TSI_22,                  //变更车道
    TSI_23,                 //靠边停车
    TSI_24,                 //掉头
    TSI_25,                 //通过路口
    TSI_26,                 //通过人行横道
    TSI_27,                 //通过学校区域
    TSI_28,                 //通过公共汽车站
    TSI_29,                 //会车
    TSI_30,                 //超车
    TSI_31,                 //夜间驾驶
    TSI_32,                 //恶劣条件下的驾驶
    TSI_33,                 //山区道路驾驶
    TSI_34,                 //高速公路驾驶
    TSI_35,                //行驶路线选择
    TSI_36                //综合驾驶及考核
};

}
typedef struct UI_CoachLogin_Up{//教练登陆消息
    wis_u8 coachid[ID_LEN] ;// 0   教练员编号   BYTE[16]    统一编号
    wis_u8 cardtype;//证件类型
    wis_u8 coachdentityid[DENTITYID_LEN];//18  教练员身份证号 BYTE[18]    ASCII码，不足18位前补0x00
    wis_u8 traincartype[TRAINCARTYPE_LEN];//  准教车型    BYTE[2] A1/A2/A3/B1/B2/C1/C2/C3/C4/D/E/F
  }  __attribute__((packed, aligned(1))) UI_CoachLogin_Up;

typedef struct UI_LearnerLogin_Up{//学员登陆消息
    wis_u8 learnerid[ID_LEN] ;// 0   学员员编号   BYTE[16]    统一编号
    wis_u8 cardtype;//证件类型
    wis_u8 learnerdentityid[DENTITYID_LEN];// 18	 证件ID
    wis_u8 trancar_type[TRAINCARTYPE_LEN];// 培训车型
    wis_u8 coachid[ID_LEN];   //	教练编号   BYTE[16]	统一编号
    wis_u32 subjectId;    //培训课程
}  __attribute__((packed, aligned(1))) UI_LearnerLogin_Up;


typedef struct UI_Learner_Info {
       wis_u8  learnerid[ID_LEN] ;// 0   学员员编号   BYTE[16]    统一编号
       wis_u16 maintraintime;//17	总培训学时	WORD	单位：min
       wis_u16 finishtime;//19	当前培训部分已完成学时	WORD	单位：min
       wis_u16 maintrainmile;//21	总培训里程	WORD	单位：1/10km
       wis_u16 finishmile;//23	当前培训部分已完成里程	WORD	单位：1/10km
} __attribute__((packed, aligned(1))) UI_Learner_Info;

typedef struct UI_Learner_record {
       wis_u8  Leaner_name[STRDATA_LENGTH];    //学员姓名
       wis_u8  learnerid[ID_LEN] ;// 0   学员员编号   BYTE[16]    统一编号
       wis_u8  coachid[ID_LEN];   //	教练编号   BYTE[16]	统一编号
       wis_u32  lesson_id;      //课程ID
       wis_u8  record_time[32];   //记录产生时间
       wis_u32  subjectId;    //培训课程
       wis_u16  max_speed;   //最大速度
       wis_u16  milage;      //里程
} __attribute__((packed, aligned(1))) UI_Learner_record;


typedef struct UI_CoachPhotonameSet
{
    wis_u8  CoachPhoto[PHOTONAME_LEN];// 教练照片名字
}__attribute__((packed, aligned(1)))  UI_CoachPhotonameSet;

typedef struct UI_LearnerPhotonameSet
{
    wis_u8  LearnerPhoto[PHOTONAME_LEN];// 学员照片名字
}__attribute__((packed, aligned(1)))  UI_LearnerPhotonameSet;


typedef struct UI_NetMainSet//网络设置
{
    wis_u8  Mainserver_IP[STRDATA_LENGTH];// 0x0013 主服务器地址，IP或域名
    wis_u8  phonenum[STRDATA_LENGTH];// 0x0015 手机号
    wis_u8  Backupserver_IP[STRDATA_LENGTH];// 0x0017 备份服务器地址，IP或域名
    wis_u32 Server_TCP_Port;// 0x0018 服务器TCP端口
    wis_u32 Server_UDP_Port;// 0x0019 服务器UDP端口
                                        //0x001a-0x001f  保留
}__attribute__((packed, aligned(1)))  UI_NetMainSet;//网络设置

typedef struct   UI_StRegInfo    //注册信息
{
    wis_u8 m_Province;  //省
    wis_u8 m_town;      //县域
    wis_u8  m_manufacturerID[MANUFACTURERID_LEN];  //制造商ID
    wis_u8  m_DeviceType[DEVICETYPE_LEN];     //终端类型
    wis_u8  m_DeviceSN[DEVICESN_LEN];        //设备SN
    wis_u8  m_IMEI[IMEI_len];          //IMEI
    wis_u8  m_CarPlateColor;    //车牌颜色
    wis_u8  m_CarNumber[PLATE_LEN];     //车牌标识
}__attribute__((packed, aligned(1))) UI_StRegInfo;


typedef struct  User_card_info    //管理员信息
{
     wis_u8   user_name[STRDATA_LENGTH];    //管理员信息
     wis_u8   user_password[STRDATA_LENGTH];    //管理员密码
}__attribute__((packed, aligned(1))) User_card_info;


typedef struct  Safetyuser_card_info    //安全员信息
{
    wis_u8   Safetyuser_name[STRDATA_LENGTH];    //安全员信息
    wis_u8   Safetyuser_password[STRDATA_LENGTH];    //安全员密码

}__attribute__((packed, aligned(1))) Safetyuser_card_info;


typedef struct  UI_MainShowInfo            //主界面显示信息
{
    wis_u8 Coach_name[STRDATA_LENGTH];    //教练姓名
    //wis_u8 Coach_stars;     //教练星级
    wis_u16   Totaltime;  //总培训学时
    wis_u8 Leaner_name[STRDATA_LENGTH];    //学员姓名
    wis_u32 TrainSubject;     //训练科目
    wis_u16 finishtime;//19	当前培训部分已完成学时	WORD	单位：min
    wis_u16 finishmile;//23	当前培训部分已完成里程	WORD	单位：1/10km

}__attribute__((packed, aligned(1))) UI_MainShowInfo;

typedef struct  UI_VideoInfo         //video设置
{
    wis_u32 nettype;    //网络类型
    wis_u8 dialnum[4];     //拨号类型
    wis_u8 passwd[4];    //拨号密码
    wis_u8 apn[15];     //接入点名称
    wis_u32 dial_port;//接入端口
    wis_u32 status_port;//状态端口

}__attribute__((packed, aligned(1))) UI_VideoInfo;


typedef struct UI_CommunicateMainSet//通信设置
{
    wis_u32 Client_Heartbeat_Sec;// 0x0001 客户端心跳发送间隔，单位为秒(s)
    wis_u32 Tcp_Reply_Sec;// 0x0002 TCP消息应答超时时间，单位为秒(s)
    wis_u32 Tcp_Retransmission;// 0x0003 TCP消息重传次数
    wis_u32 Udp_Reply_Sec;// 0x0004 UDP消息应答超时时间，单位为秒(s)
    wis_u32 Udp_Retransmission;// 0x0005 UDP消息重传次数
    wis_u32 SMS_Reply_Sec;// 0x0006 SMS消息应答超时时间，单位为秒(s)
    wis_u32 SMS_Retransmission;// 0x0007 SMS消息重传次数
                                                        //0x0008-0x000f 保留
}__attribute__((packed, aligned(1)))  UI_CommunicateMainSet;//通信设置

typedef struct UI_NetSet//网络参数设置
{
    wis_u8 Mainserver_APN[STRDATA_LENGTH];// 0x0010 主服务器APN，无线通信拨号访问点。若网络制式为CDMA，则该处为PPP拨号号码
    wis_u8 Mainserver_User[STRDATA_LENGTH];// 0x0011 主服务器无线通信拨号用户名
    wis_u8 Mainserver_Password[STRDATA_LENGTH];// 0x0012 主服务器无线通信拨号密码
    wis_u8 Mainserver_IP[STRDATA_LENGTH];// 0x0013 主服务器地址，IP或域名
    wis_u8 Backupserver_APN[STRDATA_LENGTH];// 0x0014 备份服务器APN，无线通信拨号访问点
    wis_u8 Backupserver_User[STRDATA_LENGTH];// 0x0015 备份服务器无线通信拨号用户名
    wis_u8 Backupserver_Password[STRDATA_LENGTH];// 0x0016 备份服务器无线通信拨号密码
    wis_u8 Backupserver_IP[STRDATA_LENGTH];// 0x0017 备份服务器地址，IP或域名
    wis_u32 Server_TCP_Port;// 0x0018 服务器TCP端口
    wis_u32 Server_UDP_Port;// 0x0019 服务器UDP端口
                                        //0x001a-0x001f  保留
}__attribute__((packed, aligned(1)))  UI_NetSet;//网络参数设置

typedef struct UI_ReportMainSet//汇报设置如下
{
    wis_u32 Location_Report_Way;// 0x0020 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报
    wis_u32 Location_Report_Status;// 0x0021 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态
    wis_u32 Dri_Unlisted_Time_Report;// 0x0022 驾驶员未登录汇报时间间隔，单位为秒(s),>0
                                                                //0x0023-0x0026  保留
    wis_u32 Dormant_Time_Report;// 0x0027 休眠时汇报时间间隔，单位为秒(s),>0
    wis_u32 Emergency_Alarm_Time_Report;// 0x0028 紧急报警时汇报时间间隔，单位为秒(s),>0
    wis_u32 Default_Time_Report;// 0x0029 缺省时间汇报间隔，单位为秒(s),>0
                                                //0x002A-0x002B 保留
    wis_u32 Default_Distance_Report;// 0x002C 缺省距离汇报间隔，单位为米(m),>0
    wis_u32 Dri_Unlisted_Distance_Report;// 0x002D 驾驶员未登录汇报距离间隔，单位为米(m),>0
    wis_u32 Dormant_Distance_Report;// 0x002E 休眠时汇报距离间隔，单位为米(m),>0
    wis_u32 Emergency_Alarm_Distance_Report;// 0x002F 紧急报警时汇报距离间隔，单位为米(m),>0
    wis_u32 Inflection_Point;// 0x0030 拐点补传角度，<180°
                                                //0x0031-0x003F 保留
}__attribute__((packed, aligned(1)))  UI_ReportMainSet;//汇报设置如下

typedef struct UI_ListenMainSet//监听设置
{
    wis_u8 Monitoring_Platform_Phone[STRDATA_LENGTH];// 0x0040 监控平台电话号码
    wis_u8 Reset_Phone[STRDATA_LENGTH];// 0x0041 复位电话号码，可采用此电话号码拨打终端电话让终端复位
    wis_u8 Factory_Reset_Phone[STRDATA_LENGTH];// 0x0042 恢复出厂设置电话号码，可采用此电话号码拨打终端电话让终端恢复出厂设置
    wis_u8 Monitoring_Platform_SMS_Phone[STRDATA_LENGTH];// 0x0043 监控平台SMS电话号码
    wis_u8 Receiving_SMS_Alarm[STRDATA_LENGTH];// 0x0044 接收终端SMS文本报警号码
    wis_u32 Terminal_Phone_Way;// 0x0045 终端电话接听策略，0：自动接听；1：ACCON时自动接听，OFF时手动接听
    wis_u32 Phone_Time;// 0x0046 每次最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
    wis_u32 Phone_Time_Month;// 0x0047 当月最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
    wis_u8 Monitor_Phone[STRDATA_LENGTH];// 0x0048 监听电话号码
    wis_u8 Monitor_Platform_Text_Phone[STRDATA_LENGTH];// 0x0049 监管平台特权短信号码
                                                            //0x004A-0x004F 保留
}__attribute__((packed, aligned(1)))  UI_ListenMainSet;//监听设置

typedef struct UI_ViewthresholdMainSet//摄像与门限设
{
    wis_u32 Alarm_Shield_Byte;          // 0x0050 报警屏蔽字。与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警被屏蔽
    wis_u32 Alarm_Send_SMS_Text;   // 0x0051 报警发送文本SMS开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时发送文本SMS
    wis_u32 Alarm_Picture_Switch;    // 0x0052 报警拍摄开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时摄像头拍摄
    wis_u32 Alarm_Picture_Save;       // 0x0053 报警拍摄存储标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警时牌的照片进行存储，否则实时长传
    wis_u32 Key_Identification;          // 0x0054 关键标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警为关键报警
    wis_u32 High_Speed;                    //0x0055 最高速度，单位为公里每小时(km/h)
    wis_u32 OverSpeed_Time;           // 0x0056 超速持续时间，单位为秒(s)
    wis_u32 Continue_Dri_Time;        // 0x0057 连续驾驶时间门限，单位为秒(s)
    wis_u32 Day_Dri_Time;                 // 0x0058 当天累计驾驶时间门限，单位为秒(s)
    wis_u32 Mini_Reset_Time;            // 0x0059 最小休息时间，单位为秒(s)
    wis_u32 Max_Park_Time;              // 0x005A 最长停车时间，单位为秒(s)
                                                            //0x005B-0x006F 保留
}__attribute__((packed, aligned(1)))  UI_ViewthresholdMainSet;//摄像与门限设

typedef struct UI_OtherMainSet//其他设置
{
    wis_u32 Picture;// 0x0070 图像/视频质量，1-10,1最好
    wis_u32 Lightness;// 0x0071 亮度，0-255
    wis_u32 Contrast;// 0x0072 对比度，0-127
    wis_u32 Saturation;// 0x0073 饱和度，0-127
    wis_u32 Chroma;// 0x0074 色度，0-255
                                   // 0x0075-0x007F 保留
    wis_u32 Car_Meilage;// 0x0080 车辆里程表读数，1/10km
    wis_u16 Province_ID;// 0x0081 车辆所在的省域ID
    wis_u16 City_ID;// 0x0082 车辆所在的市域ID
    wis_u8  Motor_Plate[PLATE_LEN];// 0x0083 公安交通管理部门颁发的机动车号牌
    wis_u8  Plate_Color;// 0x0084 车牌颜色，按照JT/T415-2006的5.4.12
    wis_u32 Impulse_Ratio;//0x0085 车辆脉冲系数，车辆行驶1km距离过程中产生的脉冲信号个数
}__attribute__((packed, aligned(1)))  UI_OtherMainSet;//其他设置

//支付相关
typedef struct UI_TrainTimeCost     //学时和消费 二维码数据
{
    wis_u32 trainTime;      //学时  单位：分
    double  trainCost;      //消费   单位：元
    wis_u8  learnerid[20] ;    //学员员编号   BYTE[16]
    wis_u8  devicenum[20];   //设备编号
    wis_u32  classid;     //课堂ID
    wis_u32  fee_count;  //计费分钟数
    wis_u8   subjcode[20];     //课程编码
}__attribute__((packed, aligned(1)))  UI_TrainTimeCost;

//图像加水印
//typedef struct UI_PhotoAddWater    //
//{
//    double  lantitude;      //经度
//    double lontitude;      //维度
//    int gpsspeed;//GPS
//    int roletype;//0 是教练 ，1是学员
//    std::string photopath;//照片路径
//    std::string watertime;
//}  UI_PhotoAddWater;

//typedef int (*ImageCallback)(UI_PhotoAddWater *photoWater,void *opaque);

#endif // UI_STRUCTS

