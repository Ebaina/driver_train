#ifndef SETTINGINTERFACE_H
#define SETTINGINTERFACE_H
#include "ui_structs.h"
//#include "datastructdef.h"

namespace WIS_UI{
class SettingInterface
{
public:
    explicit SettingInterface() {}
   ~ SettingInterface(){}
    //更新注册时 管理员信息  0
    virtual void updateAdminCardInfo(User_card_info user_card_info)=0;
    /**
  *@brief  callback reg ack
  *1.当进度条为0%时为：                      正在连接中心
  *2.当连接中心成功后更新到10%：        连接中心成功
  *3.设备提交注册信息更新到30%--40%：等待接收中心验证
  *4.中心验证成功更新到50%：               中心验证成功
  *5.中心验证失败直接100%：                中心验证失败
  *6.验证成功后获取注册信息更新到90%：正在保存注册信息
  *7.更新到100%：                                   信息保存成功
  *8.成功一秒，跳入注册成功页面
  *9.刷卡超时接口
  * 状态采用枚举 RegisterStatus
  */
    virtual void updateRegisterAckState(unsigned char state) = 0;


};
}

#endif // SETTINGINTERFACE_H

