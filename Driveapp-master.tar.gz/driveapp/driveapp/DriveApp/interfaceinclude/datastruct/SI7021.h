﻿#ifndef	_SI7021_H
#define	_SI7021_H

#include "stdtype.h"

#define	WRITE_CMD		0x80
#define	READ_CDM		0x81
#define	SALVE_ADDR		0x80

#define	HUMI_HOLD_MASTER	0xE5
#define	TEMP_HOLD_MASTER	0xE3
		
#define	HUMI_NOHOLD_MASTER	0xF5
#define	TEMP_NOHOLD_MASTER	0xF3



void SI7021_SCLK_HIGH();
void SI7021_SCLK_LOW();
void SI7021_SDA_HIGH();
void SI7021_SDA_LOW();
void delay_x_us ();
void start_i2c ( void );
void stop_i2c ( void );
unsigned char send_1byte ( unsigned char send_data );
unsigned char read_1byte ( void );
void master_i2c_ack ( void );
void master_i2c_noack ( void );
void measure_si7021 ( unsigned char model, union16 *value );



#endif//ifndef	_SI7021_H
