/******************************************************************************
*******************************************************************************/
#ifndef __DIRECTORY_H__
#define __DIRECTORY_H__

#include <vector>
#include <iostream>
using namespace std;

/**
 *  \file   Directory.h   
 *  \class  Directory
 *  \brief  文件目录类.
 */
class Directory{
public:
    Directory();
    ~Directory();
    static bool isEmpty(const char* name);
    static bool isExist(const char* name);
    static int getContentSize(const char* name);
    bool enter(const string& path);
    string current();
    vector<string> listAll(); 
private:
    string m_currentPath;
};

#endif
