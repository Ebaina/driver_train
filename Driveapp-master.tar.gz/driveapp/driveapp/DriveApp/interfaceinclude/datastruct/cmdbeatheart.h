﻿#ifndef CMDBEATHEART_H
#define CMDBEATHEART_H
#include "CmdBase.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/
#define CMD_T2P_BEATHEART   0x0002
class CmdBeatHeart : public BaseCmd
{
public:
    CmdBeatHeart(sp_gateway *m):BaseCmd(m){
        m_CmdName = "beatheart";
        m_Cmd = CMD_T2P_BEATHEART;
    }
private:

public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);
};

#endif    // CMDBEATHEART_H
