﻿#ifndef CMD_DOWN_COMMON_ACK_H
#define CMD_DOWN_COMMON_ACK_H
#include "CmdBase.h"


#define CMD_P2T_BEATHEART_ACK   0x8001
typedef struct
{
   unsigned short REPLY_FLOW_ID;  //应答流水号
   unsigned short Response_ID;      //应答ID
   unsigned char  Response_Result;  //结果
}__attribute__((packed, aligned(1)))down_common_Info;

class CmdCommonAckD : public BaseCmd
{
public:
      CmdCommonAckD(sp_gateway *m):BaseCmd(m){
        m_CmdName = "beatheartack";
        m_Cmd = CMD_P2T_BEATHEART_ACK;
    }
private:

public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);
};

#endif    // CMDBEATHEART_H
