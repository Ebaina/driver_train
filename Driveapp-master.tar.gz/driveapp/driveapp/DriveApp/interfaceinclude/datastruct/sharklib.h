#ifndef SHARKLIB_H
#define SHARKLIB_H


class SharkLib
{

public:
    SharkLib();
};

#endif // SHARKLIB_H
