/******************************************************************************

  Copyright (C), 2013-2015, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     : gps.h gps.c
  Version       : Initial
  Author        : NanJing Wisdom Shark BU
  Created       : 2013/7/1
  Last Modified :
  Description   :
  Function List :
  History       :
  1.Date        : 2013/7/1
    Author      : david
    Modification: Created file

******************************************************************************/
#ifndef WIS_MUTEX_H
#define WIS_MUTEX_H
#include <pthread.h>
class WisMutex
{
public:
     WisMutex();
    ~WisMutex();
    void lock();
    void unlock();
private:
    pthread_mutex_t mtx;
};

#endif
