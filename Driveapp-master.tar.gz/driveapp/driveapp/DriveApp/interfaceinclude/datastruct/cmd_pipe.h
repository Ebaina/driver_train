﻿#ifndef _CMD_PIPE_H
#define _CMD_PIPE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

#include "ctime.h"
#include "clog.h"
#include "gateway.h"
#include "CmdBase.h"
#include "cmd.h"


using namespace std;

extern long counter;

static void timer_notify(int signum);

class CmdPP
{
public:
    CmdPP() {}
private:
    CTimerpp m_timer;
    stSendCmdPiPe m_cmdlist[10];        //各自缓冲10条
    stRecvCmdPiPe m_cmdRecvlist[10];    //各自缓存10条
    pthread_t p_Thread;

    sp_gateway * p_gateway;
    static void *Timer_RefreshThread(void *param);

    int Parser_Cmd(char *buf,int len,char *pos,int len2);

public:
    void chooseGetAckType(char * indata,int length);//选择格式化对象

    void init_pipe(void *param);
    int UnTranMain_cmd(char *buf, int l, char *out, int l2);
    int Proc_Ack_Data();
    char Xor(char *buf, int len);
    //填充一个发送结构
    //该指令在命令管理器中发送几次，是否需要等待应答
    void  Receive_OneCmd(stRecvCmdPiPe data);
    void  Send_OneCmd(stSendCmdPiPe data,int times,bool ack);

};

#endif
