/******************************************************************************
 * This file is part of libemb.

*******************************************************************************/
#ifndef __SQLITEWRAPPER_H__
#define __SQLITEWRAPPER_H__

#ifdef OS_CYGWIN
#else
#include  <sqlite3.h>
#include "DataBase.h"
#include "Mutex.h"

/**
 *  \file   SqliteWrapper.h   
 *  \class  SqliteWrapper
 *  \brief  Sqlite��װ����	
 */
class SqliteWrapper:public DataBase{
public:
    SqliteWrapper();
    ~SqliteWrapper();
    bool open(std::string dbName);
    bool connect(std::string user, std::string passwd);
    bool close();
    bool exec(const std::string& sql, SqlResult_S* result=NULL);
    bool insertBlob(const std::string& sql,std::string bindVarName,char* buf, int len);
    bool selectBlob(const std::string& sql,std::string bindVarName,char* buf, int &len);
private:
    sqlite3* m_db;
    MutexLock m_dbLock;
};
#endif
#endif
