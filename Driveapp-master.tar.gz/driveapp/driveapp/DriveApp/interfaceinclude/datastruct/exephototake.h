﻿#ifndef EXEPHOTOTAKE_H
#define EXEPHOTOTAKE_H
#include "stdtype.h"
#include "CmdBase.h"
#include "exedatapass.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/

/***********************
 * 立即拍照
透传消息ID：0x8301
应答属性:0x01***********/
/***************************
*表A.45　立即拍照消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	上传模式	BYTE	1：自动请求上传
***************255：停止拍摄并上传图片
*1	摄像头通道号	BYTE	0：自动
****************1~255：表示通道号
*2	图片尺寸	BYTE	0x01：320×240；
*****************0x02：640×480；
*****************0x03：800×600；
*****************0x04：1024×768；
*****************0x05：176×144[Qcif]；
*****************0x06：352×288[Cif]；
*****************0x07：704×288[HALF D1]；
*****************0x08：704×576[D1]；
*注：终端若不支持系统要求的分辨率，则取最接近的分辨率拍摄并上传
*************************************************/
#define CMD_P2T_ASKTAKEPHOTONOW_DWON  0x8301
typedef struct Asktakephotonow_Down{
wis_u8 uploadmode;//0	上传模式	BYTE	1：自动请求上传
wis_u8 camerachannel;//1	摄像头通道号	BYTE	0：自动
wis_u8 photosize;//2	图片尺寸	BYTE	0x01：320×240；
 }__attribute__((packed, aligned(1))) Asktakephotonow_Down;


/*
A.4.2.3.2　立即拍照应答
透传消息ID：0x0301
客户端使用该消息回复服务器端的立即拍照指令，应答后执行拍照并通过透传消息ID0x0305和0x0306开始上传照片。立即拍照应答消息数据格式见表B.46。
*************************************
表A.46　立即拍照应答消息数据格式
起始字节	字段	数据类型	描述及要求
0	执行结果	BYTE	1：可以拍摄；
***************2：拍照失败；
***************3：SD卡故障；
***************4：正在拍照，不能执行；
***************5：重新连接摄像头，不能保证拍照；
***************6：正在上传查询照片，不能执行。
1	上传模式	BYTE	与下行命令一致
2	摄像头通道号	BYTE	实际拍摄的通道号
3	图片实际尺寸	BYTE	0x01：320×240；
*******************0x02：640×480；
*******************0x03：800×600；
*******************0x04：1024×768；
*******************0x05：176×144[Qcif]；
*******************0x06：352×288[Cif]；
*******************0x07：704×288[HALF D1]；
*******************0x08：704×576[D1]；
注：终端若不支持系统要求的分辨率，则取最接近的分辨率拍摄并上传
*************************************************/
#define CMD_T2P_ASKTAKEPHOTONOW_UP  0x0301
typedef struct Asktakephotonow_Up{
wis_u8 operateresult;//0	执行结果	BYTE	1：可以拍摄；
wis_u8 uploadmode;//1	上传模式	BYTE	与下行命令一致
wis_u8 camerachannel;//2	摄像头通道号	BYTE	实际拍摄的通道号
wis_u8 photosize;//3	图片实际尺寸	BYTE	0x01：320×240；
 }__attribute__((packed, aligned(1))) Asktakephotonow_Up;




/********************************8
*'A.4.2.3.3　查询照片
*透传消息ID：0x8302
*应答属性：0x01
*服务器端下发查询指令请求查询客户端存储的照片，查询照片消息数据格式见表B.47。
*************************************
*表A.47　查询照片消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	查询方式	BYTE	1：按时间查询
*1	查询开始时间	BCD[6]	YYMMDDhhmmss
*7	查询结束时间	BCD[6]	YYMMDDhhmmss
*************************************************/
#define CMD_P2T_ASKSEARCHPHOTO_DOWN 0x8302
typedef struct {
wis_u8 searchtype;//0	查询方式	BYTE	1：按时间查询
wis_u8 searchstart[6];//1	查询开始时间	BCD[6]	YYMMDDhhmmss
wis_u8 searchend[6];//7	查询结束时间	BCD[6]	YYMMDDhhmmss
  }__attribute__((packed, aligned(1))) Searchphoto_Down;


/*
.4.2.3.4　查询照片应答
*透传消息ID：0x0302
*客户端使用该消息回复服务器端下发的查询照片指令，终端应答后开始查询，并通过透传消息ID0x0303开始反馈查询结果。查询照片应答消息数据格式见表B.48。
*表A.48　查询照片应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	执行结果	BYTE	1：开始查询
*2：执行失败
*************************************************/
#define CMD_T2P_SEARCHPHOTO_UP 0x0302
typedef struct Searchphoto_Up{
wis_u8 operateresult;//0	执行结果	BYTE	1：开始查询
}__attribute__((packed, aligned(1))) Searchphoto_Up;



class exeAsktakephotonow : public BaseCmd
{
public:
    exeAsktakephotonow(sp_gateway *m):BaseCmd(m){
        m_CmdName = "asktakephotonow";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};




class exeSearchphoto : public BaseCmd
{
public:
    exeSearchphoto(sp_gateway *m):BaseCmd(m){
        m_CmdName = "Searchphoto";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};



#endif // EXEPHOTOTAKE_H
