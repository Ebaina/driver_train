/******************************************************************************
*******************************************************************************/
#ifndef __CMDEXECUTER_H__
#define __CMDEXECUTER_H__

/**
 *  \file   CmdExecuter.h   
 *  \class  CmdExecuter
 *  \brief  命令执行器类.
 */

#include "stdtype.h"
class CmdExecuter{
public:
    CmdExecuter(){};
    ~CmdExecuter(){};
    static int execute(std::string cmd, char* result, int len);
};

#endif
