﻿#ifndef COMMON_RESPONSE_ACK
#define COMMON_RESPONSE_ACK
#include "CmdBase.h"

#define CMD_T2P_COMMON_ACK    0x0001      //终端通用回复
#define CMD_P2T_COMMONDOWN_ACK    0x8001    //平台通用回复
typedef struct
{
   unsigned short REPLY_FLOW_ID;  //应答流水号
   unsigned short Response_ID;      //应答ID
   unsigned char  Response_Result;  //结果
}__attribute__((packed, aligned(1)))common_Info;   //终端通用回复信息

typedef struct
{
   unsigned short REPLY_FLOW_ID;  //应答流水号
   unsigned short Response_ID;      //应答ID
   unsigned char  Response_Result;  //结果
}__attribute__((packed, aligned(1)))down_common_Info; //平台通用回复信息


class Cmd_common : public BaseCmd
{
public:
    Cmd_common(sp_gateway *m):BaseCmd(m){
        m_CmdName = "common_response";
        m_Cmd = CMD_T2P_COMMON_ACK;}
private:

public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);
};


#endif // COMMON_RESPONSE_ACK

