﻿#ifndef EXEIDENTITYCHECK_H
#define EXEIDENTITYCHECK_H
#include "stdtype.h"
#include "CmdBase.h"
#include "exedatapass.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/
/************************************
*A.4.2.5.1　请求身份认证信息
*透传信息ID: 0x0401
*应答属性：0x01
*请求身份认证信息消息数据格式见表B.61。
*表A.61　请求身份认证信息消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	请求信息类型	BYTE	1：指纹；
*2：二维码；
*3：声纹；
*4：人脸图像。
*1	请求人员类型	BYTE	1：教练员；
*2：考核员；
*3：安全员；
*4：学员。
*2	身份证号码	BYTE[18]	ASCII码，不足18位前补0x00
************************************************/

#define  CMD_T2P_IDENTITYCHECKDATA 0x0401
typedef  struct Identitycheckdata_Up{
wis_u8  infogettype;//0	请求信息类型	BYTE	1：指纹；
wis_u8  operateresult;//1	请求人员类型	BYTE	1：教练员；
wis_u8  identityid[18];//2	身份证号码	BYTE[18]	ASCII码，不足18位前补0x00
 }__attribute__((packed, aligned(1))) Identitycheckdata_Up;





/*********************************8
*透传消息ID：0x8401
*请求身份认证信息应答消息数据格式见表B.62。
*表A.62　请求身份认证信息应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	驾培包序号	WORD	对应请求身份认证信息消息的包序号
*2	查询结果	BYTE	0：成功；1：失败（失败时无后续字段）
*3	身份认证信息长度	DWORD	长度为n
*7	身份认证信息内容	BYTE[n]
**********************************/



#define CMD_P2T_IDENTITYCHECKDATA  0x8401
typedef struct Identitycheckdata_Down{
wis_u16 drivingpackgenum;//0	驾培包序号	WORD	对应请求身份认证信息消息的包序号
wis_u8 searcgresult;//2	查询结果	BYTE	0：成功；1：失败（失败时无后续字段）
wis_u32 identitychecklenth;//3	身份认证信息长度	DWORD	长度为n
wis_u8 identitycheckdata[20];//7	身份认证信息内容	BYTE[n]
 }__attribute__((packed, aligned(1)))  Identitycheckdata_Down;




/************************************
*A.4.2.5.3　请求统一编号信息
*透传信息ID: 0x0402
*应答属性：0x01
*请求统一编号信息消息数据格式见表B.63。
*表A.63　请求统一编号信息消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	统一编号类型	BYTE	1：当前驾培机构；
*2：教练员；
*3：考核员；
*4：安全员；
*5：当前教练车；
*6：学员；
*7：本计时终端。
*1	统一编号检索字段	BYTE[18]	根据统一编号类型（type）确定字段内容，
*type =1、5、7时，置空，请求该终端所属培训机构、教练车、自身的统一编号；
*type =2、3、4、6时，为身份证号。
************************************************/

#define CMD_T2P_ASKNIFYNUM  0x0402
typedef struct Asknifynum_Up{
wis_u8 operateresult;//0	统一编号类型	BYTE	1：当前驾培机构；
                                                //2：教练员；
                                                //3：考核员；
                                                //4：安全员；
                                                //5：当前教练车；
                                                //6：学员；
                                                //7：本计时终端。
wis_u8 uniformtype;//统一编号检索字段
 }__attribute__((packed, aligned(1))) Asknifynum_Up;





/************************************
*A.4.2.5.4　请求统一编号信息应答
*透传消息ID：0x8402
*请求统一编号信息应答消息数据格式见表B.64。
*表A.64　请求统一编号信息应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	驾培包序号	WORD	对应请求统一编号信息消息的包序号
*2	查询结果	BYTE	0：成功；1：失败（失败时无后续字段）
*3	统一编号	BYTE[16]		统一编号
*19	准（教/考）车型	BYTE[2]		A1\A2\A3\B1\B2\C1\C2\C3\C4\D\E\F，非教学人员时用0x00填充
************************************************/
#define CMD_P2T_ASKUNIFYNUM  0x8402
typedef struct Askunifynum_Down{
wis_u16   driveingpackagenum;//0	驾培包序号	WORD	对应请求统一编号信息消息的包序号
wis_u8 searchresult;//2	查询结果	BYTE	0：成功；1：失败（失败时无后续字段）
wis_u8 uniformnumber[16];//3	统一编号	BYTE[16]		统一编号
wis_u8 permitedcartype[2];//19	准（教/考）车型	BYTE[2]		A1\A2\A3\B1\B2\C1\C2\C3\C4\D\E\F，非教学人员时用0x00填充
 }__attribute__((packed, aligned(1)))  Askunifynum_Down;




class exeAskIdentityCheck : public BaseCmd
{
public:
    exeAskIdentityCheck(sp_gateway *m):BaseCmd(m){
        m_CmdName = "identitycheckdata";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};




class exeAskunifynum : public BaseCmd
{
public:
    exeAskunifynum(sp_gateway *m):BaseCmd(m){
        m_CmdName = "askunifynum";
        m_Cmd = CMD_T2P_DATAPASSUP;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};
#endif // EXEIDENTITYCHECK_H
