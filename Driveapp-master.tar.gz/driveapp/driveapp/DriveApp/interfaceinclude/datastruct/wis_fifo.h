﻿/******************************************************************************

  Copyright (C), 2013-2015, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     : gps.h gps.c
  Version       : Initial
  Author        : NanJing Wisdom Shark BU
  Created       : 2013/7/1
  Last Modified :
  Description   :
  Function List :
  History       :
  1.Date        : 2013/7/1
    Author      : david
    Modification: Created file

******************************************************************************/
#ifndef WIS_FIFO_H
#define WIS_FIFO_H
#include"wis_mutex.h"

#define MAX_FIFO_LEN 4096

class Wisfifo
{
public:
    Wisfifo();
    ~Wisfifo();
private:
    char *pBuffer;
    char *pIn;
    char *pOut;
    int count;
    int len_fifo;
    WisMutex *pMtx;

public:
    int ReadFifo(char *cp,int cp_len);
    int SeekPoint(int len);
    int WriteFifo(char *data,int len);
};

#endif
