#ifndef _TCPCLIENT_H_
#define _TCPCLIENT_H_
#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <sys/time.h>
#include  <string.h>
#include  <sys/types.h>
#include  <sys/socket.h>
#include  <sys/ioctl.h>
#include  <sys/ipc.h>
#include  <sys/msg.h>
#include  <netinet/in.h>
#include  <arpa/inet.h>
#include  <pthread.h>
#include  <netdb.h>
#include "clog.h"

#define BUFFER_SEND_SIZE 1024*16
#define BUFFER_RECV_SIZE 1024*16

#define MAX_NTCP_BUFFER  1024

typedef void (*Recv_callback)(char *buf,int len,void *param);

class nTcp_Client
{
public:
    nTcp_Client();
    ~nTcp_Client();
private:
    int fd_client;
    sockaddr_in l_server;
    sockaddr_in l_remote;
    Recv_callback p_fun;
    fd_set	fdset;

    bool is_ok;
    bool m_reConnect;

    int m_mode;

    void *m_param;

    pthread_t p_rcvThread;
    pthread_t p_watchThread;

    static void *nTcp_RcvThread(void *param);
    static void *nTcp_WatchMan(void *param);
    //step 1
    bool nTcp_SetParam(char *ip,int port);

    bool nTcp_Connect();

    char m_ServerIP[32];
    int m_Port;
public:
    /*
        函数说明: 建立tcp链接
        参数说明: ip建立tcp的server ip，port：server 的端口，
                 Recv_callback，如果是异步模式注册接收函数 ，返回端口读回的数据
                 sync： 0,为同步模式 ，1,为异步模式
        返回值:
                 bool： true成功 ，false失败
    */
    bool nTcp_LinkServer(char *ip,int port,Recv_callback b_fun,int sync,void *param);

    int nTcp_Send(char *buff,int l_buff);

    int nTcp_Recv(char* buff,int l_buff,long timeout);


};

#endif
