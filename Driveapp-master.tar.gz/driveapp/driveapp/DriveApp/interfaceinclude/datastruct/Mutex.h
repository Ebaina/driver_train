/******************************************************************************
*******************************************************************************/
#ifndef __MUTEXLOCK_H__
#define __MUTEXLOCK_H__

#include "stdtype.h"
#include <pthread.h>

/**
 *  \file   Mutex.h   
 *  \class  MutexLock
 *  \brief  互斥锁类	
 */
class MutexLock{
public:
    MutexLock();
    ~MutexLock();
    int lock();
    int unLock();
    int tryLock();
private:
    pthread_mutex_t m_mutex;
friend class MutexCond;
};
/**
 *  \file   Mutex.h   
 *  \class  AutoLock
 *  \brief  自动释放的互斥锁类	
 */
class AutoLock{
public:
    AutoLock(MutexLock* mutexLock);
    virtual ~AutoLock();
private:
    MutexLock* m_mutexLock;
};

/**
 *  \file   Mutex.h   
 *  \class  MutexCond
 *  \brief  条件变量
 */
class MutexCond{
public:
    MutexCond(MutexLock* lock);
    ~MutexCond();
    void wait();
    void meet();
private:
    MutexLock* m_lock;
    pthread_cond_t m_cond;
};

#endif
