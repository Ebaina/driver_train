﻿#ifndef EXEREQUESTPACKAGEAGAIN_H
#define EXEREQUESTPACKAGEAGAIN_H

#include "CmdBase.h"
#include "stdtype.h"

# define CMD_P2T_REQUESTPACKAGEAGAIN    0x8003
/*
 * 补传分包请求
*/
/*************************************************
原始消息流水号	WORD	对应要求补传的原始消息第一包的消息流水号
重传包总数	BYTE	n
重传包ID列表	BYTE[2*n]	重传包序号顺序排列，如“包ID1包ID2……包IDn
************************************************/
typedef struct requestpackageinfo
{
    wis_u16 origialinfoID;  //原始消息流水号
    wis_u8  requestpackagenum;      //重传包总数
    wis_u8  requestpackageID[512];  //重传包ID列表

}__attribute__((packed, aligned(1))) requestpackageinfo;

class exerequestpackageagain : public BaseCmd
{
public:
    exerequestpackageagain(sp_gateway *m):BaseCmd(m){
    m_CmdName = "requestpackageagain";
    m_Cmd = CMD_P2T_REQUESTPACKAGEAGAIN;
    }
private:
public:
    int ack_cmd(void *param);

    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);
};

#endif // EXEREQUESTPACKAGEAGAIN_H
