﻿#ifndef _CTIME_H_
#define _CTIME_H_
#include "clog.h"



typedef void(*ProcessHandler)(int);

class CTimerpp{
protected:
        struct sigaction  _act;
        struct sigaction  _oldact;
        struct itimerval  _tim_ticks;
        void wait( long timeout_ms ){
                struct timespec spec;
                spec.tv_sec  = timeout_ms / 1000;
                spec.tv_nsec = (timeout_ms % 1000) * 1000000;
                nanosleep(&spec,NULL);
        }
public:
        CTimerpp(){

        }
        void initTimer(int sec,int usec){
            _tim_ticks.it_value.tv_sec = sec;
            _tim_ticks.it_value.tv_usec = usec;
            _tim_ticks.it_interval.tv_sec = sec;
            _tim_ticks.it_interval.tv_usec = usec;
        }
        void setHandler(ProcessHandler handler){
                sigemptyset( &_act.sa_mask );
                _act.sa_flags = 0;
                _act.sa_handler = handler;
        }
        bool reset(){

                int res = sigaction( SIGALRM, &_act, &_oldact );
                if ( res ) {
                        //wlog(WIS_ERROR,"Fail to install handle: " );
                        return false;
                }
                res = setitimer( ITIMER_REAL, &_tim_ticks, 0 );
                if(res){
                        //wlog(WIS_ERROR, "Fail to set timer: " );
                        sigaction( SIGALRM, &_oldact, 0 );
                        return false;

                }
                return true;
         }

};
#endif
