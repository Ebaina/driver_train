#ifndef EXEAUTHORITY_H
#define EXEAUTHORITY_H
#include "CmdBase.h"
#include "stdtype.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/
/*****************************************
*消息ID：0x0102
*计时终端使用此消息日常登录到计时平台，鉴权终端鉴权消息体数据格式见表B.11。
*表A.11　鉴权信息消息体
*起始字节	字段	数据类型	描述及要求
*0	时间戳	DWORD	从格林威治时间1970年01月01日00时00分00秒起至现在的总秒数
*4	鉴权密文	STRINGBYTE[256]	使用终端证书通过加密算法对（计时终端编号、时间戳）进行加密
*注：多次鉴权中不应使用同一个时间戳进行加密，否则平台返回相应错误码。
*************************************/
/**鉴权信息*/
typedef struct shark_authority_up
{
    wis_u32 timestamp;//时间戳
    wis_u8  encryptdata[256];//加密数据

}__attribute__((packed, aligned(1))) shark_authority_up;

# define CMD_T2P_AUTHORITY 0x0102
class exeAuthority: public BaseCmd
{
public:
    exeAuthority(sp_gateway *m):BaseCmd(m){
        m_CmdName = "Authority";
        m_Cmd = CMD_T2P_AUTHORITY;
    }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};
#endif
