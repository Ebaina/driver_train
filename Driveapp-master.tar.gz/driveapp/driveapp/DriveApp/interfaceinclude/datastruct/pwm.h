﻿#ifndef	_PWM_H
#define	_PWM_H

char pwm_str[64];
char pwm_buf[10];
void enable_pwm(void);
void set_pwm_period(int period);
void set_pwm_duty_cycle(int duty_cycle);







#endif
