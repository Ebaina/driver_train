#ifndef COMMUNICATEPLATFORM_H
#define COMMUNICATEPLATFORM_H
#include "Thread.h"
#include "uart.h"

//和平台通信


class Communicateplatform
{
    public:
     Communicateplatform();
    ~Communicateplatform();
     void Init_Data(void);
     void StartSendHeart(void);

};

#endif //
