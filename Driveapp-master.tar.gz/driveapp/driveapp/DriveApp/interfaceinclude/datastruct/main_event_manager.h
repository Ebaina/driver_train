#ifndef MAIN_EVENT_MANAGER_H
#define MAIN_EVENT_MANAGER_H
#include "Event.h"
class  AckReciceEventListioner:public  EventListner{

public :
    void handleEvent(Event &evt );
};

class  AckSendEvent:public  EventCenter{
public :


};


#endif // MAIN_EVENT_MANAGER_H
