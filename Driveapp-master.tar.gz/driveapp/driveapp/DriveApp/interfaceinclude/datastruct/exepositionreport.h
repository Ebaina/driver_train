﻿#ifndef EXEPOSITIONREPORT_H
#define EXEPOSITIONREPORT_H

#include "CmdBase.h"
#include "stdtype.h"
# define CMD_T2P_POSITIONREPORT           0x0200          //位置信息汇报
# define CMD_P2T_ASKPOSITION                  0x8201           //位置信息查询
# define CMD_T2P_ASKPOSITIONREPORT     0x0201           //位置信息查询上报
# define CMD_P2T_TMPLOCATIONCONTROL    0x8202       // 临时位置跟踪控制
/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/

/***********************************
*起始字节	字段	数据类型	描述及要求
*0	报警标识	DWORD	报警标识位定义见表B.22
*1	状态	DWORD	状态位定义见表B.23
*8	纬度	DWORD	以度为单位的纬度值乘以10的6次方，精确到百万分之一度
*12	经度	DWORD	以度为单位的纬度值乘以10的6次方，精确到百万分之一度
*16	行驶记录速度	WORD	行驶记录功能获取的速度，1/10km/h
*18	卫星定位速度	WORD	1/10km/h
*20	方向	WORD	0-359，正北为0，顺时针
*21	时间	BCD[6]	YYMMDDhhmmss(GMT+8时间，本规范之后涉及的时间均采用此时区)
*********************************************/



typedef struct PositionReport_up{
wis_u32 alarmflag;//0	报警标识	DWORD	报警标识位定义见表B.22
wis_u32 status;//1	状态	DWORD	状态位定义见表B.23
wis_u32 longitude;//8	纬度	DWORD	以度为单位的纬度值乘以10的6次方，精确到百万分之一度
wis_u32 latitude;//12	经度	DWORD	以度为单位的纬度值乘以10的6次方，精确到百万分之一度
wis_u16 carspeed;//16	行驶记录速度	WORD	行驶记录功能获取的速度，1/10km/h
wis_u16 satelitespeed;//18	卫星定位速度	WORD	1/10km/h
wis_u16 direction;//20	方向	WORD	0-359，正北为0，顺时针
wis_u8  timestamps[6];//21	时间	BCD[6]	YYMMDDhhmmss(GMT+8时间，本规范之后涉及的时间均采用此时区)
}__attribute__((packed, aligned(1))) PositionReport_up;


/***********B.22************************
*位	定义	处理说明
*0	1：紧急报瞥触动报警开关后触发	收到应答后清零
*1	1：超速报警	标识维持至报警条件解除
*2	1：疲劳驾驶	标识维持至报警条件解除
*3	1：预警	收到应答后清零
*4	1：GNSS模块发生故障	标识维持至报警条件解除
*5	1：GNSS天线未接或被剪断	标识维持至报警条件解除
*6	1：GNSS天线短路	标识维持至报警条件解除
*7	1：终端主电源欠压	标识维持至报警条件解除
*8	1：终端主电源掉电	标识维持至报警条件解除
*9	1：终端LCD或显示器故障	标识维持至报警条件解除
*10	1：TTS模块故障	标识维持至报警条件解除
*11	1：:摄像头故障	标识维持至报警条件解除
*12-17	保留
*18	1：当天累计驾驶超时	标识维持至报警条件解除
*19	1：超时停车	标识维持至报警条件解除
*20	1：进出区域	收到应答后清零
*21	1：进出路线	收到应答后清零
*22	1：路段行驶时间不足/过长	收到应答后清零
*23	1：路线偏离报警	标识维持至报警条件解除
*24	1：车辆VSS故障	标识维持至报警条件解除
*25	1：车辆油量异常	标识维持至报警条件解除
*26	1：车辆被盗(通过车辆防盗器)	标识维持至报警条件解除
*27	1：车辆非法点火	收到应答后清零
*28	1：车辆非法位移	收到应答后清零
*29-31	保留
*********************************************/

/************B.23********************************
*位	状态
*0  	0： ACC关；1：ACC开
*1	0：未定位；1：定位
*2  	0：北纬；1：南纬
*3   	0：东经；1：西经
*4	0：运营状态；1：停运状态
*5	0：经纬度未经保密插件加密；;l：经纬度已经保密插件加密
*6-9	保留
*10    	0：车辆油路正常；1：车辆油路断开
*11  	0：车辆电路正常；1：车辆电路断开
*12	0：车门解锁；1：车门加锁
*13-31	保留
*********************************************/

/**********B.24*************************
*字段	数据类型	描述及要求
*附加信息ID	BYTE	1-255
*附加信息长度	BYTE
*附加信息		附加信息定义见表B.25
*********************************************/

/**********B.25************************* ********
附加信息ID	附加信息长度	描述及要求
0x01	4	里程，DWORD，1/10km，对应车上里程表读书
0x02	2	油量，WORD，1/10L，对应车上油量表读书
0x03	2	海拔高度，单位为m
0x05	2	发动机转速，WORD
*********************************************/

/*********************
*A.3.2.3.18　位置信息查询
*消息ID: 0x8201。
*位置信息查询消息体为空。
*
*
*A.3.2.3.19　位置信息查询应答
*消息ID: 0x0201。
*位置信息查询应答消息体数据格式见表B.29。
*表A.29　位置信息查询应答消息体数据格式
*起始字节	字段	数据类型	描述及要求
*0	位置信息汇报		位置信息汇报见B.3.2.3.16
***********************************/
typedef struct PositionSearcht{
                                  //wis_u8 positionreport;        //0	位置信息汇报		位置信息汇报见B.3.2.3.16
wis_u32 alarmflag;//0	报警标识	DWORD	报警标识位定义见表B.22
wis_u32 status;//1	状态	DWORD	状态位定义见表B.23
wis_u32 longitude;//8	纬度	DWORD	以度为单位的纬度值乘以10的6次方，精确到百万分之一度
wis_u32 latitude;//12	经度	DWORD	以度为单位的纬度值乘以10的6次方，精确到百万分之一度
wis_u16 carspeed;//16	行驶记录速度	WORD	行驶记录功能获取的速度，1/10km/h
wis_u16 satelitespeed;//18	卫星定位速度	WORD	1/10km/h
wis_u16 direction;//20	方向	WORD	0-359，正北为0，顺时针
wis_u8  timestamps[6];//21	时间	BCD[6]	YYMMDDhhmmss(GMT+8时间，本规范之后涉及的时间均采用此时区)
}__attribute__((packed, aligned(1)))  PositionSearch;

/*********************
*A.3.2.3.20　临时位置跟踪控制
*消息ID: 0x8202。
*临时位置跟踪控制消息体数据格式见表B.30。
*表A.30　临时位置跟踪控制消息体数据格式
*起始字节	字段	数据类型	描述及要求
*0	时间间隔	WORD	单位为s，0则停止跟踪。停止跟踪无需带后继字段
*2	位置跟踪有效期	DWORD	单位为s，终端在接收到位置跟踪控制消息后，在有效期截止时间之前，依据消息中的时间间隔发送位置汇报
***********************************/
typedef struct TemppostionControl{
wis_u16 spacetime;        //0	时间间隔	WORD	单位为s，0则停止跟踪。停止跟踪无需带后继字段
wis_u32 positiontracktime;        //2	位置跟踪有效期	DWORD	单位为s，终端在接收到位置跟踪控制消息后，在有效期截止时间之前，依据消息中的时间间隔发送位置汇报
}__attribute__((packed, aligned(1)))  TemppostionControl;

class exePositionReport: public BaseCmd
{
public:
        exePositionReport(sp_gateway *m):BaseCmd(m){
        m_CmdName = "positionreport";
        m_Cmd = CMD_T2P_POSITIONREPORT;
        }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};

class exeSearchPosition: public BaseCmd
{
public:
        exeSearchPosition(sp_gateway *m):BaseCmd(m){
        m_CmdName = "searchposition";
        m_Cmd = CMD_T2P_ASKPOSITIONREPORT;
        }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};
#endif // EXEPOSITIONREPORT_H
