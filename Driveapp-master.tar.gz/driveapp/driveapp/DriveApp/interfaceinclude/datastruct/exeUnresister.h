#ifndef EXEUNRESISTER_H
#define EXEUNRESISTER_H

#include "CmdBase.h"


/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
*A.3.2.3.7　终端注销
*消息ID：0X0003
*计时终端拆除时使用此消息通知计时平台，终端注销消息体为空。
**********************/

# define CMD_T2P_UNREGISTER 0x0003
class exeUnResister: public BaseCmd
{
public:
    exeUnResister(sp_gateway *m):BaseCmd(m){
        m_CmdName = "UnRegister";
        m_Cmd = CMD_T2P_UNREGISTER;
    }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};
#endif
