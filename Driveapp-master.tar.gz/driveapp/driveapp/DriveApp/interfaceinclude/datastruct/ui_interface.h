﻿#ifndef UI_INTERFACE_H
#define UI_INTERFACE_H
#include "ui_structs.h"
#include "settinginterface.h"
#include "logininterface.h"
#include "statusreportinterface.h"
#include "displayinterface.h"

class Ui_Interface
{
public:
    Ui_Interface();

    void setLoginHandler(WIS_UI::LoginInterface *handler);

    void do_init_net();  //初始化网关

    void do_init_cmd(); //初始化cmd,cmdpp


   //UI 注册状态 是否注册 false  true;
    int register_Status();

   // 页面保存状态位
    int pageflag_Status();

   //UI 调用 获取网络配置信息
    UI_NetMainSet get_active_Plartform_Address();

    //UI 调用 设置网络配置信息
    int  set_active_Plartform_Address(UI_NetMainSet netMainSet);
     //是否有教练登陆信息
     int is_Coach_Login(WIS_UI::LoginInterface *loginHandler);

     //是否有学员登陆信息
     int is_Learner_Login(WIS_UI::LoginInterface *loginHandler);

     //是否有教练照片信息
     int is_Coach_Pic();

     //是否有学员照片信息
     int is_Learner_Pic();

     //课程信息选择
     void set_subjectID(int value);

     //开始进入教练与学员登录界面，界面开始响应刷卡动作
     void open_swipe();

     void close_swipe();

     //开启登出刷卡权限
     void open_logout_swipe();

     //关闭登出刷卡权限
     void close_logout_swipe();

     //重启系统
     void reboot_system();

     //注册状态回调类
    void register_statusReportHandler(WIS_UI::StatusReportInterface *reportHandler);

    //注册显示模块回调指针
    void register_display_handler(WIS_UI::DisplayInterface *displayHandler);

    void do_register(UI_StRegInfo mInfo, WIS_UI::SettingInterface *settingHandler);//注册     0100
    void do_unregister(WIS_UI::SettingInterface *settingHandler);//注销  0003


    /***main display info***/
    UI_MainShowInfo get_main_display_info();

    /*record  display info*/
    UI_Learner_record get_record_info();

    /*photo name info*/
    UI_CoachPhotonameSet get_coachphotoname_info();

    UI_LearnerPhotonameSet get_learnerphotoname_info();

    /***start train***/
    void start_train();

    /***pause train***/
    void pause_train();

    /***stop train***/
    void stop_train();

    /***设置音量 ***/
    void set_volume(int value);

    /***获取音量***/
    int  get_volume();

    /***设置亮度***/
    void set_light(int value);

    /***获取亮度***/
    int get_light();

    /***设置通信参数: true: set success; false: set failed***/
    bool set_commun_params(UI_CommunicateMainSet comPara);

    /***获取通信参数***/
    UI_CommunicateMainSet get_commun_params();

    /***设置网络参数***/
    bool set_net_params(UI_NetSet netSet);

    /***获取网络参数***/
    UI_NetSet get_net_params();

    /***设置汇报参数***/
    bool set_report_params(UI_ReportMainSet reportSet);

    /***获取汇报参数***/
    UI_ReportMainSet get_report_params();

    /***设置监控参数***/
    bool set_listen_params(UI_ListenMainSet listenSet);

    /***获取监控参数***/
    UI_ListenMainSet get_listen_params();

    /***设置摄像与门限参数***/
    bool set_view_thres_params(UI_ViewthresholdMainSet viewThresSet);

    /***获取摄像与门限参数***/
    UI_ViewthresholdMainSet get_view_thres_params();

    /***设置其他参数***/
    bool set_others_params(UI_OtherMainSet otherSet);

    /***获取其他参数***/
    UI_OtherMainSet get_others_params();

    /***设置视频参数***/
    bool set_video_params(UI_VideoInfo videoSet);

    /***获取视频参数***/
    UI_VideoInfo get_video_params();


    //支付
    /***请求本次消费时间和金额：这里你们应该只是发出请求，具体数据值应该是回调***/
    /***不能是耗时操作，耗时操作应该放在子线程中，在子线程中回调结果给我***/
    bool request_train_time_and_cost();

    /***请求刷卡支付：这里你们应该只是触发刷卡开关***/
    bool request_poscard_pay();

    /***请求取消刷卡支付：这里你们应该只是关闭刷卡开关***/
    bool request_cancel_poscard_pay();

    /***请求二维码支付数据***/
    UI_TrainTimeCost request_qrcode_data();

    /***请求二取消维码支付***/
    bool request_cancel_qrcode_pay();

    /***获取支付方式***/
    int  get_paytype();

    //temp debug
    void reset_loginstate();

//    void registerWaterCallback(ImageCallback cb, void *opaque);

};






#endif // UI_INTERFACE_H
