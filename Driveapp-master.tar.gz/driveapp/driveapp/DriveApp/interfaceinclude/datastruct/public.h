﻿#ifndef _PUBLIC_H_
#define _PUBLIC_H_
#include "RtcFacade.h"
#include <QString>
#include "stdtype.h"
#include <string>
#define LOG_PATH "/tmp/wis_log%d.txt"
/*
    函数说明: 获取系统时间
    参数说明:
           none
    返回值:
             返回系统时间tick值，单位ms
*/
extern  wis_u8	dataHead[2];
extern  wis_u8	dataRear[2] ;

unsigned long get_tick_count();

long get_timestamp();

int fun_char2bcd(unsigned char *src,unsigned char *dest,int len);
extern void ChangeHexData(std::string data, unsigned char * out );
extern void Test_tool(unsigned char *data,int i,unsigned char value);
QString   uc_to_qs(unsigned char *buf,int len);
extern  char CRC8_Table(char *p, int counter);
extern bool  Get_CheckRcv(char *data,  int rcvSize);
extern void ChangeHexStr2Char(std::string data, unsigned char * out );
extern int Configuration_parameter_set(char  *str_para_name , char *str_para);
extern int  getmaintime3char(RtcTime_S rtc,unsigned char * outdata,int length);

extern int  getmaintime(RtcTime_S rtc,unsigned char * outdata);
extern std::string  getmaintime3string(RtcTime_S rtc,int length);

/*******************************************************************************************
* 计算两个经纬度之间的距离
* 返回值 ：以米为单位的值
* StartLat: 维度  单位 度
* StartLong 经度  单位 度
********************************************************************************************/
double GetDistance(double StartLat,double StartLong,double EndLat,double EndLong);
/******************************************
* 计算两个经纬度之间的距离
* 返回值 ：以米为单位的值
* StartLat: 维度×1000000  单位 度
* StartLong 经度×1000000  单位 度
*******************************************/
double Distance(unsigned int StartLat,unsigned int StartLong,unsigned int EndLat,unsigned int EndLong);
#endif // PUBLIC

