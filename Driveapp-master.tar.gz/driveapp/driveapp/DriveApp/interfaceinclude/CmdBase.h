﻿#ifndef _CMD_BASE_H_
#define _CMD_BASE_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include  <string.h>
#include <iostream>
#include <vector>
#include "gateway.h"
#include "cmd.h"

using namespace std;

#define CMD_OK        0   // 指令发送OK
#define CMD_TIMEOUT   1   // 指令超时
#define CMD_NETERROR  2   // 网络错误
#define CMD_FORMATERR 3  // 格式错误

#define  WIS_TEST  0

enum{ WIS_INT=0,WIS_STR,WIS_BOOL};

enum{ JT808 =0,JT808BD,JDTraining=128};

typedef struct
{
    unsigned short MsgLength:10;
    unsigned short MsgEncrypt:3;
    unsigned short MsgDiv:1;
    unsigned short MsgReserved:2;

}stMsgType;


//}__attribute__((packed, aligned(1)))stMsgType;

typedef struct
{
    unsigned char v_protocol;

    unsigned short Msg_ID;

    stMsgType m;

    unsigned char Dev_PhoneNum[8];

    unsigned short Msg_Seq;

    unsigned char Reserved;
}__attribute__((packed, aligned(1)))MsgHead;

typedef struct
{
    MsgHead m_head;
    unsigned short m_totalPack;   //总包数
    unsigned short m_PackSeq;     //包序号
}MsgHeadExt;

class BaseCmd
{
public:
    BaseCmd(sp_gateway *gate){
        seq =0;
        m_appGateway =gate;
    }
    ~BaseCmd(){}
protected:

    MsgHead m_MsgHead;
    MsgHeadExt m_MsgHeadExt;
    char m_MsgContent;
    unsigned short seq;
    string m_CmdName;

    char * p_content;
    unsigned short m_Cmd;
    sp_gateway *m_appGateway;

public:
     unsigned short Add_Seq(){  seq ++  ;return 0;}//seq ++;test

     unsigned short Get_Seq(){ return seq;} //seq

     unsigned short Get_Cmd(){ return m_Cmd;}
     virtual char Xor(char *buf,int len);
    /*
        函数说明: 转译消息内容
        参数说明: 对参数进行强校验，buf：待转译内容，l：待转译内容长度，out：转译
                完内容，l2:转译存储空间大小
        返回值:
                 int 返回转译后的长度
    */
    virtual  int Trans_cmd(char *buf,int l,char *out,int l2);
    /*
        函数说明: 解转译函数
        参数说明: 对参数进行强校验，buf：待转译内容，l：待转译内容长度，out：转译
                完内容，l2:转译存储空间大小
        返回值:
                 int 返回解转译后的长度
    */
    virtual  int UnTrans_cmd(char *buf,int l, char *out,int l2);
    /*
        函数说明: 格式化消息
        参数说明：
        返回值:
                 int 返回转译后的长度
    */
    virtual int int_cmd(string phonenum) = 0;

    virtual int format_cmd(void *param) =0;

    virtual int exe_cmd(void *param) = 0;

    virtual int ack_cmd(void *param) = 0;
};

#endif
