/******************************************************************************

  Copyright (C), 2013-2015, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     : displayinterface.h
  Version       : Initial
  Author        : NanJing Wisdom Shark BU
  Created       : 2016/1/27
  Last Modified :
  Description   :   display module callback
  Function List :
  History       :
  1.Date        : 2016/1/27
    Author      : galaxy
    Modification: Created file

******************************************************************************/
#ifndef DISPLAYINTERFACE_H
#define DISPLAYINTERFACE_H


namespace WIS_UI {

class DisplayInterface{
public:
    explicit DisplayInterface(){}
    ~DisplayInterface(){}

    /**
  *@brief        train car drive speed value at once
  *@param [in]
  */
   virtual  void updateTrainSpeed(unsigned int value) = 0;

    /**
  *@brief       drive direction
  *@param  [in]  value from 0 - 360
 */
    virtual void updateDirection(unsigned int value) = 0;

    /**
  *@brief           train time
  *@param [in]  value minutes
  */
    virtual void updateTrainingMinutes(unsigned int value) = 0;

    /**
  *@brief           current once train distance
  *@param [in]
  */
    virtual void updateCurrentTrainDistance(unsigned int value) = 0;
};

}

#endif // DISPLAYINTERFACE_H

