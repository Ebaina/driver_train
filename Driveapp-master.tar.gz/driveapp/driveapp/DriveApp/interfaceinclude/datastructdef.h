#ifndef DATASTRUCTDEF_H
#define DATASTRUCTDEF_H

#include <QMap>
#include <QString>
#include "datastruct/exeAuthority.h"
#include "datastruct/execoach.h"
#include "datastruct/exeidentitycheck.h"
#include "datastruct/exelearner.h"
#include "datastruct/exephototake.h"
#include "datastruct/exephotoupload.h"
#include "datastruct/exepositionreport.h"
#include "datastruct/exeReg.h"
#include "datastruct/exesetterminaldata.h"
#include "datastruct/exeterminalcontrol.h"
#include "datastruct/app_globl.h"
#include "datastruct/can.h"
#include "datastruct/cJSON.h"
#include "datastruct/clog.h"
#include "datastruct/cmd.h"
#include "datastruct/CmdBase.h"
#include "datastruct/framework.h"
#include "datastruct/ui_structs.h"

#endif // DATASTRUCTDEF_H

