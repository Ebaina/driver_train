﻿#ifndef STATUSREPORTINTERFACE_H
#define STATUSREPORTINTERFACE_H

namespace WIS_UI{
class StatusReportInterface{
public:
    explicit StatusReportInterface(){}
    ~StatusReportInterface(){}

    virtual void updateLocatedState(unsigned char state) = 0;

    virtual void updateMobileSignal(unsigned char signalValue) = 0;

    /**
  *@brief   紧急报警
  *@param [in]  RetState
  */
    virtual void updateUrgentAlertState(unsigned char state) = 0;

    /**
  *@brief   超速报警
  *@param [in] RetState
  */
    virtual void updateSpeedAlertState(unsigned char state) = 0;

    /**
  *@brief   疲劳驾驶
  *@param [in] RetState
  */
    virtual void updateTiredDriveState(unsigned char state) = 0;

    /**
  *@brief   GNSS故障
  *@param [in]  RetState
  */
      virtual void updateGNSSFaultState(unsigned char state) = 0;

    /**
  *@brief   电源故障
  *@param [in]  RetState
  */
      virtual void updatePowerFaultState(unsigned char state) = 0;

    /**
  *@brief   TTS故障
  *@param [in]  RetState
  */
      virtual void updateTTSFaultState(unsigned char state) = 0;

    /**
  *@brief   车辆故障
  *@param [in]  RetState
  */
      virtual void updateCarFaultState(unsigned char state) = 0;

    /**
  *@brief   平台故障
  *@param [in]  RetState
  */
      virtual void updateNetToPlateState(unsigned char state) = 0;

    /**
  *@brief   网络故障
  *@param [in]  RetState
  */
      virtual void updateNetState(unsigned char state) = 0;

    /**
  *@brief   摄像故障
  *@param [in]  RetState
  */
      virtual void updateCameraFaultState(unsigned char state) = 0;

    /**
  *@brief   程序升级
  *@param [in]  RetState
  */
      virtual  void updateVersionState(unsigned char state) = 0;
};

}

#endif // STATUSREPORTINTERFACE_H


