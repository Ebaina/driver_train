﻿#ifndef PAYINTERFACE_H
#define PAYINTERFACE_H

#include "ui_structs.h"
namespace WIS_UI {

class PayInterface{
public:
    explicit PayInterface(){}
    ~PayInterface(){}

    //回调训练时间和费用
    virtual void responseTrainTimeCost(UI_TrainTimeCost timeCost) = 0;

    virtual void responsePoscardPayAck(unsigned char ack) = 0;

    //回调二维码数据
    virtual void responseQRCodeData(const unsigned char * data, int size, const char * format = 0) = 0;

    //回调二维码支付结果
    virtual void responseQRCodePayAck(unsigned char ack) = 0;
};
}

#endif // PAYINTERFACE_H

