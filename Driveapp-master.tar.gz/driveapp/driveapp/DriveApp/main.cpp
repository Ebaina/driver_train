#include <signal.h>
#include <QApplication>
#include <QPixmap>
#include <QTextCodec>
#include <QElapsedTimer>
#include <QMovie>
#include <QLabel>
#include <QFile>
#include <QDebug>
#include <QDesktopWidget>
#include "mainform.h"
#include "keyboardinputcontext.h"
#include "datastructdef.h"
#include "datastruct/app_globl.h"
#include "handlermanager.h"

//#ifdef nuc970_4_8
#include <QWSServer>
//#endif

//static void sighandler(int signum)
//{
//     printf("\033[0;31m [signum=%d] !\033[0;39m\n", signum);

// }

int main(int argc, char *argv[])
{
//    signal(SIGINT, sighandler);
//    signal(SIGTERM, sighandler);
//    signal(SIGPIPE, sighandler);
//    signal(SIGCHLD, sighandler);
    QApplication a(argc, argv);


#ifdef nuc970_4_8
//    QApplication::setOverrideCursor(Qt::BlankCursor);
    QWSServer::setCursorVisible(false);
#endif

   QWSServer::setCursorVisible(false);

    //设置中文编码格式
    QTextCodec *textCodec = QTextCodec::codecForName("UTF-8");
    QTextCodec::setCodecForCStrings(textCodec);
    QTextCodec::setCodecForLocale(textCodec);
    QTextCodec::setCodecForTr(textCodec);


    /***load style sheet***/
    QFile styleFile(":/resource/style/ui.qss");
    if(!styleFile.open(QFile::ReadOnly)){
        qDebug() << "ui.qss open failed";
    }
    QString str =QString( styleFile.readAll());
    styleFile.close();
    qApp->setStyleSheet(str);

    /***app start gif***/
    QLabel *startLb = new QLabel();
    startLb->setWindowFlags(Qt::FramelessWindowHint);
    QMovie *movie = new QMovie(":/resource/image/splash.gif");
    startLb->setMovie(movie);
    startLb->setScaledContents(true);
    movie->start();

#ifdef nuc970_4_8
    QPixmap bgPixmap;
    bgPixmap.load(":/resource/image/splash.png");
    QWSServer::setBackground(bgPixmap);
    startLb->showFullScreen();
#else
    QDesktopWidget *desktop = QApplication::desktop();
    int dw = desktop->availableGeometry().width();
    int dh = desktop->availableGeometry().height();
    startLb->resize(800,480);
    startLb->move((dw-800)/2,(dh-480)/2);
    startLb->show();
#endif

    int delay = 3;
    QElapsedTimer timer;
    timer.start();
    while(timer.elapsed() < (delay * 1000)){
        a.processEvents();
    }
    movie->stop();
    delete movie;
    delete startLb;

    //set inputcontext:means use virtual keyboard
    KeyBoardInputContext *kbic = new KeyBoardInputContext;
    a.setInputContext(kbic);
#ifdef nuc970_4_8

    HandlerManager::instance()->getFuncInterface()->setLoginHandler(HandlerManager::instance()->getLoginHandler());
    HandlerManager::instance()->getFuncInterface()->do_init_net();
    HandlerManager::instance()->getFuncInterface()->register_display_handler(HandlerManager::instance()->getDisplayHandler());

#endif

    MainForm w;

    w.show();


    return a.exec();
}
