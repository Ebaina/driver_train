﻿#ifndef NETPARAMSETFORM_H
#define NETPARAMSETFORM_H

#include <QPushButton>
#include <QLineEdit>
#include "basewidget.h"

class NetParamSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit NetParamSetForm(QWidget *parent = 0);
    ~NetParamSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();
private:
    QLineEdit *m_mainServerComUserLe;           //主服务器无线通信拨号用户名
    QLineEdit *m_mainServerComPasswdLe;      //主服务器无线通信拨号密码
    QLineEdit *m_mainServerAddrLe;                  //主服务器地址，IP或域名
    QLineEdit *m_backupServerApnLe;               //备份服务器APN，无线通信拨号访问点
    QLineEdit *m_backupServerComUserLe;      //备份服务器无线通信拨号用户名
    QLineEdit *m_backupServerComPasswdLe; //备份服务器无线通信拨号密码
    QLineEdit *m_backupServerAddrLe;             //备份服务器地址，IP或域名
    QLineEdit *m_mainServerTcpPortLe;            //服务器TCP端口
    QLineEdit *m_mainServerUdpPortLe;          //服务器UDP端口
    QPushButton *m_saveBtn;
    QPushButton *m_backBtn;

    QStackedWidget *m_mainStackWidget;
    void drawUI();

    void back();

    void showParamSetForm();

private slots:
    void onSaveBtnClicked();

    void onBackBtnClicked();
};

#endif // NETPARAMSETFORM_H
