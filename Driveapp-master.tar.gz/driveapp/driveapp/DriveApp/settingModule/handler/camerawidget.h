﻿#ifndef CAMERAWIDGET_H
#define CAMERAWIDGET_H

#include <QWidget>
#include "videosetform.h"

class Camera;
class QTimer;
class CameraWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CameraWidget(QWidget *parent = 0);
    ~CameraWidget();

    void on_startPushButton_clicked();
    void on_stopPushButton_clicked();

private slots:
    void updateImage();

private:

    Camera *_camera;
    QTimer *_timer;
    unsigned char *_imageBuffer;
    unsigned char *_rgbImageBuffer;
};

#endif // CAMERAWIDGET_H
