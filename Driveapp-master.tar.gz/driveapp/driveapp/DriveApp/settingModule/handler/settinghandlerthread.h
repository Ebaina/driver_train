#ifndef SETTINGHANDLERTHREAD_H
#define SETTINGHANDLERTHREAD_H

#include <QThread>
#include "settingevents.h"

class SettingHandler;
class SettingHandlerThreadWorker;
class SettingHandlerThread : public QThread
{
    Q_OBJECT
public:
    explicit SettingHandlerThread(QObject *parent = 0);
    ~SettingHandlerThread();

    /**
  *@brief  set this handler use to back info to GUI
  *@param [in]      settinghandler
  */
    void setSettingHandler(SettingHandler *handler);

    bool postRegisterEvent(RegisterEvent *regEvent);

    bool postUnRegisterEvent(UnRegisterEvent *unRegEvent);

protected:
    void run();


private:
    SettingHandler *m_settingHandler;

    SettingHandlerThreadWorker *m_worker;
};

class SettingHandlerThreadWorker : public QObject
{
    Q_OBJECT
public:
    explicit SettingHandlerThreadWorker(QObject *parent = 0);
    ~SettingHandlerThreadWorker();

    bool event(QEvent *event);

    /**
  *@brief       use this handler pointer to offer  callback
  *@param [in] setting handler
  */
    void setSettingHandler(SettingHandler *handler);

private:
    SettingHandler *m_settingHandler;

    void processRegisterEvent(RegisterEvent *event);

    void processUnRegisterEvent(UnRegisterEvent *event);
};

#endif // SETTINGHANDLERTHREAD_H

