#include <QDebug>
#include "settinghandler.h"
#include "handlermanager.h"

SettingHandler::SettingHandler(QObject *parent) :
    QObject(parent)
{
    qRegisterMetaType<User_card_info>("User_card_info");

#ifdef nuc970_4_8
    m_funcInterface = HandlerManager::instance()->getFuncInterface();
#endif
    m_handlerThread = new SettingHandlerThread(this);
    m_handlerThread->setSettingHandler(this);
    m_handlerThread->start();
}

SettingHandler::~SettingHandler()
{
    if(m_handlerThread){
        if(m_handlerThread->isRunning()){
            m_handlerThread->quit();
            m_handlerThread->wait(500);
        }
        delete m_handlerThread;
        m_handlerThread = NULL;
    }
}

void SettingHandler::updateAdminCardInfo(User_card_info user_card_info)
{
    emit sigUpdateUserCardInfo(user_card_info);
}

void SettingHandler::updateRegisterAckState(unsigned char state)
{
    qDebug() << "UI_callback thread id:" << (unsigned int)QThread::currentThreadId();
    qDebug() << "UI_callback state: " << state;
    emit sigUpdateRegState(state);
}

void SettingHandler::updateUnRegisterAckState(unsigned char state)
{
    emit sigUpdateUnRegState(state);
}

bool SettingHandler::isRegistered()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
#endif
    bool b = false;

#ifdef nuc970_4_8
//    b =  m_funcInterface->register_Status();
#endif
    return b;
}

int SettingHandler::isPageflag()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return 0;
#endif
    int b = 0;

#ifdef nuc970_4_8
//    b =  m_funcInterface->pageflag_Status();
#endif
    return b;
}

UI_NetMainSet SettingHandler::getNetMainParams()
{
    UI_NetMainSet netSet;
    memset((char*)&netSet, 0, sizeof(UI_NetMainSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return netSet;
//    return m_funcInterface->get_active_Plartform_Address();
#else
    return netSet;
#endif
}

bool SettingHandler::initServerInfo(UI_NetMainSet serverInfo)
{
//    qDebug() << QString((char*)serverInfo.Backupserver_IP);
//    qDebug() << QString((char*)serverInfo.Mainserver_IP);
//    qDebug() << serverInfo.Server_TCP_Port;
//    qDebug() << serverInfo.Server_UDP_Port;
//    qDebug() << QString((char*)serverInfo.phonenum).left(32).trimmed();
#ifdef nuc970_4_8
//    return m_funcInterface->set_active_Plartform_Address(serverInfo);
#endif
    return true;
}

bool SettingHandler::registerDevice(UI_StRegInfo regInfo)
{
    RegisterEvent *registerEvent = new RegisterEvent(RegisterEvent::registerDeviceEventType);
    registerEvent->setRegInfo(regInfo);

    return m_handlerThread->postRegisterEvent(registerEvent);
}

bool SettingHandler::unRegisterDevice()
{
    UnRegisterEvent *logoffEvent = new UnRegisterEvent(UnRegisterEvent::unRegisterDeviceEventType);
    return m_handlerThread->postUnRegisterEvent(logoffEvent);
}


void SettingHandler::setVolume(int value)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return;
//    m_funcInterface->set_volume(value);
#else
    (void)value;
#endif
}

int SettingHandler::getVolume()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return 0;
//    return m_funcInterface->get_volume();
#else
    return 5;
#endif
}

void SettingHandler::setLight(int value)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return;
//    m_funcInterface->set_light(value);
#else
    (void)value;
#endif
}

int SettingHandler::getLight()
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return 0;
//    return m_funcInterface->get_light();
#else
    return 5;
#endif
}


bool SettingHandler::setCommunParams(const UI_CommunicateMainSet &comParam)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_commun_params(comParam);
#else
     qDebug() << "comParam.Client_Heartbeat_Sec:" << comParam.Client_Heartbeat_Sec;
     qDebug() << "comParam.SMS_Reply_Sec:" << comParam.SMS_Reply_Sec;
     qDebug() << "comParam.SMS_Retransmission:" << comParam.SMS_Retransmission;
     qDebug() << "comParam.Tcp_Reply_Sec:" << comParam.Tcp_Reply_Sec;
     qDebug() << "comParam.Tcp_Retransmission:" << comParam.Tcp_Retransmission;
     qDebug() << "comParam.Udp_Reply_Sec:" << comParam.Udp_Reply_Sec;
     qDebug() << "comParam.Udp_Retransmission:" << comParam.Udp_Retransmission;
     return true;
#endif
}

UI_CommunicateMainSet SettingHandler::getCommunParams()
{
    UI_CommunicateMainSet comParam;
    memset((char*)&comParam, 0, sizeof(UI_CommunicateMainSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return comParam;
//    return m_funcInterface->get_commun_params();
#else
    return comParam;
#endif
}

bool SettingHandler::setNetParams(const UI_NetSet &netSet)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_net_params(netSet);
#else
    (void)netSet;
    return true;
#endif
}

UI_NetSet SettingHandler::getNetParams()
{
    UI_NetSet netSet;
    memset((char*)&netSet, 0, sizeof(UI_NetSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return netSet;
//    return m_funcInterface->get_net_params();
#else
    return netSet;
#endif
}

bool SettingHandler::setVideoParams(const UI_VideoInfo &videoSet)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_video_params(videoSet);
#else
    (void)videoSet;
    return true;
#endif
}

UI_VideoInfo SettingHandler::getVideoParams()
{
    UI_VideoInfo videoSet;
    memset((char*)&videoSet, 0, sizeof(UI_VideoInfo));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return videoSet;
//    return m_funcInterface->get_video_params();
#else
    return videoSet;
#endif
}

bool SettingHandler::setReportParams(const UI_ReportMainSet &reportSet)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_report_params(reportSet);
#else
    (void)reportSet;
    return true;
#endif
}

UI_ReportMainSet SettingHandler::getReportParams()
{
    UI_ReportMainSet reportSet;
    memset((char*)&reportSet, 0, sizeof(UI_ReportMainSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return reportSet;
//    return m_funcInterface->get_report_params();
#else
    return reportSet;
#endif
}

bool SettingHandler::setViewThresParams(const UI_ViewthresholdMainSet &viewThresSet)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_view_thres_params(viewThresSet);
#else
    (void)viewThresSet;
    return true;
#endif
}

UI_ViewthresholdMainSet SettingHandler::getViewThresParams()
{
    UI_ViewthresholdMainSet viewSet;
    memset((char*)&viewSet, 0, sizeof(UI_ViewthresholdMainSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return viewSet;
//    return m_funcInterface->get_view_thres_params();
#else
    return viewSet;
#endif
}

bool SettingHandler::setListenParams(const UI_ListenMainSet &listenSet)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_listen_params(listenSet);
#else
    (void)listenSet;
    return true;
#endif
}

UI_ListenMainSet SettingHandler::getListenParams()
{
    UI_ListenMainSet listenSet;
    memset((char*)&listenSet, 0, sizeof(UI_ListenMainSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return listenSet;
//    return m_funcInterface->get_listen_params();
#else
    return listenSet;
#endif
}

bool SettingHandler::setOthersParams(const UI_OtherMainSet otherSet)
{
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return false;
//    return m_funcInterface->set_others_params(otherSet);
#else
    (void)otherSet;
    return true;
#endif
}

UI_OtherMainSet SettingHandler::getOthersParams()
{
    UI_OtherMainSet otherSet;
    memset((char*)&otherSet, 0, sizeof(UI_OtherMainSet));
#ifdef nuc970_4_8
    if(m_funcInterface == NULL)
        return otherSet;
//    return m_funcInterface->get_others_params();
#else
    return otherSet;
#endif
}

#ifdef nuc970_4_8
Ui_Interface *SettingHandler::getFuncInterface()
{
    return HandlerManager::instance()->getFuncInterface();
}
#endif
