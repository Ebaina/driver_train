#ifndef SETTINGEVENTS_H
#define SETTINGEVENTS_H

#include <QEvent>
#include "datastructdef.h"
//#include "ui_structs.h"

class RegisterEvent : public QEvent
{
public:
    explicit RegisterEvent(QEvent::Type type);
    ~RegisterEvent();

    static QEvent::Type registerDeviceEventType;

    UI_StRegInfo regInfo() const;
    void setRegInfo(const UI_StRegInfo &regInfo);

private:
    UI_StRegInfo m_regInfo;
};

class UnRegisterEvent : public QEvent
{
public:
    explicit UnRegisterEvent(QEvent::Type type);
    ~UnRegisterEvent();

    static QEvent::Type unRegisterDeviceEventType;
};

#endif // SETTINGEVENTS_H

