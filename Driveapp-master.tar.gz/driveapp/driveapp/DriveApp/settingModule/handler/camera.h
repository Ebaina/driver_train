#ifndef CAMERA_H
#define CAMERA_H

#include <string>
typedef int (*StreamCallback)(unsigned char* buferr, int len, void* userData);
class Camera
{
    struct V4l2Buffer {
        void * start;
        unsigned int length;
    };

public:
    Camera();
    Camera(const std::string &nodeName = "/dev/video0");
    ~Camera();

    bool open();
    bool open(const std::string& nodeName);
    void close();

    bool start();
    void stop();

    bool captureFrame(unsigned char* buffer, int len);

 private:
    bool setupBuffers();
    void clearBuffers();
    bool streamOn();
    bool streamOff();


private:
    int _videoFd;
    int _width;
    int _height;
    int _bufferCount;
    std::string _nodeName;
    V4l2Buffer *_buffers;

};


#endif /*CAMERA_H*/
