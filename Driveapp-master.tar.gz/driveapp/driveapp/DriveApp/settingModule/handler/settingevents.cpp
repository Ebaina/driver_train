#include "settingevents.h"

QEvent::Type RegisterEvent::registerDeviceEventType = static_cast<QEvent::Type>(QEvent::registerEventType());
RegisterEvent::RegisterEvent(QEvent::Type type) :
    QEvent(type)
{

}

RegisterEvent::~RegisterEvent()
{

}

UI_StRegInfo RegisterEvent::regInfo() const
{
    return m_regInfo;
}

void RegisterEvent::setRegInfo(const UI_StRegInfo &regInfo)
{
    m_regInfo = regInfo;
}

QEvent::Type UnRegisterEvent::unRegisterDeviceEventType = static_cast<QEvent::Type>(QEvent::registerEventType());
UnRegisterEvent::UnRegisterEvent(QEvent::Type type) :
    QEvent(type)
{

}

UnRegisterEvent::~UnRegisterEvent()
{

}
