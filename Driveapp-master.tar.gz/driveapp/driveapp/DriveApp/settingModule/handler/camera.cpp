﻿#include "camera.h"
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <linux/types.h>
#include <linux/videodev2.h>


Camera::Camera() :
    _videoFd(-1),
    _width(320),
    _height(240),
    _buffers(0)
{

}

Camera::Camera(const std::string &nodeName) :
    _videoFd(-1),
    _width(320),
    _height(240),
    _buffers(0)

{
    _nodeName = nodeName;
}

Camera::~Camera()
{

}

/*
static   struct   v4l2_capability   cap;
struct v4l2_fmtdesc fmtdesc;
struct v4l2_format fmt,fmtack;
struct v4l2_streamparm setfps;
struct v4l2_requestbuffers req;
struct v4l2_buffer buf;
enum v4l2_buf_type type;
 */

bool Camera::open()
{
    if(_nodeName.empty())
        return false;

    //opendev
    const char* nodeName = _nodeName.c_str();
    fprintf(stderr, "nodeName = %s\n",nodeName);
    for(;;) {
        if ((_videoFd = ::open(nodeName, O_RDWR)) <=0) {
             fprintf(stderr, "Error opening V4L interface\n");
            break;
        }

        struct   v4l2_capability   cap;
        if (ioctl(_videoFd, VIDIOC_QUERYCAP, &cap) ==0 ) {
            if ((cap.capabilities & V4L2_CAP_VIDEO_CAPTURE) == V4L2_CAP_VIDEO_CAPTURE) {
                fprintf(stderr,"Device %s: supports capture.\n",nodeName);
            }

            if ((cap.capabilities & V4L2_CAP_STREAMING) == V4L2_CAP_STREAMING) {
                fprintf(stderr,"Device %s: supports streaming.\n",nodeName);
            }
        }

        struct v4l2_fmtdesc fmtdesc;
        fmtdesc.index=0;
        fmtdesc.type=V4L2_BUF_TYPE_VIDEO_CAPTURE;
        while(ioctl(_videoFd,VIDIOC_ENUM_FMT,&fmtdesc)!=-1) {
             fprintf(stderr,"\t%d.%s\n",fmtdesc.index+1,fmtdesc.description);
            fmtdesc.index++;
        }

        struct v4l2_format fmt;
        memset(&fmt, 0, sizeof(fmt));

        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
        fmt.fmt.pix.height = _height;
        fmt.fmt.pix.width = _width;
        fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;

        if(ioctl(_videoFd, VIDIOC_S_FMT, &fmt) !=0) {
             fprintf(stderr, "Unable to set format\n");
            break;
        }

        if(ioctl(_videoFd, VIDIOC_G_FMT, &fmt) !=0) {
             fprintf(stderr, "Unable to get format\n");
            break;
        }

         fprintf(stderr, "init %s \t[OK]\n",nodeName);
        return true;

    }
    ::close(_videoFd);
    _videoFd = -1;
    return false;
}

bool Camera::open(const std::string &nodeName)
{
    _nodeName = nodeName;
    return open();
}

void Camera::close()
{
    if(_videoFd != -1) {
        ::close(_videoFd);
    }
}

bool Camera::start()
{
    if(!setupBuffers())
        return false;

    if(!streamOn()) {
        clearBuffers();
        return false;
    }
    return true;
}

void Camera::stop()
{
    streamOff();
    clearBuffers();
}

bool Camera::captureFrame(unsigned char* buffer, int len)
{
    int ret;
    struct v4l2_buffer buf;

    memset(&buf, 0, sizeof(buf));
    buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    buf.memory = V4L2_MEMORY_USERPTR;

    /* Dequeue capture buffer */
    ret = ioctl(_videoFd, VIDIOC_DQBUF, &buf);
    if (ret < 0) {
         fprintf(stderr, "Cap VIDIOC_DQBUF");
        return false;
    }

    memcpy(buffer, _buffers[buf.index].start, _width*_height*2);
//    if (frame_count++ % frame_devisor == 0)
//        updateTexture((uchar *)videodev.buff_info[buf.index].start, videodev.cap_width, videodev.cap_height);

    ret = ioctl(_videoFd, VIDIOC_QBUF, &buf);
    if (ret < 0) {
        fprintf(stderr, "Cap VIDIOC_QBUF");
        return false;
    }
    return true;
}

bool Camera::setupBuffers()
{
    int err = -1;

    struct v4l2_requestbuffers reqbuf;
    reqbuf.count    = 3;
    reqbuf.type     = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    reqbuf.memory   = V4L2_MEMORY_MMAP;
    if ((err = ::ioctl(_videoFd, VIDIOC_REQBUFS, &reqbuf)) < 0) {
         fprintf(stderr,"ioctl(VIDIOC_REQBUFS) failed, errno:");
        return false;
    }

    _bufferCount = reqbuf.count;
    _buffers = new V4l2Buffer[_bufferCount];

    struct v4l2_buffer buf;
    for (uint i = 0; i < reqbuf.count; i++) {
        memset(&buf, 0, sizeof(buf));
        buf.type    = reqbuf.type;
        buf.index   = i;
        buf.memory  = reqbuf.memory;
        err = ::ioctl(_videoFd, VIDIOC_QUERYBUF, &buf);
        // todo

        _buffers[i].length = buf.length;
        //map
        _buffers[i].start = mmap(NULL ,buf.length,PROT_READ |PROT_WRITE, MAP_SHARED, _videoFd, buf.m.offset);
        if (_buffers[i].start == MAP_FAILED) {
             fprintf(stderr,"buffer map error\n");
            return false;
        }
        //QSharedPointer<V4L2VideoBuffer> vb(new V4L2VideoBuffer(mFile, buf, fmt));

        err = ::ioctl(_videoFd, VIDIOC_QBUF, &buf);


    }

    return true;
}

void Camera::clearBuffers()
{
    if(_buffers) {
        for(int i=0; i<_bufferCount; i++) {
            munmap(_buffers[i].start,_buffers[i].length);
        }
        delete [] _buffers;
        _buffers = NULL;
    }
}

bool Camera::streamOn()
{
    int cmd = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    int ret = ::ioctl(_videoFd, VIDIOC_STREAMON, &cmd);
    if (ret < 0) {
         fprintf(stderr,"ioctl(VIDIOC_STREAMON) failed, errno ");
        return false;
    }
    return true;
}

bool Camera::streamOff()
{
    int cmd = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    int ret = ioctl(_videoFd, VIDIOC_STREAMOFF, &cmd);
    if (ret < 0) {
         fprintf(stderr,"ioctl(VIDIOC_STREAMOFF) failed, errno ");
        return false;
    }

    return true;
}
