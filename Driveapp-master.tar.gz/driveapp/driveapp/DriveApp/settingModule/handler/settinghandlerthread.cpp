#include <QCoreApplication>
#include <QDebug>
#include "settinghandler.h"
#include "settinghandlerthread.h"
#include "ui_interface.h"

SettingHandlerThread::SettingHandlerThread(QObject *parent) :
    QThread(parent),
    m_settingHandler(NULL),
    m_worker(NULL)
{

}

SettingHandlerThread::~SettingHandlerThread()
{

}

bool SettingHandlerThread::postRegisterEvent(RegisterEvent *regEvent)
{
    if(m_worker == NULL)
        return false;
    QCoreApplication::postEvent(m_worker, regEvent);
    return true;
}

bool SettingHandlerThread::postUnRegisterEvent(UnRegisterEvent *unRegEvent)
{
    if(m_worker == NULL)
        return false;
    QCoreApplication::postEvent(m_worker, unRegEvent);
    return true;
}

void SettingHandlerThread::run()
{
    if(NULL == m_worker){
        m_worker = new SettingHandlerThreadWorker;
        m_worker->setSettingHandler(m_settingHandler);
    }
    exec();

    delete m_worker;
    m_worker = NULL;
}

void SettingHandlerThread::setSettingHandler(SettingHandler *handler)
{
    m_settingHandler = handler;
}

SettingHandlerThreadWorker::SettingHandlerThreadWorker(QObject *parent) :
    QObject(parent)
{

}

SettingHandlerThreadWorker::~SettingHandlerThreadWorker()
{

}

bool SettingHandlerThreadWorker::event(QEvent *event)
{
    if(event->type() == RegisterEvent::registerDeviceEventType){
        RegisterEvent *regEvent = static_cast<RegisterEvent*>(event);
        processRegisterEvent(regEvent);
        return true;
    }else if(event->type() == UnRegisterEvent::unRegisterDeviceEventType){
        UnRegisterEvent *unRegEvent = static_cast<UnRegisterEvent*>(event);
        processUnRegisterEvent(unRegEvent);
        return true;
    }
    return QObject::event(event);
}

void SettingHandlerThreadWorker::setSettingHandler(SettingHandler *handler)
{
    m_settingHandler = handler;
}

void SettingHandlerThreadWorker::processRegisterEvent(RegisterEvent *event)
{
    UI_StRegInfo regInfo = event->regInfo();

    event->accept();
    qDebug() << "provinceId:" << regInfo.m_Province;
    qDebug() << "cityId:" << regInfo.m_town;
    qDebug() << "factoryId:" << QString((char*)regInfo.m_manufacturerID).left(5);
    qDebug() << "device model no:" << QString((char*)regInfo.m_DeviceType).left(20);
    qDebug() << "SN:" << QString((char*)regInfo.m_DeviceSN).left(7);
    qDebug() << "IMEI:" << QString((char*)regInfo.m_IMEI).left(15);
    qDebug() << "color:" << regInfo.m_CarPlateColor;
    qDebug() << "car no:" << QString((char*)regInfo.m_CarNumber).left(32);

#ifdef nuc970_4_8
    Ui_Interface *funcInter = m_settingHandler->getFuncInterface();
    if(funcInter == NULL){
        return;
    }

    funcInter->do_register(regInfo, m_settingHandler);
    funcInter = NULL;

#else
    m_settingHandler->updateRegisterAckState(8);
#endif
}

void SettingHandlerThreadWorker::processUnRegisterEvent(UnRegisterEvent *event)
{
    event->accept();

#ifdef nuc970_4_8
    Ui_Interface *funcInter = m_settingHandler->getFuncInterface();
    if(funcInter == NULL){
        return;
    }

    funcInter->do_unregister(m_settingHandler);
    funcInter = NULL;
#else
    m_settingHandler->updateUnRegisterAckState(UI_HEADER::RS_YES);
#endif

}
