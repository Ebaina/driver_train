﻿#ifndef SETTINGHANDLER_H
#define SETTINGHANDLER_H

#include <QObject>
#include "settinginterface.h"
#include "settinghandlerthread.h"
using namespace WIS_UI;

class Ui_Interface;
class SettingHandler : public QObject, public SettingInterface
{
    Q_OBJECT
public:
    explicit SettingHandler(QObject *parent = 0);
    ~SettingHandler();

    /******************callback********************/
    void updateAdminCardInfo(User_card_info user_card_info);

    void updateRegisterAckState(unsigned char state);

    void updateUnRegisterAckState(unsigned char state);
    /*******************callback*******************/

    /**
  *@brief       current device has registered or not
 */
    bool isRegistered();

    int isPageflag();

   UI_NetMainSet getNetMainParams();
    /**
  *@brief
  *@param [in]
  *@return
  */
    bool initServerInfo(UI_NetMainSet serverInfo);

    /**
  *@brief   register device
  *@param [in]  register device info
  *@return  true :start registering   false:
  */
    bool registerDevice(UI_StRegInfo regInfo);

    bool unRegisterDevice();

#ifdef nuc970_4_8
    Ui_Interface* getFuncInterface();
#endif
    void setVolume(int value);

    int getVolume();

    void setLight(int value);

    int getLight();

    //set communcation params
    bool setCommunParams(const UI_CommunicateMainSet  &comParam);

    //get communcation params
    UI_CommunicateMainSet getCommunParams();

    //set net params
    bool setNetParams(const UI_NetSet &netSet);

    //get net params
    UI_NetSet getNetParams();

    //set video params
    bool setVideoParams(const UI_VideoInfo &videoSet);

    UI_VideoInfo getVideoParams();

    //set report params
    bool setReportParams(const UI_ReportMainSet &reportSet);

    UI_ReportMainSet getReportParams();

    //set carema and threshold params
    bool setViewThresParams(const UI_ViewthresholdMainSet &viewThresSet);

    UI_ViewthresholdMainSet getViewThresParams();

    //set listen params
    bool setListenParams(const UI_ListenMainSet &listenSet);

    //get listen params
    UI_ListenMainSet getListenParams();

    //set others params
    bool setOthersParams(const UI_OtherMainSet otherSet);

    //get others params
    UI_OtherMainSet getOthersParams();

private:
    SettingHandlerThread *m_handlerThread;

#ifdef nuc970_4_8
    Ui_Interface *m_funcInterface;
#endif

signals:
    void sigUpdateRegState(int state);
    void sigUpdateUnRegState(unsigned char state);
    void sigUpdateUserCardInfo(User_card_info cardInfo);
};

#endif // SETTINGHANDLER_H

