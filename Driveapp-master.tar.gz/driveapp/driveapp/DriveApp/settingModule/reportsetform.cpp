﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include "reportsetform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "commondatamgr.h"
#include "paramsetform.h"

ReportSetForm::ReportSetForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_strategyListView(NULL),
    m_schemeListView(NULL)
{
    this->setObjectName("reportSetForm");

    drawUI();

    initData();
}

ReportSetForm::~ReportSetForm()
{
    if(m_strategyListView != NULL){
        delete m_strategyListView;
        m_strategyListView = NULL;
    }
}

wis_u16 ReportSetForm::type()
{
    return WIS_UI_ENUM::SETTING_REPORT_FORM;
}

void ReportSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void ReportSetForm::updateContent()
{
    SettingHandler *setHandler = HandlerManager::instance()->getSettingHandler();
    UI_ReportMainSet reportSet = setHandler->getReportParams();
    memset((char*)&reportSet, 0, sizeof(UI_ReportMainSet));
    m_loctRepStraTegyBtn->setText(CommonDataMgr::getPostReportStrategyValue(reportSet.Location_Report_Way));
    m_locatRepSchemeBtn->setText(CommonDataMgr::getPostReportSchemeValue(reportSet.Location_Report_Status));
    m_driUnLoginTimeIntLe->setText(QString::number(reportSet.Dri_Unlisted_Time_Report,10));
    m_driUnLoginDistIntLe->setText(QString::number(reportSet.Dri_Unlisted_Distance_Report));
    m_dormantTimeIntLe->setText(QString::number(reportSet.Dormant_Time_Report, 10));
    m_dormantDistIntLe->setText(QString::number(reportSet.Dormant_Distance_Report,10));
    m_urgenTimeIntLe->setText(QString::number(reportSet.Emergency_Alarm_Time_Report, 10));
    m_urgenDistIntLe->setText(QString::number(reportSet.Emergency_Alarm_Distance_Report, 10));
    m_defaultTimeIntLe->setText(QString::number(reportSet.Default_Time_Report, 10));
    m_defaultDistanceIntLe->setText(QString::number(reportSet.Default_Distance_Report, 10));
    m_inflectRotateLe->setText(QString::number(reportSet.Inflection_Point, 10));
}

void ReportSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);

    QHBoxLayout *contentLayout = new QHBoxLayout;
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName("leftFrame");
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    QLabel *lb = new QLabel(tr("位置汇报\n策略"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_loctRepStraTegyBtn = new QPushButton(tr(""),this);
    m_loctRepStraTegyBtn->setProperty("class", QVariant("showTextBtn"));
    leftGridLayout->addWidget(lb, 0,  0, 1, 1);
    leftGridLayout->addWidget(m_loctRepStraTegyBtn, 0, 1, 1, 3);
    lb = new QLabel(tr(""), this);
    leftGridLayout->addWidget(lb, 1, 0, 1, 4);
    lb->setProperty("class", QVariant("lbHorizontalLine"));

    lb = new QLabel(tr("位置汇报\n方案"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_locatRepSchemeBtn = new QPushButton(tr(""),this);
    m_locatRepSchemeBtn->setProperty("class", QVariant("showTextBtn"));
    leftGridLayout->addWidget(lb, 2,  0, 1, 1);
    leftGridLayout->addWidget(m_locatRepSchemeBtn, 2, 1, 1, 3);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 3, 0, 1, 4);

    lb = new QLabel(tr("拐点补传\n角度"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_inflectRotateLe = new QLineEdit(this);
    m_inflectRotateLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 4,  0, 1, 1);
    leftGridLayout->addWidget(m_inflectRotateLe, 4, 1, 1, 3);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 5, 0, 1, 4);

    lb = new QLabel(tr("未登录\n时间间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_driUnLoginTimeIntLe = new QLineEdit(this);
    m_driUnLoginTimeIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6,  0, 1, 1);
    leftGridLayout->addWidget(m_driUnLoginTimeIntLe, 6, 1, 1, 1);
    lb = new QLabel(tr("未登录\n距离间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_driUnLoginDistIntLe = new QLineEdit(this);
    m_driUnLoginDistIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6,  2, 1, 1);
    leftGridLayout->addWidget(m_driUnLoginDistIntLe, 6, 3, 1, 1);

    contentLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName("rightFrame");
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    lb = new QLabel(tr("休眠\n时间间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_dormantTimeIntLe = new QLineEdit(this);
    m_dormantTimeIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 0,  0, 1, 1);
    rightGridLayout->addWidget(m_dormantTimeIntLe, 0, 1, 1, 1);
    lb = new QLabel(tr("休眠\n距离间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_dormantDistIntLe = new QLineEdit(this);
    m_dormantDistIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 0,  2, 1, 1);
    rightGridLayout->addWidget(m_dormantDistIntLe, 0, 3, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 1, 0, 1, 4);

    lb = new QLabel(tr("紧急报警\n时间间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_urgenTimeIntLe = new QLineEdit(this);
    m_urgenTimeIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2,  0, 1, 1);
    rightGridLayout->addWidget(m_urgenTimeIntLe, 2, 1, 1, 1);
    lb = new QLabel(tr("紧急报警\n距离间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_urgenDistIntLe = new QLineEdit(this);
    m_urgenDistIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2,  2, 1, 1);
    rightGridLayout->addWidget(m_urgenDistIntLe, 2, 3, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 3, 0, 1, 4);

    lb = new QLabel(tr("缺省时间\n汇报间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_defaultTimeIntLe = new QLineEdit(this);
    m_defaultTimeIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 4,  0, 1, 1);
    rightGridLayout->addWidget(m_defaultTimeIntLe, 4, 1, 1, 1);
    lb = new QLabel(tr("缺省距离\n汇报间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_defaultDistanceIntLe = new QLineEdit(this);
    m_defaultDistanceIntLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 4,  2, 1, 1);
    rightGridLayout->addWidget(m_defaultDistanceIntLe, 4, 3, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 5, 0, 1, 4);
    lb = new QLabel(tr(""), this);
    rightGridLayout->addWidget(lb, 6, 0, 1, 4);

    contentLayout->addWidget(rightFrame);

    baseVbLayout->addLayout(contentLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout();
    m_saveBtn = new QPushButton(tr("保存"),this);
    m_saveBtn->setProperty("class", QVariant("paramSaveBtn"));
    m_backBtn = new QPushButton(tr("返回"), this);
    m_backBtn->setProperty("class", QVariant("paramBackBtn"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_saveBtn);
    bottomBtnLayout->addWidget(m_backBtn);
    bottomBtnLayout->addStretch();

    baseVbLayout->addLayout(bottomBtnLayout);

    connect(m_saveBtn, SIGNAL(clicked()), this, SLOT(onSaveBtnClicked()));
    connect(m_backBtn, SIGNAL(clicked()), this, SLOT(onBackBtnClicked()));
    connect(m_loctRepStraTegyBtn, SIGNAL(clicked()), this, SLOT(onStraTegyBtnClicked()));
    connect(m_locatRepSchemeBtn, SIGNAL(clicked()), this, SLOT(onSchemeBtnClicked()));
}

void ReportSetForm::initData()
{
    m_strategyMap.clear();
    m_strategyMap.insert(UI_HEADER::RST_TIME, tr("定时汇报"));
    m_strategyMap.insert(UI_HEADER::RST_DIST, tr("定距汇报"));
    m_strategyMap.insert(UI_HEADER::RST_TIME_DIST, tr("定时定距汇报"));

    m_schemeMap.clear();
    m_schemeMap.insert(UI_HEADER::PRST_ACC_STATE, tr("根据ACC状态"));
    m_schemeMap.insert(UI_HEADER::PRST_LOGIN_ACC_STATE, tr("根据登录和ACC状态"));
}

void ReportSetForm::back()
{
    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_REPORT_FORM)->deleteLater();
}

bool ReportSetForm::saveParams()
{
    UI_ReportMainSet reportSet;
    memset((char*)&reportSet, 0, sizeof(UI_ReportMainSet));
    reportSet.Default_Distance_Report = m_defaultDistanceIntLe->text().trimmed().toInt();
    reportSet.Default_Time_Report = m_defaultTimeIntLe->text().trimmed().toInt();
    reportSet.Dormant_Distance_Report = m_dormantDistIntLe->text().trimmed().toInt();
    reportSet.Dormant_Time_Report = m_dormantTimeIntLe->text().trimmed().toInt();
    reportSet.Dri_Unlisted_Distance_Report = m_driUnLoginDistIntLe->text().trimmed().toInt();
    reportSet.Dri_Unlisted_Time_Report = m_driUnLoginTimeIntLe->text().trimmed().toInt();
    reportSet.Emergency_Alarm_Distance_Report = m_urgenDistIntLe->text().trimmed().toInt();
    reportSet.Emergency_Alarm_Time_Report = m_urgenTimeIntLe->text().trimmed().toInt();
    reportSet.Inflection_Point = m_inflectRotateLe->text().trimmed().toInt();
    reportSet.Location_Report_Status = m_locatRepSchemeBtn->whatsThis().toInt();
    reportSet.Location_Report_Way = m_loctRepStraTegyBtn->whatsThis().toInt();

    return HandlerManager::instance()->getSettingHandler()->setReportParams(reportSet);
}

void ReportSetForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void ReportSetForm::onSaveBtnClicked()
{
    if(!saveParams()){
        return;
    }
    back();
}

void ReportSetForm::onBackBtnClicked()
{
    back();
}

void ReportSetForm::onStraTegyBtnClicked()
{
    if(m_strategyListView == NULL){
        m_strategyListView = new TextListView;
        m_strategyListView->setObjectName(QString("strategyChooseListView"));
        connect(m_strategyListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onStrategyChanged(int,QString)));
    }
    m_strategyListView->setTextModel(m_strategyMap);
    m_strategyListView->showView();
}

void ReportSetForm::onStrategyChanged(int index, QString value)
{
    m_loctRepStraTegyBtn->setWhatsThis(QString::number(index, 10));
    m_loctRepStraTegyBtn->setText(value);
}

void ReportSetForm::onSchemeBtnClicked()
{
    if(m_schemeListView == NULL){
        m_schemeListView = new TextListView;
        m_schemeListView->setObjectName(QString("schemeChooseListView"));
        connect(m_schemeListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onSchemeChanged(int,QString)));
    }
    m_schemeListView->setTextModel(m_schemeMap);
    m_schemeListView->showView();
}

void ReportSetForm::onSchemeChanged(int index, QString value)
{
    m_locatRepSchemeBtn->setWhatsThis(QString::number(index, 10));
    m_locatRepSchemeBtn->setText(value);
}

