﻿#include <QFrame>
#include <QToolButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QIcon>
#include <QDebug>
#include <QTimer>
#include "swipingcardform.h"
#include "handlermanager.h"
#include "registerhintform.h"
#include "widgetcollector.h"
//#include "appglobal.h"

SwipingCardForm::SwipingCardForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    this->setObjectName(QString("swipingCardForm"));
    drawUI();

    connect(HandlerManager::instance()->getSettingHandler(), SIGNAL(sigUpdateRegState(int)), this, SLOT(updateRegRet(int)));
}

SwipingCardForm::~SwipingCardForm()
{

}

wis_u16 SwipingCardForm::type()
{
    return WIS_UI_ENUM::SWIPING_CARD_FORM;
}

void SwipingCardForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void SwipingCardForm::updateContent()
{

}

void SwipingCardForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setSpacing(0);
    QLabel *titleLb = new QLabel(tr("请刷卡进行设备注册"));
    titleLb->setContentsMargins(0,0,0,0);

    titleLb->setStyleSheet(QString("margin-top: 47px;margin-bottom: 47px;font-size:46px; color:#ffffff; text-align: center;"));
    baseVbLayout->addWidget(titleLb);
    titleLb->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
    baseVbLayout->setAlignment(titleLb,Qt::AlignHCenter);

    QFrame *userFrame = new QFrame(this);
    userFrame->setObjectName(QString("userFrame"));
    QHBoxLayout *userFrameLayout = new QHBoxLayout(userFrame);
    QLabel *userImgLb = new QLabel(this);
    userImgLb->setStyleSheet(QString("margin-left: 30px;margin-right:14px;"));
    QPixmap pixmap;
    pixmap.load(":/set_module_img/resource/image/settingModuleImg/user.png");
    userImgLb->setPixmap(pixmap);
    userImgLb->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    userFrameLayout->addWidget(userImgLb);

    QLabel *userTitleLb = new QLabel(tr("用户"),this) ;
    userTitleLb->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
    userTitleLb->setStyleSheet(QString("font-size:22px;color:#666666;text-align:left"));
    userFrameLayout->addWidget(userTitleLb);

    m_userNameLb = new QLabel(this);
    m_userNameLb->setStyleSheet(QString("margin-left:30px;font-size:22px;color:#666666;text-align:left"));
    userFrameLayout->addWidget(m_userNameLb);

    baseVbLayout->addWidget(userFrame);
    baseVbLayout->setAlignment(userFrame, Qt::AlignHCenter);

    QFrame *regProgressFrame = new QFrame(this);
    regProgressFrame->setObjectName(QString("regProgressFram"));
    QVBoxLayout *regProgressFrameLayout = new QVBoxLayout(regProgressFrame);
    regProgressFrameLayout->setSpacing(19);
    m_regProgressBar = new QProgressBar(this);
    m_regProgressBar->setTextVisible(false);
    m_regProgressBar->setRange(0,100);
    m_regProgressBar->setValue(0);
    regProgressFrameLayout->addStretch();
    regProgressFrameLayout->addWidget(m_regProgressBar);

    m_regRetLb = new QLabel(this);
    m_regRetLb->setAlignment(Qt::AlignHCenter);
    m_regRetLb->setStyleSheet(QString("font-size:16px;color:#666666;text-align:center;"));
    regProgressFrameLayout->addWidget(m_regRetLb);
    regProgressFrameLayout->addStretch();

    baseVbLayout->addWidget(regProgressFrame);
    baseVbLayout->setAlignment(regProgressFrame, Qt::AlignHCenter);
    baseVbLayout->addStretch();
}

void SwipingCardForm::updateRegRet(int state)
{
    switch(state){
    case UI_HEADER::REG_S1:
    {
        m_regRetLb->setText(tr("正在连接中心"));
    }
        break;
    case UI_HEADER::REG_S2:
    {
        m_regRetLb->setText(tr("连接中心成功"));
        m_regProgressBar->setValue(10);
    }
        break;
    case UI_HEADER::REG_S3:
    {
        m_regRetLb->setText(tr("等待连接中心验证"));
        m_regProgressBar->setValue(35);
    }
        break;
    case UI_HEADER::REG_S4:
    {
        m_regRetLb->setText(tr("中心验证成功"));
        m_regProgressBar->setValue(50);
    }
        break;
    case UI_HEADER::REG_S5:
    {
        m_regRetLb->setText(tr("中心验证失败"));
        m_regProgressBar->setValue(100);
        QTimer::singleShot(1000, this, SLOT(onRegFailed()));
    }
        break;
    case UI_HEADER::REG_S6:
    {
        m_regRetLb->setText(tr("正在保存注册信息"));
        m_regProgressBar->setValue(90);
    }
        break;
    case UI_HEADER::REG_S7:
    {
        m_regRetLb->setText(tr("信息保存成功"));
        m_regProgressBar->setValue(100);
    }
        break;
    case UI_HEADER::REG_S8:
    {
        m_regRetLb->setText(tr("成功"));
        m_regProgressBar->setValue(100);
        QTimer::singleShot(1000, this, SLOT(onRegSuccess()));
    }
        break;
    case UI_HEADER::REG_S9:
    {
        m_regRetLb->setText(tr("注册失败"));
        m_regProgressBar->setValue(100);
        QTimer::singleShot(1000, this, SLOT(onRegFailed()));
    }
        break;
    default:
    {
        m_regRetLb->setText(tr("指令错误"));
        m_regProgressBar->setValue(100);
        QTimer::singleShot(1000, this, SLOT(onRegFailed()));
    }
        break;
    }
}

void SwipingCardForm::onRegSuccess()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::REG_SUCCESS_FORM);
    RegisterHintForm*regHintForm = NULL;
    if(!bw){
        regHintForm = new RegisterHintForm(WIS_UI_ENUM::REG_SUCCESS_FORM);
        regHintForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::REG_SUCCESS_FORM,regHintForm);
        m_mainStackWidget->addWidget(regHintForm);

    }else{
        regHintForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(regHintForm);
    regHintForm->updateContent();
}

void SwipingCardForm::onRegFailed()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::REG_FAILED_FORM);
    RegisterHintForm*regHintForm = NULL;
    if(!bw){
        regHintForm = new RegisterHintForm(WIS_UI_ENUM::REG_FAILED_FORM);
        regHintForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::REG_FAILED_FORM,regHintForm);
        m_mainStackWidget->addWidget(regHintForm);

    }else{
        regHintForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(regHintForm);
    regHintForm->updateContent();
}
