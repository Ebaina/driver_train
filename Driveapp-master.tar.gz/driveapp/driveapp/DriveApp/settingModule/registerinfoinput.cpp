#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QFrame>
#include <QGridLayout>
#include <QLine>
#include <QListView>
#include <QDebug>
#include <QValidator>
#include <QIntValidator>
#include <QToolTip>
#include <QTextCodec>
#include <QTextEncoder>
#include "widgetcollector.h"
#include "registerinfoinput.h"
#include "netinitlinkform.h"
#include "handlermanager.h"
#include "swipingcardform.h"
#include "gbktochararray.h"

RegisterInfoInputForm::RegisterInfoInputForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_colorChooseListView(NULL),
    m_provinceListView(NULL)
{
    this->setObjectName("registerInfoInputForm");

    drawUI();

    initConnect();
}

RegisterInfoInputForm::~RegisterInfoInputForm()
{
    if(m_colorChooseListView != NULL){
        delete m_colorChooseListView;
        m_colorChooseListView = NULL;
    }

    if(m_provinceListView != NULL){
        delete m_provinceListView;
        m_provinceListView = NULL;
    }
}

wis_u16 RegisterInfoInputForm::type()
{
    return WIS_UI_ENUM::REGISTER_INFO_INPUT_FORM;
}

void RegisterInfoInputForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void RegisterInfoInputForm::updateContent()
{
    initDebugData();
}

void RegisterInfoInputForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(30,30,30,25);
    baseVbLayout->setSpacing(20);
    QLabel *lbTitle = new QLabel(tr("请输入注册信息"));
    lbTitle->setStyleSheet(QString("font-size:46px; font-weight:bold;color:#ffffff;bottom:25px;"));
    lbTitle->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);
    lbTitle->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTitle);

    /***left input frame area***/
    QHBoxLayout *inputHbLayout = new QHBoxLayout;
    inputHbLayout->setSpacing(20);
    inputHbLayout->setContentsMargins(0,0,0,0);
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName(QString("leftInputFrame"));
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    leftGridLayout->setHorizontalSpacing(30);
    leftGridLayout->setVerticalSpacing(5);
    leftGridLayout->setContentsMargins(20,21,20,21);
    QLabel *lb = new QLabel("省域ID",this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb, 0,0,1,1);
    m_provinceIdLe = new QLineEdit(this);
    QIntValidator *intVal = new QIntValidator(this);
    intVal->setRange(0,65535);
    m_provinceIdLe->setValidator(intVal);
    m_provinceIdLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_provinceIdLe->setPlaceholderText(tr("填写省ID"));
    leftGridLayout->addWidget(m_provinceIdLe,0,1,1,1);
    QLabel *lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,1,0,1,2);

    lb = new QLabel(tr("市县域ID"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb, 2,0,1,1);
    m_cityIdLe = new QLineEdit(this);
    m_cityIdLe->setValidator(intVal);
    m_cityIdLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_cityIdLe->setPlaceholderText(tr("填写填写市县ID"));
    leftGridLayout->addWidget(m_cityIdLe,2,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,3,0,1,2);

    lb = new QLabel(tr("制造商ID"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb, 4,0,1,1);
    m_madeFactoryLe = new QLineEdit(this);
    m_madeFactoryLe->setMaxLength(5);
    m_madeFactoryLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_madeFactoryLe->setPlaceholderText(tr("填写制造商ID"));
    leftGridLayout->addWidget(m_madeFactoryLe,4,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,5,0,1,2);

    lb = new QLabel(tr("终端型号"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    leftGridLayout->addWidget(lb,6,0,1,1);
    m_deviceModelNoLe = new QLineEdit(this);
    m_deviceModelNoLe->setMaxLength(20);
    m_deviceModelNoLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_deviceModelNoLe->setPlaceholderText(tr("填写终端型号"));
    leftGridLayout->addWidget(m_deviceModelNoLe,6,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lbLine,7,0,1,2);

    inputHbLayout->addWidget(leftFrame);

    /***right input frame area***/
    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName(tr("rightInputFrame"));
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    rightGridLayout->setHorizontalSpacing(30);
    rightGridLayout->setVerticalSpacing(5);
    rightGridLayout->setContentsMargins(20,21,20,21);
    lb = new QLabel(tr("终端序列号"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,0,0,1,1);
    m_deviceSerialNoLe = new QLineEdit(this);
    m_deviceSerialNoLe->setMaxLength(7);
    m_deviceSerialNoLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_deviceSerialNoLe->setPlaceholderText(tr("填写终端序列号"));
    rightGridLayout->addWidget(m_deviceSerialNoLe,0,1,1,2);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,1,0,1,3);

    lb = new QLabel(tr("IMEI"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,2,0,1,1);
    m_deviceIMEILe = new QLineEdit(this);
    m_deviceIMEILe->setMaxLength(15);
    m_deviceIMEILe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_deviceIMEILe->setPlaceholderText(tr("填写IMEI"));
    rightGridLayout->addWidget(m_deviceIMEILe,2,1,1,2);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,3,0,1,3);

    lb = new QLabel(tr("车牌颜色"));
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,4,0,1,1);
//    m_carLicenseColorLe = new QLineEdit(this);
//    m_carLicenseColorLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
//    m_carLicenseColorLe->setPlaceholderText(tr("选择车牌颜色"));
    m_carLicenseColorBtn = new QPushButton(this);
    m_carLicenseColorBtn->setObjectName(tr("carLicenseColorBtn"));
    m_carLicenseColorBtn->setText(tr("选择车牌颜色"));
    m_carLicenseColorBtn->setText(tr("蓝色"));
    m_carLicenseColorBtn->setWhatsThis(QString::number(UI_HEADER::LC_BLUE));
    rightGridLayout->addWidget(m_carLicenseColorBtn,4,1,1,2);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,5,0,1,3);

    lb = new QLabel(tr("车牌号"));
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    rightGridLayout->addWidget(lb,6,0,1,1);
    m_privinceBtn = new QPushButton(this);
    m_privinceBtn->setText(tr("京"));
    m_privinceBtn->setObjectName(tr("carLicenseColorBtn"));
    rightGridLayout->addWidget(m_privinceBtn,6,1,1,1);
    m_carLicenseNoLe = new QLineEdit(this);
    m_carLicenseNoLe->setMaxLength(6);
    m_carLicenseNoLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_carLicenseNoLe->setPlaceholderText(tr("填写车牌号"));
    rightGridLayout->addWidget(m_carLicenseNoLe,6,2,1,1);

    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lbLine,7,0,1,3);

    inputHbLayout->addWidget(rightFrame);
    baseVbLayout->addLayout(inputHbLayout);

    QHBoxLayout *btnLayout = new QHBoxLayout;
    btnLayout->setContentsMargins(0,0,0,0);
    m_preBtn = new QPushButton(tr("上一步"),this);
    m_preBtn->setObjectName(QString("preBtn"));
    btnLayout->addStretch();
    btnLayout->addWidget(m_preBtn);
    m_regBtn = new QPushButton(tr("注册"),this);
    m_regBtn->setObjectName(QString("regBtn"));
    btnLayout->addWidget(m_regBtn);
    btnLayout->addStretch();
    btnLayout->setSpacing(20);

    baseVbLayout->addLayout(btnLayout);
}

void RegisterInfoInputForm::initConnect()
{
    connect(m_carLicenseColorBtn,   SIGNAL(clicked(bool)), this, SLOT(onChooseCarLicenseColor(bool)));
    connect(m_preBtn, SIGNAL(clicked(bool)), this, SLOT(onPreBtnClicked(bool)));
    connect(m_regBtn, SIGNAL(clicked(bool)), this, SLOT(onRegBtnClicked(bool)));
//    connect(HandlerManager::instance()->getSettingHandler(), SIGNAL(sigUpdateRegState(int)), this, SLOT(updateRegState(int)));
    connect(m_privinceBtn, SIGNAL(clicked(bool)), this, SLOT(onPrivinceBtnClicked(bool)));
}

void RegisterInfoInputForm::initDebugData()
{
    m_provinceIdLe->setText(QString("0032"));
    m_cityIdLe->setText(QString("0115"));
    m_madeFactoryLe->setText(QString("01235"));
    m_deviceModelNoLe->setText(QString("KDJS-01"));
    m_deviceSerialNoLe->setText(QString("3040101"));
    m_deviceIMEILe->setText(QString("356156070646310"));
    m_carLicenseNoLe->setText(QString("EBBB4"));
}

bool RegisterInfoInputForm::setRegisterInfo()
{
    UI_StRegInfo regInfo;
    memset(&regInfo,0,sizeof(regInfo));
    regInfo.m_Province = m_provinceIdLe->text().trimmed().toInt();
    regInfo.m_town = m_cityIdLe->text().trimmed().toInt();
    strcpy((char *)(regInfo.m_manufacturerID), m_madeFactoryLe->text().trimmed().toStdString().c_str());   
    strcpy((char *)(regInfo.m_DeviceType), m_deviceModelNoLe->text().trimmed().toStdString().c_str());
    strcpy((char *)(regInfo.m_DeviceSN), m_deviceSerialNoLe->text().trimmed().toStdString().c_str());
    strcpy((char*)(regInfo.m_IMEI), m_deviceIMEILe->text().trimmed().toStdString().c_str());
    regInfo.m_CarPlateColor = m_carLicenseColorBtn->whatsThis().toInt();

    char outdata[20];
    char data_last[5];
    string xuelast = "学";
    memset(outdata,0,sizeof(outdata));
    int mm1 = GbktoCharArray::getInstance()->charqTostring(m_privinceBtn->text().trimmed().toStdString().c_str(),outdata) ;
    memcpy(&outdata[mm1],(char *)m_carLicenseNoLe->text().trimmed().toStdString().c_str(),m_carLicenseNoLe->text().trimmed().toStdString().length());
    int mm2 = GbktoCharArray::getInstance()->charqTostring(xuelast.c_str(),data_last) ;
    memcpy(&outdata[strlen(outdata)],(char *)data_last,mm2);
    memcpy((char *)(regInfo.m_CarNumber), outdata,strlen(outdata));

    /***send this action to thread***/
    return HandlerManager::instance()->getSettingHandler()->registerDevice(regInfo);
}

bool RegisterInfoInputForm::verifyInput()
{
    if(m_provinceIdLe->text().trimmed().isEmpty()){
        QToolTip::showText(m_provinceIdLe->mapToGlobal(QPoint(0,0)),QString(tr("省域ID未填写")));
        return false;
    }
    if(m_cityIdLe->text().isEmpty()){
        QToolTip::showText(m_cityIdLe->mapToGlobal(QPoint(0,0)),QString(tr("市县域ID未填写")));
        return false;
    }
    if(m_madeFactoryLe->text().isEmpty()){
        QToolTip::showText(m_madeFactoryLe->mapToGlobal(QPoint(0,0)),QString(tr("制造商ID未填写")));
        return false;
    }
    if(m_deviceModelNoLe->text().isEmpty()){
        QToolTip::showText(m_deviceModelNoLe->mapToGlobal(QPoint(0,0)),QString(tr("终端型号未填写")));
        return false;
    }
    if(m_deviceSerialNoLe->text().isEmpty()){
        QToolTip::showText(m_deviceSerialNoLe->mapToGlobal(QPoint(0,0)),QString(tr("终端编号未填写")));
        return false;
    }
    if(m_deviceIMEILe->text().isEmpty()){
        QToolTip::showText(m_deviceIMEILe->mapToGlobal(QPoint(0,0)),QString(tr("IMEI未填写")));
        return false;
    }
    if(m_carLicenseNoLe->text().isEmpty()){
        QToolTip::showText(m_carLicenseNoLe->mapToGlobal(QPoint(0,0)),QString(tr("车牌号未填写")));
        return false;
    }

    return true;
}

void RegisterInfoInputForm::onPreBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::NET_INITLINK_FORM);
    NetInitLinkForm*netInitLinkForm = NULL;
    if(!bw){
        netInitLinkForm = new NetInitLinkForm();
        netInitLinkForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::NET_INITLINK_FORM,netInitLinkForm);
        m_mainStackWidget->addWidget(netInitLinkForm);

    }else{
        netInitLinkForm = static_cast<NetInitLinkForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(netInitLinkForm);
}

void RegisterInfoInputForm::onChooseCarLicenseColor(bool clicked)
{
    Q_UNUSED(clicked)
    if(m_colorChooseListView == NULL){
        m_colorChooseListView = new TextListView;
        m_colorChooseListView->setObjectName(QString("colorChooseListView"));
        connect(m_colorChooseListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onCarLicenseColorChanged(int,QString)));
    }

    QMap<int,QString> colorMap;
    colorMap.insert(UI_HEADER::LC_BLUE, tr("蓝色"));
    colorMap.insert(UI_HEADER::LC_YELLOW, tr("黄色"));
    colorMap.insert(UI_HEADER::LC_BLACK, tr("黑色"));
    colorMap.insert(UI_HEADER::LC_WHITE,tr("白色"));
    colorMap.insert(UI_HEADER::LC_GREEN,tr("绿色"));
    colorMap.insert(UI_HEADER::LC_OTHER,tr("其他"));
    m_colorChooseListView->setTextModel(colorMap);
    m_colorChooseListView->showView();
}

void RegisterInfoInputForm::onCarLicenseColorChanged(int index, QString value)
{
    m_carLicenseColorBtn->setText(value);

    m_carLicenseColorBtn->setWhatsThis(QString::number(index));
}

void RegisterInfoInputForm::onCarProChanged(int index, QString value)
{
    m_privinceBtn->setText(value);
    m_privinceBtn->setWhatsThis(QString::number(index));
}

void RegisterInfoInputForm::onRegBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    if(!verifyInput()){
        return;
    }

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SWIPING_CARD_FORM);
    SwipingCardForm*swipForm = NULL;
    if(!bw){
        swipForm = new SwipingCardForm();
        swipForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SWIPING_CARD_FORM,swipForm);
        m_mainStackWidget->addWidget(swipForm);

    }else{
        swipForm = static_cast<SwipingCardForm*>(bw);
    }

    if(!setRegisterInfo()){
        return;
    }

    m_mainStackWidget->setCurrentWidget(swipForm);

}

void RegisterInfoInputForm::onPrivinceBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    QStringList pList;
    pList << tr("京") << tr("津") << tr("冀") << tr("晋") << tr("蒙") << tr("辽") << tr("吉") << tr("黑")
             << tr("沪") << tr("苏") << tr("浙") << tr("皖") << tr("闽") << tr("赣") << tr("鲁") << tr("豫")
             << tr("鄂") << tr("湘") << tr("粤") << tr("桂") << tr("琼") << tr("川") << tr("贵") << tr("云")
             << tr("渝") << tr("藏") << tr("陕") << tr("甘") << tr("青") << tr("宁") << tr("新");

    if(m_provinceListView == NULL){
        m_provinceListView = new TextListView;
        m_provinceListView->setObjectName(QString("proChooseListView"));
        connect(m_provinceListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onCarProChanged(int,QString)));
    }

    m_provinceListView->setTextModel(pList);
    m_provinceListView->showView();
}

