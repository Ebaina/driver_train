﻿#ifndef NETINITLINKFORM_H
#define NETINITLINKFORM_H

#include <QLineEdit>
#include <QPushButton>
#include "basewidget.h"

class SettingHandler;
class NetInitLinkForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit NetInitLinkForm(QWidget *parent = 0);
    ~NetInitLinkForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();
private:
    QStackedWidget *m_mainStackWidget;

    SettingHandler *m_settingHandler;

    /***UI***/
    QLineEdit *m_mainServerAddrLe;
    QLineEdit *m_backupServerAddrLe;
    QLineEdit *m_serverTcpPort;
    QLineEdit *m_serverUdpPort;
    QLineEdit *m_phone;

    QPushButton *m_cancelBtn;
    QPushButton *m_linkBtn;
    /***UI end***/

    void drawUI();

    // debug data
    void initDebugData();

    void initConnect();

    bool initServerInfo();

    bool verfyInput();

private slots:
    void onInitNetLinkSettings(bool clicked);

    void onCancelBtnClicked(bool clicked);
};

#endif // NETINITLINKFORM_H

