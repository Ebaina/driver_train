﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include "otherssetform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "commondatamgr.h"
#include "paramsetform.h"

OthersSetForm::OthersSetForm(QWidget *parent):
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_colorChooseListView(NULL),
    m_provinceListView(NULL)
{
    this->setObjectName("othersSetForm");
    drawUI();
}

OthersSetForm::~OthersSetForm()
{
    if(m_colorChooseListView != NULL){
        delete m_colorChooseListView;
        m_colorChooseListView = NULL;
    }

    if(m_provinceListView != NULL){
        delete m_provinceListView;
        m_provinceListView = NULL;
    }
}

wis_u16 OthersSetForm::type()
{
    return WIS_UI_ENUM::SETTING_OTHER_FORM;
}

void OthersSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void OthersSetForm::updateContent()
{
    UI_OtherMainSet otherSet = HandlerManager::instance()->getSettingHandler()->getOthersParams();
    m_pictureLe->setText(QString::number(otherSet.Picture,10));
    m_m_lightnessLe->setText(QString::number(otherSet.Lightness, 10));
    m_contrastLe->setText(QString::number(otherSet.Contrast, 10));
    m_saturationLe->setText(QString::number(otherSet.Saturation, 10));
    m_chromaLe->setText(QString::number(otherSet.Chroma, 10));
    m_carMeilageLe->setText(QString::number(otherSet.Car_Meilage, 10));
    m_provinceIdLe->setText(QString::number(otherSet.Province_ID, 10));
    m_cityIdLe->setText(QString::number(otherSet.City_ID, 10));
    QString carPno = QString((char*)otherSet.Motor_Plate).left(PLATE_LEN).trimmed();
    m_proviceSimpleNameBtn->setText(carPno.left(1));
//    m_motorPlateLe->setText(carPno.mid(1));
    m_plateColorBtn->setText(CommonDataMgr::getLicenseColorValue(otherSet.Plate_Color));
    m_plateColorBtn->setWhatsThis(QString::number(otherSet.Plate_Color, 10));
    m_impulseRatioLe->setText(QString::number(otherSet.Impulse_Ratio, 10));
}

void OthersSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);

    QHBoxLayout *contentLayout = new QHBoxLayout;
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName("leftFrame");
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    QLabel *lb = new QLabel(tr("图像"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_pictureLe = new QLineEdit(this);
    m_pictureLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_pictureLe, 0, 1, 1, 1);
    lb = new QLabel(tr("亮度"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_m_lightnessLe = new QLineEdit(this);
    m_m_lightnessLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 0, 2, 1, 1);
    leftGridLayout->addWidget(m_m_lightnessLe, 0, 3, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 1, 0, 1, 4);

    lb = new QLabel(tr("对比度"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_contrastLe = new QLineEdit(this);
    m_contrastLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_contrastLe, 2, 1, 1, 1);
    lb = new QLabel(tr("饱和度"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_saturationLe = new QLineEdit(this);
    m_saturationLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 2, 2, 1, 1);
    leftGridLayout->addWidget(m_saturationLe, 2, 3, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 3, 0, 1, 4);

    lb = new QLabel(tr("色度"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_chromaLe = new QLineEdit(this);
    m_chromaLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 4, 0, 1, 1);
    leftGridLayout->addWidget(m_chromaLe, 4, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 5, 0, 1, 4);


    lb = new QLabel(tr("里程表"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_carMeilageLe = new QLineEdit(this);
    m_carMeilageLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 0, 1, 1);
    leftGridLayout->addWidget(m_carMeilageLe, 6, 1, 1, 1);
    lb = new QLabel(tr("脉冲"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_impulseRatioLe = new QLineEdit(this);
    m_impulseRatioLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 2, 1, 1);
    leftGridLayout->addWidget(m_impulseRatioLe, 6, 3, 1, 1);

    contentLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName("rightFrame");
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    lb = new QLabel(tr("省域ID"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_provinceIdLe = new QLineEdit(this);
    m_provinceIdLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 0, 0, 1, 1);
    rightGridLayout->addWidget(m_provinceIdLe, 0, 1, 1, 2);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 1, 0, 1, 3);

    lb = new QLabel(tr("市域ID"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_cityIdLe = new QLineEdit(this);
    m_cityIdLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2, 0, 1, 1);
    rightGridLayout->addWidget(m_cityIdLe, 2, 1, 1, 2);

    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 3, 0, 1, 3);

    lb = new QLabel(tr("车牌颜色"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_plateColorBtn = new QPushButton(this);
    m_plateColorBtn->setProperty("class", QVariant("showTextBtn"));
    rightGridLayout->addWidget(lb, 4, 0, 1, 1);
    rightGridLayout->addWidget(m_plateColorBtn, 4, 1, 1, 2);


    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 5, 0, 1, 3);

    lb = new QLabel(tr(""),this);            //车牌
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_proviceSimpleNameBtn = new QPushButton(this);
    m_proviceSimpleNameBtn->setProperty("class", QVariant("showTextBtn"));
    m_proviceSimpleNameBtn->setVisible(false);
    m_motorPlateLe = new QLineEdit(this);
    m_motorPlateLe->setProperty("class", QVariant("rightContentLineEdit"));
    m_motorPlateLe->setVisible(false);
    rightGridLayout->addWidget(lb, 6, 0, 1, 1);
    rightGridLayout->addWidget(m_proviceSimpleNameBtn, 6, 1, 1, 1);
    rightGridLayout->addWidget(m_motorPlateLe, 6, 2, 1, 1);


    contentLayout->addWidget(rightFrame);

    baseVbLayout->addLayout(contentLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_saveBtn  = new QPushButton(tr("保存"),this);
    m_saveBtn->setProperty("class", QVariant("paramSaveBtn"));
    m_backBtn = new QPushButton(tr("返回"),this);
    m_backBtn->setProperty("class", QVariant("paramBackBtn"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_saveBtn);
    bottomBtnLayout->addWidget(m_backBtn);
    bottomBtnLayout->addStretch();

    baseVbLayout->addLayout(bottomBtnLayout);

    connect(m_saveBtn, SIGNAL(clicked()), this, SLOT(onSaveBtnClicked()));
    connect(m_backBtn, SIGNAL(clicked()), this, SLOT(onBackBtnClicked()));
    connect(m_plateColorBtn, SIGNAL(clicked()), this, SLOT(onPlateColorBtnClicked()));
    connect(m_proviceSimpleNameBtn, SIGNAL(clicked()), this, SLOT(onProvinSimpleNameBtnClicked()));
}

void OthersSetForm::back()
{
    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_OTHER_FORM)->deleteLater();
}

bool OthersSetForm::verifyInput()
{
    return true;
}

void OthersSetForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void OthersSetForm::onSaveBtnClicked()
{
    if(!verifyInput()){
        return;
    }

    UI_OtherMainSet otherSet;
    memset((char*)&otherSet, 0, sizeof(UI_OtherMainSet));
    otherSet.Picture = m_pictureLe->text().trimmed().toInt();
    otherSet.Lightness = m_m_lightnessLe->text().trimmed().toInt();
    otherSet.Contrast = m_contrastLe->text().trimmed().toInt();
    otherSet.Saturation = m_saturationLe->text().toInt();
    otherSet.Chroma = m_chromaLe->text().toInt();
    otherSet.Car_Meilage = m_carMeilageLe->text().trimmed().toInt();
    otherSet.Province_ID = m_provinceIdLe->text().trimmed().toInt();
    otherSet.City_ID = m_cityIdLe->text().trimmed().toInt();
    QString carPno = m_proviceSimpleNameBtn->text().trimmed() + m_motorPlateLe->text().trimmed();
    strcpy((char*)otherSet.Motor_Plate, carPno.left(PLATE_LEN).toStdString().c_str());
    otherSet.Plate_Color = m_plateColorBtn->whatsThis().toInt();
    otherSet.Impulse_Ratio = m_impulseRatioLe->text().trimmed().toInt();

    if(!HandlerManager::instance()->getSettingHandler()->setOthersParams(otherSet)){
        return;
    }

    back();
}

void OthersSetForm::onBackBtnClicked()
{
    back();
}

void OthersSetForm::onPlateColorBtnClicked()
{
    if(m_colorChooseListView == NULL){
        m_colorChooseListView = new TextListView;
        m_colorChooseListView->setObjectName(QString("colorChooseListView"));
        connect(m_colorChooseListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onCarLicenseColorChanged(int,QString)));
    }

    QMap<int,QString> colorMap;
    colorMap.insert(UI_HEADER::LC_BLUE, tr("蓝色"));
    colorMap.insert(UI_HEADER::LC_YELLOW, tr("黄色"));
    colorMap.insert(UI_HEADER::LC_BLACK, tr("黑色"));
    colorMap.insert(UI_HEADER::LC_WHITE,tr("白色"));
    colorMap.insert(UI_HEADER::LC_GREEN,tr("绿色"));
    colorMap.insert(UI_HEADER::LC_OTHER,tr("其他"));
    m_colorChooseListView->setTextModel(colorMap);
    m_colorChooseListView->showView();
}

void OthersSetForm::onCarLicenseColorChanged(int index, QString value)
{
    m_plateColorBtn->setWhatsThis(QString::number(index, 10));
    m_plateColorBtn->setText(value);
}

void OthersSetForm::onProvinSimpleNameBtnClicked()
{
    QStringList pList;
    pList << tr("京") << tr("津") << tr("冀") << tr("晋") << tr("蒙") << tr("辽") << tr("吉") << tr("黑")
             << tr("沪") << tr("苏") << tr("浙") << tr("皖") << tr("闽") << tr("赣") << tr("鲁") << tr("豫")
             << tr("鄂") << tr("湘") << tr("粤") << tr("桂") << tr("琼") << tr("川") << tr("贵") << tr("云")
             << tr("渝") << tr("藏") << tr("陕") << tr("甘") << tr("青") << tr("宁") << tr("新");

    if(m_provinceListView == NULL){
        m_provinceListView = new TextListView;
        m_provinceListView->setObjectName(QString("proChooseListView"));
        connect(m_provinceListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onCarPriSimpleNameChanged(int,QString)));
    }

    m_provinceListView->setTextModel(pList);
    m_provinceListView->showView();
}

void OthersSetForm::onCarPriSimpleNameChanged(int index, QString value)
{
    m_proviceSimpleNameBtn->setText(value);
    m_proviceSimpleNameBtn->setWhatsThis(QString::number(index, 10));
}

