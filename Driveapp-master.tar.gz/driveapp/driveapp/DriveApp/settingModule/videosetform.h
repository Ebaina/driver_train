﻿#ifndef VIDEOSETFORM_H
#define VIDEOSETFORM_H

#include <QObject>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"
#include "settingmgrform.h"

class TextListView;
class Camera;
class QTimer;
class videosetform : public BaseWidget
{
    Q_OBJECT
public:
    explicit videosetform(QWidget *parent = 0);
    ~videosetform();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

    void setvideoInfo();


private:
    QStackedWidget *m_mainStackWidget;


    /***UI start***/
    QLabel *videolb;
    QLineEdit *m_yearNoLe;
    QLineEdit *m_monthNoLe;
    QLineEdit *m_dayNoLe;
    QLineEdit *m_hourNoLe;
    QLineEdit *m_minuteNoLe;
    QLineEdit *m_dialtypeNoLe;
    QLineEdit *m_dialportNoLe;
    QLineEdit *m_dialpasswordNoLe;
    QLineEdit *m_statusportNoLe;
    QLineEdit *m_nettypeNoLe;
    QLineEdit *m_netnameNoLe;
    QPushButton *m_startvideoBtn;
    QPushButton *m_stopvideoBtn;
    QPushButton *m_ensureBtn;
    QPushButton *m_nettypeBtn;
    QPushButton *m_netnameBtn;

    TextListView *m_netStatusListView;
    TextListView *m_netnametListView;
    /***UI end***/

    QMap<int,QString> m_subjectMap;

    void drawUI();

    void initData();

    void initConnect();

    void showsetmgrForm();

private slots:
    void onstartvideoBtnClicked(bool clicked);

    void onstopvideoBtnClicked(bool clicked);

    void onensureBtnClicked(bool clicked);

    void updateImage();

private:

    Camera *_camera;
    QTimer *_timer;
    unsigned char *_imageBuffer;
    unsigned char *_rgbImageBuffer;

public:
    void on_startPushButton_clicked();
    void on_stopPushButton_clicked();

};

#endif // VIDEOSETFORM_H

