﻿/******************************************************************************

  Copyright (C), 2013-2015, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     : settingmgrform.h settingmgrform.cpp
  Version       : Initial
  Author        : Galaxy
  Created       : 2016/12/11
  Last Modified :
  Description   :
  Function List :
  History       :
  1.Date        : 2016/12/11
    Author      : Galaxy
    Modification: Created file

******************************************************************************/
#ifndef SETTINGMGRFORM_H
#define SETTINGMGRFORM_H

#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"

class SettingMgrForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit SettingMgrForm(QWidget *parent = 0);
    ~SettingMgrForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;

    /***UI widget start***/
    QPushButton *m_deviceParamSetBtn;
    QPushButton *m_deviceRegBtn;
    QPushButton *m_showVolumeSetBtn;
    QPushButton *m_deviceLogoutBtn;
    QPushButton *m_quitBtn;
    QToolButton   *m_homeBtn;
    /***UI widget end***/

private:
    void drawUI();

    /**
  *@brief   manager connect signal and slot
 */
    void initConnect();

    void showWelcomeRegForm();

    void showRegSuccessForm();

    void showTrainLoginForm();

    void showVideoSetForm();

    void showLogoffHintForm();

    void showVolumeLightForm();

    void showParamSetForm();

private slots:
    void onDeviceRegBtnClicked(bool clicked);

    void onDeviceLogoffBtnClicked(bool clicked);

    void onHomeBtnClicked(bool clicked);

    void onQuitBtnClicked(bool clicked);

    void onVolumeLightBtnClicked(bool clicked);

    void onParamSetBtnClicked(bool clicked);

};

#endif // SETTINGMGRFORM_H

