/******************************************************************************

  Copyright (C), 2013-2015, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     : registerinfoinput.h registerinfoinput.cpp
  Version       : Initial
  Author        : Galaxy
  Created       : 2016/12/12
  Last Modified :
  Description   :
  Function List :
  History       :
  1.Date        : 2016/12/12
    Author      : Galaxy
    Modification: Created file

******************************************************************************/
#ifndef REGISTERINFOINPUT_H
#define REGISTERINFOINPUT_H

#include <QLineEdit>
#include <QPushButton>
#include "basewidget.h"
#include "textlistview.h"

class RegisterInfoInputForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit RegisterInfoInputForm(QWidget *parent = 0);
    ~RegisterInfoInputForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();


private:
    QStackedWidget *m_mainStackWidget;

    /***UI  widget start***/
    QLineEdit *m_provinceIdLe;
    QLineEdit *m_cityIdLe;
    QLineEdit *m_madeFactoryLe;
    QLineEdit *m_deviceModelNoLe;

    QLineEdit *m_deviceSerialNoLe;
    QLineEdit *m_deviceIMEILe;
    QLineEdit *m_carLicenseColorLe;
    QPushButton *m_carLicenseColorBtn;
    QPushButton *m_privinceBtn;
    QLineEdit *m_carLicenseNoLe;

    QPushButton *m_regBtn;
    QPushButton *m_preBtn;

    /***color choost list***/
    TextListView *m_colorChooseListView;
    TextListView *m_provinceListView;
    /***UI widget end***/

    void drawUI();

    void initConnect();

    void initDebugData();

    /**
  *@brief   set info for register
 */
    bool setRegisterInfo();

    bool verifyInput();

private slots:
    void onPreBtnClicked(bool clicked);

    void onChooseCarLicenseColor(bool clicked);

    void onCarLicenseColorChanged(int index, QString value);

    void onCarProChanged(int index, QString value);

    void onRegBtnClicked(bool clicked);

    void onPrivinceBtnClicked(bool clicked);
};

#endif // REGISTERINFOINPUT_H

