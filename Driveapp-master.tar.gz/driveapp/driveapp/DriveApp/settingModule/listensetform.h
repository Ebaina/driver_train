﻿#ifndef LISTENSETFORM_H
#define LISTENSETFORM_H

#include <QPushButton>
#include <QLineEdit>
#include "basewidget.h"
#include "textlistview.h"

class ListenSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit ListenSetForm(QWidget *parent = 0);
    ~ListenSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;

    //ui widgets
    QLineEdit *m_monitPlatPhoneLe;    //监控平台电话号码
    QLineEdit *m_resetPhone;                //复位电话号码
    QLineEdit *m_monitPlatSmsPhoneLe;  //监控平台SMS电话号码
    QLineEdit *m_recvSmsAlarmLe;        //接收终端SMS文本报警号码
    QLineEdit *m_monitPhoneLe;           //监听电话号码
    QPushButton *m_terminalPhoneWayBtn;     //终端电话接听策略
    QLineEdit *m_monitPlatTextPhoneLe;           //监管平台特权短信号码
    QLineEdit *m_factoryResetPhoneLe;              //恢复出厂设置电话号码
    QLineEdit *m_phoneTimeLe;                          //每次最长通话时间
    QLineEdit *m_phoneTimeMonthLe;              //当月最长通话时间
    QPushButton *m_saveBtn;
    QPushButton *m_backBtn;

    TextListView *m_phoneWayListView;
    QMap<int, QString> m_phoneWayMap;

    void drawUI();

    void initData();

    void back();

    //verify input value valid or not
    bool verifyInput();

    void showParamSetForm();

private slots:
    void onSaveBtnClicked();

    void onBackBtnClicked();

    void onTerminalPhoneWayBtnClicked();

    void onPhoneWayChanged(int index, QString value);
};

#endif // LISTENSETFORM_H
