#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QTimer>
#include <QDebug>
#include "logoffform.h"
#include "settingmgrform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "registerhintform.h"

LogOffForm::LogOffForm(wis_u16 type, QWidget *parent) :
    BaseWidget(parent),
    m_type(type),
    m_mainStackWidget(NULL)
{
    this->setObjectName(QString("logOffForm"));
    drawUI();
    initConnect();
}

LogOffForm::~LogOffForm()
{

}

wis_u16 LogOffForm::type()
{
    return WIS_UI_ENUM::LOGOFF_FORM;
}

void LogOffForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void LogOffForm::updateContent()
{
    switch(m_type){
    case WIS_UI_ENUM::LOGOFF_FORM:
        m_lbTitle->setText(tr("你确定注销此设备吗"));
        break;
    default:
        break;
    }
}

void LogOffForm::drawUI()
{
    switch (m_type) {
    case WIS_UI_ENUM::LOGOFF_HINT_FORM:
        drawHintLogoffForm();
        break;
    case WIS_UI_ENUM::LOGOFF_FORM:
        drawLogoffForm();
        break;
    case WIS_UI_ENUM::LOGOFF_SUCCESS_FORM:
        drawLogoffSuccessForm();
        break;
    default:
        break;
    }
}

void LogOffForm::initConnect()
{
    switch (m_type) {
    case WIS_UI_ENUM::LOGOFF_HINT_FORM:
    {
        connect(m_pbLeft, SIGNAL(clicked(bool)), this, SLOT(onNextBtnClicked(bool)));
        connect(m_pbright, SIGNAL(clicked(bool)), this, SLOT(onBackSetFormBtnClicked(bool)));
    }
        break;
    case WIS_UI_ENUM::LOGOFF_FORM:
    {
        connect(m_pbright, SIGNAL(clicked(bool)), this, SLOT(onBackSetFormBtnClicked(bool)));
        connect(m_pbLeft, SIGNAL(clicked(bool)), this, SLOT(onEnsureLogoffBtnClicked(bool)));
        connect(HandlerManager::instance()->getSettingHandler(), SIGNAL(sigUpdateUnRegState(unsigned char)), this, SLOT(onUpdateUnRegDeviceAck(unsigned char)));
    }
        break;
    case WIS_UI_ENUM::LOGOFF_SUCCESS_FORM:
    {
       connect(m_pbright, SIGNAL(clicked(bool)), this, SLOT(onBackSetFormBtnClicked(bool)));
       connect(m_pbLeft, SIGNAL(clicked(bool)), this, SLOT(onRegBtnClicked(bool)));
    }
        break;
    default:
        break;
    }
}

void LogOffForm::onNextBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showLogoffForm();
}

void LogOffForm::onBackSetFormBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showSetForm();
}

void LogOffForm::onEnsureLogoffBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    bool b = HandlerManager::instance()->getSettingHandler()->unRegisterDevice();
    if(!b){
        return;
    }
    m_lbTitle->setText(tr("正在注销..."));
    updateBtnEnable(false);
}

void LogOffForm::drawHintLogoffForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 96, 0, 20);
    QLabel *lbOne = new QLabel(this);
    m_lbTitle = lbOne;
    lbOne->setText(tr("确定注销此设备吗"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

//    请点击下一步注销
    QLabel *lbTwo = new QLabel(this);
    lbTwo->setStyleSheet(QString("font-size:30px;color:#ffffff"));
    lbTwo->setText(tr("请点击下一步注销"));
    lbTwo->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTwo);

    QHBoxLayout *midBtnLayout = new QHBoxLayout;
    m_pbLeft = new QPushButton(tr("下一步"),this);
    m_pbLeft->setObjectName(QString("leftBtn"));
    midBtnLayout->addStretch();
    midBtnLayout->addWidget(m_pbLeft);
    m_pbright = new QPushButton(tr("返回"),this);
    m_pbright->setObjectName(QString("rightBtn"));
    midBtnLayout->addWidget(m_pbright);
    midBtnLayout->addStretch();

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(midBtnLayout);

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    m_homeBtn = new QToolButton(this);
    m_homeBtn->setVisible(true);
    m_homeBtn->setObjectName(QString("homeBtn"));
    m_homeBtn->setToolButtonStyle(Qt::ToolButtonIconOnly);
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home.png"));
    bottomLayout->addStretch();
    bottomLayout->addWidget(m_homeBtn);

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(bottomLayout);
}

void LogOffForm::drawLogoffForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 96, 0, 20);
    QLabel *lbOne = new QLabel(this);
    m_lbTitle = lbOne;
    lbOne->setText(tr("确定要注销此设备?"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

    QHBoxLayout *midBtnLayout = new QHBoxLayout;
    m_pbLeft = new QPushButton(tr("确认"),this);
    m_pbLeft->setObjectName(QString("leftBtn"));
    midBtnLayout->addStretch();
    midBtnLayout->addWidget(m_pbLeft);
    m_pbright = new QPushButton(tr("返回"),this);
    m_pbright->setObjectName(QString("rightBtn"));
    midBtnLayout->addWidget(m_pbright);
    midBtnLayout->addStretch();

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(midBtnLayout);

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    m_homeBtn = new QToolButton(this);
    m_homeBtn->setVisible(true);
    m_homeBtn->setObjectName(QString("homeBtn"));
    m_homeBtn->setToolButtonStyle(Qt::ToolButtonIconOnly);
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home.png"));
    bottomLayout->addStretch();
    bottomLayout->addWidget(m_homeBtn);

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(bottomLayout);
}

void LogOffForm::drawLogoffSuccessForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 96, 0, 20);
    QLabel *lbOne = new QLabel(this);
    m_lbTitle = lbOne;
    lbOne->setText(tr("此设备已经注销成功"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

//    请点击下一步注销
    QLabel *lbTwo = new QLabel(this);
    lbTwo->setStyleSheet(QString("font-size:30px;color:#ffffff"));
    lbTwo->setText(tr("如果继续使用,请重新注册"));
    lbTwo->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTwo);

    QHBoxLayout *midBtnLayout = new QHBoxLayout;
    m_pbLeft = new QPushButton(tr("注册"),this);
    m_pbLeft->setObjectName(QString("leftBtn"));
    midBtnLayout->addStretch();
    midBtnLayout->addWidget(m_pbLeft);
    m_pbright = new QPushButton(tr("返回"),this);
    m_pbright->setObjectName(QString("rightBtn"));
    midBtnLayout->addWidget(m_pbright);
    midBtnLayout->addStretch();

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(midBtnLayout);

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    m_homeBtn = new QToolButton(this);
    m_homeBtn->setVisible(false);
    m_homeBtn->setObjectName(QString("homeBtn"));
    m_homeBtn->setToolButtonStyle(Qt::ToolButtonIconOnly);
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home.png"));
    bottomLayout->addStretch();
    bottomLayout->addWidget(m_homeBtn);

    baseVbLayout->addStretch();
    baseVbLayout->addLayout(bottomLayout);
}

void LogOffForm::showLogoffForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::LOGOFF_FORM);
    LogOffForm *logoffForm = NULL;
    if(!bw){
        logoffForm = new LogOffForm(WIS_UI_ENUM::LOGOFF_FORM);
        logoffForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::LOGOFF_FORM,logoffForm);
        m_mainStackWidget->addWidget(logoffForm);

    }else{
        logoffForm = static_cast<LogOffForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(logoffForm);
    logoffForm->updateContent();
}

void LogOffForm::showSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_MGR_FORM);
    SettingMgrForm *setForm = NULL;
    if(!bw){
        setForm = new SettingMgrForm();
        setForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_MGR_FORM,setForm);
        m_mainStackWidget->addWidget(setForm);

    }else{
        setForm = static_cast<SettingMgrForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(setForm);
    setForm->updateContent();
}

void LogOffForm::showRegisterForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::WELCOME_REG_HINT_FORM);
    RegisterHintForm *welcomeRegForm = NULL;
    if(!bw){
        welcomeRegForm = new RegisterHintForm(WIS_UI_ENUM::WELCOME_REG_HINT_FORM);
        welcomeRegForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::WELCOME_REG_HINT_FORM,welcomeRegForm);
        m_mainStackWidget->addWidget(welcomeRegForm);

    }else{
        welcomeRegForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(welcomeRegForm);
    welcomeRegForm->updateContent();
}

void LogOffForm::showLogoffSuccessForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::LOGOFF_SUCCESS_FORM);
    LogOffForm *successForm = NULL;
    if(!bw){
        successForm = new LogOffForm(WIS_UI_ENUM::LOGOFF_SUCCESS_FORM);
        successForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::LOGOFF_SUCCESS_FORM,successForm);
        m_mainStackWidget->addWidget(successForm);

    }else{
        successForm = static_cast<LogOffForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(successForm);
    successForm->updateContent();
}

void LogOffForm::updateBtnEnable(bool b)
{
    m_pbLeft->setEnabled(b);
    m_pbright->setEnabled(b);
    m_homeBtn->setEnabled(b);
}

void LogOffForm::onUpdateUnRegDeviceAck(unsigned char state)
{
    updateBtnEnable(true);
    qDebug() << "state ====" << state;
    if(state == UI_HEADER::RS_YES){
        m_lbTitle->setText(tr("你确定注销此设备吗"));
        showLogoffSuccessForm();
    }else{
       m_lbTitle->setText(tr("注销失败"));
       QTimer::singleShot(2000, this, SLOT(onTimeout()));
    }
}

void LogOffForm::onRegBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showRegisterForm();
}

void LogOffForm::onTimeout()
{
    m_lbTitle->setText(tr("你确定注销此设备吗"));
}

