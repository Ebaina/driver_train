#ifndef SWIPINGCARDFORM_H
#define SWIPINGCARDFORM_H

#include <QLabel>
#include <QProgressBar>
#include "basewidget.h"

class SwipingCardForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit SwipingCardForm(QWidget *parent = 0);
    ~SwipingCardForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;

    /***UI start***/
    QLabel *m_userNameLb;
    QProgressBar *m_regProgressBar;
    QLabel *m_regRetLb;
    /***UI end***/

    void drawUI();

private slots:
    void updateRegRet(int state);

    /***handle reg success***/
    void onRegSuccess();

    /***hand reg failed***/
    void onRegFailed();
};

#endif // SWIPINGCARDFORM_H

