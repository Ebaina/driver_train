﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include "netparamsetform.h"
#include "handlermanager.h"
#include "widgetcollector.h"
#include "paramsetform.h"

NetParamSetForm::NetParamSetForm(QWidget *parent) :
    BaseWidget(parent)
{
    this->setObjectName("netParamSetForm");
    m_mainStackWidget = NULL;
    drawUI();
}

NetParamSetForm::~NetParamSetForm()
{

}

wis_u16 NetParamSetForm::type()
{
    return WIS_UI_ENUM::SETTING_NET_FORM;
}

void NetParamSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void NetParamSetForm::updateContent()
{
    //init param values
    UI_NetSet netSet = HandlerManager::instance()->getSettingHandler()->getNetParams();
    m_mainServerComUserLe->setText(QString((char*)netSet.Mainserver_User).left(STRDATA_LENGTH).trimmed());
    m_mainServerComPasswdLe->setText(QString((char*)netSet.Mainserver_Password).left(STRDATA_LENGTH).trimmed());
    m_mainServerAddrLe->setText(QString((char*)netSet.Mainserver_IP).left(STRDATA_LENGTH).trimmed());
    m_backupServerApnLe->setText(QString((char*)netSet.Backupserver_APN).left(STRDATA_LENGTH).trimmed());
    m_backupServerComUserLe->setText(QString((char*)netSet.Backupserver_User).left(STRDATA_LENGTH).trimmed());
    m_backupServerComPasswdLe->setText(QString((char*)netSet.Backupserver_Password).left(STRDATA_LENGTH).trimmed());
    m_backupServerAddrLe->setText(QString((char*)netSet.Backupserver_IP).left(STRDATA_LENGTH).trimmed());
    m_mainServerTcpPortLe->setText(QString::number(netSet.Server_TCP_Port, 10));
    m_mainServerUdpPortLe->setText(QString::number(netSet.Server_UDP_Port, 10));
}

void NetParamSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);

    QHBoxLayout *contentLayout = new QHBoxLayout;
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName("leftFrame");
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    QLabel *lb = new QLabel(tr("主服务器无线\n拨号用户名"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_mainServerComUserLe = new QLineEdit(this);
    m_mainServerComUserLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_mainServerComUserLe, 0, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 1, 0, 1, 4);

    lb = new QLabel(tr("主服务器无线\n拨号密码"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_mainServerComPasswdLe = new QLineEdit(this);
    m_mainServerComPasswdLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_mainServerComPasswdLe, 2, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 3, 0, 1, 4);

    lb = new QLabel(tr("主服务器地址\nIP或域名"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_mainServerAddrLe = new QLineEdit(this);
    m_mainServerAddrLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 4, 0, 1, 1);
    leftGridLayout->addWidget(m_mainServerAddrLe, 4, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 5, 0, 1, 4);

    lb = new QLabel(tr("TCP端口"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_mainServerTcpPortLe= new QLineEdit(this);
    m_mainServerTcpPortLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 0, 1, 1);
    leftGridLayout->addWidget(m_mainServerTcpPortLe, 6, 1, 1, 1);
    lb = new QLabel(tr("UDP端口"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_mainServerUdpPortLe= new QLineEdit(this);
    m_mainServerUdpPortLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 2, 1, 1);
    leftGridLayout->addWidget(m_mainServerUdpPortLe, 6, 3, 1, 1);

    contentLayout->addWidget(leftFrame);
    //备份服务器布局
    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName("rightFrame");
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    lb = new QLabel(tr("备份服务器无线\n拨号用户名"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_backupServerComUserLe = new QLineEdit(this);
    m_backupServerComUserLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 0, 0, 1, 1);
    rightGridLayout->addWidget(m_backupServerComUserLe, 0, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 1, 0, 1, 2);

    lb = new QLabel(tr("备份服务器无线\n拨号密码"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_backupServerComPasswdLe = new QLineEdit(this);
    m_backupServerComPasswdLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2, 0, 1, 1);
    rightGridLayout->addWidget(m_backupServerComPasswdLe, 2, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 3, 0, 1, 2);

    lb = new QLabel(tr("备份服务器地址\nIP或域名"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_backupServerAddrLe = new QLineEdit(this);
    m_backupServerAddrLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 4, 0, 1, 1);
    rightGridLayout->addWidget(m_backupServerAddrLe, 4, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 5, 0, 1, 2);

    lb = new QLabel(tr("服务器APN\n访问点"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_backupServerApnLe = new QLineEdit(this);
    m_backupServerApnLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 6, 0, 1, 1);
    rightGridLayout->addWidget(m_backupServerApnLe, 6, 1, 1, 1);

    contentLayout->addWidget(rightFrame);

    baseVbLayout->addLayout(contentLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_saveBtn  = new QPushButton(tr("保存"),this);
    m_saveBtn->setProperty("class", QVariant("paramSaveBtn"));
    m_backBtn = new QPushButton(tr("返回"),this);
    m_backBtn->setProperty("class", QVariant("paramBackBtn"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_saveBtn);
    bottomBtnLayout->addWidget(m_backBtn);
    bottomBtnLayout->addStretch();

    baseVbLayout->addLayout(bottomBtnLayout);

    connect(m_saveBtn, SIGNAL(clicked()), this, SLOT(onSaveBtnClicked()));
    connect(m_backBtn, SIGNAL(clicked()), this, SLOT(onBackBtnClicked()));
}

void NetParamSetForm::back()
{
    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_NET_FORM)->deleteLater();
}

void NetParamSetForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void NetParamSetForm::onSaveBtnClicked()
{
    UI_NetSet netSet;
    memset((char*)&netSet, 0, sizeof(UI_NetSet));
    strcpy((char*)netSet.Backupserver_APN, m_backupServerApnLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Backupserver_IP, m_backupServerAddrLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Backupserver_Password, m_backupServerComPasswdLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Backupserver_User, m_backupServerComUserLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Mainserver_APN, m_mainServerAddrLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Mainserver_IP, m_mainServerAddrLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Mainserver_Password, m_mainServerComPasswdLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    strcpy((char*)netSet.Mainserver_User, m_mainServerComUserLe->text().trimmed().left(STRDATA_LENGTH).toStdString().c_str());
    netSet.Server_TCP_Port = m_mainServerTcpPortLe->text().trimmed().toInt();
    netSet.Server_UDP_Port = m_mainServerUdpPortLe->text().trimmed().toInt();

    bool b = HandlerManager::instance()->getSettingHandler()->setNetParams(netSet);
    if(!b){
        return;
    }

    back();
}

void NetParamSetForm::onBackBtnClicked()
{
    back();
}

