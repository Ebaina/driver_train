﻿#include <QGridLayout>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QDebug>
#include "settingmgrform.h"
#include "registerhintform.h"
#include "widgetcollector.h"
#include "trainloginform.h"
#include "logoffform.h"
#include "handlermanager.h"
#include "volumelightsetform.h"
#include "paramsetform.h"
#include "videosetform.h"

SettingMgrForm::SettingMgrForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    this->setObjectName(QString("settingMgrForm"));
    drawUI();

    initConnect();
}

SettingMgrForm::~SettingMgrForm()
{

}

wis_u16 SettingMgrForm::type()
{
    return WIS_UI_ENUM::SETTING_MGR_FORM;
}

void SettingMgrForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void SettingMgrForm::updateContent()
{

}

void SettingMgrForm::drawUI()
{
    QVBoxLayout *baseVBLayout = new QVBoxLayout(this);

    QGridLayout *gridLayout = new QGridLayout;

    m_deviceParamSetBtn = new QPushButton(this);
    m_deviceParamSetBtn->setObjectName(QString("devParamSetBtn"));
    m_deviceParamSetBtn->setText(tr("终端参数设置"));
    m_deviceParamSetBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/dev_param_set.png"));
    gridLayout->addWidget(m_deviceParamSetBtn,0,0,1,1);

    m_deviceRegBtn = new QPushButton(this);
    m_deviceRegBtn->setObjectName(QString("deviceRegBtn"));
    m_deviceRegBtn->setText(tr("终端注册"));
    m_deviceRegBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/device_reg.png"));
    gridLayout->addWidget(m_deviceRegBtn,0,1,1,1);

    m_showVolumeSetBtn = new QPushButton(this);
    m_showVolumeSetBtn->setObjectName(QString("showVolumeSetBtn"));
    m_showVolumeSetBtn->setText(tr("显示和音量设置"));
    m_showVolumeSetBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/volume_set.png"));
    gridLayout->addWidget(m_showVolumeSetBtn,1,0,1,1);

    m_deviceLogoutBtn = new QPushButton(this);
    m_deviceLogoutBtn->setObjectName(QString("deviceLogoutBtn"));
    m_deviceLogoutBtn->setText(tr("终端注销"));
    m_deviceLogoutBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/device_logout.png"));
    gridLayout->addWidget(m_deviceLogoutBtn,1,1,1,1);

    baseVBLayout->addLayout(gridLayout);

    QHBoxLayout *bottomHbLayout = new QHBoxLayout;
    m_quitBtn = new QPushButton(this);
    m_quitBtn->setObjectName(QString("quitBtn"));
    m_quitBtn->setText(tr("退出"));
    bottomHbLayout->addStretch();
    bottomHbLayout->addWidget(m_quitBtn);

    m_homeBtn = new QToolButton(this);
//    m_homeBtn->setVisible(false);
    m_homeBtn->setObjectName(QString("homeBtn"));
    m_homeBtn->setToolButtonStyle(Qt::ToolButtonIconOnly);
    m_homeBtn->setIcon(QIcon(":/resource/image/video_set.png"));
    bottomHbLayout->addStretch();
    bottomHbLayout->addWidget(m_homeBtn);

    baseVBLayout->addLayout(bottomHbLayout);
}

void SettingMgrForm::initConnect()
{
    connect(m_deviceRegBtn, SIGNAL(clicked(bool)), this, SLOT(onDeviceRegBtnClicked(bool)));
    connect(m_homeBtn, SIGNAL(clicked(bool)), this, SLOT(onHomeBtnClicked(bool)));
    connect(m_quitBtn, SIGNAL(clicked(bool)), this, SLOT(onQuitBtnClicked(bool)));
    connect(m_deviceLogoutBtn, SIGNAL(clicked(bool)), this, SLOT(onDeviceLogoffBtnClicked(bool)));
    connect(m_showVolumeSetBtn, SIGNAL(clicked(bool)), this, SLOT(onVolumeLightBtnClicked(bool)));
    connect(m_deviceParamSetBtn, SIGNAL(clicked(bool)), this, SLOT(onParamSetBtnClicked(bool)));
}

void SettingMgrForm::showWelcomeRegForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::WELCOME_REG_HINT_FORM);
    RegisterHintForm *welcomeRegForm = NULL;
    if(!bw){
        welcomeRegForm = new RegisterHintForm(WIS_UI_ENUM::WELCOME_REG_HINT_FORM);
        welcomeRegForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::WELCOME_REG_HINT_FORM,welcomeRegForm);
        m_mainStackWidget->addWidget(welcomeRegForm);

    }else{
        welcomeRegForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(welcomeRegForm);
    welcomeRegForm->updateContent();
}

void SettingMgrForm::showRegSuccessForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::REG_SUCCESS_FORM);
    RegisterHintForm*regHintForm = NULL;
    if(!bw){
        regHintForm = new RegisterHintForm(WIS_UI_ENUM::REG_SUCCESS_FORM);
        regHintForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::REG_SUCCESS_FORM,regHintForm);
        m_mainStackWidget->addWidget(regHintForm);

    }else{
        regHintForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(regHintForm);
    regHintForm->updateContent();
}

void SettingMgrForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void SettingMgrForm::showVideoSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_VIDEO_FORM);
    videosetform *videoSetForm = NULL;
    if(!bw){
        videoSetForm = new videosetform();
        videoSetForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_VIDEO_FORM,videoSetForm);
        m_mainStackWidget->addWidget(videoSetForm);

    }else{
        videoSetForm = static_cast<videosetform*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(videoSetForm);
    videoSetForm->updateContent();
}

void SettingMgrForm::showLogoffHintForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::LOGOFF_HINT_FORM);
    LogOffForm *logoffHintForm = NULL;
    if(!bw){
        logoffHintForm = new LogOffForm(WIS_UI_ENUM::LOGOFF_HINT_FORM);
        logoffHintForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::LOGOFF_HINT_FORM,logoffHintForm);
        m_mainStackWidget->addWidget(logoffHintForm);

    }else{

        logoffHintForm = static_cast<LogOffForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(logoffHintForm);
    logoffHintForm->updateContent();
}

void SettingMgrForm::showVolumeLightForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM);
    VolumeLightSetForm *voghtForm = NULL;
    if(!bw){
        voghtForm = new VolumeLightSetForm();
        voghtForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM,voghtForm);
        m_mainStackWidget->addWidget(voghtForm);

    }else{
        voghtForm = static_cast<VolumeLightSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(voghtForm);
    voghtForm->setParentWidget(type());
    voghtForm->updateContent();
}

void SettingMgrForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void SettingMgrForm::onDeviceRegBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    SettingHandler *setHandler = HandlerManager::instance()->getSettingHandler();
    if(setHandler == NULL){
        return;
    }

    if(setHandler->isRegistered()){
        showRegSuccessForm();
    }else{
        showWelcomeRegForm();
    }

    setHandler = NULL;
}

void SettingMgrForm::onDeviceLogoffBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showLogoffHintForm();
}

void SettingMgrForm::onHomeBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showVideoSetForm();
}

void SettingMgrForm::onQuitBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showTrainLoginForm();
}

void SettingMgrForm::onVolumeLightBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    showVolumeLightForm();
}

void SettingMgrForm::onParamSetBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    showParamSetForm();
}
