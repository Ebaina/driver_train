﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include "paramadjustdlg.h"

ParamAdjustDlg::ParamAdjustDlg(QWidget *parent) :
    QDialog(parent)
{

}

void ParamAdjustDlg::drawUI()
{
//    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);

}

