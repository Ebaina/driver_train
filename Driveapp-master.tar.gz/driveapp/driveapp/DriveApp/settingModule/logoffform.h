#ifndef LOGOFFFORM_H
#define LOGOFFFORM_H

#include <QObject>
#include <QPushButton>
#include <QToolButton>
#include <QLabel>
#include "basewidget.h"

class LogOffForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit LogOffForm(wis_u16 type, QWidget *parent = 0);
    ~LogOffForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

signals:

public slots:
    void onNextBtnClicked(bool clicked);

    void onBackSetFormBtnClicked(bool clicked);

    void onEnsureLogoffBtnClicked(bool clicked);


private:
    wis_u16 m_type;
    QStackedWidget *m_mainStackWidget;
    QPushButton *m_pbLeft;
    QPushButton *m_pbright;
    QToolButton *m_homeBtn;
    QLabel *m_lbTitle;

    void drawUI();

    void initConnect();

    void drawHintLogoffForm();

    void drawLogoffForm();

    void drawLogoffSuccessForm();

    void showLogoffForm();

    void showSetForm();

    void showRegisterForm();

    void showLogoffSuccessForm();

    void updateBtnEnable(bool b);

private slots:
    void onUpdateUnRegDeviceAck(unsigned char state);

    void onRegBtnClicked(bool clicked);

    void onTimeout();
};

#endif // LOGOFFFORM_H
