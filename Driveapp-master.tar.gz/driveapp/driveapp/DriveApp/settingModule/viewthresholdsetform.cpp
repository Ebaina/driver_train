﻿#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QDebug>
#include "viewthresholdsetform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "paramsetform.h"

ViewthresholdSetForm::ViewthresholdSetForm(QWidget *parent) :
    BaseWidget(parent)
{
    this->setObjectName("viewthresholdSetForm");
    drawUI();
}

ViewthresholdSetForm::~ViewthresholdSetForm()
{

}

wis_u16 ViewthresholdSetForm::type()
{
    return WIS_UI_ENUM::SETTING_VIEW_THRES_FORM;
}

void ViewthresholdSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void ViewthresholdSetForm::updateContent()
{
    UI_ViewthresholdMainSet viewSet;
    memset((char*)&viewSet, 0, sizeof(UI_ViewthresholdMainSet));
    viewSet = HandlerManager::instance()->getSettingHandler()->getViewThresParams();
    m_alarmShieldByteLe->setText(QString::number(viewSet.Alarm_Shield_Byte, 10));
    m_alarmSendSMSTextLe->setText(QString::number(viewSet.Alarm_Send_SMS_Text, 10));
    m_alarmPictureSwitchLe->setText(QString::number(viewSet.Alarm_Picture_Switch, 10));
    m_alarmPictureSaveLe->setText(QString::number(viewSet.Alarm_Picture_Save, 10));
    m_keyIdentificationLe->setText(QString::number(viewSet.Key_Identification, 10));
    m_highSpeedLe->setText(QString::number(viewSet.High_Speed, 10));
    m_overSpeedTimeLe->setText(QString::number(viewSet.OverSpeed_Time, 10));
    m_continueDriTimeLe->setText(QString::number(viewSet.Continue_Dri_Time, 10));
    m_dayDriTimeLe->setText(QString::number(viewSet.Day_Dri_Time, 10));
    m_miniRestTimeLe->setText(QString::number(viewSet.Mini_Reset_Time, 10));
    m_maxParkTimeLe->setText(QString::number(viewSet.Max_Park_Time, 10));
}

void ViewthresholdSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);

    QHBoxLayout *contentLayout = new QHBoxLayout;
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName("leftFrame");
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    QLabel *lb = new QLabel(tr("报警屏蔽字"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_alarmShieldByteLe = new QLineEdit(this);
    m_alarmShieldByteLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_alarmShieldByteLe, 0, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 1, 0, 1, 2);

    lb = new QLabel(tr("报警SMS"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_alarmSendSMSTextLe = new QLineEdit(this);
    m_alarmSendSMSTextLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_alarmSendSMSTextLe, 2, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 3, 0, 1, 2);

    lb = new QLabel(tr("报警拍摄\n开关"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_alarmPictureSwitchLe = new QLineEdit(this);
    m_alarmPictureSwitchLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 4, 0, 1, 1);
    leftGridLayout->addWidget(m_alarmPictureSwitchLe, 4, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 5, 0, 1, 2);

    lb = new QLabel(tr("报警拍摄\n存储标识"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_alarmPictureSaveLe = new QLineEdit(this);
    m_alarmPictureSaveLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 0, 1, 1);
    leftGridLayout->addWidget(m_alarmPictureSaveLe, 6, 1, 1, 1);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 7, 0, 1, 2);

    lb = new QLabel(tr("关键标识"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_keyIdentificationLe = new QLineEdit(this);
    m_keyIdentificationLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 8, 0, 1, 1);
    leftGridLayout->addWidget(m_keyIdentificationLe, 8, 1, 1, 1);
    contentLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName("rightFrame");
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    lb = new QLabel(tr("最高速度"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_highSpeedLe = new QLineEdit(this);
    m_highSpeedLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 0, 0, 1, 1);
    rightGridLayout->addWidget(m_highSpeedLe, 0, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 1, 0, 1, 4);

    lb = new QLabel(tr("超速时间"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_overSpeedTimeLe = new QLineEdit(this);
    m_overSpeedTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2, 0, 1, 1);
    rightGridLayout->addWidget(m_overSpeedTimeLe, 2, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 3, 0, 1, 4);

    lb = new QLabel(tr("驾驶时间\n门限"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_continueDriTimeLe = new QLineEdit(this);
    m_continueDriTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 4, 0, 1, 1);
    rightGridLayout->addWidget(m_continueDriTimeLe, 4, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 5, 0, 1, 4);


    lb = new QLabel(tr("日累计\n驾驶时间"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_dayDriTimeLe = new QLineEdit(this);
    m_dayDriTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 6, 0, 1, 1);
    rightGridLayout->addWidget(m_dayDriTimeLe, 6, 1, 1, 3);
    lb = new QLabel(this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 7, 0, 1, 4);

    lb = new QLabel(tr("休息时间"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_miniRestTimeLe = new QLineEdit(this);
    m_miniRestTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 8, 0, 1, 1);
    rightGridLayout->addWidget(m_miniRestTimeLe, 8, 1, 1, 1);
    lb = new QLabel(tr("停车时间"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_maxParkTimeLe = new QLineEdit(this);
    m_maxParkTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 8, 2, 1, 1);
    rightGridLayout->addWidget(m_maxParkTimeLe, 8, 3, 1, 1);

    contentLayout->addWidget(rightFrame);
    baseVbLayout->addLayout(contentLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_saveBtn  = new QPushButton(tr("保存"),this);
    m_saveBtn->setProperty("class", QVariant("paramSaveBtn"));
    m_backBtn = new QPushButton(tr("返回"),this);
    m_backBtn->setProperty("class", QVariant("paramBackBtn"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_saveBtn);
    bottomBtnLayout->addWidget(m_backBtn);
    bottomBtnLayout->addStretch();

    baseVbLayout->addLayout(bottomBtnLayout);

    connect(m_saveBtn, SIGNAL(clicked()), this, SLOT(onSaveBtnClicked()));
    connect(m_backBtn, SIGNAL(clicked()), this, SLOT(onBackBtnClicked()));
}

void ViewthresholdSetForm::back()
{
    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_VIEW_THRES_FORM)->deleteLater();
}

bool ViewthresholdSetForm::verifyInput()
{
    return true;
}

void ViewthresholdSetForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void ViewthresholdSetForm::onBackBtnClicked()
{
    back();
}

void ViewthresholdSetForm::onSaveBtnClicked()
{
    if(!verifyInput()){
        return;
    }
    UI_ViewthresholdMainSet viewSet;
    memset((char*)&viewSet, 0, sizeof(UI_ViewthresholdMainSet));

    viewSet.Alarm_Picture_Save = m_alarmPictureSaveLe->text().trimmed().toInt();
    viewSet.Alarm_Picture_Switch = m_alarmPictureSwitchLe->text().trimmed().toInt();
    viewSet.Alarm_Send_SMS_Text = m_alarmSendSMSTextLe->text().trimmed().toInt();
    viewSet.Alarm_Shield_Byte = m_alarmShieldByteLe->text().trimmed().toInt();
    viewSet.Continue_Dri_Time = m_continueDriTimeLe->text().trimmed().toInt();
    viewSet.Day_Dri_Time = m_dayDriTimeLe->text().trimmed().toInt();
    viewSet.High_Speed = m_highSpeedLe->text().trimmed().toInt();
    viewSet.Key_Identification = m_keyIdentificationLe->text().trimmed().toInt();
    viewSet.Max_Park_Time = m_maxParkTimeLe->text().trimmed().toInt();
    viewSet.Mini_Reset_Time = m_miniRestTimeLe->text().trimmed().toInt();
    viewSet.OverSpeed_Time = m_overSpeedTimeLe->text().trimmed().toInt();

   if(!HandlerManager::instance()->getSettingHandler()->setViewThresParams(viewSet)){
       qDebug() << "set view and thres params failed";
       return;
   }

   back();
}

