﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include <QDebug>
#include "communicatesetform.h"
#include "handlermanager.h"
#include "widgetcollector.h"
#include "paramsetform.h"

CommunicateSetForm::CommunicateSetForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    this->setObjectName("communicateSetForm");
    drawUI();
}

CommunicateSetForm::~CommunicateSetForm()
{

}

wis_u16 CommunicateSetForm::type()
{
    return WIS_UI_ENUM::SETTING_COMMUNCATE_FORM;
}

void CommunicateSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void CommunicateSetForm::updateContent()
{
    SettingHandler *setHandler = HandlerManager::instance()->getSettingHandler();
    UI_CommunicateMainSet comParamSet = setHandler->getCommunParams();

    m_beatIntervalLe->setText(QString::number(comParamSet.Client_Heartbeat_Sec,10));
    m_tcpAckTimeoutLe->setText(QString::number(comParamSet.Tcp_Reply_Sec, 10));
    m_tcpMsgSendTimesLe->setText(QString::number(comParamSet.Tcp_Retransmission, 10));
    m_smsMsgAckTimeLe->setText(QString::number(comParamSet.SMS_Reply_Sec, 10));
    m_udpMsgAckTimeoutLe->setText(QString::number(comParamSet.Udp_Reply_Sec, 10));
    m_udpMsgSendTimesLe->setText(QString::number(comParamSet.Udp_Retransmission, 10));
    m_mainServerApnLe->setText(QString::number(comParamSet.SMS_Retransmission, 10));
}

void CommunicateSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);

    QHBoxLayout *hLayout = new QHBoxLayout;
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName("leftFrame");
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    QLabel *lb = new QLabel(tr("终端心跳\n发送间隔"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_beatIntervalLe = new QLineEdit(this);
    m_beatIntervalLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_beatIntervalLe, 0, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 1, 0, 1, 2);

    lb = new QLabel(tr("TCP消息\n应答超时时间"), this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_tcpAckTimeoutLe = new QLineEdit(this);
    m_tcpAckTimeoutLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_tcpAckTimeoutLe, 2, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 3, 0, 1, 2);

    lb = new QLabel(tr("TCP消息\n重传次数"), this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_tcpMsgSendTimesLe = new QLineEdit(this);
    m_tcpMsgSendTimesLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 4, 0, 1, 1);
    leftGridLayout->addWidget(m_tcpMsgSendTimesLe, 4, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 5, 0, 1, 2);

    lb = new QLabel(tr("SMS消息\n应答时间"), this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_smsMsgAckTimeLe = new QLineEdit(this);
    m_smsMsgAckTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 0, 1, 1);
    leftGridLayout->addWidget(m_smsMsgAckTimeLe, 6, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 7, 0, 1, 2);

    hLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName("rightFrame");
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);

    lb = new QLabel(tr("UDP消息\n应答超时时间"), this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_udpMsgAckTimeoutLe = new QLineEdit(this);
    m_udpMsgAckTimeoutLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 0, 0, 1, 1);
    rightGridLayout->addWidget(m_udpMsgAckTimeoutLe, 0, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 1, 0, 1, 2);

    lb = new QLabel(tr("UDP消息\n重传次数"), this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_udpMsgSendTimesLe = new QLineEdit(this);
    m_udpMsgSendTimesLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2, 0, 1, 1);
    rightGridLayout->addWidget(m_udpMsgSendTimesLe, 2, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 3, 0, 1, 2);

    lb = new QLabel(tr("SMS消息\n重传次数"), this);                      //主服务器APN\n无线拨号访问点
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_mainServerApnLe = new QLineEdit(this);
    m_mainServerApnLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 4, 0, 1, 1);
    rightGridLayout->addWidget(m_mainServerApnLe, 4, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 5, 0, 1, 2);

    lb = new QLabel(tr(""), this);               //CDMA的\nPPP拨号号码
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_cdmaPppNum = new QLineEdit(this);
    m_cdmaPppNum->setProperty("class", QVariant("rightContentLineEdit"));
    m_cdmaPppNum->setVisible(false);
    rightGridLayout->addWidget(lb, 6, 0, 1, 1);
    rightGridLayout->addWidget(m_cdmaPppNum, 6, 1, 1, 1);
    lb = new QLabel(tr(""),this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 7, 0, 1, 2);

    hLayout->addWidget(rightFrame);

    baseVbLayout->addLayout(hLayout);

    QHBoxLayout *btnLayout = new QHBoxLayout;
    m_saveBtn = new QPushButton(tr("保存"), this);
    m_saveBtn->setProperty("class", QVariant("paramSaveBtn"));
    m_backBtn = new QPushButton(tr("返回"), this);
    m_backBtn->setProperty("class", QVariant("paramBackBtn"));
//    m_homeBtn = new QToolButton(this);
    btnLayout->addStretch();
    btnLayout->addWidget(m_saveBtn);
    btnLayout->addWidget(m_backBtn);
    btnLayout->addStretch();
//    btnLayout->addWidget(m_homeBtn);

    baseVbLayout->addLayout(btnLayout);

    connect(m_saveBtn, SIGNAL(clicked()), this, SLOT(onSaveBtnClicked()));
    connect(m_backBtn, SIGNAL(clicked()), this, SLOT(onBackBtnClicked()));
}

bool CommunicateSetForm::verifyInput()
{
    return true;
}

bool CommunicateSetForm::saveCommunParams()
{

     SettingHandler *setHandler = HandlerManager::instance()->getSettingHandler();
     UI_CommunicateMainSet comParamSet;
     memset(&comParamSet,0,sizeof(comParamSet));
     comParamSet.Client_Heartbeat_Sec = m_beatIntervalLe->text().trimmed().toInt();
     comParamSet.SMS_Reply_Sec = m_smsMsgAckTimeLe->text().trimmed().toInt();
     comParamSet.Tcp_Reply_Sec = m_tcpAckTimeoutLe->text().trimmed().toInt();
     comParamSet.Tcp_Retransmission = m_tcpMsgSendTimesLe->text().trimmed().toInt();
     comParamSet.Udp_Reply_Sec = m_udpMsgAckTimeoutLe->text().trimmed().toInt();
     comParamSet.Udp_Retransmission = m_udpMsgSendTimesLe->text().trimmed().toInt();

     return setHandler->setCommunParams(comParamSet);
}

void CommunicateSetForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void CommunicateSetForm::onSaveBtnClicked()
{
    if(!saveCommunParams()){
        qDebug() << "save comparam failed";
        return;
    }

    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_COMMUNCATE_FORM)->deleteLater();
}

void CommunicateSetForm::onBackBtnClicked()
{
    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_COMMUNCATE_FORM)->deleteLater();
}

