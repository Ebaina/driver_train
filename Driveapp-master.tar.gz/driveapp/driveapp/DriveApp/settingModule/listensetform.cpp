﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include <QDebug>
#include "listensetform.h"
#include "widgetcollector.h"
#include "commondatamgr.h"
#include "handlermanager.h"
#include "paramsetform.h"

ListenSetForm::ListenSetForm(QWidget *parent) :
    BaseWidget(parent),
    m_phoneWayListView(NULL)
{
    this->setObjectName("listenSetForm");
    drawUI();

    initData();
}

ListenSetForm::~ListenSetForm()
{
    if(m_phoneWayListView != NULL){
        delete m_phoneWayListView;
        m_phoneWayListView = NULL;
    }
}

wis_u16 ListenSetForm::type()
{
    return WIS_UI_ENUM::SETTING_LISTEN_FORM;
}

void ListenSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void ListenSetForm::updateContent()
{
    UI_ListenMainSet listenSet;
    memset((char*)&listenSet, 0, sizeof(UI_ListenMainSet));
    listenSet = HandlerManager::instance()->getSettingHandler()->getListenParams();
    m_monitPlatPhoneLe->setText(QString((char*)listenSet.Monitoring_Platform_Phone).left(STRDATA_LENGTH).trimmed());
    m_resetPhone->setText(QString((char*)listenSet.Reset_Phone).left(STRDATA_LENGTH).trimmed());
    m_factoryResetPhoneLe->setText(QString((char*)listenSet.Factory_Reset_Phone).left(STRDATA_LENGTH).trimmed());
    m_monitPlatSmsPhoneLe->setText(QString((char*)listenSet.Monitoring_Platform_SMS_Phone).left(STRDATA_LENGTH).trimmed());
    m_recvSmsAlarmLe->setText(QString((char*)listenSet.Receiving_SMS_Alarm).left(STRDATA_LENGTH).trimmed());
    m_terminalPhoneWayBtn->setText(CommonDataMgr::getTerminalPhoneRecvWayValue(listenSet.Terminal_Phone_Way));
    m_terminalPhoneWayBtn->setWhatsThis(QString::number(listenSet.Terminal_Phone_Way, 10));
    m_phoneTimeLe->setText(QString::number(listenSet.Phone_Time, 10));
    m_phoneTimeMonthLe->setText(QString::number(listenSet.Phone_Time_Month, 10));
    m_monitPhoneLe->setText(QString((char*)listenSet.Monitor_Phone).left(STRDATA_LENGTH).trimmed());
    m_monitPlatTextPhoneLe->setText(QString((char*)listenSet.Monitor_Platform_Text_Phone).left(STRDATA_LENGTH).trimmed());
}

void ListenSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    QHBoxLayout *contentLayout = new QHBoxLayout;
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName("leftFrame");
    QGridLayout *leftGridLayout = new QGridLayout(leftFrame);
    QLabel *lb = new QLabel(tr("监控平台\n电话号码"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_monitPlatPhoneLe = new QLineEdit(this);
    m_monitPlatPhoneLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 0, 0, 1, 1);
    leftGridLayout->addWidget(m_monitPlatPhoneLe,0, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 1, 0, 1, 2);

    lb = new QLabel(tr("复位电话"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_resetPhone = new QLineEdit(this);
    m_resetPhone->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 2, 0, 1, 1);
    leftGridLayout->addWidget(m_resetPhone, 2, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 3, 0, 1, 2);

    lb = new QLabel(tr("监控平台\nSMS电话"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_monitPlatSmsPhoneLe = new QLineEdit(this);
    m_monitPlatSmsPhoneLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 4, 0, 1, 1);
    leftGridLayout->addWidget(m_monitPlatSmsPhoneLe, 4, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 5, 0, 1, 2);

    lb = new QLabel(tr("接收终端SMS\n文本报警号码"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_recvSmsAlarmLe = new QLineEdit(this);
    m_recvSmsAlarmLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 6, 0, 1, 1);
    leftGridLayout->addWidget(m_recvSmsAlarmLe, 6, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    leftGridLayout->addWidget(lb, 7, 0, 1, 2);

    lb = new QLabel(tr("监管平台\n特权短信号码"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_monitPlatTextPhoneLe = new QLineEdit(this);
    m_monitPlatTextPhoneLe->setProperty("class", QVariant("rightContentLineEdit"));
    leftGridLayout->addWidget(lb, 8, 0, 1, 1);
    leftGridLayout->addWidget(m_monitPlatTextPhoneLe, 8, 1, 1, 1);

    contentLayout->addWidget(leftFrame);

    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName("rightFrame");
    QGridLayout *rightGridLayout = new QGridLayout(rightFrame);
    lb = new QLabel(tr("终端电话\n接听策略"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_terminalPhoneWayBtn = new QPushButton(this);
    m_terminalPhoneWayBtn->setProperty("class", QVariant("showTextBtn"));
    rightGridLayout->addWidget(lb, 0, 0, 1, 1);
    rightGridLayout->addWidget(m_terminalPhoneWayBtn,0, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 1, 0, 1, 2);

    lb = new QLabel(tr("监听电话"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_monitPhoneLe = new QLineEdit(this);
    m_monitPhoneLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 2, 0, 1, 1);
    rightGridLayout->addWidget(m_monitPhoneLe,2, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 3, 0, 1, 2);

    lb = new QLabel(tr("恢复出厂设置\n电话号码"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_factoryResetPhoneLe = new QLineEdit(this);
    m_factoryResetPhoneLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 4, 0, 1, 1);
    rightGridLayout->addWidget(m_factoryResetPhoneLe,4, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 5, 0, 1, 2);

    lb = new QLabel(tr("每次最长\n通话时间"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_phoneTimeLe = new QLineEdit(this);
    m_phoneTimeLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 6, 0, 1, 1);
    rightGridLayout->addWidget(m_phoneTimeLe,6, 1, 1, 1);
    lb = new QLabel(tr(""), this);
    lb->setProperty("class", QVariant("lbHorizontalLine"));
    rightGridLayout->addWidget(lb, 7, 0, 1, 2);

    lb = new QLabel(tr("当月最长\n通话时间"),this);
    lb->setProperty("class", QVariant("leftNameLb2"));
    m_phoneTimeMonthLe = new QLineEdit(this);
    m_phoneTimeMonthLe->setProperty("class", QVariant("rightContentLineEdit"));
    rightGridLayout->addWidget(lb, 8, 0, 1, 1);
    rightGridLayout->addWidget(m_phoneTimeMonthLe,8, 1, 1, 1);

    contentLayout->addWidget(rightFrame);
    baseVbLayout->addLayout(contentLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_saveBtn = new QPushButton(tr("保存"),this);
    m_saveBtn->setProperty("class", QVariant("paramSaveBtn"));
    m_backBtn = new QPushButton(tr("返回"),this);
    m_backBtn->setProperty("class", QVariant("paramBackBtn"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_saveBtn);
    bottomBtnLayout->addWidget(m_backBtn);
    bottomBtnLayout->addStretch();

    baseVbLayout->addLayout(bottomBtnLayout);

    connect(m_saveBtn, SIGNAL(clicked()), this, SLOT(onSaveBtnClicked()));
    connect(m_backBtn, SIGNAL(clicked()), this, SLOT(onBackBtnClicked()));
    connect(m_terminalPhoneWayBtn, SIGNAL(clicked()), this, SLOT(onTerminalPhoneWayBtnClicked()));
}

void ListenSetForm::initData()
{
    m_phoneWayMap.clear();
    m_phoneWayMap.insert(UI_HEADER::TPRW_AUTO, tr("自动接听"));
    m_phoneWayMap.insert(UI_HEADER::TPRW_MANUAL, tr("手动接听"));
}

void ListenSetForm::back()
{
    showParamSetForm();
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_LISTEN_FORM)->deleteLater();
}

bool ListenSetForm::verifyInput()
{
    return true;
}

void ListenSetForm::showParamSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_PARAM_FORM);
    ParamSetForm *paramForm = NULL;
    if(!bw){
        paramForm = new ParamSetForm();
        paramForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_PARAM_FORM,paramForm);
        m_mainStackWidget->addWidget(paramForm);

    }else{
        paramForm = static_cast<ParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(paramForm);
    paramForm->updateContent();
}

void ListenSetForm::onSaveBtnClicked()
{
    if(!verifyInput()){
        return;
    }

    UI_ListenMainSet listenSet;
    memset((char*)&listenSet, 0, sizeof(UI_ListenMainSet));
    strcpy((char*)listenSet.Monitoring_Platform_Phone, m_monitPlatPhoneLe->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    strcpy((char*)listenSet.Reset_Phone, m_resetPhone->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    strcpy((char*)listenSet.Factory_Reset_Phone, m_factoryResetPhoneLe->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    strcpy((char*)listenSet.Monitoring_Platform_SMS_Phone, m_monitPlatSmsPhoneLe->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    strcpy((char*)listenSet.Receiving_SMS_Alarm, m_recvSmsAlarmLe->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    listenSet.Terminal_Phone_Way = m_terminalPhoneWayBtn->whatsThis().toInt();
    listenSet.Phone_Time = m_phoneTimeLe->text().trimmed().toInt();
    listenSet.Phone_Time_Month = m_phoneTimeMonthLe->text().trimmed().toInt();
    strcpy((char*)listenSet.Monitor_Phone, m_monitPhoneLe->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    strcpy((char*)listenSet.Monitor_Platform_Text_Phone, m_monitPlatTextPhoneLe->text().left(STRDATA_LENGTH).trimmed().toStdString().c_str());
    if(!HandlerManager::instance()->getSettingHandler()->setListenParams(listenSet)){
        qDebug() << "set listen params failed";
        return;
    }

    back();
}

void ListenSetForm::onBackBtnClicked()
{
    back();
}

void ListenSetForm::onTerminalPhoneWayBtnClicked()
{
    if(m_phoneWayListView == NULL){
        m_phoneWayListView = new TextListView;
        m_phoneWayListView->setObjectName(QString("phoneWayChooseListView"));
        connect(m_phoneWayListView, SIGNAL(sigItemClicked(int,QString)), this, SLOT(onPhoneWayChanged(int,QString)));
    }
    m_phoneWayListView->setTextModel(m_phoneWayMap);
    m_phoneWayListView->showView();
}

void ListenSetForm::onPhoneWayChanged(int index, QString value)
{
    m_terminalPhoneWayBtn->setWhatsThis(QString::number(index, 10));
    m_terminalPhoneWayBtn->setText(value);
}

