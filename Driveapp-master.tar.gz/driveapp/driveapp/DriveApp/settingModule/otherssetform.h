﻿#ifndef OTHERSSETFORM_H
#define OTHERSSETFORM_H

#include <QPushButton>
#include <QLineEdit>
#include "textlistview.h"
#include "basewidget.h"

class OthersSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit OthersSetForm(QWidget *parent = 0);
    ~OthersSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();
private:
    QStackedWidget *m_mainStackWidget;

    //UI widgets
    QLineEdit *m_pictureLe;                //图像质量 1-10,1最好
    QLineEdit *m_m_lightnessLe;       //亮度 0-255
    QLineEdit *m_contrastLe;              //对比度，0-127
    QLineEdit *m_saturationLe;           //饱和度，0-127
    QLineEdit *m_chromaLe;               //色度, 0-255
    QLineEdit *m_provinceIdLe;                  //车辆所在的省域ID
    QLineEdit *m_cityIdLe;                          //车辆所在的市域ID
    QLineEdit *m_carMeilageLe;                   //车辆里程表读数
    QPushButton *m_proviceSimpleNameBtn;    //省域简称
    QLineEdit *m_motorPlateLe;                 //车号牌
    QPushButton *m_plateColorBtn;          //车牌颜色
    QLineEdit *m_impulseRatioLe;              //车辆脉冲系数
    QPushButton *m_saveBtn;
    QPushButton *m_backBtn;

    TextListView *m_colorChooseListView;
    TextListView *m_provinceListView;
    void drawUI();

    void back();

    bool verifyInput();

    void showParamSetForm();

private slots:
    void onSaveBtnClicked();

    void onBackBtnClicked();

    void onPlateColorBtnClicked();

    void onCarLicenseColorChanged(int index,QString value);

    void onProvinSimpleNameBtnClicked();

    void onCarPriSimpleNameChanged(int index,QString value);
};

#endif // OTHERSSETFORM_H
