﻿#ifndef VOLUMELIGHTSETFORM_H
#define VOLUMELIGHTSETFORM_H

#include <QToolButton>
#include <QProgressBar>
#include <QPushButton>
#include "basewidget.h"

class VolumeLightSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit VolumeLightSetForm(QWidget *parent = 0);
    ~VolumeLightSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

    //由于这个界面的入口有两个，所以返回的时候要返回到入口界面，所以要记住，这识设计商的不足之处吧
    void setParentWidget(int widgetType);

private:
    QStackedWidget *m_mainStackWidget;
    QToolButton *m_subLightBtn;
    QToolButton *m_addLightBtn;
    QProgressBar *m_lightPg;
    QToolButton *m_subVolumeBtn;
    QToolButton *m_addVolumeBtn;
    QProgressBar *m_volumePg;

    QPushButton *m_ensureBtn;
    QToolButton *m_homeBtn;

    int m_widgetType;

    void drawUI();

    void showtrainDisplayForm();

    void showSettingMgrForm();

private slots:
    void onEnsureBtnClicked(bool clicked);

    void onSubLightBtnClicked();

    void onAddLightBtnClicked();

    void onSubVolumeBtnClicked();

    void onAddVolumeBtnClicked();

};

#endif // VOLUMELIGHTSETFORM_H
