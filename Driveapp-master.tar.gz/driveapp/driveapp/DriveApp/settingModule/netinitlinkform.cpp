﻿#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QDebug>
#include <string.h>
#include <QValidator>
#include <QIntValidator>
#include <QToolTip>
#include "netinitlinkform.h"
#include "registerinfoinput.h"
#include "widgetcollector.h"
#include "settingmgrform.h"
#include "handlermanager.h"


NetInitLinkForm::NetInitLinkForm(QWidget *parent) :
    BaseWidget(parent)
{
    this->setObjectName(QString("netInitLinkForm"));

    drawUI();

    initConnect();

    m_settingHandler = HandlerManager::instance()->getSettingHandler();
}

NetInitLinkForm::~NetInitLinkForm()
{

}

wis_u16 NetInitLinkForm::type()
{
    return WIS_UI_ENUM::NET_INITLINK_FORM;
}

void NetInitLinkForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void NetInitLinkForm::updateContent()
{
    initDebugData();
}

void NetInitLinkForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(30,30,30,25);
    baseVbLayout->setSpacing(20);
    QLabel *lbTitle = new QLabel(tr("请输入网络信息"));
    lbTitle->setStyleSheet(QString("font-size:46px; font-weight:bold;color:#ffffff;bottom:25px;"));
    lbTitle->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);
    lbTitle->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTitle);

    QFrame *inputInfoFrame = new QFrame(this);
    inputInfoFrame->setObjectName(QString("inputNetInfoFrame"));
    QGridLayout *inputFrameLayout = new QGridLayout(inputInfoFrame);

    QLabel *lb = new QLabel("主服务器",this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    inputFrameLayout->addWidget(lb, 0,0,1,1);
    m_mainServerAddrLe = new QLineEdit(this);
    m_mainServerAddrLe->setMaxLength(16);
    m_mainServerAddrLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_mainServerAddrLe->setPlaceholderText(tr("IP或域名"));
    inputFrameLayout->addWidget(m_mainServerAddrLe,0,1,1,1);
    QLabel *lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    inputFrameLayout->addWidget(lbLine,1,0,1,2);

    lb = new QLabel(tr("备份服务器"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    inputFrameLayout->addWidget(lb, 2,0,1,1);
    m_backupServerAddrLe = new QLineEdit(this);
    m_backupServerAddrLe->setMaxLength(16);
    m_backupServerAddrLe->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_backupServerAddrLe->setPlaceholderText(tr("IP或域名"));
    inputFrameLayout->addWidget(m_backupServerAddrLe,2,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    inputFrameLayout->addWidget(lbLine,3,0,1,2);

    lb = new QLabel(tr("TCP端口"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    inputFrameLayout->addWidget(lb, 4,0,1,1);
    m_serverTcpPort = new QLineEdit(this);
    QIntValidator *intValid =new QIntValidator(this);
    intValid->setRange(0, 65535);
    m_serverTcpPort->setValidator(intValid);
    m_serverTcpPort->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_serverTcpPort->setPlaceholderText(tr("填写TCP端口"));
    inputFrameLayout->addWidget(m_serverTcpPort,4,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    inputFrameLayout->addWidget(lbLine,5,0,1,2);

//    lb = new QLabel(tr("UDP端口"),this);
//    lb->setProperty("class",QVariant(QString("leftnameLb")));
//    inputFrameLayout->addWidget(lb,6,0,1,1);
//    m_serverUdpPort = new QLineEdit(this);
//    m_serverUdpPort->setValidator(intValid);
//    m_serverUdpPort->setProperty("class",QVariant(QString("rightContentLineEdit")));
//    m_serverUdpPort->setPlaceholderText(tr("填写UDP端口"));
//    inputFrameLayout->addWidget(m_serverUdpPort,6,1,1,1);
    lb = new QLabel(tr("手机号"),this);
    lb->setProperty("class",QVariant(QString("leftnameLb")));
    inputFrameLayout->addWidget(lb,6,0,1,1);
    m_phone = new QLineEdit(this);
    m_phone->setMaxLength(16);
    m_phone->setProperty("class",QVariant(QString("rightContentLineEdit")));
    m_phone->setPlaceholderText(tr("填写手机号"));
    inputFrameLayout->addWidget(m_phone,6,1,1,1);
    lbLine = new QLabel(tr(""),this);
    lbLine->setProperty("class",QVariant("lbHorizontalLine"));
    inputFrameLayout->addWidget(lbLine,7,0,1,2);

    baseVbLayout->addWidget(inputInfoFrame);
    baseVbLayout->setAlignment(inputInfoFrame, Qt::AlignHCenter);

    QHBoxLayout *btnLayout = new QHBoxLayout;
    btnLayout->setContentsMargins(0,0,0,0);
    m_cancelBtn = new QPushButton(tr("取消"),this);
    m_cancelBtn->setObjectName(QString("cancelBtn"));
    btnLayout->addStretch();
    btnLayout->addWidget(m_cancelBtn);
    m_linkBtn = new QPushButton(tr("连接"),this);
    m_linkBtn->setObjectName(QString("linkBtn"));
    btnLayout->addWidget(m_linkBtn);
    btnLayout->addStretch();
    btnLayout->setSpacing(20);

    baseVbLayout->addLayout(btnLayout);
}

void NetInitLinkForm::initDebugData()
{
    SettingHandler *setHandler = HandlerManager::instance()->getSettingHandler();
    UI_NetMainSet netmainSet = setHandler->getNetMainParams();

    m_mainServerAddrLe->setText(QString((char*)netmainSet.Mainserver_IP).left(STRDATA_LENGTH).trimmed());
    m_backupServerAddrLe->setText(QString((char*)netmainSet.Backupserver_IP).left(STRDATA_LENGTH).trimmed());
    m_serverTcpPort->setText(QString::number(netmainSet.Server_TCP_Port, 10));
    m_phone->setText(QString((char*)netmainSet.phonenum).left(STRDATA_LENGTH).trimmed());
}

void NetInitLinkForm::initConnect()
{
    connect(m_linkBtn, SIGNAL(clicked(bool)), this, SLOT(onInitNetLinkSettings(bool)));
    connect(m_cancelBtn,SIGNAL(clicked(bool)), this, SLOT(onCancelBtnClicked(bool)));
}

bool NetInitLinkForm::initServerInfo()
{
    QString mainServerAddr = m_mainServerAddrLe->text().trimmed();
    QString backupServerAddr = m_backupServerAddrLe->text().trimmed();
    int tcpPort = m_serverTcpPort->text().trimmed().toInt();
    QString phonenum = m_phone->text().trimmed();

    UI_NetMainSet serverInfo;
    memset(&serverInfo,0,sizeof(serverInfo));
    strcpy((char*)serverInfo.Mainserver_IP,mainServerAddr.toStdString().c_str());
    strcpy((char*)serverInfo.Backupserver_IP,backupServerAddr.toStdString().c_str());
    serverInfo.Server_TCP_Port = tcpPort;

    int t = 16 - phonenum.length();
    for(int index = 0; index < t ; index++)
    {
        phonenum.insert(0,"0");
    }
    strcpy((char*)serverInfo.phonenum,phonenum.toStdString().c_str());

    qDebug() << serverInfo.Mainserver_IP << serverInfo.Backupserver_IP;

    return m_settingHandler->initServerInfo(serverInfo);
    return true;
}

bool NetInitLinkForm::verfyInput()
{
    if(m_mainServerAddrLe->text().isEmpty()){
        QToolTip::showText(m_mainServerAddrLe->mapToGlobal(QPoint(0,0)),QString("主服务器未填写"));
        qDebug() << "UI----->主服务器未填写";
//        m_mainServerAddrLe->setFocus();
        return false;
    }
    if(m_backupServerAddrLe->text().isEmpty()){
        QToolTip::showText(m_backupServerAddrLe->mapToGlobal(QPoint(0,0)),QString("备份服务器未填写"));
//        m_backupServerAddrLe->setFocus();
        qDebug() << "UI-------->备份服务器未填写";
        return false;
    }

    if(m_serverTcpPort->text().isEmpty()){
         QToolTip::showText(m_serverTcpPort->mapToGlobal(QPoint(0,0)),QString("TCP端口未填写"));
         qDebug() << "UI---------->TCP端口未填写";
        return false;
    }

    qDebug() << "phone length =========" << m_phone->text().trimmed().length();
    if(m_phone->text().isEmpty()){
        qDebug() << "UI------------->手机号未填写 " ;
        QToolTip::showText(m_phone->mapToGlobal(QPoint(0,0)),QString("手机号未填写"));
        return false;
    }
    return true;
}

void NetInitLinkForm::onInitNetLinkSettings(bool clicked)
{
    Q_UNUSED(clicked)
    if(!verfyInput()){
        qDebug() << "UI------->> input has null";
        return;
    }
    if(!initServerInfo()){
        qDebug() << "initserver info back=======>" << 0;
           return;
    }

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::REGISTER_INFO_INPUT_FORM);
    RegisterInfoInputForm *infoInputForm = NULL;
    if(!bw){
        infoInputForm = new RegisterInfoInputForm();
        infoInputForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::REGISTER_INFO_INPUT_FORM,infoInputForm);
        m_mainStackWidget->addWidget(infoInputForm);

    }else{
        infoInputForm = static_cast<RegisterInfoInputForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(infoInputForm);
    infoInputForm->updateContent();

}

void NetInitLinkForm::onCancelBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_MGR_FORM);
    SettingMgrForm *settingMgrForm = NULL;
    if(!bw){
        settingMgrForm = new SettingMgrForm();
        settingMgrForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_MGR_FORM,settingMgrForm);
        m_mainStackWidget->addWidget(settingMgrForm);

    }else{
        settingMgrForm = static_cast<SettingMgrForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(settingMgrForm);
}
