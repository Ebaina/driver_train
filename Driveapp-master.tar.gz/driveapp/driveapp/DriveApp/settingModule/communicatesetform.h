﻿#ifndef COMMUNICATESETFORM_H
#define COMMUNICATESETFORM_H

#include <QLineEdit>
#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"
class CommunicateSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit CommunicateSetForm(QWidget *parent = 0);
    ~CommunicateSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;
    QLineEdit *m_beatIntervalLe;                          //主服务器无线通信拨号用户名
    QLineEdit *m_tcpAckTimeoutLe;                    //TCP消息应答超时时间
    QLineEdit *m_tcpMsgSendTimesLe;                   //TCP消息重传次数
    QLineEdit *m_smsMsgAckTimeLe;                 //SMS消息应答时间
    QLineEdit *m_udpMsgAckTimeoutLe;            //UDP消息应答超时时间
    QLineEdit *m_udpMsgSendTimesLe;             //UDP消息重传次数
    QLineEdit *m_mainServerApnLe;                  // 主服务器APN无线拨号访问点
    QLineEdit *m_cdmaPppNum;                        //CDMA的PPP拨号号码
    QPushButton *m_saveBtn;
    QPushButton *m_backBtn;
//    QToolButton *m_homeBtn;
    void drawUI();

    //verify input value
    bool verifyInput();
    
    //save param to device
    bool saveCommunParams();

    void showParamSetForm();

private slots:
    void onSaveBtnClicked();

    void onBackBtnClicked();
};

#endif // COMMUNICATESETFORM_H
