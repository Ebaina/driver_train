﻿#ifndef VIEWTHRESHOLDSETFORM_H
#define VIEWTHRESHOLDSETFORM_H

#include <QLineEdit>
#include <QPushButton>
#include "basewidget.h"

class ViewthresholdSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit ViewthresholdSetForm(QWidget *parent = 0);
    ~ViewthresholdSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;

    //ui widgets
    QLineEdit *m_alarmShieldByteLe;            //报警屏蔽字
    QLineEdit *m_alarmSendSMSTextLe;       //报警发送文本SMS开关
    QLineEdit *m_alarmPictureSwitchLe;       //报警拍摄开关
    QLineEdit *m_alarmPictureSaveLe;          //报警拍摄存储标识
    QLineEdit *m_keyIdentificationLe;           //关键标识
    QLineEdit *m_highSpeedLe;                      //最高速度
    QLineEdit *m_overSpeedTimeLe;              //超速持续时间
    QLineEdit *m_continueDriTimeLe;            //连续驾驶时间门限
    QLineEdit *m_dayDriTimeLe;                     //天累计驾驶时间
    QLineEdit *m_miniRestTimeLe;                 //最小休息时间
    QLineEdit *m_maxParkTimeLe;                 //最长停车时间
    QPushButton *m_saveBtn;
    QPushButton *m_backBtn;

    void drawUI();

    void back();

    //检验输入的参数值是否正确
    bool verifyInput();

    void showParamSetForm();

private slots:
    void onBackBtnClicked();

    void onSaveBtnClicked();
};

#endif // VIEWTHRESHOLDSETFORM_H
