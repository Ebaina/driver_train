/******************************************************************************

  Copyright (C), 2013-2015, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     : registerhintform.h  registerhintform.cpp
  Version       : Initial
  Author        : NanJing Wisdom Shark BU
  Created       : 2016/12/7
  Last Modified :
  Description   :   register hint form
  Function List :
  History       :
  1.Date        : 2016/12/7
    Author      : galaxy
    Modification: Created file

******************************************************************************/
#ifndef REGISTERHINTFORM_H
#define REGISTERHINTFORM_H

#include <QObject>
#include <QPaintEvent>
#include "basewidget.h"

class RegisterHintForm : public BaseWidget
{
    Q_OBJECT
public:
    RegisterHintForm(wis_u16 type, QWidget *parent = 0);

     wis_u16 type();

     void updateContent();

     void setMainStackWidget(QStackedWidget *stackWidget);

private:
     wis_u16 m_type;
     QStackedWidget *m_mainStackWidget;
     bool m_autoJumpFlag;                                //timeout jump to other form

private:
    void drawUI();

    /**
    *@brief     draw form for hint enter reg form
    */
   void drawEnterRegHintForm();

   /**
  *@brief   draw form for welcome to reg
 */
   void drawWelcomeRegForm();

   /**
  *@brief   draw form for registeer
 */
   void drawRegSuccessForm();

   /**
  *@brief   draw reg failed form
 */
   void drawRegFailedForm();

   bool autoJumpFlag() const;
   void setAutoJumpFlag(bool autoJumpFlag);

private slots:
   void onEnterSettingBtnClicked(bool clicked);

   /**
  *@brief  enter next btn function:enter form for input register info
 */
   void onEnterNextBtnClicked(bool clicked);

   /**
  *@brief   enter to train login form
 */
   void onTrainLoginBtnClicked(bool clicked);

   void onTimeout();

};

#endif // REGISTERHINTFORM_H

