﻿#ifndef REPORTSETFORM_H
#define REPORTSETFORM_H

#include <QLineEdit>
#include <QPushButton>
#include "basewidget.h"
#include "textlistview.h"

class ReportSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit ReportSetForm(QWidget *parent = 0);
    ~ReportSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;

    //布局组件
    /*
     * wis_u32 Location_Report_Way;// 0x0020 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报
    wis_u32 Location_Report_Status;// 0x0021 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态
    wis_u32 Dri_Unlisted_Time_Report;// 0x0022 驾驶员未登录汇报时间间隔，单位为秒(s),>0
                                                                //0x0023-0x0026  保留
    wis_u32 Dormant_Time_Report;// 0x0027 休眠时汇报时间间隔，单位为秒(s),>0
    wis_u32 Emergency_Alarm_Time_Report;// 0x0028 紧急报警时汇报时间间隔，单位为秒(s),>0
    wis_u32 Default_Time_Report;// 0x0029 缺省时间汇报间隔，单位为秒(s),>0
                                                //0x002A-0x002B 保留
    wis_u32 Default_Distance_Report;// 0x002C 缺省距离汇报间隔，单位为米(m),>0
    wis_u32 Dri_Unlisted_Distance_Report;// 0x002D 驾驶员未登录汇报距离间隔，单位为米(m),>0
    wis_u32 Dormant_Distance_Report;// 0x002E 休眠时汇报距离间隔，单位为米(m),>0
    wis_u32 Emergency_Alarm_Distance_Report;// 0x002F 紧急报警时汇报距离间隔，单位为米(m),>0
    wis_u32 Inflection_Point;// 0x0030 拐点补传角度，<180°
                                                //0x0031-0x003F 保留
     */
    QPushButton *m_loctRepStraTegyBtn;          //位置汇报策略
    QPushButton *m_locatRepSchemeBtn;         //位置汇报方案
    QLineEdit *m_driUnLoginTimeIntLe;              //驾驶员未登录汇报时间间隔
    QLineEdit *m_dormantTimeIntLe;                  //休眠时汇报时间间隔
    QLineEdit *m_urgenTimeIntLe;                      //紧急报警时汇报时间间隔
    QLineEdit *m_defaultTimeIntLe;                    //缺省时间汇报间隔
    QLineEdit *m_defaultDistanceIntLe;                  //缺省距离汇报间隔
    QLineEdit *m_driUnLoginDistIntLe;               //驾驶员未登录汇报距离间隔
    QLineEdit *m_dormantDistIntLe;                   //休眠时汇报距离间隔
    QLineEdit *m_urgenDistIntLe;                        //紧急报警时汇报距离间隔
    QLineEdit *m_inflectRotateLe;                        //拐点补传角度
    QPushButton *m_saveBtn;
    QPushButton *m_backBtn;

    TextListView *m_strategyListView;
    TextListView *m_schemeListView;
    QMap<int, QString> m_strategyMap;
    QMap<int, QString> m_schemeMap;

    void drawUI();

    void initData();

    void back();

    bool saveParams();

    void showParamSetForm();

private slots:
    void onSaveBtnClicked();

    void onBackBtnClicked();

    void onStraTegyBtnClicked();

    void onStrategyChanged(int index, QString value);

    void onSchemeBtnClicked();

    void onSchemeChanged(int index, QString value);
};

#endif // REPORTSETFORM_H
