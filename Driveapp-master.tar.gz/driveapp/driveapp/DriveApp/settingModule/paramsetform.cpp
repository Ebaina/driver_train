﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <settingmgrform.h>
#include "paramsetform.h"
#include "widgetcollector.h"
#include "communicatesetform.h"
#include "netparamsetform.h"
#include "reportsetform.h"
#include "listensetform.h"
#include "viewthresholdsetform.h"
#include "otherssetform.h"

ParamSetForm::ParamSetForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    drawUI();
}

ParamSetForm::~ParamSetForm()
{

}

wis_u16 ParamSetForm::type()
{
    return WIS_UI_ENUM::SETTING_PARAM_FORM;
}

void ParamSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void ParamSetForm::updateContent()
{


}

void ParamSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    //
    QGridLayout *btnGridLayout = new QGridLayout;
    m_communicationBtn = new QPushButton(tr("通信设置"),this);
    m_communicationBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/commun_param.png"));
    m_communicationBtn->setProperty("class", QVariant("paramSetBtn"));
    m_reportBtn = new QPushButton(tr("汇报设置"),this);
    m_reportBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/report_param.png"));
    m_reportBtn->setProperty("class", QVariant("paramSetBtn"));
    btnGridLayout->addWidget(m_communicationBtn, 0, 0, 1, 1);
    btnGridLayout->addWidget(m_reportBtn, 0, 1, 1, 1);

    m_netBtn = new QPushButton(tr("网络设置"), this);
    m_netBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/net_param.png"));
    m_netBtn->setProperty("class", QVariant("paramSetBtn"));
    m_cameraBtn = new QPushButton(tr("摄像设置"), this);
    m_cameraBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/camera_param.png"));
    m_cameraBtn->setProperty("class", QVariant("paramSetBtn"));
    btnGridLayout->addWidget(m_netBtn, 1, 0, 1, 1);
    btnGridLayout->addWidget(m_cameraBtn, 1, 1, 1, 1);

    m_monitorBtn = new QPushButton(tr("监控设置"), this);
    m_monitorBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/monitor_param.png"));
    m_monitorBtn->setProperty("class", QVariant("paramSetBtn"));
    m_otherBtn = new QPushButton(tr("其他设置"), this);
    m_otherBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/others_param.png"));
    m_otherBtn->setProperty("class", QVariant("paramSetBtn"));
    btnGridLayout->addWidget(m_monitorBtn, 2, 0, 1, 1);
    btnGridLayout->addWidget(m_otherBtn, 2, 1, 1, 1);
    baseVbLayout->addLayout(btnGridLayout);

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_exitBtn = new QPushButton(tr("退出"),this);
    m_exitBtn->setObjectName("exitBtn");
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_exitBtn);
//    m_homeBtn = new QToolButton(this);
//    m_homeBtn->setObjectName("homeBtn");
    bottomBtnLayout->addStretch();
//    bottomBtnLayout->addWidget(m_homeBtn);
//    bottomBtnLayout->setAlignment(m_exitBtn, Qt::AlignHCenter);
//    bottomBtnLayout->setAlignment(m_homeBtn, Qt::AlignRight);

    baseVbLayout->addLayout(bottomBtnLayout);

    connect(m_exitBtn, SIGNAL(clicked(bool)), this, SLOT(onExitBtnClicked(bool)));
    connect(m_communicationBtn, SIGNAL(clicked()), this, SLOT(onCommunicationBtnClicked()));
    connect(m_netBtn, SIGNAL(clicked()), this, SLOT(onNetSetBtnClicked()));
    connect(m_reportBtn, SIGNAL(clicked()), this, SLOT(onReportSetBtnClicked()));
    connect(m_monitorBtn, SIGNAL(clicked()), this, SLOT(onMonitorBtnClicked()));
    connect(m_cameraBtn, SIGNAL(clicked()), this, SLOT(onCaremaBtnClicked()));
    connect(m_otherBtn, SIGNAL(clicked()), this, SLOT(onOthersBtnClicked()));
}

void ParamSetForm::showCommuncationSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_COMMUNCATE_FORM);
    CommunicateSetForm *communForm = NULL;
    if(!bw){
        communForm = new CommunicateSetForm();
        communForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_COMMUNCATE_FORM,communForm);
        m_mainStackWidget->addWidget(communForm);

    }else{
        communForm = static_cast<CommunicateSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(communForm);
    communForm->updateContent();
}

void ParamSetForm::showNetSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_NET_FORM);
    NetParamSetForm *netForm = NULL;
    if(!bw){
        netForm = new NetParamSetForm();
        netForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_NET_FORM,netForm);
        m_mainStackWidget->addWidget(netForm);

    }else{
        netForm = static_cast<NetParamSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(netForm);
    netForm->updateContent();
}

void ParamSetForm::showReportSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_REPORT_FORM);
    ReportSetForm *reportForm = NULL;
    if(!bw){
        reportForm = new ReportSetForm();
        reportForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_REPORT_FORM,reportForm);
        m_mainStackWidget->addWidget(reportForm);

    }else{
        reportForm = static_cast<ReportSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(reportForm);
    reportForm->updateContent();
}

void ParamSetForm::showListenSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_LISTEN_FORM);
    ListenSetForm *listenForm = NULL;
    if(!bw){
        listenForm = new ListenSetForm();
        listenForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_LISTEN_FORM,listenForm);
        m_mainStackWidget->addWidget(listenForm);

    }else{
        listenForm = static_cast<ListenSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(listenForm);
    listenForm->updateContent();
}

void ParamSetForm::showCaremaSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_VIEW_THRES_FORM);
    ViewthresholdSetForm *cameraForm = NULL;
    if(!bw){
        cameraForm = new ViewthresholdSetForm();
        cameraForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_VIEW_THRES_FORM,cameraForm);
        m_mainStackWidget->addWidget(cameraForm);

    }else{
        cameraForm = static_cast<ViewthresholdSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(cameraForm);
    cameraForm->updateContent();
}

void ParamSetForm::showOthersSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_OTHER_FORM);
    OthersSetForm *otherForm = NULL;
    if(!bw){
        otherForm = new OthersSetForm();
        otherForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_OTHER_FORM,otherForm);
        m_mainStackWidget->addWidget(otherForm);

    }else{
        otherForm = static_cast<OthersSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(otherForm);
    otherForm->updateContent();
}

void ParamSetForm::onExitBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_MGR_FORM);
    SettingMgrForm *setForm = NULL;
    if(!bw){
        setForm = new SettingMgrForm();
        setForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_MGR_FORM,setForm);
        m_mainStackWidget->addWidget(setForm);

    }else{
        setForm = static_cast<SettingMgrForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(setForm);
    setForm->updateContent();
}

void ParamSetForm::onCommunicationBtnClicked()
{
    showCommuncationSetForm();
}

void ParamSetForm::onNetSetBtnClicked()
{
    showNetSetForm();
}

void ParamSetForm::onReportSetBtnClicked()
{
    showReportSetForm();
}

void ParamSetForm::onMonitorBtnClicked()
{
    showListenSetForm();
}

void ParamSetForm::onCaremaBtnClicked()
{
    showCaremaSetForm();
}

void ParamSetForm::onOthersBtnClicked()
{
    showOthersSetForm();
}

