﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QDebug>
#include "volumelightsetform.h"
#include "traindisplayform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "settingmgrform.h"

VolumeLightSetForm::VolumeLightSetForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_widgetType(WIS_UI_ENUM::TRAIN_DISPLAY_FORM)
{
    this->setObjectName("volumeLightSetForm");
    drawUI();
}

VolumeLightSetForm::~VolumeLightSetForm()
{

}

wis_u16 VolumeLightSetForm::type()
{
    return WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM;
}

void VolumeLightSetForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void VolumeLightSetForm::updateContent()
{
    //get current volume and light
    m_lightPg->setValue(HandlerManager::instance()->getSettingHandler()->getLight());
    m_volumePg->setValue(HandlerManager::instance()->getSettingHandler()->getVolume());
}

void VolumeLightSetForm::setParentWidget(int widgetType)
{
    m_widgetType = widgetType;
}

void VolumeLightSetForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->addStretch();
    QFrame *midFrame = new QFrame(this);
    midFrame->setObjectName(QString("midFrame"));
    QGridLayout *frameLayout = new QGridLayout(midFrame);
    frameLayout->setContentsMargins(15,30,20,30);

    m_subLightBtn = new QToolButton(this);
    m_subLightBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/sub_light.png"));
    m_subLightBtn->setProperty("class", QVariant("subBtn"));
    m_lightPg = new QProgressBar(this);
    m_lightPg->setRange(0,10);
    m_lightPg->setValue(0);
    m_lightPg->setTextVisible(false);
    m_addLightBtn = new QToolButton(this);
    m_addLightBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/add_light.png"));
    m_addLightBtn->setProperty("class", QVariant("addBtn"));
    frameLayout->addWidget(m_subLightBtn, 0, 0, 1, 1);
    frameLayout->addWidget(m_lightPg, 0, 1, 1, 1);
    frameLayout->addWidget(m_addLightBtn, 0, 2, 1, 1);

    m_subVolumeBtn = new QToolButton(this);
    m_subVolumeBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/sub_volume.png"));
    m_subVolumeBtn->setProperty("class", QVariant("subBtn"));
    m_volumePg = new QProgressBar(this);
    m_volumePg->setRange(0,10);
    m_volumePg->setValue(0);
    m_volumePg->setTextVisible(false);
    m_addVolumeBtn = new QToolButton(this);
    m_addVolumeBtn->setIcon(QIcon(":/set_module_img/resource/image/settingModuleImg/add_volume.png"));
    m_addVolumeBtn->setProperty("class", QVariant("addBtn"));
    frameLayout->addWidget(m_subVolumeBtn, 1, 0, 1, 1);
    frameLayout->addWidget(m_volumePg, 1, 1, 1, 1);
    frameLayout->addWidget(m_addVolumeBtn, 1, 2, 1, 1);

    baseVbLayout->addWidget(midFrame);
    baseVbLayout->setAlignment(midFrame,Qt::AlignHCenter);
    baseVbLayout->addStretch();

    m_ensureBtn = new QPushButton(tr("确认"),this);
    m_ensureBtn->setObjectName(QString("ensureBtn"));
    baseVbLayout->addWidget(m_ensureBtn);

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    m_homeBtn = new QToolButton(this);
    m_homeBtn->setIcon(QIcon(":/resource/image/back_to_home_white.png"));
    m_homeBtn->setObjectName(QString("homeBtn"));
    bottomLayout->addStretch();
    bottomLayout->addWidget(m_homeBtn);
    baseVbLayout->addLayout(bottomLayout);

    connect(m_ensureBtn, SIGNAL(clicked(bool)), this, SLOT(onEnsureBtnClicked(bool)));
    connect(m_subLightBtn, SIGNAL(clicked()), this, SLOT(onSubLightBtnClicked()));
    connect(m_addLightBtn, SIGNAL(clicked()), this, SLOT(onAddLightBtnClicked()));
    connect(m_subVolumeBtn, SIGNAL(clicked()), this, SLOT(onSubVolumeBtnClicked()));
    connect(m_addVolumeBtn, SIGNAL(clicked()), this, SLOT(onAddVolumeBtnClicked()));
}

void VolumeLightSetForm::showtrainDisplayForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM);
    TrainDisplayForm *displayFom = NULL;
    if(!bw){
        displayFom = new TrainDisplayForm();
        displayFom->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM,displayFom);
        m_mainStackWidget->addWidget(displayFom);

    }else{
        displayFom = static_cast<TrainDisplayForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(displayFom);
    displayFom->updateContent();
}

void VolumeLightSetForm::showSettingMgrForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_MGR_FORM);
    SettingMgrForm *setForm = NULL;
    if(!bw){
        setForm = new SettingMgrForm();
        setForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_MGR_FORM,setForm);
        m_mainStackWidget->addWidget(setForm);

    }else{
        setForm = static_cast<SettingMgrForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(setForm);
    setForm->updateContent();
}

void VolumeLightSetForm::onEnsureBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    //back last page
    if(m_widgetType == WIS_UI_ENUM::TRAIN_DISPLAY_FORM){
        showtrainDisplayForm();
    }else if(WIS_UI_ENUM::SETTING_MGR_FORM == m_widgetType){
        showSettingMgrForm();
    }
    m_mainStackWidget->removeWidget(this);
    WidgetCollector::takeWidget(WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM)->deleteLater();
//    showtrainDisplayForm();
}

void VolumeLightSetForm::onSubLightBtnClicked()
{
    if(m_lightPg->value() == m_lightPg->minimum())
        return;
    m_lightPg->setValue(m_lightPg->value() - 1);
    HandlerManager::instance()->getSettingHandler()->setLight(m_lightPg->value());
}

void VolumeLightSetForm::onAddLightBtnClicked()
{

    if(m_lightPg->value() == m_lightPg->maximum())
        return;
    m_lightPg->setValue(m_lightPg->value() + 1);
    HandlerManager::instance()->getSettingHandler()->setLight(m_lightPg->value());
}

void VolumeLightSetForm::onSubVolumeBtnClicked()
{
    if(m_volumePg->value() == m_volumePg->minimum())
        return;
    m_volumePg->setValue(m_volumePg->value() - 1);
    HandlerManager::instance()->getSettingHandler()->setVolume(m_volumePg->value());
}

void VolumeLightSetForm::onAddVolumeBtnClicked()
{
    if(m_volumePg->value() == m_volumePg->maximum())
        return;
    m_volumePg->setValue(m_volumePg->value() + 1);
    HandlerManager::instance()->getSettingHandler()->setVolume(m_volumePg->value());
}

