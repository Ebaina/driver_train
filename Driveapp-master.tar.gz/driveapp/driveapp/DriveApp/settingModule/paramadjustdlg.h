﻿#ifndef PARAMADJUSTDLG_H
#define PARAMADJUSTDLG_H

#include <QDialog>
#include <QLabel>
#include <QProgressBar>
#include <QToolButton>
#include <QPushButton>

class ParamAdjustDlg : public QDialog
{
    Q_OBJECT
public:
    explicit ParamAdjustDlg(QWidget *parent = 0);

private:

    void drawUI();
};

#endif // PARAMADJUSTDLG_H
