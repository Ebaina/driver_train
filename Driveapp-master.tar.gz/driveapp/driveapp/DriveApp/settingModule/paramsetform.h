﻿#ifndef PARAMSETFORM_H
#define PARAMSETFORM_H

#include <QPushButton>
#include <QToolButton>
#include "basewidget.h"

class ParamSetForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit ParamSetForm(QWidget *parent = 0);
    ~ParamSetForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

private:
    QStackedWidget *m_mainStackWidget;
    QPushButton *m_communicationBtn;
    QPushButton *m_reportBtn;
    QPushButton *m_netBtn;
    QPushButton *m_cameraBtn;
    QPushButton *m_monitorBtn;
    QPushButton *m_otherBtn;

    QPushButton *m_exitBtn;
//    QToolButton *m_homeBtn;

    void drawUI();

    void showCommuncationSetForm();

    void showNetSetForm();

    void showReportSetForm();

    void showListenSetForm();

    void showCaremaSetForm();

    void showOthersSetForm();
private slots:
    void onExitBtnClicked(bool clicked);

    void onCommunicationBtnClicked();

    void onNetSetBtnClicked();

    void onReportSetBtnClicked();

    void onMonitorBtnClicked();

    void onCaremaBtnClicked();

    void onOthersBtnClicked();
};

#endif // PARAMSETFORM_H
