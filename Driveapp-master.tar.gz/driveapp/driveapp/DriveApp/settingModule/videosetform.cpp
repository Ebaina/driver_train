﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>
#include <QTimer>
#include <QDebug>
#include <QTimer>
#include <QPixmap>
#include "videosetform.h"
#include "textlistview.h"
#include "learnerloginsuccessform.h"
#include "widgetcollector.h"
#include "commondatamgr.h"
#include "loginhintform.h"
#include "handlermanager.h"
#include "handler/camera.h"

static int convert_yuv_to_rgb_pixel(int y, int u, int v)
{
        unsigned int pixel32 = 0;
        unsigned char *pixel = (unsigned char *)&pixel32;
        int r, g, b;
        r = y + (1.370705 * (v-128));
        g = y - (0.698001 * (v-128)) - (0.337633 * (u-128));
        b = y + (1.732446 * (u-128));
        if(r > 255) r = 255;
        if(g > 255) g = 255;
        if(b > 255) b = 255;
        if(r < 0) r = 0;
        if(g < 0) g = 0;
        if(b < 0) b = 0;
        pixel[0] = r ;
        pixel[1] = g ;
        pixel[2] = b ;
        return pixel32;
}

static int convert_yuv_to_rgb_buffer(unsigned char *yuv, unsigned char *rgb, unsigned int width, unsigned int height)
{
        unsigned int in, out = 0;
        unsigned int pixel_16;
        unsigned char pixel_24[3];
        unsigned int pixel32;
        int y0, u, y1, v;

        for(in = 0; in < width * height * 2; in += 4)
        {
                pixel_16 =
                                yuv[in + 3] << 24 |
                                yuv[in + 2] << 16 |
                                yuv[in + 1] <<  8 |
                                yuv[in + 0];
                y0 = (pixel_16 & 0x000000ff);
                u  = (pixel_16 & 0x0000ff00) >>  8;
                y1 = (pixel_16 & 0x00ff0000) >> 16;
                v  = (pixel_16 & 0xff000000) >> 24;
                pixel32 = convert_yuv_to_rgb_pixel(y0, u, v);
                pixel_24[0] = (pixel32 & 0x000000ff);
                pixel_24[1] = (pixel32 & 0x0000ff00) >> 8;
                pixel_24[2] = (pixel32 & 0x00ff0000) >> 16;
                rgb[out++] = pixel_24[0];
                rgb[out++] = pixel_24[1];
                rgb[out++] = pixel_24[2];
                pixel32 = convert_yuv_to_rgb_pixel(y1, u, v);
                pixel_24[0] = (pixel32 & 0x000000ff);
                pixel_24[1] = (pixel32 & 0x0000ff00) >> 8;
                pixel_24[2] = (pixel32 & 0x00ff0000) >> 16;
                rgb[out++] = pixel_24[0];
                rgb[out++] = pixel_24[1];
                rgb[out++] = pixel_24[2];
        }
        return 0;

}

videosetform::videosetform(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL),
    m_netStatusListView(NULL),
    m_netnametListView(NULL)
{
    _camera = new Camera("/dev/video0");
    _timer = new QTimer(this);
    connect(_timer, SIGNAL(timeout()), this, SLOT(updateImage()));
    _imageBuffer = new unsigned char[640*480*2];
    _rgbImageBuffer = new unsigned char[640*480*3];

    this->setObjectName(QString("videosetform"));

    drawUI();

    initConnect();

//    initData();
}

videosetform::~videosetform()
{
    if(m_netStatusListView != NULL){
        delete m_netStatusListView;
        m_netStatusListView = NULL;
    }
    if(m_netnametListView != NULL){
        delete m_netnametListView;
        m_netnametListView = NULL;
    }
    delete[] _imageBuffer;
    delete[] _rgbImageBuffer;
}

wis_u16 videosetform::type()
{
    return WIS_UI_ENUM::SETTING_VIDEO_FORM;
}

void videosetform::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void videosetform::updateContent()
{

    UI_VideoInfo videosetInfo  = HandlerManager::instance()->getSettingHandler()->getVideoParams();
    m_nettypeNoLe->setText(QString::number(videosetInfo.nettype, 10));
    m_netnameNoLe->setText(QString((char *)videosetInfo.apn).left(15));
    m_dialtypeNoLe->setText(QString((char *)videosetInfo.dialnum).left(4));
    m_dialpasswordNoLe->setText(QString((char *)videosetInfo.passwd).left(4));
    m_dialportNoLe->setText(QString::number(videosetInfo.dial_port, 10));
    m_statusportNoLe->setText(QString::number(videosetInfo.status_port, 10));
}


void videosetform::setvideoInfo()
{
    UI_VideoInfo videosetInfo;
    memset(&videosetInfo, 0, sizeof(UI_VideoInfo));
    videosetInfo.nettype = m_nettypeNoLe->text().trimmed().toInt();
    QString str = m_dialtypeNoLe->text().trimmed();
    memcpy(videosetInfo.dialnum, str.toUtf8().constData(),str.length());
    QString str1 = m_dialpasswordNoLe->text().trimmed();
    memcpy(videosetInfo.passwd, str1.toUtf8().constData(),str1.length());
    videosetInfo.dial_port = m_dialportNoLe->text().trimmed().toInt();
    videosetInfo.status_port = m_statusportNoLe->text().trimmed().toInt();
    QString str2 = m_netnameNoLe->text().trimmed();
    memcpy(videosetInfo.apn, str2.toUtf8().constData(),str2.length());

    bool b = HandlerManager::instance()->getSettingHandler()->setVideoParams(videosetInfo);
    if(!b){
        return;
    }

}

void videosetform::drawUI()
{

    QHBoxLayout *baseLayout = new QHBoxLayout(this);
    baseLayout->setContentsMargins(0,0,0,0);
    baseLayout->setSpacing(20);
    QFrame *leftFrame = new QFrame(this);
    leftFrame->setObjectName(QString("leftFrame"));
    QGridLayout *leftLayout = new QGridLayout(leftFrame);
    leftLayout->setContentsMargins(30,30,20,30);
    leftLayout->setHorizontalSpacing(20);
    leftLayout->setVerticalSpacing(35);
    QPixmap videoPix;
    videoPix.load(":/resource/image/video.png");
    videolb = new QLabel(this);
    videolb->setPixmap(videoPix);
    videolb->setStyleSheet(QString("min-width: 308px;min-height: 290px;max-width: 308px;max-height:290px;"));
    leftLayout->addWidget(videolb,0,0,1,1);

    QFrame *buttonFrame = new QFrame(this);
    buttonFrame->setObjectName(QString("buttonFrame"));
    QHBoxLayout *buttonLayout = new QHBoxLayout(buttonFrame);

    m_startvideoBtn = new QPushButton(this);
    m_startvideoBtn->setObjectName(QString("startBtn"));
    m_startvideoBtn->setText(tr("开始校准"));
    m_startvideoBtn->setStyleSheet(QString("background-color: #5da1d1;color: #ffffff;text-align: center;font-size: 18px;min-width: 140px;min-height: 45px;max-width: 140px;max-height:45px;border-width: 0;border-radius: 5px;"));
    m_stopvideoBtn = new QPushButton(this);
    m_stopvideoBtn->setObjectName(QString("stopBtn"));
    m_stopvideoBtn->setText(tr("结束校准"));
    m_stopvideoBtn->setStyleSheet(QString("background-color: #5da1d1;color: #ffffff;text-align: center;font-size: 18px;min-width: 140px;min-height: 45px;max-width: 140px;max-height:45px;border-width: 0;border-radius: 5px;"));

    buttonLayout->addWidget(m_startvideoBtn);
    buttonLayout->addWidget(m_stopvideoBtn);
    buttonLayout->addStretch();
    leftLayout->addWidget(buttonFrame,1,0,1,1);

    baseLayout->addWidget(leftFrame);
    baseLayout->addStretch();


    QFrame *rightFrame = new QFrame(this);
    rightFrame->setObjectName(QString("rightFrame"));
    QVBoxLayout *rightLayout = new QVBoxLayout(rightFrame);
    rightLayout->setContentsMargins(22,30,30,30);
    rightLayout->setSpacing(20);

    QFrame *timeFrame = new QFrame(this);
    timeFrame->setObjectName(QString("timeFrame"));
    timeFrame->setStyleSheet(QString("background-color: #ffffff;border-radius: 5px;"));
    QGridLayout *timeLayout = new QGridLayout(timeFrame);
    timeLayout->setContentsMargins(22,10,22,10);
    timeLayout->setHorizontalSpacing(10);
    m_yearNoLe = new QLineEdit(this);
    m_yearNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    QLabel *lb = new QLabel(tr(""),this);//年
    lb->setProperty("class",QVariant("leftnameLb"));
    timeLayout->addWidget(m_yearNoLe,0,0,1,1);
    timeLayout->addWidget(lb,0,1,1,1);

    m_monthNoLe = new QLineEdit(this);
    m_monthNoLe->setProperty("class",QVariant("rightContentLineEdit"));
     lb = new QLabel(tr(""),this);//月
    lb->setProperty("class",QVariant("leftnameLb"));
    timeLayout->addWidget(m_monthNoLe,0,2,1,1);
    timeLayout->addWidget(lb,0,3,1,1);

    m_dayNoLe = new QLineEdit(this);
    m_dayNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    lb = new QLabel(tr(""),this);//日
    lb->setProperty("class",QVariant("leftnameLb"));
    timeLayout->addWidget(m_dayNoLe,0,4,1,1);
    timeLayout->addWidget(lb,0,5,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    timeLayout->addWidget(lb,1,0,1,2);

    m_hourNoLe = new QLineEdit(this);
    m_hourNoLe->setProperty("class",QVariant("rightContentLineEdit"));
     lb = new QLabel(tr(""),this);//时
    lb->setProperty("class",QVariant("leftnameLb"));
    timeLayout->addWidget(m_hourNoLe,2,0,1,1);
    timeLayout->addWidget(lb,2,1,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbVerticalLine"));
    timeLayout->addWidget(lb,2,2,1,1);

    m_minuteNoLe = new QLineEdit(this);
    m_minuteNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    lb = new QLabel(tr(""),this);//分
    lb->setProperty("class",QVariant("leftnameLb"));
    timeLayout->addWidget(m_minuteNoLe,2,3,1,1);
    timeLayout->addWidget(lb,2,4,1,1);

    QFrame *netFrame = new QFrame(this);
    netFrame->setObjectName(QString("netFrame"));
    netFrame->setStyleSheet(QString("background-color: #ffffff;border-radius: 5px;"));
    QGridLayout *netLayout = new QGridLayout(netFrame);
    netLayout->setContentsMargins(20,20,20,25);
    netLayout->setHorizontalSpacing(20);
    netLayout->setVerticalSpacing(30);
    lb = new QLabel(tr("网络类型:"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_nettypeNoLe = new QLineEdit(this);
    m_nettypeNoLe->setProperty("class",QVariant("rightContentLineEdit"));
//    m_nettypeBtn = new QPushButton(this);
//    m_nettypeBtn->setProperty("class",QVariant("showTextBtn"));
//    m_nettypeBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/down.png"));
//    m_nettypeBtn->setLayoutDirection(Qt::RightToLeft);
    netLayout->addWidget(lb,0,0,1,1);
    netLayout->addWidget(m_nettypeNoLe,0,1,1,1);

    lb = new QLabel(tr("APN名称:"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_netnameNoLe = new QLineEdit(this);
    m_netnameNoLe->setProperty("class",QVariant("rightContentLineEdit"));
//    m_netnameBtn = new QPushButton(this);
//    m_netnameBtn->setProperty("class",QVariant("showTextBtn"));
//    m_netnameBtn->setIcon(QIcon(":/login_module_img/resource/image/loginModuleImg/down.png"));
//    m_netnameBtn->setLayoutDirection(Qt::RightToLeft);
    netLayout->addWidget(lb,0,2,1,1);
    netLayout->addWidget(m_netnameNoLe,0,3,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    timeLayout->addWidget(lb,1,0,1,2);

    lb = new QLabel(tr("拨号类型:"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_dialtypeNoLe = new QLineEdit(this);
    m_dialtypeNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    netLayout->addWidget(lb,2,0,1,1);
    netLayout->addWidget(m_dialtypeNoLe,2,1,1,1);

    lb = new QLabel(tr("接入端口:"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_dialportNoLe = new QLineEdit(this);
    m_dialportNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    netLayout->addWidget(lb,2,2,1,1);
    netLayout->addWidget(m_dialportNoLe,2,3,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    timeLayout->addWidget(lb,3,0,1,2);

    lb = new QLabel(tr("拨号密码:"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_dialpasswordNoLe = new QLineEdit(this);
    m_dialpasswordNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    netLayout->addWidget(lb,4,0,1,1);
    netLayout->addWidget(m_dialpasswordNoLe,4,1,1,1);

    lb = new QLabel(tr("状态端口:"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_statusportNoLe = new QLineEdit(this);
    m_statusportNoLe->setProperty("class",QVariant("rightContentLineEdit"));
    netLayout->addWidget(lb,4,2,1,1);
    netLayout->addWidget(m_statusportNoLe,4,3,1,1);

    rightLayout->addWidget(timeFrame);
    rightLayout->addWidget(netFrame);
    rightLayout->addStretch();

    QHBoxLayout *bottomBtnLayout = new QHBoxLayout;
    m_ensureBtn = new QPushButton(tr("确认"),this);
    m_ensureBtn->setProperty("class", QVariant("enSureBtn"));
    m_ensureBtn->setStyleSheet(QString("background-color: #f39c12;color: #feffff;text-align: center;font-size: 24px;min-width: 200px;min-height: 60px;max-width: 200px;max-height:60px;border-width: 0;border-radius: 5px;"));
    bottomBtnLayout->addStretch();
    bottomBtnLayout->addWidget(m_ensureBtn);
    bottomBtnLayout->addStretch();

    rightLayout->addLayout(bottomBtnLayout);

    baseLayout->addWidget(rightFrame);
    baseLayout->addStretch();

}

void videosetform::initData()
{
    m_subjectMap.insert(UI_HEADER::TSI_11, tr("基础驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_12, tr("场地驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_13, tr("综合驾驶及考核"));
    m_subjectMap.insert(UI_HEADER::TSI_21, tr("跟车行驶"));
    m_subjectMap.insert(UI_HEADER::TSI_22, tr("变更车道"));
    m_subjectMap.insert(UI_HEADER::TSI_23, tr("靠边停车"));
    m_subjectMap.insert(UI_HEADER::TSI_24, tr("掉头"));
    m_subjectMap.insert(UI_HEADER::TSI_25, tr("通过路口"));
    m_subjectMap.insert(UI_HEADER::TSI_26, tr("通过人行横道"));
    m_subjectMap.insert(UI_HEADER::TSI_27, tr("通过学校区域"));
    m_subjectMap.insert(UI_HEADER::TSI_28, tr("通过公共汽车站"));
    m_subjectMap.insert(UI_HEADER::TSI_29, tr("会车"));
    m_subjectMap.insert(UI_HEADER::TSI_30, tr("超车"));
    m_subjectMap.insert(UI_HEADER::TSI_31, tr("夜间驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_32, tr("恶劣条件下的驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_33, tr("山区道路驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_34, tr("高速公路驾驶"));
    m_subjectMap.insert(UI_HEADER::TSI_35, tr("行驶路线选择"));
}

void videosetform::initConnect()
{
    connect(m_startvideoBtn,SIGNAL(clicked(bool)),this,SLOT(onstartvideoBtnClicked(bool)));
    connect(m_ensureBtn, SIGNAL(clicked(bool)), this, SLOT(onensureBtnClicked(bool)));
    connect(m_stopvideoBtn, SIGNAL(clicked(bool)), this, SLOT(onstopvideoBtnClicked(bool)));
}


void videosetform::showsetmgrForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_MGR_FORM);
    SettingMgrForm *setmgrForm = NULL;
    if(!bw){
        setmgrForm = new SettingMgrForm();
        setmgrForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_MGR_FORM,setmgrForm);
        m_mainStackWidget->addWidget(setmgrForm);
    }else
    {
        setmgrForm = static_cast<SettingMgrForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(setmgrForm);
    setmgrForm->updateContent();
}


void videosetform::onstartvideoBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    on_startPushButton_clicked();
}

void videosetform::onstopvideoBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    on_stopPushButton_clicked();
    showsetmgrForm();
}

void videosetform::onensureBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    setvideoInfo();
    showsetmgrForm();

}


void videosetform::on_startPushButton_clicked()
{

    bool result = _camera->open();
    if(!result) {
        qDebug()<<"Open camera failed";
        return;
    }
    result = _camera->start();
    if(!result) {
        qDebug()<<"start camera failed";
        return;
    }
    qDebug()<<"start camera ok";
    _timer->start(40);
}

void videosetform::on_stopPushButton_clicked()
{
    _timer->stop();
    _camera->stop();
    _camera->close();
}

void videosetform::updateImage()
{

    bool result = _camera->captureFrame(_imageBuffer, 320*240*2);
    if(result)
    {
        qDebug()<<result;
        convert_yuv_to_rgb_buffer(_imageBuffer, _rgbImageBuffer, 320, 240);
        QImage *image = new QImage(_rgbImageBuffer, 320, 240, QImage::Format_RGB888);
         image->save("/");
        videolb->setPixmap(QPixmap::fromImage(*image));
        delete image;
    }
}










