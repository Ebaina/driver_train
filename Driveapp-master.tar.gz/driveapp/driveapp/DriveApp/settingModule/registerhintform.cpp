#include <QDebug>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QVariant>
#include <QApplication>
#include <QTimer>
#include "registerhintform.h"
#include "appglobal.h"
#include "settingmgrform.h"
#include "widgetcollector.h"
#include "registerinfoinput.h"
#include "netinitlinkform.h"
#include "trainloginform.h"

RegisterHintForm::RegisterHintForm(wis_u16 type, QWidget *parent) :
   BaseWidget(parent),
    m_type(type),
    m_mainStackWidget(NULL)
{
    setObjectName(QString("registerForm"));

    drawUI();
}

wis_u16 RegisterHintForm::type()
{
    return m_type;
}

void RegisterHintForm::updateContent()
{
    setAutoJumpFlag(true);
    QTimer::singleShot(2000, this, SLOT(onTimeout()));
}

void RegisterHintForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

bool RegisterHintForm::autoJumpFlag() const
{
    return m_autoJumpFlag;
}

void RegisterHintForm::setAutoJumpFlag(bool autoJumpFlag)
{
    m_autoJumpFlag = autoJumpFlag;
}

void RegisterHintForm::drawUI()
{
    switch(m_type){
    case WIS_UI_ENUM::ENTER_REG_HINT_FORM:
        drawEnterRegHintForm();
        break;
    case WIS_UI_ENUM::WELCOME_REG_HINT_FORM:
        drawWelcomeRegForm();
        break;
    case WIS_UI_ENUM::REG_SUCCESS_FORM:
        drawRegSuccessForm();

        break;
    case WIS_UI_ENUM::REG_FAILED_FORM:
        drawRegFailedForm();

        break;
    default:
        break;
    }
}

void RegisterHintForm::drawEnterRegHintForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 98, 0, 95);
    QLabel *lbOne = new QLabel(this);

    lbOne->setStyleSheet(QString("font-size:48px;font-weight:bold;color:#ffffff"));
    lbOne->setText(tr("当前设备未注册"));
    lbOne->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbOne);
    QLabel *lbTwo = new QLabel(this);
    lbTwo->setStyleSheet(QString("font-size:30px;color:#ffffff"));
    lbTwo->setText(tr("请进入设置页面，进行注册"));
    lbTwo->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTwo);
    QPushButton *enterSettingBtn = new QPushButton(this);
    enterSettingBtn->setObjectName(QString("enterSettingBtn"));
    enterSettingBtn->setText(tr("进入注册"));
//    enterSettingBtn->setFixedSize(320,60);
    baseVbLayout->addWidget(enterSettingBtn);

    connect(enterSettingBtn, SIGNAL(clicked(bool)), this, SLOT(onEnterSettingBtnClicked(bool)));
}

void RegisterHintForm::drawWelcomeRegForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 98, 0, 95);
    QLabel *lbOne = new QLabel(this);

    lbOne->setStyleSheet(QString("font-size:48px;font-weight:bold;color:#ffffff"));
    lbOne->setText(tr("欢迎使用驾驶培训计时终端"));
    lbOne->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbOne);
    QLabel *lbTwo = new QLabel(this);
    lbTwo->setStyleSheet(QString("font-size:30px;color:#ffffff"));
    lbTwo->setText(tr("请点击下一步注册"));
    lbTwo->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTwo);
    QPushButton *enterNextBtn = new QPushButton(this);
    enterNextBtn->setObjectName(QString("enterNextBtn"));
    enterNextBtn->setText(tr("下一步"));
//    enterSettingBtn->setFixedSize(320,60);
    baseVbLayout->addWidget(enterNextBtn);

    connect(enterNextBtn, SIGNAL(clicked(bool)), this, SLOT(onEnterNextBtnClicked(bool)));
}

void RegisterHintForm::drawRegSuccessForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 118, 0, 142);
    baseVbLayout->setSpacing(61);
    QLabel *lbOne = new QLabel(this);

    lbOne->setText(tr("注册成功"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

    QPushButton *trainLoginBtn = new QPushButton(tr("训练登入"),this);
    trainLoginBtn->setObjectName(QString("trainLogBtn"));
    baseVbLayout->addWidget(trainLoginBtn);

    connect(trainLoginBtn, SIGNAL(clicked(bool)), this, SLOT(onTrainLoginBtnClicked(bool)));
}

void RegisterHintForm::drawRegFailedForm()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0, 98, 0, 95);
    QLabel *lbOne = new QLabel(this);

    lbOne->setText(tr("注册失败"));
    lbOne->setAlignment(Qt::AlignCenter);
    lbOne->setStyleSheet(QString("font-size:60px;color:#ffffff;text-align:center;font-weight: bold;"));
    baseVbLayout->addWidget(lbOne);

    QLabel *lbTwo = new QLabel(this);
    lbTwo->setStyleSheet(QString("font-size:30px;color:#ffffff"));
    lbTwo->setText(tr("检查输入的信息是否有误"));
    lbTwo->setAlignment(Qt::AlignCenter);
    baseVbLayout->addWidget(lbTwo);


    QPushButton *backBtn = new QPushButton(tr("返回"),this);
    backBtn->setObjectName(QString("failedBackBtn"));
    baseVbLayout->addWidget(backBtn);

}

void RegisterHintForm::onEnterSettingBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    setAutoJumpFlag(false);

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::WELCOME_REG_HINT_FORM);
    RegisterHintForm *welcomeRegForm = NULL;
    if(!bw){
        welcomeRegForm = new RegisterHintForm(WIS_UI_ENUM::WELCOME_REG_HINT_FORM);
        welcomeRegForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::WELCOME_REG_HINT_FORM,welcomeRegForm);
        m_mainStackWidget->addWidget(welcomeRegForm);

    }else{
        qDebug() << "set mge form is not null";
        welcomeRegForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(welcomeRegForm);
    welcomeRegForm->updateContent();
}

void RegisterHintForm::onEnterNextBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::NET_INITLINK_FORM);
     NetInitLinkForm*netInitLinkForm = NULL;
    if(!bw){
        netInitLinkForm = new NetInitLinkForm();
        netInitLinkForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::NET_INITLINK_FORM,netInitLinkForm);
        m_mainStackWidget->addWidget(netInitLinkForm);

    }else{
        netInitLinkForm = static_cast<NetInitLinkForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(netInitLinkForm);
    netInitLinkForm->updateContent();
#if 0
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::REGISTER_INFO_INPUT_FORM);
    RegisterInfoInputForm *infoInputForm = NULL;
    if(!bw){
        infoInputForm = new RegisterInfoInputForm();
        infoInputForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::REGISTER_INFO_INPUT_FORM,infoInputForm);
        m_mainStackWidget->addWidget(infoInputForm);

    }else{
        qDebug() << "set mge form is not null";
        infoInputForm = static_cast<RegisterInfoInputForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(infoInputForm);
#endif
}

void RegisterHintForm::onTrainLoginBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    setAutoJumpFlag(false);

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
     TrainLoginForm*trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void RegisterHintForm::onTimeout()
{
    if(autoJumpFlag() == false){
        return;
    }

    switch(m_type){
    case WIS_UI_ENUM::REG_SUCCESS_FORM:
    {
        onTrainLoginBtnClicked(true);
    }
        break;
    case WIS_UI_ENUM::REG_FAILED_FORM:
    {
        onEnterSettingBtnClicked(true);
    }
        break;
    default:
        break;
    }


}


