#ifndef EMBEDVIRTUALBOARD_H
#define EMBEDVIRTUALBOARD_H

#include <QWidget>

class EmbedVirtualBoard : public QWidget
{
    Q_OBJECT
public:
    explicit EmbedVirtualBoard(QWidget *parent = 0);

signals:

public slots:
};

#endif // EMBEDVIRTUALBOARD_H
