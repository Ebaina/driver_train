#ifndef WKEYBOARD_H
#define WKEYBOARD_H

#include <QWidget>
#include <QSignalMapper>
#include <QPushButton>

namespace Ui {
class WKeyBoard;
}

class WKeyBoard : public QWidget
{
    Q_OBJECT

public:
    explicit WKeyBoard(QWidget *parent = 0);
    ~WKeyBoard();

    QWidget* getFocusWidget();
    static WKeyBoard* instance();

signals:
    void characterGenerated(QString str);

protected:
    bool event(QEvent *e);

private slots:
    void saveFocusWidget(QWidget *oldFocus, QWidget *newFocus);
    void buttonClicked(QWidget *w);

private:
    Ui::WKeyBoard *ui;
    static WKeyBoard *keyboard;

    QWidget *lastFocusedWidget;
    QSignalMapper signalMapper;
    QList<QPushButton *> mBtnList;

    void initUI();
    void initConnect();
};

#endif // WKEYBOARD_H
