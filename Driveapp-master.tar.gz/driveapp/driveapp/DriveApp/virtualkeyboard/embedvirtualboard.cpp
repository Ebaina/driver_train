#include "embedvirtualboard.h"

EmbedVirtualBoard::EmbedVirtualBoard(QWidget *parent) : QWidget(parent)
{

}

