#ifndef KEYBOARDIINPUTCONTEXT_H
#define KEYBOARDIINPUTCONTEXT_H

#include <QInputContext>
#include <QObject>
#include <QEvent>
#include "wkeyboard.h"

/*************special keyButton*******************/
#define IS_KEY(keyTextPressed, keyValCompare)   (keyTextPressed).contains((keyValCompare), Qt::CaseInsensitive)
#define KEY_BACKSPACE                           tr("BACKSPACE")
#define KEY_ESC                                         tr("ESC")
#define KEY_TAB                                         tr("TAB")
#define KEY_CAPS                                       tr("CAP")
#define KEY_SHIFT                                      tr("SHIFT")
#define KEY_CTRL                                        tr("CTRL")
#define KEY_ALT                                           tr("ALT")
#define KEY_RETURN                                    tr("ENTER")
#define KEY_COPY                                        tr("COPY")
#define KEY_CLOSE                                       tr("CLOSE")
#define KEY_SPACE                                       " "

/************define function use to judge************/
#define IS_BACK(text)                                IS_KEY(text, KEY_BACKSPACE)
#define IS_ESC(text)                                   IS_KEY(text,KEY_ESC)
#define IS_TAB(text)                                   IS_KEY(text,KEY_TAB)
#define IS_CAPS(text)                                 IS_KEY(text,KEY_CAPS)
#define IS_SHIFT(text)                                IS_KEY(text,KEY_SHIFT)
#define IS_CTRL(text)                                  IS_KEY(text,KEY_CTRL)
#define IS_ALT(text)                                    IS_KEY(text,KEY_ALT)
#define IS_RETURN(text)                             IS_KEY(text,KEY_RETURN)
#define IS_SPACE(text)                                IS_KEY(text,KEY_SPACE)
#define IS_COPY(text)                                  IS_KEY(text,KEY_COPY)
#define IS_CLOSE(text)                                IS_KEY(text,KEY_CLOSE)

#define IS_SPECIALKEY(text)                     ((text).length() != 1)

class KeyBoardInputContext : public QInputContext
{
    Q_OBJECT
public:
    KeyBoardInputContext();
    ~KeyBoardInputContext();

    bool filterEvent(const QEvent* event);
    static WKeyBoard* keyboardInstance();

    QString identifierName();
    QString language();

    bool isComposing() const;

    void reset();

private slots:
    void sendCharacter(QString text);

private:
    void updatePosition();
    void handleSpecialKey(int &keyCode,QString &text);

private:
    WKeyBoard *mKeyboard;
    static WKeyBoard *keyboard;

};

#endif // KEYBOARDIINPUTCONTEXT_H

