﻿#include "keyboardinputcontext.h"
#include <QPointer>
#include <QApplication>
#include <QDesktopWidget>
#include <QDebug>

WKeyBoard* KeyBoardInputContext::keyboard = NULL;
KeyBoardInputContext::KeyBoardInputContext()
{
    mKeyboard = new WKeyBoard;
//    int dw = QApplication::desktop()->availableGeometry().width();
//    int dh = QApplication::desktop()->availableGeometry().height();
//    mKeyboard->resize(dw * 0.7, dh * 0.7);
    keyboard = mKeyboard;
    connect(mKeyboard,SIGNAL(characterGenerated(QString)),this,SLOT(sendCharacter(QString)));
}

KeyBoardInputContext::~KeyBoardInputContext()
{
    if(mKeyboard){
        delete mKeyboard;
        mKeyboard = NULL;
    }
}

/**************open and close keyboard event************************/
bool KeyBoardInputContext::filterEvent(const QEvent *event)
{
    if(event->type() == QEvent::RequestSoftwareInputPanel){
        updatePosition();
        mKeyboard->show();
        return true;
    }else if(event->type() == QEvent::CloseSoftwareInputPanel){
//        qDebug() << "close input panel";
        mKeyboard->hide();
        return true;
    }

    return false;
}

WKeyBoard *KeyBoardInputContext::keyboardInstance()
{
    if(keyboard != NULL){
        return keyboard;
    }

    return NULL;
}

QString KeyBoardInputContext::identifierName()
{
    return QString("wisdom virtual keyboard");
}

QString KeyBoardInputContext::language()
{
    return QString("en_US");
}

bool KeyBoardInputContext::isComposing() const
{
    return false;
}

void KeyBoardInputContext::reset()
{

}

void KeyBoardInputContext::sendCharacter(QString text)
{
//    QPointer<QWidget> w = focusWidget();
    QPointer<QWidget> w = mKeyboard->getFocusWidget();
    int keyCode = text.toUtf8()[0];

    if(!w){
        return;
    }

    /***********judge the key value is special or not*****************/
    if(IS_CLOSE(text)){
      mKeyboard->hide();
      return;
    }
    if(IS_SPECIALKEY(text)){
        handleSpecialKey(keyCode,text);
    }

    QKeyEvent keyPressEvent(QEvent::KeyPress,keyCode,Qt::NoModifier,QString(text));
    QApplication::sendEvent(w,&keyPressEvent);
}

void KeyBoardInputContext::updatePosition()
{
    QWidget * widget = focusWidget();
    if(!widget){
        return;
    }

    QRect widgetRect = widget->rect();
    QPoint keyboardPos = QPoint(widgetRect.left(),widgetRect.bottom() + 2);
    keyboardPos = widget->mapToGlobal(keyboardPos);
    mKeyboard->move(keyboardPos.x() /2,keyboardPos.y());
    mKeyboard->move((QApplication::desktop()->availableGeometry().width() - mKeyboard->width())/2,
    QApplication::desktop()->availableGeometry().height() - mKeyboard->height());
}

void KeyBoardInputContext::handleSpecialKey(int &keyCode, QString &text)
{
    if(IS_ALT(text)){
        keyCode = Qt::Key_Alt;
        text.clear();
    }else if(IS_BACK(text)){
        keyCode = Qt::Key_Backspace;
        text.clear();
    }else if(IS_CAPS(text)){
        keyCode = Qt::Key_CapsLock;
        text.clear();
    }else if(IS_CTRL(text)){
        keyCode = 0;
        text.clear();
    }else if(IS_ESC(text)){
        keyCode = Qt::Key_Escape;
        text.clear();
    }else if(IS_RETURN(text)){
        keyCode = Qt::Key_Return;
        text.clear();
    }else if(IS_SHIFT(text)){
        keyCode = Qt::Key_Shift;
        text.clear();
    }else if(IS_SPACE(text)){
        keyCode = Qt::Key_Space;
        text.clear();
        text.append(" ");
    }else if(IS_TAB(text)){
        keyCode = Qt::Key_Space;
        text.clear();
    }else if(IS_COPY(text)){
        keyCode = Qt::Key_Copy;
        text.clear();
    }
}















