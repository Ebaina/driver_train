﻿#include "wkeyboard.h"
#include "ui_wkeyboard.h"
#include <QDebug>

WKeyBoard* WKeyBoard::keyboard = NULL;
WKeyBoard::WKeyBoard(QWidget *parent) :
    QWidget(parent,Qt::WindowStaysOnTopHint),
    lastFocusedWidget(0),
    ui(new Ui::WKeyBoard)
{
    ui->setupUi(this);
    this->setObjectName("widget_keyboard");
    keyboard = this;
    initUI();
    initConnect();

}

WKeyBoard::~WKeyBoard()
{
    delete ui;
}

QWidget *WKeyBoard::getFocusWidget()
{
    return lastFocusedWidget;
}

WKeyBoard *WKeyBoard::instance()
{
    if(keyboard){
        return keyboard;
    }

    return NULL;
}

bool WKeyBoard::event(QEvent *e)
{
    switch(e->type()){
    case QEvent::WindowActivate:
        if(lastFocusedWidget){
            lastFocusedWidget->activateWindow();
        }
        break;

    default:
        break;
    }

    return::QWidget::event(e);
}

void WKeyBoard::saveFocusWidget(QWidget *oldFocus, QWidget *newFocus)
{
    Q_UNUSED(oldFocus)
    if (newFocus != 0 && !this->isAncestorOf(newFocus)) {
        lastFocusedWidget = newFocus;
    }
}

void WKeyBoard::buttonClicked(QWidget *w)
{
    QString str  = w->property("text").toString();
    if(ui->pb_cap->isChecked()){
        str = str.toUpper();
    }else{
        str = str.toLower();
    }
    emit characterGenerated(str);
}

void WKeyBoard::initUI()
{
    this->setWindowFlags(Qt::FramelessWindowHint);  //隐藏标题栏
//    this->setWindowTitle(QString(tr("virtual keyboard")));
//    ui->pb_esc->setVisible(false);
//    ui->pb_add->setVisible(false);
//    ui->pb_sub->setVisible(false);
//    ui->pb_tab->setVisible(false);
//    ui->pb_slash->setVisible(false);
//    ui->pb_enter->setVisible(false);
//    ui->pb_semicolon->setVisible(false);
//    ui->pb_double_quot->setVisible(false);
//    ui->pb_shift->setVisible(false);
//    ui->pb_comma->setVisible(false);
//    ui->pb_question->setVisible(false);
//    ui->pb_at->setVisible(false);
//    ui->pb_well->setVisible(false);
//    ui->pb_ctrl->setVisible(false);
//    ui->pb_alt->setVisible(false);


    ui->pb_space->setText(QString(" "));
    ui->pb_cap->setCheckable(true);
    mBtnList << ui->pb_num_0 << ui->pb_num_1 << ui->pb_num_2 << ui->pb_num_3
             <<ui->pb_num_4 << ui->pb_num_5 << ui->pb_num_6 << ui->pb_num_7 << ui->pb_num_8
            << ui->pb_num_9 << ui->pb_esc << ui->pb_add << ui->pb_sub << ui->pb_backspace << ui->pb_tab
            << ui->pb_q << ui->pb_w << ui->pb_e << ui->pb_r << ui->pb_t << ui->pb_y << ui->pb_u << ui->pb_i << ui->pb_o
            << ui->pb_p << ui->pb_asterisk << ui->pb_slash << ui->pb_enter << ui->pb_cap << ui->pb_a << ui->pb_s << ui->pb_d
            << ui->pb_f << ui->pb_g << ui->pb_h << ui->pb_j << ui->pb_k << ui->pb_l << ui->pb_colon << ui->pb_semicolon << ui->pb_double_quot
            << ui->pb_shift << ui->pb_z << ui->pb_x << ui->pb_c << ui->pb_v << ui->pb_b << ui->pb_n << ui->pb_m << ui->pb_comma
            << ui->pb_point << ui->pb_question << ui->pb_well << ui->pb_ctrl << ui->pb_alt << ui->pb_at << ui->pb_space << ui->pb_close;

//    this->setFixedSize(this->size());
}

void WKeyBoard::initConnect()
{
    connect(qApp, SIGNAL(focusChanged(QWidget*,QWidget*)),
            this, SLOT(saveFocusWidget(QWidget*,QWidget*)));

    for(int i = 0;i < mBtnList.length();++i){
        signalMapper.setMapping(mBtnList.at(i),mBtnList.at(i));
        connect(mBtnList[i],SIGNAL(clicked()),&signalMapper,SLOT(map()));
    }

    connect(&signalMapper,SIGNAL(mapped(QWidget*)),this,SLOT(buttonClicked(QWidget*)));
}
