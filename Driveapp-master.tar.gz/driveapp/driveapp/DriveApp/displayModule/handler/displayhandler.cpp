#include "displayhandler.h"
#include "ui_interface.h"
#include "handlermanager.h"
DisplayHandler::DisplayHandler(QObject *parent) : QObject(parent)
{
#ifdef nuc970_4_8
    m_funcInterface = NULL;
//    m_funcInterface = new Ui_Interface;
        m_funcInterface = HandlerManager::instance()->getFuncInterface();

#endif
}

DisplayHandler::~DisplayHandler()
{
#ifdef nuc970_4_8
    if(m_funcInterface != NULL){
//        delete m_funcInterface;
//        delete m_funcInterface;
    }
#endif
}

void DisplayHandler::updateTrainSpeed(unsigned int value)
{
    emit sigUpdateTrainSpeed(value);
}

void DisplayHandler::updateDirection(unsigned int value)
{
    emit sigUpdateDirection(value);
}

void DisplayHandler::updateTrainingMinutes(unsigned int value)
{
    emit sigUpdateTrainingMinutes(value);
}

void DisplayHandler::updateCurrentTrainDistance(unsigned int value)
{
    emit sigUpdateCurrentTrainDistance(value);
}

UI_MainShowInfo DisplayHandler::getMainDisplayInfo()
{
    UI_MainShowInfo info;
#ifdef nuc970_4_8
    (void)info;
    return m_funcInterface->get_main_display_info();
#else
    strcpy((char*)info.Coach_name, "王尼玛");
//    info.Coach_stars = UI_HEADER::CSR_5;
    strcpy((char*)info.Leaner_name,"李叉叉");
    info.TrainSubject = UI_HEADER::TST_2;
    info.finishtime = 200;
    info.finishmile = 100;
    return info;
#endif
}

void DisplayHandler::startTrain()
{
#ifdef nuc970_4_8
    m_funcInterface->start_train();
#else

#endif
}

void DisplayHandler::pauseTrain()
{
#ifdef nuc970_4_8
    m_funcInterface->pause_train();
#else

#endif
}

void DisplayHandler::stopTrain()
{
#ifdef nuc970_4_8
    m_funcInterface->stop_train();
#else

#endif
}

