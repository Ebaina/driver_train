﻿#ifndef DISPLAYHANDLER_H
#define DISPLAYHANDLER_H
#include <QObject>
#include "displayinterface.h"
#include "ui_structs.h"
using namespace WIS_UI;

class Ui_Interface;
class DisplayHandler : public QObject, public DisplayInterface
{
    Q_OBJECT
public:
    explicit DisplayHandler(QObject *parent = 0);
    ~DisplayHandler();

    void updateTrainSpeed(unsigned int value);

    void updateDirection(unsigned int value);

    void updateTrainingMinutes(unsigned int value);

    void updateCurrentTrainDistance(unsigned int value);

    UI_MainShowInfo getMainDisplayInfo();

    /**
  *@brief   start train
 */
    void startTrain();

    /**
  *@brief   pause train
 */
    void pauseTrain();

    /**
  *@brief   stop train
 */
    void stopTrain();
signals:
    void sigUpdateTrainSpeed(unsigned int value);
    void sigUpdateDirection(unsigned int value);
    void sigUpdateTrainingMinutes(unsigned int value);
    void sigUpdateCurrentTrainDistance(unsigned int value);

public slots:

private:
#ifdef nuc970_4_8
    Ui_Interface *m_funcInterface;
#endif
};

#endif // DISPLAYHANDLER_H
