﻿#ifndef TRAINDISPLAYFORM_H
#define TRAINDISPLAYFORM_H
#include <QLineEdit>
#include <QLabel>
#include <QToolButton>
#include <QPushButton>
#include <QObject>
#include "basewidget.h"
#include "carspeeddial.h"
#include "compassdial.h"
#include "contentunitdial.h"

#define TB_STYLE_SHEET  ( " background-color: transparent;    \
                                             border: none;      \
                                             min-width:44px;    \
                                             min-height: 44px;  \
                                             max-width:44px;    \
                                             max-width:44px;    \
                                             icon-size: 40px;")

class ConfirmMessageDialog;
class TrainDisplayForm : public BaseWidget
{
    Q_OBJECT
public:
    explicit TrainDisplayForm(QWidget *parent = 0);
    ~TrainDisplayForm();

    wis_u16 type();

    void setMainStackWidget(QStackedWidget *stackWidget);

    void updateContent();

    QMap<int,QString> m_subjectMap;

    void initData();
private:
    QStackedWidget *m_mainStackWidget;
    CarSpeedDial *m_carSpeedDial;
    CompassDial *m_compassDial;
    ContentUnitDial *m_trainTimeDial;
    ContentUnitDial *m_trainMileageDial;

    QLineEdit *m_coachNameLe;
    QLineEdit *m_trainProjectLe;
    QLineEdit *m_trainToatltime;
//    QLabel *m_coachStarLb;
    QLineEdit *m_passedLearnTimeLe;
    QLineEdit *m_leanerNameLe;
    QLineEdit *m_passedMilesLe;
    QToolButton *m_volumnBtn;
    QPushButton *m_startTrainBtn;
    QPushButton *m_pauseTrainBtn;
    QPushButton *m_stopBtn;
    QToolButton *m_endTrainBtn;
    QLabel *m_qardLb;
    ConfirmMessageDialog *m_confirmDlg;


    void drawUI();

    void showTrainLoginForm();

    void showVolumeLightSetForm();

private slots:
    void onStartTrainBtnClicked(bool clicked);

    void onStartOk();

    void onPauseTrainBtnClicked(bool clicked);

    void onPauseOk();

    void onStopTrainBtnClicked(bool clicked);

    void onEndTrainBtnClicked();

    void onStopOk();

    void onConfirmDlgFinished(int ret);

    void onVolumeLightBtnClicked(bool clicked);

    void onUpdateDriveSpeed(unsigned int value);

    void onUpdateDirection(unsigned int value);

    void onUpdateTrainingMinutes(unsigned int value);

    void onUpdateCurrentTrainDistance(unsigned int value);



};

#endif // TRAINDISPLAYFORM_H
