﻿#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QTextCodec>
#include <QLabel>
#include <QFile>
#include <QApplication>
#include <QDebug>
#include "traindisplayform.h"
#include "trainloginform.h"
#include "widgetcollector.h"
#include "handlermanager.h"
#include "timeutil.h"
#include "commondatamgr.h"
#include "confirmmessagedialog.h"
#include "volumelightsetform.h"
#include "trainlogoutform.h"
#include "QTimer"

TrainDisplayForm::TrainDisplayForm(QWidget *parent) :
    BaseWidget(parent),
    m_mainStackWidget(NULL)
{
    this->setObjectName(QString("trainDisplayForm"));
    m_confirmDlg = NULL;
    drawUI();
    initData();
    connect(m_stopBtn, SIGNAL(clicked(bool)), this, SLOT(onStopTrainBtnClicked(bool)));
    connect(m_startTrainBtn, SIGNAL(clicked(bool)), this, SLOT(onStartTrainBtnClicked(bool)));
    connect(m_pauseTrainBtn, SIGNAL(clicked(bool)), this, SLOT(onPauseTrainBtnClicked(bool)));
    connect(m_volumnBtn, SIGNAL(clicked(bool)), this, SLOT(onVolumeLightBtnClicked(bool)));
    connect(m_endTrainBtn, SIGNAL(clicked(bool)), this, SLOT(onEndTrainBtnClicked()));

    connect(HandlerManager::instance()->getDisplayHandler(), SIGNAL(sigUpdateTrainSpeed(uint)), this, SLOT(onUpdateDriveSpeed(uint)));
    connect(HandlerManager::instance()->getDisplayHandler(), SIGNAL(sigUpdateDirection(uint)), this, SLOT(onUpdateDirection(uint)));
    connect(HandlerManager::instance()->getDisplayHandler(),SIGNAL(sigUpdateTrainingMinutes(uint)), this, SLOT(onUpdateTrainingMinutes(uint)));
    connect(HandlerManager::instance()->getDisplayHandler(), SIGNAL(sigUpdateCurrentTrainDistance(uint)), this, SLOT(onUpdateCurrentTrainDistance(uint)));

}

TrainDisplayForm::~TrainDisplayForm()
{

}

wis_u16 TrainDisplayForm::type()
{
    return WIS_UI_ENUM::TRAIN_DISPLAY_FORM;
}

void TrainDisplayForm::setMainStackWidget(QStackedWidget *stackWidget)
{
    m_mainStackWidget = stackWidget;
}

void TrainDisplayForm::updateContent()
{
    UI_MainShowInfo mainInfo;
    mainInfo = HandlerManager::instance()->getDisplayHandler()->getMainDisplayInfo();
    QTextCodec *codec = QTextCodec::codecForName("GBK");
    QString mm1 = codec->toUnicode((const char*)mainInfo.Coach_name);
    QString mm2 = codec->toUnicode((const char*)mainInfo.Leaner_name);
    m_coachNameLe->setText(mm1); 
    m_trainProjectLe->setText(m_subjectMap.value(mainInfo.TrainSubject));
    subID = mainInfo.TrainSubject;
    m_trainToatltime->setText(QString::number(mainInfo.Totaltime,10).append("分钟"));
//    m_coachStarLb->setPixmap(QPixmap(CommonDataMgr::getCoachStarImgSource(mainInfo.Coach_stars)));
    m_passedLearnTimeLe->setText(TimeUtil::minutesNumToFormatStr(mainInfo.finishtime).append("小时"));
    m_leanerNameLe->setText(mm2);
    m_passedMilesLe->setText(QString::number(mainInfo.finishmile,10).append("公里"));
}

void TrainDisplayForm::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setContentsMargins(0,0,0,0);
    baseVbLayout->setSpacing(0);

//    QFrame *topFrame = new QFrame(this);
//    topFrame->setObjectName(QString("topFrame"));
    QWidget *topWidget = new QWidget(this);
    topWidget->setStyleSheet("background-color: transparent;background-image: url(\":/resource/image/bg_1.png\");");
    QHBoxLayout *dialLayout = new QHBoxLayout(topWidget);
    m_carSpeedDial = new CarSpeedDial(this);
    dialLayout->addWidget(m_carSpeedDial);
    m_compassDial = new CompassDial(this);
    dialLayout->addWidget(m_compassDial);
    m_trainTimeDial = new ContentUnitDial(this);
    m_trainTimeDial->setUnit(QString("小时"));
    m_trainTimeDial->setValue(QString("0:00"));
    dialLayout->addWidget(m_trainTimeDial);
    m_trainMileageDial = new ContentUnitDial(this);
    m_trainMileageDial->setUnit(QString("km"));
    m_trainMileageDial->setValue(QString("0"));
    dialLayout->addWidget(m_trainMileageDial);

    baseVbLayout->addWidget(topWidget);

//    QFrame *bottomFrame = new QFrame(this);
    QWidget *bottomWidget = new QWidget(this);
//    bottomWidget->setObjectName(QString("bottomFrame"));
    bottomWidget->setStyleSheet("background-color: transparent;");

    QVBoxLayout *bottomFrameLayout = new QVBoxLayout(bottomWidget);
    QGridLayout *infoGridLayout = new QGridLayout;
    QHBoxLayout *picGirdLayout = new QHBoxLayout;

    QLabel  *lb = new QLabel(tr("教练姓名"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_coachNameLe = new QLineEdit(this);
    m_coachNameLe->setReadOnly(true);
    m_coachNameLe->setProperty("class",QVariant("rightContentLineEdit"));
    infoGridLayout->addWidget(lb, 0,0,1,1);
    infoGridLayout->addWidget(m_coachNameLe,0,1,1,1);

    lb = new QLabel(tr("学员姓名"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_leanerNameLe = new QLineEdit(this);
    m_leanerNameLe->setReadOnly(true);
    m_leanerNameLe->setProperty("class",QVariant("rightContentLineEdit"));
    infoGridLayout->addWidget(lb,  0,2,1,1);
    infoGridLayout->addWidget(m_leanerNameLe, 0,3,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    infoGridLayout->addWidget(lb,1,0,1,4);

    lb = new QLabel(tr("训练科目"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_trainProjectLe = new QLineEdit(this);
    m_trainProjectLe->setReadOnly(true);
    m_trainProjectLe->setProperty("class",QVariant("rightContentLineEdit"));
    infoGridLayout->addWidget(lb,  2,0,1,1);
    infoGridLayout->addWidget(m_trainProjectLe, 2,1,1,1);

    lb = new QLabel(tr("总培训学时"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_trainToatltime = new QLineEdit(this);
    m_trainToatltime->setReadOnly(true);
    m_trainToatltime->setProperty("class",QVariant("rightContentLineEdit"));
    infoGridLayout->addWidget(lb,  2,2,1,1);
    infoGridLayout->addWidget(m_trainToatltime, 2,3,1,1);
//    lb = new QLabel(tr("教练星级"),this);
//    lb->setProperty("class",QVariant("leftnameLb"));
//    m_coachStarLb = new QLabel(tr(""),this);
//    infoGridLayout->addWidget(lb,  2,0,1,1);
//    infoGridLayout->addWidget(m_coachStarLb, 2,1,1,1);

    lb = new QLabel(tr(""),this);
    lb->setProperty("class",QVariant("lbHorizontalLine"));
    infoGridLayout->addWidget(lb,3,0,1,4);

    lb = new QLabel(tr("完成里程"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_passedMilesLe = new QLineEdit(this);
    m_passedMilesLe->setReadOnly(true);
    m_passedMilesLe->setProperty("class",QVariant("rightContentLineEdit"));
    infoGridLayout->addWidget(lb,  4,0,1,1);
    infoGridLayout->addWidget(m_passedMilesLe, 4,1,1,1);

    lb = new QLabel(tr("完成学时"),this);
    lb->setProperty("class",QVariant("leftnameLb"));
    m_passedLearnTimeLe = new QLineEdit(this);
    m_passedLearnTimeLe->setReadOnly(true);
    m_passedLearnTimeLe->setProperty("class",QVariant("rightContentLineEdit"));
    infoGridLayout->addWidget(lb,  4,2,1,1);
    infoGridLayout->addWidget(m_passedLearnTimeLe, 4,3,1,1);

    picGirdLayout->addLayout(infoGridLayout);

    QPixmap qarcodePix;
    qarcodePix.load(":/resource/image/kedu.jpg");
    m_qardLb = new QLabel(this);
    m_qardLb->setPixmap(qarcodePix);
    picGirdLayout->addWidget(m_qardLb);
    picGirdLayout->setAlignment(m_qardLb,Qt::AlignHCenter);
    picGirdLayout->addStretch();

    bottomFrameLayout->addLayout(picGirdLayout);

    QHBoxLayout *btnLayout = new QHBoxLayout;
    m_volumnBtn = new QToolButton(this);
    m_volumnBtn->setObjectName(QString("volumnLightBtn"));
    m_volumnBtn->setStyleSheet(QString(TB_STYLE_SHEET));
    m_volumnBtn->setIcon(QIcon(":/resource/image/volumn_light.png"));
    btnLayout->addWidget(m_volumnBtn);
    btnLayout->addStretch();
    m_startTrainBtn = new QPushButton(tr("开始训练"),this);
    m_startTrainBtn->setObjectName(QString("startTrainBtn"));
    m_startTrainBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: #f39c12;background-image: none; color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
    btnLayout->addWidget(m_startTrainBtn);
    m_pauseTrainBtn = new QPushButton(tr("暂停训练"),this);
    m_pauseTrainBtn->setObjectName(QString("pauseTrainBtn"));
    m_pauseTrainBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: #f39c12; background-image: none;color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
    btnLayout->addWidget(m_pauseTrainBtn);
    m_stopBtn = new QPushButton(tr("结束训练"),this);
    m_stopBtn->setObjectName(QString("stopTrainBtn"));
    m_stopBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: #f39c12; background-image: none;color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
    btnLayout->addWidget(m_stopBtn);
    btnLayout->addStretch();
    m_endTrainBtn = new QToolButton(this);
    m_endTrainBtn->setObjectName(QString("exitTrainBtn"));
    m_endTrainBtn->setStyleSheet(TB_STYLE_SHEET);
    m_endTrainBtn->setIcon(QIcon(":/resource/image/exit.png"));
    btnLayout->addWidget(m_endTrainBtn);

    bottomFrameLayout->addLayout(btnLayout);

    baseVbLayout->addWidget(bottomWidget);

    baseVbLayout->setStretchFactor(topWidget,2);
    baseVbLayout->setStretchFactor(bottomWidget,3);
}

void TrainDisplayForm::initData()
{
    m_subjectMap.insert(UI_HEADER::TSI_11, tr("科目二 （基础驾驶）"));
    m_subjectMap.insert(UI_HEADER::TSI_12, tr("科目二 （场地驾驶）"));
    m_subjectMap.insert(UI_HEADER::TSI_13, tr("科目二 （综合驾驶及考核）"));
    m_subjectMap.insert(UI_HEADER::TSI_21, tr("科目三 （跟车行驶） "));
    m_subjectMap.insert(UI_HEADER::TSI_22, tr("科目三 （变更车道）"));
    m_subjectMap.insert(UI_HEADER::TSI_23, tr("科目三 （靠边停车）"));
    m_subjectMap.insert(UI_HEADER::TSI_24, tr("科目三 （掉头）"));
    m_subjectMap.insert(UI_HEADER::TSI_25, tr("科目三 （通过路口）"));
    m_subjectMap.insert(UI_HEADER::TSI_26, tr("科目三 （通过人行横道）"));
    m_subjectMap.insert(UI_HEADER::TSI_27, tr("科目三 （通过学校区域）"));
    m_subjectMap.insert(UI_HEADER::TSI_28, tr("科目三 （通过公共汽车站）"));
    m_subjectMap.insert(UI_HEADER::TSI_29, tr("科目三 （会车）"));
    m_subjectMap.insert(UI_HEADER::TSI_30, tr("科目三 （超车）"));
    m_subjectMap.insert(UI_HEADER::TSI_31, tr("科目三 （夜间驾驶）"));
    m_subjectMap.insert(UI_HEADER::TSI_32, tr("科目三 （恶劣条件下的驾驶）"));
    m_subjectMap.insert(UI_HEADER::TSI_33, tr("科目三 （山区道路驾驶）"));
    m_subjectMap.insert(UI_HEADER::TSI_34, tr("科目三 （高速公路驾驶）"));
    m_subjectMap.insert(UI_HEADER::TSI_35, tr("科目三 （行驶路线选择）"));
    m_subjectMap.insert(UI_HEADER::TSI_36, tr("科目三 （综合驾驶及考核）"));
}

void TrainDisplayForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainLoginForm = NULL;
    if(!bw){
        trainLoginForm = new TrainLoginForm();
        trainLoginForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainLoginForm);
        m_mainStackWidget->addWidget(trainLoginForm);

    }else{
        trainLoginForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainLoginForm);
    trainLoginForm->updateContent();
}

void TrainDisplayForm::showVolumeLightSetForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM);
    VolumeLightSetForm *voghtForm = NULL;
    if(!bw){
        voghtForm = new VolumeLightSetForm();
        voghtForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::SETTING_VOLUME_LIGHT_FORM,voghtForm);
        m_mainStackWidget->addWidget(voghtForm);

    }else{
        voghtForm = static_cast<VolumeLightSetForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(voghtForm);
    voghtForm->setParentWidget(type());
    voghtForm->updateContent();
}

void TrainDisplayForm::onStartTrainBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    if(m_confirmDlg == NULL){
        m_confirmDlg = new ConfirmMessageDialog;
        m_confirmDlg->setTest(tr("是否开始训练?"));
        connect(m_confirmDlg, SIGNAL(sigOk()), this, SLOT(onStartOk()));
        connect(m_confirmDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished(int)));
    }

#ifdef nuc970_4_8
    m_confirmDlg->showFullScreen();
#else
    m_confirmDlg->resize(this->size());
    m_confirmDlg->move(this->mapToGlobal(QPoint(0,0)));
    m_confirmDlg->exec();
#endif

}

void TrainDisplayForm::onStartOk()
{
    qDebug() << "start ok ...";
    //real start train
    DisplayHandler *handler = HandlerManager::instance()->getDisplayHandler();
    handler->startTrain();
    m_startTrainBtn->setEnabled(false);
    m_startTrainBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: blue;background-image: none; color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
}

void TrainDisplayForm::onPauseTrainBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    if(m_confirmDlg == NULL){
        m_confirmDlg = new ConfirmMessageDialog;
        m_confirmDlg->setTest(tr("是否暂停训练?"));
        connect(m_confirmDlg, SIGNAL(sigOk()), this, SLOT(onPauseOk()));
        connect(m_confirmDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished(int)));
    }
#ifdef nuc970_4_8
    m_confirmDlg->showFullScreen();
#else
    m_confirmDlg->resize(this->size());
    m_confirmDlg->move(this->mapToGlobal(QPoint(0,0)));
    m_confirmDlg->exec();
#endif
}

void TrainDisplayForm::onPauseOk()
{
    qDebug() << "pause ok...";
    //real pause train
    DisplayHandler *handler = HandlerManager::instance()->getDisplayHandler();
    handler->pauseTrain();
    m_startTrainBtn->setEnabled(true);
    m_startTrainBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: #f39c12;background-image: none; color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
}

void TrainDisplayForm::onStopTrainBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)
    Q_UNUSED(clicked)
    if(m_confirmDlg == NULL){
        m_confirmDlg = new ConfirmMessageDialog;
        m_confirmDlg->setTest(tr("是否停止训练?"));
        connect(m_confirmDlg, SIGNAL(sigOk()), this, SLOT(onStopOk()));
        connect(m_confirmDlg, SIGNAL(finished(int)), this, SLOT(onConfirmDlgFinished(int)));
    }
#ifdef nuc970_4_8
    m_confirmDlg->showFullScreen();
#else
    m_confirmDlg->resize(this->size());
    m_confirmDlg->move(this->mapToGlobal(QPoint(0,0)));
    m_confirmDlg->exec();
#endif
//    HandlerManager::instance()->getLoginHandler()->resetLoginState();
//    showTrainLoginForm();
}

void TrainDisplayForm:: onEndTrainBtnClicked()
{
//    Q_UNUSED(clicked)
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGOUT_FORM);
    TrainLogoutForm *logoutForm = NULL;
    if(!bw){
        logoutForm = new TrainLogoutForm();
        logoutForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGOUT_FORM,logoutForm);
        m_mainStackWidget->addWidget(logoutForm);

    }else{
        logoutForm = static_cast<TrainLogoutForm*>(bw);
    }

    m_startTrainBtn->setEnabled(true);
    m_startTrainBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: #f39c12;background-image: none; color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
    m_mainStackWidget->setCurrentWidget(logoutForm);
    logoutForm->updateContent();
}

void TrainDisplayForm::onStopOk()
{
    //real stop train
    qDebug() << "stop ok...";
    DisplayHandler *handler = HandlerManager::instance()->getDisplayHandler();
    handler->stopTrain();
    m_startTrainBtn->setEnabled(true);
    m_startTrainBtn->setStyleSheet(QString("min-width:144px;  min-height:44px; max-width:144px; max-height:44px;  background-color: #f39c12;background-image: none; color:#feffff; font-size:22px; text-align:center;  border-width: 0; border-radius: 5px;"));
    QTimer::singleShot(1000, this, SLOT(onEndTrainBtnClicked()));
}

void TrainDisplayForm::onConfirmDlgFinished(int ret)
{
    (void)ret;
//    m_confirmDlg->accept();
    qDebug() << "finished";
    m_confirmDlg = NULL;
}

void TrainDisplayForm::onVolumeLightBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    showVolumeLightSetForm();
}

void TrainDisplayForm::onUpdateDriveSpeed(unsigned int value)
{
//    qDebug() << "[UI]Drive speed ------>" << value;
    m_carSpeedDial->setSpeedValue(value);
}

void TrainDisplayForm::onUpdateDirection(unsigned int value)
{
//    qDebug() << "[UI]directioin value----->" << value;
    m_compassDial->setDirectionValue(value);
}

void TrainDisplayForm::onUpdateTrainingMinutes(unsigned int value)
{
//        qDebug() << "[UI]train minutes----->" << value;
        m_trainTimeDial->setValue(TimeUtil::minutesNumToFormatStr(value));
        updateContent();
}

void TrainDisplayForm::onUpdateCurrentTrainDistance(unsigned int value)
{
//    qDebug() << "[UI]trian distance---->" << value;
    m_trainMileageDial->setValue(QString::number(value));
}

