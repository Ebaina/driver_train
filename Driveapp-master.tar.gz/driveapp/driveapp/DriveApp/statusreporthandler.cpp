﻿#include "statusreporthandler.h"
#include "handlermanager.h"

StatusReportHandler::StatusReportHandler(QObject *parent) :
    QObject(parent)
{

}

StatusReportHandler::~StatusReportHandler()
{

}

void StatusReportHandler::updateLocatedState(unsigned char state)
{
    emit sigUpdateLocateState(state);
}

void StatusReportHandler::updateMobileSignal(unsigned char signalValue)
{
    emit sigUpdateMobileSignal(signalValue);
}

void StatusReportHandler::updateUrgentAlertState(unsigned char state)
{
    emit sigUpdateUrgentAlertState(state);
}

void StatusReportHandler::updateSpeedAlertState(unsigned char state)
{
    emit sigUpdateSpeedAlertState(state);
}

void StatusReportHandler::updateNetToPlateState(unsigned char state)
{
    emit sigUpdateNetToPlateState(state);
}

void StatusReportHandler::updateNetState(unsigned char state)
{
    emit sigUpdateNetState(state);
}

void StatusReportHandler::updateTiredDriveState(unsigned char state)
{
    emit sigUpdateTiredDriveState(state);
}

void StatusReportHandler::updateGNSSFaultState(unsigned char state)
{
    emit sigUpdateGNSSFaultState(state);
}

void StatusReportHandler::updatePowerFaultState(unsigned char state)
{
    emit sigUpdatePowerFaultState(state);
}

void StatusReportHandler::updateTTSFaultState(unsigned char state)
{
    emit sigUpdateTTSFaultState(state);
}

void StatusReportHandler::updateCarFaultState(unsigned char state)
{
    emit sigUpdateCarFaultState(state);
}

void StatusReportHandler::updateCameraFaultState(unsigned char state)
{
    emit sigUpdateCameraFaultState(state);
}

void StatusReportHandler::updateVersionState(unsigned char state)
{
    emit sigUpdateVersionState(state);
}

void StatusReportHandler::registerReportHandler()
{
#ifdef nuc970_4_8
    Ui_Interface *funcInter = NULL;
    funcInter = HandlerManager::instance()->getFuncInterface();
    if(funcInter == NULL){
        return;
    }
    funcInter->register_statusReportHandler(this);
#endif
}

