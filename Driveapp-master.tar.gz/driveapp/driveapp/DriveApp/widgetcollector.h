#ifndef WIDGETCOLLECTOR_H
#define WIDGETCOLLECTOR_H

#include <QMap>
#include "appglobal.h"
#include "basewidget.h"

class WidgetCollector
{
public:
    static QMap<wis_u16, BaseWidget*>  s_widgetMap;

    static void insertWidget(wis_u16 type, BaseWidget* widget );

    static void removeWidget(wis_u16 type);

    static BaseWidget* getWidget(wis_u16 type);

    static BaseWidget* takeWidget(wis_u16 type);

private:
    WidgetCollector();
    WidgetCollector(const WidgetCollector &); // 禁止拷贝
    WidgetCollector & operator= (const WidgetCollector &); // 禁止赋值
    ~WidgetCollector();
};

#endif // WIDGETCOLLECTOR_H

