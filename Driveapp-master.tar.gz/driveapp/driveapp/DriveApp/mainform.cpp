#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QVariant>
#include <QDateTime>
#include <QDebug>
#include <QApplication>
#include <QFile>
#include <QIcon>
#include <QDesktopWidget>

#include "mainform.h"
#include "appglobal.h"
#include "widgetcollector.h"
#include "registerhintform.h"
#include "handlermanager.h"
#include "trainloginform.h"
#include "widgetcollector.h"
#include "traindisplayform.h"

MainForm::MainForm(QWidget *parent)
    : QWidget(parent),
      m_clockTimer(NULL)
{
    initSize();
    drawUI();
    initConnect();
    onTimeSlot();
    m_clockTimer = new QTimer(this);
    m_clockTimer->start(1000);
    connect(m_clockTimer, SIGNAL(timeout()), this, SLOT(onTimeSlot()));
    HandlerManager::instance()->getStatusReportHandler()->registerReportHandler();
    showFirstForm();
}

MainForm::~MainForm()
{
    if(m_clockTimer->isActive())
        m_clockTimer->stop();

    qDeleteAll(WidgetCollector::s_widgetMap);
    WidgetCollector::s_widgetMap.clear();
}

void MainForm::initSize()
{

    this->setWindowFlags(Qt::FramelessWindowHint);
    this->showFullScreen();

    this->setMaximumSize(800,480);
    this->resize(800, 480);
}

void MainForm::drawUI()
{
    QVBoxLayout *baseVBLayout = new QVBoxLayout(this);
    baseVBLayout->setContentsMargins(0, 0, 0, 0);
    baseVBLayout->setSpacing(0);
    /***top bar***/
    QWidget *topToolBar = new QWidget(this);
    topToolBar->setObjectName(QString("topToolBar"));
    QHBoxLayout *topToolBarLayout = new QHBoxLayout(topToolBar);
    m_tbUrgentAlert = new QToolButton(this);
    m_tbUrgentAlert->setVisible(false);
    m_tbUrgentAlert->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbUrgentAlert->setIcon(QIcon(":/topbar/resource/image/topbar/urgent_alert.png"));
    m_tbUrgentAlert->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbUrgentAlert->setToolTip(tr("紧急报警"));
    m_tbUrgentAlert->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbUrgentAlert);
    m_tbSpeedAlert = new QToolButton(this);
    m_tbSpeedAlert->setVisible(false);
    m_tbSpeedAlert->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbSpeedAlert->setIcon(QIcon(":/topbar/resource/image/topbar/speed_alert.png"));
    m_tbSpeedAlert->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbSpeedAlert->setToolTip(tr("超速报警"));
    m_tbSpeedAlert->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbSpeedAlert);
    m_tbTiredDrive = new QToolButton(this);
    m_tbTiredDrive->setVisible(false);
    m_tbTiredDrive->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbTiredDrive->setIcon(QIcon(":/topbar/resource/image/topbar/tired_drive.png"));
    m_tbTiredDrive->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbTiredDrive->setToolTip(tr("疲劳驾驶"));
    m_tbTiredDrive->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbTiredDrive);
    m_tbGNSS = new QToolButton(this);
    m_tbGNSS->setVisible(false);
    m_tbGNSS->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbGNSS->setIcon(QIcon(":/topbar/resource/image/topbar/gnss_alert.png"));
    m_tbGNSS->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbGNSS->setToolTip(tr("GNSS故障"));
    m_tbGNSS->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbGNSS);
    m_tbPower = new QToolButton(this);
    m_tbPower->setVisible(false);
    m_tbPower->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbPower->setIcon(QIcon(":/topbar/resource/image/topbar/power_alert.png"));
    m_tbPower->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbPower->setToolTip(tr("电源故障"));
    m_tbPower->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbPower);
    m_tbPlate = new QToolButton(this);
    m_tbPlate->setVisible(false);
    m_tbPlate->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbPlate->setIcon(QIcon(":/topbar/resource/image/topbar/net_toplate.png"));
    m_tbPlate->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbPlate->setToolTip(tr("平台故障"));
    m_tbPlate->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbPlate);
    m_tbNet = new QToolButton(this);
    m_tbNet->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbNet->setIcon(QIcon(":/topbar/resource/image/topbar/net_fail.png"));
    m_tbNet->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbNet->setToolTip(tr("网络故障"));
    m_tbNet->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbNet);
    m_tbUpdate = new QToolButton(this);
    m_tbUpdate->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbUpdate->setIcon(QIcon(":/topbar/resource/image/topbar/update.png"));
    m_tbUpdate->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbUpdate->setToolTip(tr(" 程序升级"));
    m_tbUpdate->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbUpdate);
    m_tbTTS = new QToolButton(this);
    m_tbTTS->setVisible(false);
    m_tbTTS->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbTTS->setIcon(QIcon(":/topbar/resource/image/topbar/audio_alert.png"));
    m_tbTTS->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbTTS->setToolTip(tr("TTS故障"));
    m_tbTTS->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbTTS);
    m_tbCar = new QToolButton(this);
    m_tbCar->setVisible(false);
    m_tbCar->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbCar->setIcon(QIcon(":/topbar/resource/image/topbar/car_alert.png"));
    m_tbCar->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbCar->setToolTip(tr("车辆故障"));
    m_tbCar->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbCar);
    m_tbCamera = new QToolButton(this);
    m_tbCamera->setVisible(false);
    m_tbCamera->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbCamera->setIcon(QIcon(":/topbar/resource/image/topbar/carema_alert.png"));
    m_tbCamera->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbCamera->setToolTip(tr("摄像故障"));
    m_tbCamera->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbCamera);
    m_tbGPS = new QToolButton(this);
    m_tbGPS->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbGPS->setIcon(QIcon(":/topbar/resource/image/topbar/gps_ok.png"));
    m_tbGPS->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbGPS->setToolTip(tr("GPS"));
    m_tbGPS->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbGPS);
    m_tbMobile = new QToolButton(this);
    m_tbMobile->setFixedSize(STATUSBTN_SIZE, STATUSBTN_SIZE);
    m_tbMobile->setIcon(QIcon(":/topbar/resource/image/topbar/signal_none.png"));
    m_tbMobile->setIconSize(QSize(STATUSBTN_SIZE,STATUSBTN_SIZE));
    m_tbMobile->setToolTip(tr("34G信号"));
    m_tbMobile->setProperty("class", QVariant("toolbarBtn"));
    topToolBarLayout->addWidget(m_tbMobile);
    topToolBarLayout->addStretch();
    m_lbTime = new QLabel(this);
    m_lbTime->setStyleSheet(QString("font-size:21px;color:#e8edf1;"));
    topToolBarLayout->addWidget(m_lbTime);
    topToolBarLayout->setContentsMargins(16, 1, 16, 1);
    topToolBar->setLayout(topToolBarLayout);

    baseVBLayout->addWidget(topToolBar);
    /***main stack widget: manage sub widgets***/
    m_mainStackWidget = new QStackedWidget(this);
    baseVBLayout->addWidget(m_mainStackWidget);


    this->setLayout(baseVBLayout);
}

void MainForm::initConnect()
{
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateLocateState(unsigned char)), this, SLOT(onUpdateLocatedState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateMobileSignal(unsigned char)), this, SLOT(onUpdateMobileSignal(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateUrgentAlertState(unsigned char)), this, SLOT(onUpdateUrgentAlertState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateSpeedAlertState(unsigned char)), this, SLOT(onUpdateSpeedAlertState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateTiredDriveState(unsigned char)), this, SLOT(onUpdateTiredDriveState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateGNSSFaultState(unsigned char)), this, SLOT(onUpdateGNSSFaultState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdatePowerFaultState(unsigned char)), this, SLOT(onUpdatePowerFaultState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateTTSFaultState(unsigned char)), this, SLOT(onUpdateTTSFaultState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateCarFaultState(unsigned char)), this, SLOT(onUpdateCarFaultState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateNetToPlateState(unsigned char)), this, SLOT(onUpdateNetToPlateState(unsigned char)));
     connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateNetState(unsigned char)), this, SLOT(onUpdateNetState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateCameraFaultState(unsigned char)), this, SLOT(onUpdateCameraFaultState(unsigned char)));
    connect(HandlerManager::instance()->getStatusReportHandler(), SIGNAL(sigUpdateVersionState(unsigned char)), this, SLOT(onUpdateVersionState(unsigned char)));
}


void MainForm::showFirstForm()
{
    if(isRegistered()){
        qDebug() << "is Registered";
        if((pageflag() == 0) || (pageflag() == 1))
                showTrainLoginForm();
        else if(pageflag() == 2)
            showDisplayForm();
    }
    else
    {
        showRegForm();
    }
}

bool MainForm::isRegistered()
{
    /***+++++TO DO+++++++++***/
    return HandlerManager::instance()->getSettingHandler()->isRegistered();
}

int MainForm::pageflag()
{
    /***+++++TO DO+++++++++***/
    return HandlerManager::instance()->getSettingHandler()->isPageflag();
}

void MainForm::showRegForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::ENTER_REG_HINT_FORM);
    RegisterHintForm *regForm = NULL;
    if(!bw){
        regForm = new RegisterHintForm(WIS_UI_ENUM::ENTER_REG_HINT_FORM);
        regForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::ENTER_REG_HINT_FORM,regForm);
        m_mainStackWidget->addWidget(regForm);

    }else{
        regForm = static_cast<RegisterHintForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(regForm);
    regForm->updateContent();
}

void MainForm::showTrainLoginForm()
{
    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM);
    TrainLoginForm *trainForm = NULL;
    if(!bw){
        trainForm = new TrainLoginForm;
        trainForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_LOGIN_FORM,trainForm);
        m_mainStackWidget->addWidget(trainForm);

    }else{
        trainForm = static_cast<TrainLoginForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(trainForm);
    trainForm->updateContent();
}

void MainForm::showDisplayForm()
{

    BaseWidget *bw = WidgetCollector::getWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM);
    TrainDisplayForm *displayForm = NULL;
    if(!bw){
        displayForm = new TrainDisplayForm;
        displayForm->setMainStackWidget(m_mainStackWidget);
        WidgetCollector::insertWidget(WIS_UI_ENUM::TRAIN_DISPLAY_FORM,displayForm);
        m_mainStackWidget->addWidget(displayForm);

    }else{
        displayForm = static_cast<TrainDisplayForm*>(bw);
    }

    m_mainStackWidget->setCurrentWidget(displayForm);
    displayForm->updateContent();
}

void MainForm::onTimeSlot()
{
    QString timeStr = QDateTime::currentDateTime().toString(WIS_DATETIME_FORMAT);
    m_lbTime->setText(timeStr);
}

void MainForm::onUpdateLocatedState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbGPS->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbGPS->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateMobileSignal(unsigned char state)
{
    switch(state){
    case UI_HEADER::M_SIGNAL0:
    {
        m_tbMobile->setIcon(QIcon(":/topbar/resource/image/topbar/signal_none.png"));
    }
        break;
    case UI_HEADER::M_SIGNAL1:
    {
        m_tbMobile->setIcon(QIcon(":/topbar/resource/image/topbar/signal_1.png"));
    }
        break;
    case UI_HEADER::M_SIGNAL2:
    {
        m_tbMobile->setIcon(QIcon(":/topbar/resource/image/topbar/signal_2.png"));
    }
        break;
    case UI_HEADER::M_SIGNAL3:
    {
        m_tbMobile->setIcon(QIcon(":/topbar/resource/image/topbar/signal_3.png"));
    }
        break;
    case UI_HEADER::M_SIGNAL4:
    {
        m_tbMobile->setIcon(QIcon(":/topbar/resource/image/topbar/signal_4.png"));
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateUrgentAlertState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbUrgentAlert->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbUrgentAlert->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateSpeedAlertState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbSpeedAlert->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbSpeedAlert->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateTiredDriveState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbTiredDrive->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbTiredDrive->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateGNSSFaultState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbGNSS->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbGNSS->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdatePowerFaultState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbPower->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbPower->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateTTSFaultState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbTTS->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbTTS->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateCarFaultState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbCar->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbCar->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateNetToPlateState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbPlate->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbPlate->setVisible(true);
    }
        break;
    default:
        break;
    }
}


void MainForm::onUpdateNetState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbNet->setIcon(QIcon(":/topbar/resource/image/topbar/net_fail.png"));
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbNet->setIcon(QIcon(":/topbar/resource/image/topbar/net_success.png"));
    }
        break;
    default:
        break;
    }
}
void MainForm::onUpdateCameraFaultState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbCamera->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbCamera->setVisible(true);
    }
        break;
    default:
        break;
    }
}

void MainForm::onUpdateVersionState(unsigned char state)
{
    switch(state){
    case UI_HEADER::RS_NO:
    {
        m_tbUpdate->setVisible(false);
    }
        break;
    case UI_HEADER::RS_YES:
    {
        m_tbCamera->setIcon(QIcon(":/topbar/resource/image/topbar/update.png"));
    }
        break;
    case 2:
    {
        m_tbCamera->setIcon(QIcon(":/topbar/resource/image/topbar/update_ok.png"));
    }
        break;
    default:
        break;
    }
}
