﻿#ifndef STATUSREPORTHANDLER_H
#define STATUSREPORTHANDLER_H

#include <QObject>
#include "statusreportinterface.h"
using namespace WIS_UI;

class StatusReportHandler : public QObject, public StatusReportInterface
{
    Q_OBJECT
public:
    explicit StatusReportHandler(QObject *parent = 0);
    ~StatusReportHandler();

    void updateLocatedState(unsigned char state);

    void updateMobileSignal(unsigned char signalValue);

    /**
  *@brief   紧急报警
  *@param [in]  RetState
  */
    void updateUrgentAlertState(unsigned char state);

    /**
  *@brief   超速报警
  *@param [in] RetState
  */
    void updateSpeedAlertState(unsigned char state);

    /**
  *@brief   疲劳驾驶
  *@param [in] RetState
  */
    void updateTiredDriveState(unsigned char state);

    /**
  *@brief   GNSS故障
  *@param [in]  RetState
  */
      void updateGNSSFaultState(unsigned char state);

    /**
  *@brief   电源故障
  *@param [in]  RetState
  */
      void updatePowerFaultState(unsigned char state);

    /**
  *@brief   TTS故障
  *@param [in]  RetState
  */
      void updateTTSFaultState(unsigned char state);

    /**
  *@brief   车辆故障
  *@param [in]  RetState
  */
      void updateCarFaultState(unsigned char state);

    /**
  *@brief   摄像故障
  *@param [in]  RetState
  */
      void updateCameraFaultState(unsigned char state);

      /**
    *@brief   升级程序
    *@param [in]  RetState
    */
      void updateVersionState(unsigned char state);

      /**
    *@brief   连接平台故障
    *@param [in]  RetState
    */
      void updateNetToPlateState(unsigned char state);

      /**
    *@brief   网络故障
    *@param [in]  RetState
    */
      void updateNetState(unsigned char state);

    void registerReportHandler();

signals:
    void sigUpdateLocateState(unsigned char state);
    void sigUpdateMobileSignal(unsigned char value);
    void sigUpdateUrgentAlertState(unsigned char state);
    void sigUpdateSpeedAlertState(unsigned char state);
    void sigUpdateNetToPlateState(unsigned char state);
    void sigUpdateNetState(unsigned char state);
    void sigUpdateTiredDriveState(unsigned char state);
    void sigUpdateGNSSFaultState(unsigned char state);
    void sigUpdatePowerFaultState(unsigned char state);
    void sigUpdateTTSFaultState(unsigned char state);
    void sigUpdateCarFaultState(unsigned char state);
    void sigUpdateCameraFaultState(unsigned char state);
    void sigUpdateVersionState(unsigned char state);
};

#endif // STATUSREPORTHANDLER_H
