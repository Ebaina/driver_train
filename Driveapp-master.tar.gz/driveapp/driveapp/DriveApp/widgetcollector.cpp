#include "widgetcollector.h"

QMap<wis_u16, BaseWidget*> WidgetCollector::s_widgetMap = QMap<wis_u16, BaseWidget*>();
void WidgetCollector::insertWidget(wis_u16 type, BaseWidget *widget)
{
    s_widgetMap.insert(type, widget);
}

void WidgetCollector::removeWidget(wis_u16 type)
{
    if(s_widgetMap.contains(type))
        s_widgetMap.remove(type);
}

BaseWidget *WidgetCollector::getWidget(wis_u16 type)
{
    return s_widgetMap.value(type,NULL);
}

BaseWidget *WidgetCollector::takeWidget(wis_u16 type)
{
    return s_widgetMap.take(type);
}

WidgetCollector::WidgetCollector()
{

}

WidgetCollector::~WidgetCollector()
{

}
