﻿#ifndef GBKTOCHARARRAY_H
#define GBKTOCHARARRAY_H
#include<QString>
#include <string>

class GbktoCharArray
{
public:
    GbktoCharArray();
    ~GbktoCharArray();
    static GbktoCharArray* getInstance()
    {
        static GbktoCharArray instance;
        return &instance;
    }
    int  charqTostring(const std::string  &str,char *outdata);

private:
      int codeConvert(const char *from_charset, const char *to_charset,const char *inbuf, size_t inlen, char *outbuf, size_t outlen);
      int utf2Gbk(const char *inbuf, int inlen, char *outbuf, int outlen) ;
      int gbk2Utf8(const char *inbuf, size_t inlen, char *outbuf, size_t outlen);
      char buff[20];
      };
#endif // TTSUTILS_H
