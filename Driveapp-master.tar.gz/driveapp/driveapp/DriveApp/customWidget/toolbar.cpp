#include "toolbar.h"

ToolBar::ToolBar(QWidget *parent) :
    QWidget(parent)
{

}

ToolBar::~ToolBar()
{

}


