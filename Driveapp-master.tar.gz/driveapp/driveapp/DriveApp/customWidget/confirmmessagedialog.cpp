﻿#include <QPainter>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QStyleOption>
#include "confirmmessagedialog.h"

ConfirmMessageDialog::ConfirmMessageDialog(QWidget *parent) :
    QDialog(parent)
{
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground,true);
    this->setAttribute(Qt::WA_DeleteOnClose,true);
    m_text = "";

    drawUI();
}


ConfirmMessageDialog::~ConfirmMessageDialog()
{

}

void ConfirmMessageDialog::paintEvent(QPaintEvent *)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);

    p.fillRect(this->rect(),QColor(0,0,0,80));
}

void ConfirmMessageDialog::mousePressEvent(QMouseEvent *mouseEvent)
{
    QWidget::mousePressEvent(mouseEvent);
    this->close();
}

void ConfirmMessageDialog::keyPressEvent(QKeyEvent *keyEvent)
{
    if(keyEvent->key() == Qt::Key_Escape){
        this->close();
    }

    QWidget::keyPressEvent(keyEvent);
}

QString ConfirmMessageDialog::test() const
{
    return m_textLb->text();
}

void ConfirmMessageDialog::setTest(const QString &test)
{
    m_text = test;
    m_textLb->setText(m_text);
}

void ConfirmMessageDialog::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setSpacing(40);

    m_textLb = new QLabel(this);
    m_textLb->setText(tr("请确认"));
    m_textLb->setAlignment(Qt::AlignCenter);
    m_textLb->setStyleSheet(QString("font-size:60px;font-weight:bold;color:#ffffff;text-align:center;"));
    baseVbLayout->addStretch();
    baseVbLayout->addWidget(m_textLb);


    m_okBtn = new QPushButton(tr("确认"), this);
    m_okBtn->setObjectName(QString("okBtn"));
    QHBoxLayout *btnLayout = new QHBoxLayout;
    btnLayout->setSpacing(10);
    btnLayout->addStretch();
    btnLayout->addWidget(m_okBtn);
    m_cancelBtn = new QPushButton(tr("返回"), this);
    m_cancelBtn->setObjectName(QString("cancelBtn"));
    btnLayout->addWidget(m_cancelBtn);
    btnLayout->addStretch();

    baseVbLayout->addLayout(btnLayout);
    baseVbLayout->addStretch();

    connect(m_okBtn, SIGNAL(clicked()), this, SLOT(onOkBtnClicked()));
    connect(m_cancelBtn, SIGNAL(clicked()), this, SLOT(onCancelBtnClicked()));
}

void ConfirmMessageDialog::onOkBtnClicked()
{
    emit sigOk();
    this->close();
}

void ConfirmMessageDialog::onCancelBtnClicked()
{
    emit sigCancel();
    this->close();
}
