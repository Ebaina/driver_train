﻿#ifndef CONFIRMMESSAGEDIALOG_H
#define CONFIRMMESSAGEDIALOG_H

#include <QWidget>
#include <QDialog>
#include <QPaintEvent>
#include <QPushButton>
#include <QLabel>
#include <QMouseEvent>
#include <QKeyEvent>

class ConfirmMessageDialog : public QDialog
{
    Q_OBJECT
public:
    explicit ConfirmMessageDialog(QWidget *parent = 0);
    ~ConfirmMessageDialog();

    QString test() const;
    void setTest(const QString &test);

    QString m_text;
    QLabel *m_textLb;
    QPushButton *m_cancelBtn;
    QPushButton *m_okBtn;

    void drawUI();

signals:
    void sigOk();
    void sigCancel();

protected:
    void paintEvent(QPaintEvent *);

    void mousePressEvent(QMouseEvent *mouseEvent);

    void keyPressEvent(QKeyEvent *keyEvent);
private:


private slots:
    void onOkBtnClicked();

    void onCancelBtnClicked();

};

#endif // CONFIRMMESSAGEDIALOG_H
