#ifndef CARSPEEDDIAL_H
#define CARSPEEDDIAL_H

#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QColor>


class CarSpeedDial : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(int speedValue READ speedValue WRITE setSpeedValue NOTIFY speedValueChanged)
public:
    explicit CarSpeedDial(QWidget *parent = 0);

    QString speedUnit() const;
    void setSpeedUnit(const QString &speedUnit);

    int speedValue() const;
    void setSpeedValue(int speedValue);

    int maxSpeedValue() const;
    void setMaxSpeedValue(int maxSpeedValue);

    int minSpeedValue() const;
    void setMinSpeedValue(int minSpeedValue);

signals:
    void speedValueChanged(int speedValue);

public slots:

protected:
    void paintEvent(QPaintEvent *event);

private:
    QString m_speedText;
    int m_speedValue;
    int m_minSpeedValue;
    int m_maxSpeedValue;
    QString m_speedUnit;
    QColor m_background;

    void drawBackground(QPainter *painter);

    void drawScale(QPainter *painter);

    void drawSpeedValue(QPainter *painter);

    void drawSpeedUnit(QPainter *painter);
};

#endif // CARSPEEDDIAL_H
