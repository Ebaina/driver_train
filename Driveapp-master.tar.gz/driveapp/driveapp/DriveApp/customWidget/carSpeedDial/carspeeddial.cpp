﻿#include "carspeeddial.h"

CarSpeedDial::CarSpeedDial(QWidget *parent) : QWidget(parent)
{
    m_background = QColor(Qt::transparent);
    m_minSpeedValue = 0;
    m_speedValue = 0;
    m_maxSpeedValue = 60;
    m_speedUnit = QString("km/h");

}

void CarSpeedDial::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    int side = qMin(width(), height());

    painter.setViewport((width() - side) / 2, (height() - side) / 2,side, side);
    painter.setWindow(-50, -50, 100, 100);

    drawBackground(&painter);

    drawScale(&painter);

    drawSpeedValue(&painter);

    drawSpeedUnit(&painter);
}

int CarSpeedDial::minSpeedValue() const
{
    return m_minSpeedValue;
}

void CarSpeedDial::setMinSpeedValue(int minSpeedValue)
{
    if(minSpeedValue < 0)
        return;
    m_minSpeedValue = qMin(minSpeedValue, m_maxSpeedValue - 1);
}

int CarSpeedDial::maxSpeedValue() const
{
    return m_maxSpeedValue;
}

void CarSpeedDial::setMaxSpeedValue(int maxSpeedValue)
{
    if(maxSpeedValue < 0)
        return;
    m_maxSpeedValue = qMax(maxSpeedValue, m_minSpeedValue + 1);
}

int CarSpeedDial::speedValue() const
{
    return m_speedValue;
}

void CarSpeedDial::setSpeedValue(int speedValue)
{
    if(m_speedValue < m_minSpeedValue){
        m_speedValue = m_minSpeedValue;
    }else if(m_speedValue > m_maxSpeedValue){
        m_speedValue = m_maxSpeedValue;
    }

    if(m_speedValue != speedValue){
        m_speedValue = speedValue;
        update();
        emit speedValueChanged(speedValue);
    }
}

void CarSpeedDial::drawBackground(QPainter *painter)
{
    painter->save();
    painter->setBrush(m_background);
        QPen pen(QColor(243, 156, 18),4);
//    QPen pen(Qt::red,4);
    painter->setPen(pen);
    painter->drawEllipse(-45,-45,90,90);

    int range = m_maxSpeedValue - m_minSpeedValue;
    double r = (double)m_speedValue / range;
    pen = QPen(QColor(Qt::white),4);
    painter->setPen(pen);
    painter->setBrush(Qt::NoBrush);
    painter->rotate(180);
    painter->drawArc(-45,-45,90,90,-90 *16,360*r*16);
    painter->restore();
}

void CarSpeedDial::drawScale(QPainter *painter)
{
    float r = 360 / 5.0;
    for(int i = 0;i < 5;++i){
        painter->save();
        painter->setBrush(QColor(243, 156, 18));
        painter->setPen(Qt::NoPen);
        painter->rotate(i * r);
        painter->drawRoundedRect(-2,-43,4,12,1,1);
        painter->restore();
    }
}

void CarSpeedDial::drawSpeedValue(QPainter *painter)
{
    painter->save();
    QPen pen(QColor(Qt::white),2);
    QFont font = painter->font();
//    font.setBold(true);
    font.setPointSize(16);
    painter->setFont(font);
    painter->setPen(pen);
    painter->drawText(-20,-20,40,20,Qt::AlignHCenter | Qt::AlignVCenter,QString::number(m_speedValue));
    painter->restore();
}

void CarSpeedDial::drawSpeedUnit(QPainter *painter)
{
    painter->save();
    QPen pen(QColor(Qt::white),1.5);
    QFont font = painter->font();
    font.setPointSize(4);
    painter->setPen(pen);
    painter->drawText(-20,0,40,20,Qt::AlignHCenter | Qt::AlignVCenter,m_speedUnit);
    painter->restore();
}

QString CarSpeedDial::speedUnit() const
{
    return m_speedUnit;
}

void CarSpeedDial::setSpeedUnit(const QString &speedUnit)
{
    m_speedUnit = speedUnit;
}



