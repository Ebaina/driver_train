#ifndef CONTENTUNITDIAL_H
#define CONTENTUNITDIAL_H

#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QColor>

class ContentUnitDial : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(QString value READ value WRITE setValue NOTIFY valueChanged)
public:
    explicit ContentUnitDial(QWidget *parent = 0);

    QColor background() const;
    void setBackground(const QColor &background);

    QString value() const;
    void setValue(const QString &value);

    QString unit() const;
    void setUnit(const QString &unit);

signals:
    void valueChanged(QString value);
public slots:

protected:
    void paintEvent(QPaintEvent *event);

    void drawBackground(QPainter *painter);

    void drawScale(QPainter *painter);

    void drawValue(QPainter *painter);

    void drawUnit(QPainter *painter);

private:
    QColor m_background;

    QString m_value;

    QString m_unit;
};

#endif // CONTENTUNITDIAL_H
