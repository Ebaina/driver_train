﻿#include <QPainter>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QStyleOption>
#include "messagebox.h"

Messagebox::Messagebox(QWidget *parent):
    QWidget(parent)
{
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground,true);
    this->setAttribute(Qt::WA_DeleteOnClose,true);
    m_text = "";

    drawUI();
}

Messagebox::~Messagebox()
{

}

void Messagebox::paintEvent(QPaintEvent *)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);

    p.fillRect(this->rect(),QColor(0,0,0,80));
}

void Messagebox::mousePressEvent(QMouseEvent *mouseEvent)
{
    QWidget::mousePressEvent(mouseEvent);
    this->close();
}

void Messagebox::keyPressEvent(QKeyEvent *keyEvent)
{
    if(keyEvent->key() == Qt::Key_Escape){
        this->close();
    }

    QWidget::keyPressEvent(keyEvent);
}

QString Messagebox::test() const
{
    return m_textLb->text();
}

void Messagebox::setTest(const QString &test)
{
    m_text = test;
    m_textLb->setText(m_text);
}

void Messagebox::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setSpacing(40);

    m_textLb = new QLabel(this);
    m_textLb->setText(tr("请确认"));
    m_textLb->setAlignment(Qt::AlignCenter);
    m_textLb->setStyleSheet(QString("font-size:60px;font-weight:bold;color:#ffffff;text-align:center;"));
    baseVbLayout->addStretch();
    baseVbLayout->addWidget(m_textLb);


    m_okBtn = new QPushButton(tr("确认"), this);
    m_okBtn->setObjectName(QString("okBtn"));
    QHBoxLayout *btnLayout = new QHBoxLayout;
    btnLayout->setSpacing(10);
    btnLayout->addStretch();
    btnLayout->addWidget(m_okBtn);
    m_cancelBtn = new QPushButton(tr("返回"), this);
    m_cancelBtn->setObjectName(QString("cancelBtn"));
    btnLayout->addWidget(m_cancelBtn);
    btnLayout->addStretch();

    baseVbLayout->addLayout(btnLayout);
    baseVbLayout->addStretch();

    connect(m_okBtn, SIGNAL(clicked()), this, SLOT(onOkBtnClicked()));
    connect(m_cancelBtn, SIGNAL(clicked()), this, SLOT(onCancelBtnClicked()));
}

void Messagebox::onOkBtnClicked()
{
    emit sigOk();
    this->close();
}

void Messagebox::onCancelBtnClicked()
{
    emit sigCancel();
    this->close();
}
