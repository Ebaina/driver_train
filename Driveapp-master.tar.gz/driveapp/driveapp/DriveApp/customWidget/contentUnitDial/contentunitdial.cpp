#include "contentunitdial.h"

ContentUnitDial::ContentUnitDial(QWidget *parent) : QWidget(parent)
{
    m_background = QColor(Qt::transparent);
}

void ContentUnitDial::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    int side = qMin(width(), height());

    painter.setViewport((width() - side) / 2, (height() - side) / 2,side, side);
    painter.setWindow(-50, -50, 100, 100);

    drawBackground(&painter);

    drawScale(&painter);

    drawValue(&painter);

    drawUnit(&painter);
}

void ContentUnitDial::drawBackground(QPainter *painter)
{
    painter->save();
    painter->setBrush(m_background);
        QPen pen(QColor(243, 156, 18),4);
//    QPen pen(Qt::red,4);
    painter->setPen(pen);
    painter->drawEllipse(-45,-45,90,90);

    painter->restore();
}

void ContentUnitDial::drawScale(QPainter *painter)
{
    int r = 360 / 4;
    for(int i = 0;i < 4;++i){
        painter->save();
        painter->setBrush(QColor(243, 156, 18));
        painter->setPen(Qt::NoPen);
        painter->rotate(i * r);
        painter->drawRoundedRect(-2,-43,4,12,1,1);
        painter->restore();
    }
}

void ContentUnitDial::drawValue(QPainter *painter)
{
    painter->save();
    QPen pen(QColor(Qt::white),2);
    QFont font = painter->font();
//    font.setBold(true);
    font.setPointSize(14);
    painter->setFont(font);
    painter->setPen(pen);
    painter->drawText(-20,-20,40,20,Qt::AlignHCenter | Qt::AlignVCenter,m_value);
    painter->restore();
}

void ContentUnitDial::drawUnit(QPainter *painter)
{
    painter->save();
    QPen pen(QColor(Qt::white),1.5);
    QFont font = painter->font();
    font.setPointSize(4);
    painter->setPen(pen);
    painter->drawText(-20,0,40,20,Qt::AlignHCenter | Qt::AlignVCenter,m_unit);
    painter->restore();
}

QString ContentUnitDial::unit() const
{
    return m_unit;
}

void ContentUnitDial::setUnit(const QString &unit)
{
    m_unit = unit;
    update();
}

QString ContentUnitDial::value() const
{
    return m_value;
}

void ContentUnitDial::setValue(const QString &value)
{
    m_value = value;
    update();
}

QColor ContentUnitDial::background() const
{
    return m_background;
}

void ContentUnitDial::setBackground(const QColor &background)
{
    m_background = background;
}

