﻿#ifndef MESSAGEBOX_H
#define MESSAGEBOX_H
#include <QWidget>
#include <QPaintEvent>
#include <QPushButton>
#include <QLabel>
#include <QMouseEvent>
#include <QKeyEvent>

class Messagebox : public QWidget
{
    Q_OBJECT
public:
    explicit Messagebox(QWidget *parent = 0);
    ~Messagebox();

    QString test() const;
    void setTest(const QString &test);

    QString m_text;
    QLabel *m_textLb;
    QPushButton *m_cancelBtn;
    QPushButton *m_okBtn;

    void drawUI();

signals:
    void sigOk();
    void sigCancel();

protected:
    void paintEvent(QPaintEvent *);

    void mousePressEvent(QMouseEvent *mouseEvent);

    void keyPressEvent(QKeyEvent *keyEvent);
private:


private slots:
    void onOkBtnClicked();

    void onCancelBtnClicked();
};

#endif // MESSAGEBOX_H


