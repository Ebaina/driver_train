#ifndef COMPASSDIAL_H
#define COMPASSDIAL_H

#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QColor>

class CompassDial : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(int directionValue READ directionValue WRITE setDirectionValue NOTIFY directionValueChanged)
public:
    explicit CompassDial(QWidget *parent = 0);

    QColor background() const;
    void setBackground(const QColor &background);

    int directionValue() const;
    /**
  *@brief       directionValue : 0 - 360       0: north
 */
    void setDirectionValue(int directionValue);

signals:
    void directionValueChanged(int directionValue);
public slots:

protected:
    void paintEvent(QPaintEvent *event);

    void drawBackground(QPainter *painter);

    void drawDirectionScale(QPainter *painter);

    void drawNeedle(QPainter *painter);

private:
    QColor m_background;

    /***  0 - 360**/
    int m_minDirectionValue;
    int m_maxDirectionValue;
    int m_directionValue;
};

#endif // COMPASSDIAL_H
