#include "compassdial.h"

#ifndef MIN_DIRECTION_VALUE
#define MIN_DIRECTION_VALUE 0
#endif

#ifndef MAX_DIRECTION_VALUE
#define MAX_DIRECTION_VALUE 360
#endif


CompassDial::CompassDial(QWidget *parent) : QWidget(parent)
{
    m_background = QColor(Qt::transparent);
    m_directionValue = 0;
}

void CompassDial::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    int side = qMin(width(), height());

    painter.setViewport((width() - side) / 2, (height() - side) / 2,side, side);
    painter.setWindow(-50, -50, 100, 100);

    drawBackground(&painter);

    drawDirectionScale(&painter);

    drawNeedle(&painter);
}

void CompassDial::drawBackground(QPainter *painter)
{
    painter->save();
    painter->setBrush(m_background);
        QPen pen(QColor(243, 156, 18),4);
//    QPen pen(Qt::red,4);
    painter->setPen(pen);
    painter->drawEllipse(-45,-45,90,90);

    painter->restore();
}

void CompassDial::drawDirectionScale(QPainter *painter)
{
    painter->save();
    QPen pen(QColor(243, 156, 18),0.5);
    painter->setPen(pen);
    painter->drawText(-15,-40,30,25,Qt::AlignHCenter | Qt::AlignTop, QString("N"));
    painter->restore();
}

void CompassDial::drawNeedle(QPainter *painter)
{
    painter->save();
    QPolygon headPolygon;
    QPen pen(QColor(Qt::white),0.5);
    painter->setPen(pen);
    painter->setBrush(QColor(Qt::white));
    headPolygon.setPoints(3, -2,0, 2,0, 0,-20);
    painter->rotate(m_directionValue);
    painter->drawPolygon(headPolygon);

    QPolygon tailPolygon;
    tailPolygon.setPoints(3, -2,0, 2,0, 0,20);
    painter->setBrush(Qt::NoBrush);
    painter->drawPolygon(tailPolygon);
    painter->restore();
}

int CompassDial::directionValue() const
{
    return m_directionValue;
}

void CompassDial::setDirectionValue(int directionValue)
{
    if(directionValue < MIN_DIRECTION_VALUE){
        m_directionValue = MIN_DIRECTION_VALUE;
    }else if(directionValue > MAX_DIRECTION_VALUE){
        m_directionValue = MAX_DIRECTION_VALUE;
    }

    if(m_directionValue != directionValue){
        m_directionValue = directionValue;
        update();
        emit directionValueChanged(m_directionValue);
    }
}

QColor CompassDial::background() const
{
    return m_background;
}

void CompassDial::setBackground(const QColor &background)
{
    m_background = background;
}

