/******************************************************************************

  Copyright (C), 2013-2016, NanJing Wisdom Iot. Tech. Co., Ltd.

 ******************************************************************************
  File Name     :toolbar.h   toolbar.cpp
  Version       : Initial
  Author        : hxq
  Created       : 2016/11/24
  Last Modified :
  Description   :
  Function List :
  History       :
  1.Date        : 2016/11/24
    Author      : hxq
    Modification: Created file

******************************************************************************/
#ifndef TOOLBAR_H
#define TOOLBAR_H

#include <QWidget>

class ToolBar : public QWidget
{
    Q_OBJECT
public:
    explicit ToolBar(QWidget *parent = 0);
    ~ToolBar();

private:



};

#endif // TOOLBAR_H

