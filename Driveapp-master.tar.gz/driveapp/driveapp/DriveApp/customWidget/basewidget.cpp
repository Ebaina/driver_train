#include <QStyleOption>
#include <QPainter>
#include "basewidget.h"

BaseWidget::BaseWidget(QWidget *parent) :
    QWidget(parent)
{

}

BaseWidget::~BaseWidget()
{

}

void BaseWidget::paintEvent(QPaintEvent *)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
