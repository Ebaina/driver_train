#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPainter>
#include <QColor>
#include <QApplication>
#include <QDesktopWidget>
#include <QFrame>
#include <QKeyEvent>
#include <QCoreApplication>

#include "textlistview.h"

TextListView::TextListView(QWidget *parent) :
    QDialog(parent)
{
    this->setWindowFlags(Qt::FramelessWindowHint);

//    this->setWindowOpacity(0.5);
    this->setAttribute(Qt::WA_TranslucentBackground,true);

    drawUI();
    initConnect();
}

TextListView::~TextListView()
{

}

void TextListView::setTextModel(QStringList &textModel)
{
    m_listWidget->clear();
    int count = textModel.size();
    QListWidgetItem *item = NULL;
    for(int i = 0;i < count;++i){
        item = new QListWidgetItem(textModel.at(i));
        item->setWhatsThis(QString::number(i));
        m_listWidget->addItem(item);
    }
}

void TextListView::setTextModel(QMap<int, QString> &textModel)
{
    m_listWidget->clear();
    QListWidgetItem *item = NULL;
    QMap<int,QString> :: const_iterator modelIterator;
    for(modelIterator = textModel.constBegin(); modelIterator != textModel.constEnd(); ++modelIterator){
        item = new QListWidgetItem(modelIterator.value());
        item->setWhatsThis(QString::number(modelIterator.key()));
        m_listWidget->addItem(item);
    }
}

void TextListView::drawUI()
{
    QVBoxLayout *baseVbLayout = new QVBoxLayout(this);
    baseVbLayout->setSpacing(0);
    m_listWidget = new QListWidget(this);
    m_listWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_listWidget->setWindowOpacity(1.0);
//    m_listWidget->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);

    baseVbLayout->addStretch();
    baseVbLayout->addWidget(m_listWidget);
    baseVbLayout->setAlignment(m_listWidget, Qt::AlignHCenter);

//    QFrame *btnFrame = new QFrame(this);
//    btnFrame->setObjectName(QString("btnFrame"));
//    btnFrame->setStyleSheet("background-color: #ffffff;");
    QHBoxLayout *btnLayout = new QHBoxLayout;
    btnLayout->setSpacing(9);
    m_prePageBtn = new QPushButton(tr("向上"),this);
    m_prePageBtn->setObjectName(QString("prePageBtn"));
    m_nextPageBtn = new QPushButton(tr("向下"),this);
    m_nextPageBtn->setObjectName(QString("nextPageBtn"));
    btnLayout->addStretch();
    btnLayout->addWidget(m_prePageBtn);
    btnLayout->addWidget(m_nextPageBtn);
    btnLayout->addStretch();
    baseVbLayout->addLayout(btnLayout);
    baseVbLayout->setAlignment(btnLayout,Qt::AlignHCenter);

    baseVbLayout->addStretch();
}

void TextListView::initConnect()
{
    connect(m_listWidget, SIGNAL(itemClicked(QListWidgetItem*)), this,SLOT(onItemClicked(QListWidgetItem*)));
    connect(m_prePageBtn, SIGNAL(clicked(bool)), this, SLOT(onPrePageBtnClicked(bool)));
    connect(m_nextPageBtn, SIGNAL(clicked(bool)), this, SLOT(onNextPageBtnClicked(bool)));
}

void TextListView::onItemClicked(QListWidgetItem *item)
{
    emit sigItemClicked(item->whatsThis().toInt(), item->text());
    this->close();
}

void TextListView::onPrePageBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    QKeyEvent keyPressEvent(QEvent::KeyPress,Qt::Key_Up,Qt::NoModifier,QString(""));
    QApplication::sendEvent(m_listWidget,&keyPressEvent);
}

void TextListView::onNextPageBtnClicked(bool clicked)
{
    Q_UNUSED(clicked)

    QKeyEvent keyPressEvent(QEvent::KeyPress,Qt::Key_Down,Qt::NoModifier,QString(""));
    QApplication::sendEvent(m_listWidget,&keyPressEvent);
}

void TextListView::showView()
{
#ifdef nuc970_4_8
    this->showFullScreen();
#else
    int dw = QApplication::desktop()->availableGeometry().width();
    int dh = QApplication::desktop()->availableGeometry().height();
    this->setMaximumSize(800,480);
    this->resize(800,480);
    this->move((dw-800)/2, (dh-480)/2);
    this->exec();
#endif
}

void TextListView::paintEvent(QPaintEvent *)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);

    p.fillRect(this->rect(),QColor(0,0,0,80));
}

void TextListView::mousePressEvent(QMouseEvent *mouseEvent)
{
    QWidget::mousePressEvent(mouseEvent);
    this->close();
}

void TextListView::keyPressEvent(QKeyEvent *keyEvent)
{
    if(keyEvent->key() == Qt::Key_Escape){
        this->close();
    }

    QWidget::keyPressEvent(keyEvent);
}
