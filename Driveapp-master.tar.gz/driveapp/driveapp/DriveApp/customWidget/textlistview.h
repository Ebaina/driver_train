#ifndef TEXTLISTVIEW
#define TEXTLISTVIEW

#include <QListWidget>
#include <QDialog>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QListWidgetItem>
#include <QKeyEvent>
#include <QPushButton>

class TextListView : public QDialog
{
    Q_OBJECT
public:
    explicit TextListView(QWidget *parent = 0);
    ~TextListView();

    void setTextModel(QStringList &textModel);

    void setTextModel(QMap<int,QString> &textModel);

signals:
    void sigItemClicked(int index, QString value);

public slots:
    void showView();

protected:
    void paintEvent(QPaintEvent *);

    void mousePressEvent(QMouseEvent *mouseEvent);

    void keyPressEvent(QKeyEvent *keyEvent);

private:
    QListWidget *m_listWidget;
    QPushButton *m_prePageBtn;
    QPushButton *m_nextPageBtn;

    void drawUI();

    void initConnect();

private slots:
    void onItemClicked(QListWidgetItem *item);

    void onPrePageBtnClicked(bool clicked);

    void onNextPageBtnClicked(bool clicked);
};

#endif // TEXTLISTVIEW

