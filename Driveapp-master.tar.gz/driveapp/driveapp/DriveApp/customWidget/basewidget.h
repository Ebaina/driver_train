#ifndef BASEWIDGET_H
#define BASEWIDGET_H

#include <QWidget>
#include <QStackedWidget>
#include <QPaintEvent>
#include "appglobal.h"
//#include "widgetcollector.h"

class BaseWidget : public QWidget
{
    Q_OBJECT
public:
    explicit BaseWidget(QWidget *parent = 0);
    ~BaseWidget();
    
    virtual wis_u16 type() = 0;

    virtual void setMainStackWidget(QStackedWidget *stackWidget) = 0;

    virtual void updateContent() = 0;

protected:
    void paintEvent(QPaintEvent*);
};

#endif // BASEWIDGET_H

