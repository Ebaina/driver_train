﻿#include <QObject>
#include "commondatamgr.h"
#include "ui_structs.h"
using namespace UI_HEADER;
CommonDataMgr::CommonDataMgr()
{

}

QString CommonDataMgr::getCardTypeValue(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case CT_IDCARD:
        value = QObject::tr("身份证");
        break;
    case CT_PASSPORT:
        value = QObject::tr("护照");
        break;
    case CT_OFFICER_CARD:
        value = QObject::tr("军官证");
        break;
    case CT_LIVING_CARD:
        value = QObject::tr("居住证");
        break;
    default:
        break;
    }

    return value;
}

QString CommonDataMgr::getLicenseColorValue(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case LC_BLUE:
        value = QObject::tr("蓝色         ");
        break;
    case LC_YELLOW:
        value = QObject::tr("黄色");
        break;
    case LC_BLACK:
        value = QObject::tr("黑色");
        break;
    case LC_WHITE:
        value = QObject::tr("白色");
        break;
    case LC_GREEN:
        value = QObject::tr("绿色");
        break;
    case LC_OTHER:
        value = QObject::tr("其他");
        break;
    default:
        break;
    }

    return value;
}

QString CommonDataMgr::getCarTypeValue(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case A1:
        value = QObject::tr("A1");
        break;
    case A2:
        value = QObject::tr("A2");
        break;
    case A3:
        value = QObject::tr("A3");
        break;
    case B1:
        value = QObject::tr("B1");
        break;
    case B2:
        value = QObject::tr("B2");
        break;
    case C1:
        value = QObject::tr("C1");
        break;
    case C2:
        value = QObject::tr("C2");
        break;
    case C3:
        value = QObject::tr("C3");
        break;
    case C4:
        value = QObject::tr("C4");
        break;
    case C5:
        value = QObject::tr("C5");
        break;
    case D:
        value = QObject::tr("D");
        break;
    case E:
        value = QObject::tr("E");
        break;
    case F:
        value = QObject::tr("F");
        break;
    case M:
        value = QObject::tr("M");
        break;
    case N:
        value = QObject::tr("N");
        break;
    case P:
        value = QObject::tr("P");
        break;
    default:
        break;
    }

    return value;
}

QString CommonDataMgr::getCoachStarImgSource(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case CSR_1:
        value = QString(":/display_module_img/resource/image/displayModuleImg/star_1.png");
        break;
    case CSR_2:
        value = QString(":/display_module_img/resource/image/displayModuleImg/star_2.png");
        break;
    case CSR_3:
        value = QString(":/display_module_img/resource/image/displayModuleImg/star_3.png");
        break;
    case CSR_4:
        value = QString(":/display_module_img/resource/image/displayModuleImg/star_4.png");
        break;
    case CSR_5:
        value = QString(":/display_module_img/resource/image/displayModuleImg/star_5.png");
        break;
    default:
        break;
    }

    return value;
}

QString CommonDataMgr::getTrainSubjectValue(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case TST_1:
        value = QObject::tr("科目一");
        break;
    case TST_2:
        value = QObject::tr("科目二");
        break;
    case TST_3:
        value = QObject::tr("科目三");
        break;
    case TST_4:
        value = QObject::tr("科目四");
        break;
    default:
        break;
    }

    return value;

}

QString CommonDataMgr::getPostReportStrategyValue(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case RST_TIME:
        value = QObject::tr("定时汇报");
        break;
    case RST_DIST:
        value = QObject::tr("定距汇报");
        break;
    case RST_TIME_DIST:
        value = QObject::tr("定时和定距汇报");
        break;
    default:
        break;
    }

    return value;
}

QString CommonDataMgr::getPostReportSchemeValue(const unsigned char &key)
{
    QString value = "";
    switch (key) {
    case PRST_ACC_STATE:
        value = QObject::tr("根据ACC状态");
        break;
    case PRST_LOGIN_ACC_STATE:
        value = QObject::tr("根据登录和ACC状态");
        break;
    default:
        break;
    }

    return value;
}

QString CommonDataMgr::getTerminalPhoneRecvWayValue(const unsigned char &key)
{
    QString value = "";
    switch(key){
    case TPRW_AUTO:
        value = QObject::tr("自动接听");
        break;
    case TPRW_MANUAL:
        value = QObject::tr("ACC ON时自动 OFF时手动");
        break;
    default:
        break;
    }

    return value;
}






