#ifndef WISDATATYPEDEF_H
#define WISDATATYPEDEF_H

//typedef signed char         wis_s8;       // 8 bit signed
//typedef unsigned char     wis_u8;      // 8 bit unsigned
//typedef short                    wis_s16;      // 16 bit signed
//typedef unsigned short    wis_u16;     // 16 bit unsigned
//typedef int                         wis_s32;      // 32 bit signed
//typedef unsigned int         wis_u32;     // 32 bit unsigned
//typedef long                       wis_s64;      // 64 bit signed
//typedef unsigned long      wis_u64;     // 64 bit unsigned

#endif // WISDATATYPEDEF_H

