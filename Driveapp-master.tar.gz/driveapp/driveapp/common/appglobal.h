﻿#ifndef APPGLOBAL_H
#define APPGLOBAL_H

#include "wisdatatypedef.h"
#include "datastructdef.h"

//#ifndef WIS_UI_DEBUG
//#define WIS_UI_DEBUG
//#endif

#define WIS_DATETIME_FORMAT "yyyy-MM-dd hh:mm:ss"
#define QT_BEGIN_NAMESPACE_WIS_UI namespace WIS_UI_ENUM {
#define QT_END_NAMESPACE_WIS_UI  }


QT_BEGIN_NAMESPACE_WIS_UI
enum WIdgetType{
    ENTER_REG_HINT_FORM,                     //hint enter reg form
    WELCOME_REG_HINT_FORM,              //welcome to reg form
    SETTING_MGR_FORM,                          //setting manager form
    NET_INITLINK_FORM,                          //input to link server
    REGISTER_INFO_INPUT_FORM,           //input register's info
    SWIPING_CARD_FORM,                      //swip card and wait register
    REG_SUCCESS_FORM,                         // reg succeed form
    REG_FAILED_FORM,                            //reg failed form

    //setting module
    SETTING_VOLUME_LIGHT_FORM,      //volume and light set
    SETTING_PARAM_FORM,                     //param set form
    SETTING_COMMUNCATE_FORM,        //communcation  param set form
    SETTING_NET_FORM,                           //net params set form
    SETTING_REPORT_FORM,                    //report params set form
    SETTING_VIEW_THRES_FORM,             //view and threshold set form
    SETTING_LISTEN_FORM,                      //listen param set form
    SETTING_OTHER_FORM,                     // other params set form
    SETTING_VIDEO_FORM,                    //video set form

    LOGOFF_HINT_FORM,                                    //log off form
    LOGOFF_FORM,
    LOGOFF_SUCCESS_FORM,

    //login module
    TRAIN_LOGIN_FORM,                           //train login form: display trainer and student status
    ADMIN_LOGIN_FORM,                         //admin login form
    COACH_LOGIN_INFO_FORM,              //show coach login info form
    LEARNER_LOGIN_INFO_FORM,            //show learner login info form
    COACH_LOGIN_SUCCESS_HINT_FORM,  //show coach login success hint form
    COACH_LOGIN_FAILED_HINT_FORM,       //show coach login failed hint form
    LEARNER_LOGIN_SUCCESS_HINT_FORM,    //show learner login success hint form
    LEARNER_LOGIN_FAILED_HINT_FORM,         //show learner login failed hint form
    TRAIN_LOGOUT_FORM,                              //train logout form
    REPORT_LEARN_REC_FORM,                      //report  learn rec form

    //display module
    TRAIN_DISPLAY_FORM,                             //train display form

    //pay module
    TRAIN_ACCOUNT_FORM                         //train account form
};

enum RegisterHintFormType{
    ENTER_REG_HINT_TYPE,
    NEXT_REG_HINT_TYPE
};

QT_END_NAMESPACE_WIS_UI



#endif // APPGLOBAL_H

