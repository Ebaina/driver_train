﻿#ifndef COMMONDATAMGR_H
#define COMMONDATAMGR_H

#include <QString>
class CommonDataMgr
{
public:
    CommonDataMgr();

    static QString getCardTypeValue(const unsigned char &key);

    static QString getLicenseColorValue(const unsigned char &key);

    static QString getCarTypeValue(const unsigned char &key);

    static QString getCoachStarImgSource(const unsigned char &key);

    static QString getTrainSubjectValue(const unsigned char &key);

    static QString getPostReportStrategyValue(const unsigned char &key);

    static QString getPostReportSchemeValue(const unsigned char &key);

    static QString getTerminalPhoneRecvWayValue(const unsigned char &key);
};

#endif // COMMONDATAMGR_H
