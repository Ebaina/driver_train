#ifndef TIMEUTIL_H
#define TIMEUTIL_H

#include <QString>

class TimeUtil
{
public:
    TimeUtil();
    ~TimeUtil();

    //default format mm:ss
    static QString  minutesNumToFormatStr(unsigned int minutes);
};

#endif // TIMEUTIL_H
