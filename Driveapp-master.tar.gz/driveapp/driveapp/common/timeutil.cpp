#include "timeutil.h"

TimeUtil::TimeUtil()
{

}

TimeUtil::~TimeUtil()
{

}

QString TimeUtil::minutesNumToFormatStr(unsigned int minutes)
{
    QString minStr = "";
    if(minutes == 0){
        minStr = QString("00:00");
    }else{
        int m = minutes / 60;
        int s = minutes % 60;
        minStr = QString::number(m, 10);
        minStr += ":";
        QString tmp = QString("00") + QString::number(s, 10);
        minStr += tmp.right(2);
    }

    return minStr;
}

