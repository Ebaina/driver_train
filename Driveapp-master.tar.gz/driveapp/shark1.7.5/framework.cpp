﻿#include"framework.h"
#include "ManagerExe.h"
#include "app_globl.h"
#include <string.h>
#include "Tracer.h"
#include "Utils.h"
#include "offlinesave.h"
#include  "rsa_op.h"
DeviceFramework::DeviceFramework()
{

}
void DeviceFramework::do_init_net(char *ip ,int n)
{
    appGateway.ini_net(ip,n);   //初始化网关
    m_CmdProcessTask.init_pipe(&appGateway);  //初始化命令处理 任务
}

void DeviceFramework::do_register(stRegInfo mInfo)//, WIS_UI::SettingInterface *settingHandler)//注册报文   0100
{
    IsAuthority = 0;
    stSendCmdPiPe m;
    p_CmdReg->int_cmd(phone_num);
    int sizeindex= p_CmdReg->format_cmd(&m);
    TRACE_INFO("bodysize:%d\n",sizeindex);
    memcpy( & (m.ts_content[sizeindex])  ,(char*)&mInfo,sizeof(mInfo));
    m.ts_bodyLength=sizeindex+sizeof(mInfo);
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,3,true);

}

void DeviceFramework::reg_ack(stRecvCmdPiPe  strevdata) //注册回复   8100
{
    p_CmdReg ->ack_cmd(&strevdata);
}

void DeviceFramework::do_unregister()                 //注销报文   0003
{
    stSendCmdPiPe m;
    p_CmdUnregister->int_cmd(phone_num);
    p_CmdUnregister->format_cmd(&m);
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,3,true);
}

void DeviceFramework::do_authority(shark_authority_up mInfo)   //终端鉴权   0102
{
    stSendCmdPiPe m;
    p_CmdAuthority->int_cmd(phone_num);
    int sizeindex= p_CmdAuthority->format_cmd(&m);
    TRACE_INFO("bodysize:%d\n",sizeindex);
    memcpy( & (m.ts_content[sizeindex])  ,(char*)&mInfo,sizeof(mInfo));
    TRACE_INFO("struct shark_authority_up :%d\n",sizeof(mInfo));
    m.ts_bodyLength=sizeindex+sizeof(mInfo);
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,true);
}

void DeviceFramework::do_Send_SaveSata()
{
    vector<stSendCmdPiPe*>  data;
    OfflineSave::getInstance()->selectMessageBySendStatus(0,data );
    TRACE_CYAN("数据大小：%d\n", data.size());
    for(vector<stSendCmdPiPe*>::iterator iter=data.begin();iter!=data.end();iter++)
    {
        stSendCmdPiPe  *stSend=new stSendCmdPiPe ;
        stSend=*iter;
        TRACE_CYAN("数据发送：%d\n", stSend->ts_cmd);
        //    m_CmdProcessTask.Send_OneCmd(stSend,1,true);
    }
}



void DeviceFramework:: do_beatheart()                //客户端心跳信息  0002
{
    stSendCmdPiPe m;
    p_CmdBeat->int_cmd(phone_num);
    p_CmdBeat->format_cmd(&m);
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,true);   //测试时写为false  不需要回复  |  否则写true  需要回复
}

void DeviceFramework::do_requestpakageagain(stRecvCmdPiPe  strevdata)   //补传分包请求 8003
{
    p_exerequestpackageagain->ack_cmd(&strevdata);
}

void DeviceFramework::do_common_response(common_Info mInfo)     //终端通用回复  0001
{
    stSendCmdPiPe m;
    p_down_common->int_cmd(phone_num);
    int sizeindex= p_down_common->format_cmd(&m);
    TRACE_INFO("bodysize:%d\n",sizeindex);
    memcpy( & (m.ts_content[sizeindex])  ,(char*)&mInfo,sizeof(mInfo));
    m.ts_bodyLength=sizeindex+sizeof(mInfo);
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework::do_common_response_ack(stRecvCmdPiPe  strevdata)   //平台通用回复  8001
{
    p_down_common->ack_cmd(&strevdata);
}

void DeviceFramework:: do_set_terminaldata(stRecvCmdPiPe  strevdata)             //设置终端参数    8103
{
    TRACE_INFO("参数设置\n");
    p_exesetterminaldata->ack_cmd(&strevdata);
}

void DeviceFramework:: do_search_terminaldata_ack(stRecvCmdPiPe  strevdata)       //查询终端参数    8104
{
    p_exeSearchTerminalData->ack_cmd(&strevdata);
}

void DeviceFramework:: do_search_select_terminaldata_ack(stRecvCmdPiPe  strevdata)     //查询指定终端参数   8106
{
    p_exesearchselectterminaldata->ack_cmd(&strevdata);
}

void DeviceFramework:: do_search_select_terminaldata(SearchTerminalParamAck mInfo, int count ,int index,char *ackbuf,int buf_len)    //查询终端参数应答  0104
{
    stSendCmdPiPe m;
    p_exeSearchTerminalData->int_cmd(phone_num);
    int sizeindex= p_exeSearchTerminalData->format_cmd(&m);
    if(count>0){
        m.encodeflag=true;
        m.packgeindex=index;
        m.  mainpackgesize=count;
        switch(index)
        {
        case 1:

            memcpy( & (m.ts_content[sizeindex])  ,(char*)&mInfo,sizeof(mInfo));
            sizeindex = sizeindex+sizeof(mInfo);
            memcpy( & (m.ts_content[sizeindex]) ,ackbuf,buf_len);
            m.ts_bodyLength=sizeindex+buf_len;
            break;
        default:
            memcpy( & (m.ts_content[sizeindex]) ,ackbuf,buf_len);
            m.ts_bodyLength=sizeindex+buf_len;
            break;
        }
    }
    else{
        m.encodeflag=false;
        memcpy( & (m.ts_content[sizeindex])  ,(char*)&mInfo,sizeof(mInfo));
        sizeindex = sizeindex+sizeof(mInfo);
        memcpy( & (m.ts_content[sizeindex]) ,ackbuf,buf_len);
        m.ts_bodyLength=sizeindex+buf_len;
    }
    //m.is_photo = false;
    m_CmdProcessTask.Send_OneCmd(m,1,false);
}

void DeviceFramework:: do_report_position(PositionReport_up mInfo)           //位置信息汇报  0200
{
    stSendCmdPiPe m;
    p_CmdPositionReport->int_cmd(phone_num);
    int sizeindex= p_CmdPositionReport->format_cmd(&m);
    memcpy(& (m.ts_content[sizeindex])  ,(char*)&mInfo,sizeof(mInfo));
    char  data[10]={0};
    data[0]=0x05;
    data[1]=0x02;
    data[2]=0x00;
    data[3]=0x00;
    data[4]=0x01;
    data[5]=0x04;
    data[6]=0x00;
    data[7]=0x00;
    data[8]=0x00;
    data[9]=0x00;
    memcpy(&(m.ts_content[sizeindex+sizeof(mInfo)]),data  ,10);
    m.ts_bodyLength=sizeindex+sizeof(mInfo)+10;
    m.ts_isoffline=false;  //05020000  010400000000
    m_CmdProcessTask.Send_OneCmd(m,3,true);
}

void DeviceFramework:: do_terminal_control(stRecvCmdPiPe  strevdata)      //终端控制  8105
{
    p_exeterminaldatacontrol->ack_cmd(&strevdata);
}

void DeviceFramework:: do_search_position_ack(stRecvCmdPiPe  strevdata)    //位置信息查询  8201
{
    p_exesearchpositionreport->ack_cmd(&strevdata);
}

void DeviceFramework:: do_search_position(PositionSearch mInfo)    //位置信息查询应答  0201
{
    stSendCmdPiPe m;
    p_exesearchpositionreport->int_cmd(phone_num);
    int sizeindex= p_exesearchpositionreport->format_cmd(&m);
    memcpy( & (m.ts_content[sizeindex]),(char*)&mInfo,sizeof(mInfo));
    m.ts_bodyLength=sizeindex+sizeof(mInfo);
    m.ts_isoffline=false;
    m_CmdProcessTask.Send_OneCmd(m,1,false);
}

void DeviceFramework:: do_track_temp_position(stRecvCmdPiPe  strevdata)//临时位置跟踪控制  8202
{
    p_CmdPositionReport->ack_cmd(&strevdata);
}


void DeviceFramework:: SetPhotoSize(int datasize){
    this->PhotoSizeData=datasize;
}
int DeviceFramework::getPhotoSize(){
    return this->PhotoSizeData;
}


//transferid : 透传ID
//extraproperty: 扩展属性
//contentdata:数据内容
void DeviceFramework:: do_transmit_transparently_down(stRecvCmdPiPe  strevdata)   //数据下行透传  8900
{
    p_exedatapass ->ack_cmd(&strevdata);
}

int Drvernum = 0x0001;//临时调试
int DeviceFramework:: do_transmit_transparently_packge(wis_u16 transferid,wis_u16 extraproperty,void *contentdata,wis_u32 len,wis_u8 *output)        //数据上行透传  0900
{
    Datapassup dataup;
    int len0=sizeof  (dataup.datatype);
    int len1=sizeof  (dataup.messdata.messageid);//0：透传消息ID       透传消息ID为功能编号+消息编号
    int len2=sizeof  (dataup.messdata.extandmessagetype);  //扩展消息属性bit0表示消息时效类型，应答中也应附带此内容，0：实时消息，1：补传消息；
    //bit1表示应答属性，0：不需要应答，1：需要应答；
    //  bit4-7表示加密算法，0：未加密，1：SHA1，2：SHA256
    int len3=sizeof (dataup.messdata. drivingpackgenum);  //驾培包序号           扩展驾培协议包序号，从1开始，除协议中特别声明外，循环递增
    int len4=16;                   //sizeof  (terminalid[16]);         //计时终端编号
    int len5=sizeof  (dataup.messdata.datalength) ;              //数据长度
    // int len7=256;              //sizeof  (checkcode[256]);     //校验串
    if(transferid!=(0xFFFF))
    {
        dataup.datatype = 0x13;
        dataup.messdata.messageid =htons(transferid) ;
        //        dataup.messdata.extandmessagetype = htons(extraproperty);
        dataup.messdata.extandmessagetype = htons(0x0020);
        dataup.messdata.drivingpackgenum =htons(Drvernum++) ;
        memcpy(&dataup.messdata.terminalid[0],(char *)Device_Num.c_str(),Device_Num.size());
        if (transferid==CMD_T2P_UPLOADPHOTODATA_UP){
            dataup.messdata.datalength =  this->getPhotoSize();  //htonl(len);
        }else{
            dataup.messdata.datalength = htonl(len);
        }
        memcpy( &dataup.messdata.data[0],(char *)contentdata,len);
        memcpy(&output[0],(char *)&dataup.datatype,len0);
        memcpy(&output[len0],(char *)&dataup.messdata.messageid,len1);
        memcpy(&output[len0+len1],(char *)&dataup.messdata.extandmessagetype,len2);
        memcpy(&output[len0+len1+len2],(char *)&dataup.messdata.drivingpackgenum,len3);
        memcpy(&output[len0+len1+len2+len3],(char *)&dataup.messdata.terminalid,len4);
        memcpy(&output[len0+len1+len2+len3+len4],(char *)&dataup.messdata.datalength,len5);
        memcpy(&output[len0+len1+len2+len3+len4+len5],(char *)&dataup.messdata.data,len);
        int encodeinlen=len0+len1+len2+len3+len4+len5+len;
        if (transferid != CMD_T2P_UPLOADPHOTODATA_UP)
        {
//            TRACE_IF("\nEncodeRSAKeyFile before\n");
//            Tracer::getInstance()->printHex(1,"原始数据",(char *)&output[0],encodeinlen);
            RsaOperater::getInstance()->EncodeRSAKeyFileChar("/user/prikey.pem",(char *)&output[1],encodeinlen-1,(char *)&dataup.messdata.checkcode[0]);
//            TRACE_IF("\nEncodeRSAKeyFile end\n");
            memcpy(&output[encodeinlen],(char *)&dataup.messdata.checkcode[0],256);
            return (len0+len1+len2+len3+len4+len5+len+256);   //+len7
        }
        else
        {
            return (len0+len1+len2+len3+len4+len5+len);   //+len7
        }
    }
    else
    {
        memcpy(&output[0],(char *)contentdata,len);
        return (len);   //+len6
    }
}
int DeviceFramework:: do_transmit_photo_packge(  wis_u16 transferid ,char  *contentdata,wis_u32 len,wis_u8 *output)        //数据上行透传  0900
{
    Datapassup dataup;
    memset(&dataup,0,sizeof(dataup));
    int len0=sizeof  (dataup.datatype);
    int len1=sizeof  (dataup.messdata.messageid);//0：透传消息ID       透传消息ID为功能编号+消息编号
    int len2=sizeof  (dataup.messdata.extandmessagetype);  //扩展消息属性bit0表示消息时效类型，应答中也应附带此内容，0：实时消息，1：补传消息；
    //bit1表示应答属性，0：不需要应答，1：需要应答；
    //  bit4-7表示加密算法，0：未加密，1：SHA1，2：SHA256
    int len3=sizeof (dataup.messdata. drivingpackgenum);  //驾培包序号           扩展驾培协议包序号，从1开始，除协议中特别声明外，循环递增
    int len4=16;//sizeof  (terminalid[16]);         //计时终端编号
    int len5=sizeof  (dataup.messdata.datalength) ;              //数据长度
    {

        dataup.datatype = 0x13;
        dataup.messdata.messageid =htons(transferid) ;
        dataup.messdata.extandmessagetype = htons(0x0020);
        dataup.messdata.drivingpackgenum =htons(Drvernum++) ;//Drvernum++
        memcpy(&dataup.messdata.terminalid[0],(char *)Device_Num.c_str(),Device_Num.size());
        int encodeinlen=len0+len1+len2+len3+len4+len5+len;
        dataup.messdata.datalength = htonl( len);
        char * outdata=new char[len0+len1+len2+len3+len4+len5+len];
        memset(outdata,0x00,len0+len1+len2+len3+len4+len5+len);
        memcpy(&outdata[0],(char *)&dataup.datatype,len0);
        memcpy(&outdata[len0],(char *)&dataup.messdata.messageid,len1);
        memcpy(&outdata[len0+len1],(char *)&dataup.messdata.extandmessagetype,len2);
        memcpy(&outdata[len0+len1+len2],(char *)&dataup.messdata.drivingpackgenum,len3);
        memcpy(&outdata[len0+len1+len2+len3],(char *)&dataup.messdata.terminalid,len4);
        memcpy(&outdata[len0+len1+len2+len3+len4],(char *)&dataup.messdata.datalength,len5);
        memcpy(&outdata[len0+len1+len2+len3+len4+len5],(char *)contentdata,len);

        memcpy(&output[0],(char *)outdata,encodeinlen);

        //        Tracer::getInstance()->printHex(1,"encod1",(char *)&output[0],len0+len1+len2+len3+len4+len5);
        RsaOperater::getInstance()->EncodeRSAKeyFileChar("/user/prikey.pem",(char *)&outdata[1],encodeinlen-1,(char *)&dataup.messdata.checkcode[0]);
        //        Tracer::getInstance()->printHex(1,"加密",(char *)&dataup.messdata.checkcode[0],256);

        memcpy(&output[encodeinlen],(char *)&dataup.messdata.checkcode[0],256);
        delete[] outdata;
        return (len0+len1+len2+len3+len4+len5+len+256);   //+len7
    }

}

/*扩展消息类型   消息类型同为0x13  驾培*/
void DeviceFramework:: do_coachlogin(CoachLogin_Up mInfo)                      //教练登陆  0101
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeCoachLogin->int_cmd(phone_num);
    int sizeindex= p_exeCoachLogin->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);

    int  lenth= do_transmit_transparently_packge(CMD_T2P_COACHLOGIN,0x0000,buffout,len,bufftemp);

    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;

    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,3,true);
}

void DeviceFramework:: do_coachlogin_ack(stRecvCmdPiPe  strevdata)  //教练登入应答  8101
{
    p_exeCoachLogin->ack_cmd(&strevdata);
}

void DeviceFramework::ClearSendPipe(stSendCmdPiPe &m)
{
    delete[]  m.ts_content;
}

void DeviceFramework:: do_coachlogout(CoachLogout_Up mInfo)                        //教练登出   0102
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeCoachLogout->int_cmd(phone_num);
    int sizeindex= p_exeCoachLogout->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_COACHLOGOUT,0x0000,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;
    m_CmdProcessTask.Send_OneCmd(m,3,true);

}
void DeviceFramework:: do_coachlogout_ack(stRecvCmdPiPe  strevdata)  //教练登出应答  8102
{
    p_exeCoachLogout->ack_cmd(&strevdata);
}

void DeviceFramework:: do_learnerlogin(LearnerLogin_Up mInfo)           //学员登陆   0201
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeLearnerLogin->int_cmd(phone_num);
    int sizeindex= p_exeLearnerLogin->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);

    int  lenth= do_transmit_transparently_packge(CMD_T2P_LERNERLOGIN,0x0000,buffout,len,bufftemp);

    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;
    m_CmdProcessTask.Send_OneCmd(m,3,true);
}
void DeviceFramework:: do_learnerlogin_ack(stRecvCmdPiPe  strevdata)  //学员登录应答  8201
{
    p_exeLearnerLogin->ack_cmd(&strevdata);
}

void DeviceFramework:: do_learnerlogout(LearnerLogout_Up mInfo)                     //学员登出    0202
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeLearnerLogout->int_cmd(phone_num);
    int sizeindex= p_exeLearnerLogout->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_LERNERLOGOUT,0x0000,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,3,true);
}

void DeviceFramework:: do_learnerlogout_ack(stRecvCmdPiPe  strevdata)  //学员登出应答  8202
{
    p_exeLearnerLogout->ack_cmd(&strevdata);
}
void DeviceFramework:: do_reportrain_record(ReportLearnMessage_Up mInfo)              //上报学时记录  0203
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeReportTrainRecord->int_cmd(phone_num);
    int sizeindex= p_exeReportTrainRecord->format_cmd(&m);
    len = sizeof(mInfo);
    TRACE_INFO_CLASS("学时记录长度: %d\n",len);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_REPORTTRAINRECORD,0x0000,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;
    m_CmdProcessTask.Send_OneCmd(m,3,true);
}

void DeviceFramework:: do_ask_reportrain_record(AskReportLearnMessage_Up mInfo)        //命令上报学时记录应答   0205
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeAskReportTrainRecord->int_cmd(phone_num);
    int sizeindex= p_exeAskReportTrainRecord->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_ASK_REPORTTRAINRECORD_UP,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    //m.is_photo = false;
    m.ts_isoffline=false;
    m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework:: do_ask_reportrain_record_ack(stRecvCmdPiPe  strevdata)    //命令上报学时记录  8205
{
    p_exeAskReportTrainRecord->ack_cmd(&strevdata);
}

void DeviceFramework:: do_takephoto_now(Asktakephotonow_Up mInfo )              //立即拍照应答    0301
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeAsktakephotonow->int_cmd(phone_num);
    int sizeindex= p_exeAsktakephotonow->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_ASKTAKEPHOTONOW_UP,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework:: do_takephoto_now_ack(stRecvCmdPiPe  strevdata)         //立即拍照   8301
{
    p_exeAsktakephotonow->ack_cmd(&strevdata);
}

void DeviceFramework:: do_searchphoto(Searchphoto_Up mInfo)                    //查询照片应答      0302
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeSearchphoto->int_cmd(phone_num);
    int sizeindex= p_exeSearchphoto->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_SEARCHPHOTO_UP,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}

void DeviceFramework:: do_searchphoto_ack(stRecvCmdPiPe  strevdata)    //查询照片   8302
{
    p_exeSearchphoto->ack_cmd(&strevdata);
}

void DeviceFramework:: do_upload_searchphoto_result(Searchphotoresult_UP &mInfo,char *  photonums,int lenth2)       //上报查询照片结果应答   0303
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeSearchphotoresult->int_cmd(phone_num);
    int sizeindex= p_exeSearchphotoresult->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    memcpy(&buffout[len], photonums ,lenth2);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_SEARCHPHOTORESULT_UP,0x0002,buffout,len+lenth2,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}

void DeviceFramework:: do_upload_searchphoto_result_ack(stRecvCmdPiPe  strevdata)   //上报查询照片结果   8303
{
    p_exeSearchphotoresult->ack_cmd(&strevdata);
}

void DeviceFramework:: do_upload_selectphoto(Uploadselectphoto_Up mInfo)            //上传指定照片应答  0304
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeUploadselectphoto->int_cmd(phone_num);
    int sizeindex= p_exeUploadselectphoto->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_UPLOADSELECTPHOTO_UP,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework:: do_upload_selectphoto_ack(stRecvCmdPiPe  strevdata)  //上传指定照片  8304
{
    p_exeUploadselectphoto->ack_cmd(&strevdata);
}

void DeviceFramework:: do_upload_photo_init(Uploadphotoinit_Up mInfo)       //上报照片初始化应答     0305
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeUploadphotoinit->int_cmd(phone_num);
    int sizeindex= p_exeUploadphotoinit->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_UPLOADPHOTOINIT_UP,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,true);
}
void DeviceFramework:: do_upload_photo_init_ack(stRecvCmdPiPe  strevdata)      //上报照片初始化  8305
{
    p_exeUploadphotoinit->ack_cmd(&strevdata);
}

void DeviceFramework:: do_upload_photo_data(Uploadphotodata_Up mInfo,int  datasize,int  photosize,bool  multyflag,unsigned short  packegesize,unsigned short  index)        //上报照片数据    0306
{
    stSendCmdPiPe m;
    wis_u32 len = 0;//int  lenth;
    p_exeUploadphotodata->int_cmd(phone_num);
    int sizeindex= p_exeUploadphotodata->format_cmd(&m);
    len=datasize;

    if(index==1){
        memcpy( & (m.ts_content[sizeindex+4]),(unsigned char*)&mInfo.photo[0],len);//序号和包数4
    }else{
        memcpy( & (m.ts_content[sizeindex+4]),(unsigned char*)&mInfo.photo[0],len);//序号和包数4
    }
    m.ts_bodyLength=sizeindex+len+4;
    m.multyflag=multyflag;
    m.packgeindex=index;
    m.mainpackgesize=packegesize;
    m_CmdProcessTask.Send_OneCmd(m,1,true);
}

void DeviceFramework:: do_set_terminal_app_data(Setterminalappdata_Up mInfo)    //设置计时终端应用参数应答    0501
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeSetterminalappdata->int_cmd(phone_num);
    int sizeindex= p_exeSetterminalappdata->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_SETTERMINALAPPDATA_UP,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}




int DeviceFramework:: GetPhotodata(std::string photonum,std::string path,char *photodata ,int datasize )    //path 照片路径
{
    FILE * fp;
    const char *path_1=( const char * )path.c_str();
    if((fp=fopen(path_1,"r"))==NULL)
    {
        TRACE_INFO("cant open the file");
        return 0;
    }
    else
    {
#if 1
        fseek( fp , 0 , SEEK_END );
        int file_size, byteReads = 0;
        file_size = ftell( fp );
        if(file_size > datasize) {
            TRACE_INFO("file too big");
            fclose(fp);
            return 0;
        }
        fseek( fp , 0 , SEEK_SET);
        do {
            int retBytes = fread(photodata+byteReads,sizeof(char),1024,fp);
            if(retBytes >0)
            {
                byteReads += retBytes;
            }
            else
            {
                break;
            }
        }while(1);

        if(byteReads != file_size ) {
            TRACE_INFO("read file error\n");
            fclose(fp);
            return 0;
        }
        fclose(fp);
        return byteReads;
#else
        fseek( fp , 0 , SEEK_END );
        int file_size;
        file_size = ftell( fp );
        char *tmp11 = new char[file_size];
        fseek( fp , 0 , SEEK_SET);
        fread( tmp11 , file_size , sizeof(char) , fp);
        TRACE_INFO( "大小1：%d\n" , file_size );
        memcpy(&photodata[0],(char *)&tmp11[0],file_size);
        datasize=file_size;
        delete[]  tmp11;
        fclose(fp);
        return datasize;
#endif
    }
}

void DeviceFramework:: MultPacge_Tools(std::string  photonum,char * photodata,int length){
    char* output1=new char [length+photonum.size()];
    memset(output1,0x00,length+photonum.size());
    memcpy(&output1[0],(char *)photonum.c_str(),photonum.size());
    memcpy(&output1[photonum.size()],(char *)photodata,length);
    unsigned char* output2=new unsigned char [length+256+100];
    memset(output2,0x00,length+256+100);
    //    TRACE_ERR_CLASS("上传1\n" );
    int lenindex=700;
    this->SetPhotoSize(length+10);

    int getsize=  this-> do_transmit_photo_packge  (  CMD_T2P_UPLOADPHOTODATA_UP ,output1,length+photonum.size(), output2);
    int pacagesize;
    //     TRACE_ERR_CLASS("上传4 \n"  );
    if(getsize%lenindex==0)
    {
        pacagesize=(getsize/lenindex);
    }
    else
    {
        pacagesize=(getsize/lenindex)+1;
    }
    //   TRACE_ERR_CLASS("上传5\n"  );
//     TRACE_ERR("\npacagesize:%d\n", pacagesize );
    if(getsize>lenindex){
        for(int  index=0;index<(pacagesize);index++)
        {
            //            TRACE_ERR_CLASS("上传4:%d\n",index );
            if(index==(pacagesize-1)){
                Uploadphotodata_Up mInfo;
                if(getsize%lenindex==0)
                {
                    memcpy(&mInfo.photo[0],(char *)&output2[index*lenindex], lenindex);
                    do_upload_photo_data(  mInfo,( lenindex),length,true,pacagesize,index+1);
                }
                else
                {
                      memcpy(&mInfo.photo[0],(char *)&output2[index*lenindex],getsize%lenindex);
                      do_upload_photo_data(  mInfo,(getsize%lenindex),length,true,pacagesize,index+1);
                }
                usleep(200000);
            }else{
                Uploadphotodata_Up mInfo1;
                memcpy(&mInfo1.photo[0],(char *)&output2[index*lenindex], lenindex);
                do_upload_photo_data(  mInfo1,(lenindex),length,true,pacagesize,index+1);
                usleep(200000);
            }
        }
    }
    delete[] output1;
    delete[] output2;
}

void DeviceFramework:: do_set_terminal_app_data_ack(stRecvCmdPiPe  strevdata)  //设置计时终端应用参数  8501
{
    p_exeSetterminalappdata->ack_cmd(&strevdata);
}

void DeviceFramework:: do_set_forbidtrain_app(Setforbidtrain_Up mInfo)          //设置禁训状态应答    0502
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeSetforbidtrain->int_cmd(phone_num);
    int sizeindex= p_exeSetforbidtrain->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_SETFORBIDTRAIN_UP,0x0000,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework:: do_set_forbidtrain_app_ack(stRecvCmdPiPe  strevdata)     //设置禁训状态    8502
{
    p_exeSetforbidtrain->ack_cmd(&strevdata);
}


void DeviceFramework:: do_search_terminal_app_data(Searchterminalappdata_Up mInfo)             //查询计时终端应用参数应答   0503
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeSearchterminalappdata->int_cmd(phone_num);
    int sizeindex= p_exeSearchterminalappdata->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_SEARCHTERMINALAPPDATA_UP,0x0000,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework:: do_search_terminal_app_data_ack(stRecvCmdPiPe  strevdata)   //查询计时终端应用参数   8503
{
    p_exeSearchterminalappdata->ack_cmd(&strevdata);
}

void DeviceFramework:: do_ask_identity_check(Identitycheckdata_Up mInfo)     //身份请求认证信息   0401
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeAskIdentityCheck->int_cmd(phone_num);
    int sizeindex= p_exeAskIdentityCheck->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_IDENTITYCHECKDATA,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}
void DeviceFramework:: do_ask_identity_check_ack(stRecvCmdPiPe  strevdata)        //身份请求认证信息应答   8401
{
    p_exeAskIdentityCheck->ack_cmd(&strevdata);
}

void DeviceFramework:: do_ask_unifynum(Asknifynum_Up mInfo)                         //请求统一编号信息   0402
{
    stSendCmdPiPe m;
    wis_u8   bufftemp[512];
    wis_u32 len = 0;
    wis_u8  buffout[512];
    p_exeAskunifynum->int_cmd(phone_num);
    int sizeindex= p_exeAskunifynum->format_cmd(&m);
    len = sizeof(mInfo);
    memcpy(&buffout[0],(char *)&mInfo,len);
    int  lenth= do_transmit_transparently_packge(CMD_T2P_ASKNIFYNUM,0x0002,buffout,len,bufftemp);
    memcpy( & (m.ts_content[sizeindex]),(unsigned char*)&bufftemp,lenth);
    m.ts_bodyLength=sizeindex+lenth;
    //m.is_photo = false;
    m.ts_isoffline=false;   m_CmdProcessTask.Send_OneCmd(m,1,false);
}

void DeviceFramework:: do_ask_unifynum_ack(stRecvCmdPiPe  strevdata)   //请求统一编号信息应答   8402
{
    p_exeAskunifynum->ack_cmd(&strevdata);
}


void DeviceFramework::do_init_cmd()
{
    /*下传部分*/
    p_exesetterminaldata = new exeSetTerminalData(&appGateway);   //参数设置
    save_exe(p_exesetterminaldata);

    p_exerequestpackageagain = new exerequestpackageagain(&appGateway) ;  //补传分包请求
    save_exe(p_exerequestpackageagain);

    p_exeterminaldatacontrol = new exeTerminalDataControl(&appGateway); //终端控制
    save_exe(p_exeterminaldatacontrol);

    p_exesearchselectterminaldata = new exeSearchSelectTerminalData(&appGateway); //查询终端指定参数
    save_exe(p_exesearchselectterminaldata);

    /*上传部分*/
    //1
    p_CmdBeat = new CmdBeatHeart(&appGateway);  //心跳信息
    save_exe(p_CmdBeat);

    //2
    p_down_common  = new Cmd_common(&appGateway);  //通用回复
    save_exe(p_down_common);

    //3
    p_CmdReg = new CmdReg(&appGateway);      //注册信息
    save_exe(p_CmdReg);

    //4
    p_CmdUnregister=new exeUnResister(&appGateway);    //注销信息
    save_exe(p_CmdUnregister);

    //5
    p_CmdAuthority=new  exeAuthority(&appGateway);   //终端鉴权
    save_exe(p_CmdAuthority);

    //6
    p_CmdPositionReport=new exePositionReport(&appGateway);   //位置信息上报
    save_exe(p_CmdPositionReport);

    //7
    p_exesearchpositionreport = new exeSearchPosition(&appGateway);  //位置信息查询
    save_exe(p_exesearchpositionreport);

    //8
    p_exeSearchTerminalData=new exeSearchTerminalData(&appGateway);   //查询终端参数
    save_exe(p_exeSearchTerminalData);

    //9
    p_exedatapass = new exeDatapass(&appGateway);   //数据透传
    save_exe(p_exedatapass);

    //10
    p_exeCoachLogin=new  exeCoachLogin(&appGateway);   //教练登录
    save_exe(p_exeCoachLogin);

    //11
    p_exeCoachLogout=new  exeCoachLogout(&appGateway);   //教练登出
    save_exe(p_exeCoachLogout);

    //12
    p_exeLearnerLogin = new exeLearnerLogin(&appGateway);  //学员登入
    save_exe(p_exeLearnerLogin);

    //13
    p_exeLearnerLogout = new exeLearnerLogout(&appGateway);  //学员登出
    save_exe(p_exeLearnerLogout);

    //14
    p_exeReportTrainRecord = new exeReportTrainRecord(&appGateway); //上报学时记录
    save_exe(p_exeReportTrainRecord);

    //15
    p_exeAskReportTrainRecord = new exeAskReportTrainRecord(&appGateway);  //命令上报学时记录
    save_exe(p_exeAskReportTrainRecord);

    //16
    p_exeAsktakephotonow = new exeAsktakephotonow(&appGateway);   //立即拍照应答
    save_exe(p_exeAsktakephotonow);

    //17
    p_exeSearchphoto = new exeSearchphoto(&appGateway);   //查询照片应答
    save_exe(p_exeSearchphoto);

    //18
    p_exeSearchphotoresult = new exeSearchphotoresult(&appGateway);  //上报查询照片结果应答
    save_exe(p_exeSearchphotoresult);

    //19
    p_exeUploadselectphoto = new exeUploadselectphoto(&appGateway);  //上传指定照片应答
    save_exe(p_exeUploadselectphoto);

    //20
    p_exeUploadphotoinit = new exeUploadphotoinit(&appGateway); //上报照片初始化应答
    save_exe(p_exeUploadphotoinit);

    //21
    p_exeUploadphotodata = new exeUploadphotodata(&appGateway);  //上报照片数据
    save_exe(p_exeUploadphotodata);

    //22
    p_exeSetterminalappdata = new exeSetterminalappdata(&appGateway);  //设置计时终端应用参数应答
    save_exe(p_exeSetterminalappdata);

    //23
    p_exeSetforbidtrain = new exeSetforbidtrain(&appGateway); //设置禁训状态应答
    save_exe(p_exeSetforbidtrain);

    //24
    p_exeSearchterminalappdata = new exeSearchterminalappdata(&appGateway);  //查询计时终端应用参数应答
    save_exe(p_exeSearchterminalappdata);

    //25
    p_exeAskIdentityCheck = new exeAskIdentityCheck(&appGateway);  //身份请求认证信息
    save_exe( p_exeAskIdentityCheck);

    //26
    p_exeAskunifynum = new exeAskunifynum(&appGateway);  //请求统一编号信息
    save_exe(p_exeAskunifynum);
}
