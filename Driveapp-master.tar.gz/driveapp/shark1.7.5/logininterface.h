﻿#ifndef LOGININTERFACE_H
#define LOGININTERFACE_H
#include "ui_structs.h"
namespace WIS_UI{

class LoginInterface
{
public:
    explicit LoginInterface() {}
   ~ LoginInterface(){}

    /**
  *@brief    callback coach login ack
  *@param [in]      loginState
  *                           1:登录成功
  *                           0:登录失败
  */
    virtual void updateCoachLoginAckState(unsigned char loginState) = 0;

    /**
  *@brief callback   coach logout ack
  * @param [in]  logoutState
  *                         1:登出成功
  *                         0:登出失败
  */
    virtual void updateCoachLogoutAckState(unsigned char logoutState) = 0;


    /**
  *@brief  callback learner login ack
  *@param [in]      loginState
  *                           1:登录成功
  *                           0:登录失败
  */
    virtual void updateLearnerLoginAckState(unsigned char loginState) = 0;

    /**
  *@brief   call back learner logout ack
  * @param [in]  logoutState
  *                         1:登出成功
  *                         0:登出失败
  */
    virtual void updateLearnerLogoutAckState(unsigned char logoutState) = 0;

    //教练登陆信息
    virtual void coachLogin(UI_CoachLogin_Up coachLogin_Up) = 0;

    //学员登陆信息
    virtual void learnerLogin(UI_LearnerLogin_Up learnerLogin_Up ) = 0;

    virtual void learnerUpdateInfo(UI_Learner_Info learner_Info ) = 0;

    virtual void updateNetAckState(unsigned char status ) = 0;

    virtual void updateIdentifyAckState(unsigned char status) = 0;

    //参数是枚举类型 FingerprintAckStatus
    virtual void learnerFingerprintAck(unsigned char status , UI_Learner_Info learnerInfo) = 0;

    //参数是枚举类型 FingerprintAckStatus
    virtual void coachFingerprintAck(unsigned char status ) = 0;//

    //教练或学员登出   LogoutType
     virtual void logoutAck(unsigned char state) = 0;

};

}
#endif // LOGININTERFACE_H

