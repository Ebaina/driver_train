﻿#ifndef APP_GLOBL
#define APP_GLOBL
#include  "framework.h"
#include  <string.h>
#include <stdio.h>
#include <stdlib.h>
#include  "Event.h"
#include  "Thread.h"
#include  "execoach.h"
#include  "exelearner.h"
#include  "exeidentitycheck.h"
#include  "exephototake.h"
#include  "exephotoupload.h"
#include  "exepositionreport.h"
#include  "exeReg.h"
#include  "exeUnresister.h"
#include  "exesetterminaldata.h"
#include  "cmd_pipe.h"
#include  "cmdbeatheart.h"
#include  "gateway.h"
#include  "common_response_ack.h"
#include  "Event.h"
#include  "Thread.h"
#include  "exeAuthority.h"
#include  "main_event_manager.h"
#include  "public.h"
#include  "tts.h"
#include  "ManagerExe.h"
#include  "dictionary.h"
#include  "iniparser.h"
#include  "ui_structs.h"
#include  "fingerprint.h"
#include "minmea.h"
#include "src/module/snap/snap.h"
#include "src/module/dial/dial.h"
#include "src/module/dial/dial.h"
#include "pwm.h"
#include "Tracer.h"
#include "photodb.h"
#include "checkvideo.h"
#include "stm32_card.h"
#include "verupdate.h"
#include "udputils.h"
#define MAX_SNAP_NUM 100
extern int  MainRpm ;
extern int  MainSpeed ;
class DeviceFramework;
extern DeviceFramework  appcon;
extern sp_gateway appGateway;
extern CmdPP m_CmdProcessTask;
extern stRegInfo sreginfo;
extern CoachLogin_Up coachup_info;
extern LearnerLogin_Up learnerup_info;
extern LearnerLogin_down learner_login_info;
extern CommunicateMainSet commu_info;
extern NetMainSet net_info;
extern ReportMainSet report_info;
extern ListenMainSet  monitor_info;
extern ViewthresholdMainSet  videolisten_info;
extern OtherMainSet other_info;
extern CommandParam terminal_control_para_info;
extern UpdatePara updateversion;
extern Searchterminalappdata_Up   appdata_setinfo;
extern stRegInfo_ack     regack_info;
extern Context4G    c4g_info;
extern  string  phone_num ;
extern  wis_u8 TerminalLoginStatus ;
//extern  minmea_sentence_gga gga_frame;
//extern  minmea_sentence_rmc rmc_frame;
extern  PositionReport_up positionReport_up;
extern st4gNetStatus netStatus;
extern photodb p_db;

extern int coachSuccess_flag;  //教练后台登入成功标志
extern int stuSuccess_flag;      //学员后台登入成功标志
extern int remaining_min;   //剩余学时
extern int takePhototime;
extern int  forbidenflag ;

extern int  RfcardReadFlag;    //打开读卡方式
extern int  RfcardlogoutFlag;  //登出的读卡方式

extern int  Isregister; //注册标志
extern int  Ispageflag; //页面标志
extern wis_u32  subjectcode; //课程码
extern pthread_t net_4g_tID1;

extern int  IsCoachLogin; //  教练登入标志
extern int  IsLearnerLogin; //学员登入标志

extern std:: string Keyencode;
extern std:: string Keyencode5004;
extern std:: string Keyencode5000;

extern int Uploadflag;//照片上传成功标志

extern int TrainRecordNum ;//学时记录编号

extern  unsigned char IsAuthority;//鉴全标志

extern stm32_info coachcardinfo;
extern stm32_info studentcardinfo;
extern stm32_info admincardinfo;
extern int StartTrainFlag;
extern int TrainLessonId;
extern int UpdateFlag ;

#define WIS_DATETIME_FORMAT_SHARK " MM-dd hh:mm:ss"
#define WIS_DATETIME_FORMAT_WHOLE " MM-dd hh:mm:ss"
extern int Mainlantitude;
extern int Mainlontitude;
extern unsigned short TrainCouts;
extern int  TcpLinkConnectFlag;//TCP 链路 标志

extern int Trainminutes;

extern std:: string  MainCoachPhotoPath;
extern std:: string  MainStudentPhotoPath;
extern int  IsMainCoachPhotoPathFlag;

extern int  IsMainStudentPhotoPathFlag;


extern  double MainGetDistance;//总里程
extern  int MainStartLat;//开始纬度
extern  int MainStartLong;//开始经度
extern  int MainEndLat;
extern  int MainEndLong;
extern std::string  http_port;
extern std::string  http_url;
extern std::string  subjectID;
extern  std::string  Device_Num;
extern int RealTimeVideoStatus();
#endif // APP_GLOBL

