﻿#include "main_event_manager.h"
#include "app_globl.h"
#include "Tracer.h"
#include "Utils.h"
#include "offlinesave.h"
#include "cmd_pipe.h"'"
 AckReciceEventListioner::AckReciceEventListioner(){}
 AckReciceEventListioner::~AckReciceEventListioner(){}
void AckReciceEventListioner::handleEvent( stRecvCmdPiPe  strrevCmdpip){
//     memset(strrevCmdpip.td_content,0x00,sizeof(strrevCmdpip.td_content));
//    int length= evt.getParam( strrevCmdpip.td_content, strrevCmdpip.td_bodyLength );
//    strrevCmdpip.td_bodyLength=length;
    int flowid=strrevCmdpip.td_content[13]<<8|strrevCmdpip.td_content[14];
    TRACE_INFO("\n消息ID：%04x=====流水号：%04x==\n",strrevCmdpip.td_cmd,flowid);
     switch(strrevCmdpip.td_cmd){
        case CMD_P2T_REGISTER:   //注册回复
        strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.reg_ack (strrevCmdpip);
        break;
    case CMD_P2T_COMMONDOWN_ACK:    //通用回复
        strrevCmdpip.td_seq=flowid;
        appcon.do_common_response_ack(strrevCmdpip);
        break;
    case CMD_P2T_SETTERMINALDATAACK:   //设置终端参数
          strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.do_set_terminaldata(strrevCmdpip);
        break;

    case CMD_P2T_SEARCHTERMINALDATA:   //查询终端参数
         strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.do_search_terminaldata_ack(strrevCmdpip);
        break;

    case CMD_P2T_SERACHSELECTTERMINALDATA:   //查询指定终端参数应答
        strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.do_search_select_terminaldata_ack(strrevCmdpip);
        break;

    case CMD_P2T_TERMINALCONTROL:   //终端控制
        strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.do_terminal_control(strrevCmdpip);
        break;

    case CMD_P2T_ASKPOSITION:   //位置信息查询
        strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.do_search_position_ack(strrevCmdpip);
        break;

    case CMD_P2T_TMPLOCATIONCONTROL:   //临时位置跟踪控制
        strrevCmdpip.td_isAck=true;//
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        appcon.do_track_temp_position(strrevCmdpip);
        break;

    case CMD_P2T_DATAPASSDOWN:   //数据下行透传
        strrevCmdpip.td_isAck=true;
        strrevCmdpip.td_ackEnable=false;
        strrevCmdpip.td_seq=flowid;
        int cmd = ((strrevCmdpip.td_content[17] & 0xff )<<8|(strrevCmdpip.td_content[18]) & 0xff) ;
        switch (cmd) {
        case CMD_P2T_COACHLOGIN:   //教练登陆应答
            appcon.do_coachlogin_ack(strrevCmdpip);
                m_CmdProcessTask.Remove_OneCmdFromSendList(strrevCmdpip);
            break;
        case CMD_P2T_COACHLOGOUT:   //教练登出应答
            appcon.do_coachlogout_ack(strrevCmdpip);
            m_CmdProcessTask.Remove_OneCmdFromSendList(strrevCmdpip);
            break;
        case CMD_P2T_LERNERLOGIN:   //学员登陆应答
            appcon.do_learnerlogin_ack(strrevCmdpip);
            m_CmdProcessTask.Remove_OneCmdFromSendList(strrevCmdpip);
                       break;
        case CMD_P2T_LERNERLOGOUT:   //学员登出应答
//            strrevCmdpip.td_cmd=0x8
//            OfflineSave::getInstance()-> deleteMessageByFlowid(CMD_T2P_LERNERLOGOUT_NEW,m_cmdlist[i].ts_seq );
            appcon.do_learnerlogout_ack(strrevCmdpip);
            m_CmdProcessTask.Remove_OneCmdFromSendList(strrevCmdpip);
            break;
        case CMD_P2T_ASK_REPORTTRAINRECORD_DOWN:   //命令上报学时记录
            appcon.do_ask_reportrain_record_ack(strrevCmdpip);
            m_CmdProcessTask.Remove_OneCmdFromSendList(strrevCmdpip);
            break;

        case CMD_P2T_ASKTAKEPHOTONOW_DWON:   //立即拍照
            appcon.do_takephoto_now_ack(strrevCmdpip);
            break;

        case CMD_P2T_ASKSEARCHPHOTO_DOWN:   //查询照片
            appcon.do_searchphoto_ack(strrevCmdpip);
            break;

        case CMD_P2T_SEARCHPHOTORESULT_DOWN:   //上报查询照片结果
            appcon.do_upload_searchphoto_result_ack(strrevCmdpip);
            break;

        case CMD_P2T_UPSELECTPHOTO_DOWN:   //上传指定照片
            appcon.do_upload_selectphoto_ack(strrevCmdpip);
            break;

        case CMD_P2T_UPLOADPHOTOINIT_DOWN:   //上报照片初始化
            appcon.do_upload_photo_init_ack(strrevCmdpip);
            break;

        case CMD_P2T_SETTERMINALAPPDATA_DOWN:   //设置终端应用参数
            appcon.do_set_terminal_app_data_ack(strrevCmdpip);
                m_CmdProcessTask.Remove_OneCmdFromSendList(strrevCmdpip);
            break;

        case CMD_P2T_SETFORBIDTRAIN_DOWN:   //设置禁训状态
            appcon.do_set_forbidtrain_app_ack(strrevCmdpip);
            break;

        case CMD_P2T_SEARCHTERMINALAPPDATA_DOWN:   //查询计时终端应用参数
            appcon.do_search_terminal_app_data_ack(strrevCmdpip);
            break;

        case CMD_P2T_IDENTITYCHECKDATA:   //身份请求认证信息应答
            appcon.do_ask_identity_check_ack(strrevCmdpip);
            break;

        case CMD_P2T_ASKUNIFYNUM:   //请求统一编号信息应答
            appcon.do_ask_unifynum_ack(strrevCmdpip);
            break;
        default:
            break;
        }
        break;

    }

}
