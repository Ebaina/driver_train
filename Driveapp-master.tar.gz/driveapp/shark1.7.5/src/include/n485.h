#ifndef N485_H
#define N485_H
#include "uart.h"
#include "public.h"
#include <semaphore.h>

class N485_UART : public CUART
{
public:
    N485_UART();
    ~N485_UART();
    /*
        函数说明: 获取系统时间
        参数说明:
               none
        返回值:
                 返回系统时间tick值，单位ms
    */
    bool N485_Open(tagUARTParam& param);
    void N485_Close();
    int N485_CmdSend(char *buf,int len_buf,char *outbuf,int len_out,int timeout);
private:
    sem_t  mLock;
    bool   m485Open;
};

#endif // TEST_H

