#ifndef UART_H_
#define UART_H_
#include <vector>
#include <string>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>


typedef std::string String;

enum FlowControl
{
    FLOW_CONTROL_HARD, FLOW_CONTROL_SOFT, FLOW_CONTROL_NONE,
};

struct tagUARTParam
{
    String dev;
    int baudRate;
    int dataBits;
    char parity;
    int stopBits;
    FlowControl flowControl;
};

class CUART
{
public:
	CUART();
	virtual ~CUART();

	bool open(tagUARTParam& param);
	int send(char* buf, int len, int timeout);
	int recv(char* buf, int len, int timeout);
	void close();

private:
	bool setBaudRate(int baudRate);
	bool setParity(int parity);
	bool setDataBits(int dataBits);
	bool setStopBits(int stopBits);
	bool setFlowControl(FlowControl flowControl);

private:
	/** Character used to signal that I/O can start while using
	 software flow control with the serial port.
	 */
	static const char CTRL_Q = 0x11;

	/** Character used to signal that I/O should stop while using
	 software flow control with the serial port.
	 */
	static const char CTRL_S = 0x13;

	int serialfd_;

};

#endif /* SERIALPORT_H_ */


