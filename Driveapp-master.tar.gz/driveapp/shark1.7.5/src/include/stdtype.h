/*--- HEADER FILE DESCRIPTOR --------------------------------------------------
Project : Realtime Micro Library
File    : stdtype.h
Author  : zjy
E-mail  : 
Data    : 2016.11.10
Version : V1.0 
Note    : 
-----------------------------------------------------------------------------*/

#ifndef __STDTYPE_H_
#define __STDTYPE_H_

 
/* boolean */
typedef  enum _BOOLEAN
{
	bFALSE = 0,
	bTRUE  = 1
}BOOLEAN;
typedef  BOOLEAN  wis_bool ;
 
//datatypechange
 typedef   unsigned char    wis_u8;
 typedef   char             wis_s8;
 typedef   unsigned short   wis_u16;
 typedef   short            wis_s16;
 typedef   unsigned int     wis_u32;
 typedef   int              wis_s32;
 typedef   unsigned long    wis_u64;
 typedef   long             wis_s64;         
 



#endif
