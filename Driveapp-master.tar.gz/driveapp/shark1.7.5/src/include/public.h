#ifndef _PUBLIC_H_
#define _PUBLIC_H_

#define LOG_PATH "/tmp/wis_log%d.txt"
/*
    函数说明: 获取系统时间
    参数说明:
           none
    返回值:
             返回系统时间tick值，单位ms
*/

unsigned long get_tick_count();


#endif // PUBLIC

