﻿#ifndef EXEDATAPASS_H
#define EXEDATAPASS_H
#include "stdtype.h"
#include "CmdBase.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/
# define CMD_P2T_DATAPASSDOWN 0x8900   //数据下行透传
# define CMD_T2P_DATAPASSUP        0x0900   //数据上行透传
/************************************
*B.3.2.3.21　数据上行透传
*透传信息ID: 0x0900
*起始字节	字段	数据类型	描述及要求
*0：透传消息类型；
*1：透传消息内容；  0x13为驾培业务
************************************************/
/***********************************************
*消息内容
************************************************/
typedef  struct messagedata {
wis_u16  messageid;//0：透传消息ID       透传消息ID为功能编号+消息编号
wis_u16  extandmessagetype;  //扩展消息属性bit0表示消息时效类型，应答中也应附带此内容，0：实时消息，1：补传消息；
                                                      //bit1表示应答属性，0：不需要应答，1：需要应答；
                                                     //  bit4-7表示加密算法，0：未加密，1：SHA1，2：SHA256
wis_u16   drivingpackgenum;  //驾培包序号           扩展驾培协议包序号，从1开始，除协议中特别声明外，循环递增
wis_u8     terminalid[16];         //计时终端编号
wis_u32   datalength ;              //数据长度
wis_u8     data[900];                  //数据内容
wis_u8     checkcode[256];     //校验串
 }__attribute__((packed, aligned(1))) messagedata;

typedef  struct Datapassup{
wis_u8  datatype;//0：透传消息类型；
messagedata  messdata;//1：透传消息内容；
 }__attribute__((packed, aligned(1))) Datapassup;
/************************************
*B.3.2.3.21　数据下行透传
*透传信息ID: 0x8900
*起始字节	字段	数据类型	描述及要求
*0：透传消息类型；
*1：透传消息内容；
************************************************/
typedef  struct Datapassdown{
wis_u8  datatype;//0：透传消息类型；
messagedata messdata;//1：透传消息内容；
 }__attribute__((packed, aligned(1))) Datapassdown;

class exeDatapass : public BaseCmd
{
public:
    exeDatapass(sp_gateway *m):BaseCmd(m){
        m_CmdName = "datapassdown";
        m_Cmd = CMD_P2T_DATAPASSDOWN;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);
};

#endif // EXEDATAPASS_H
