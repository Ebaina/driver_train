﻿#include "exephototake.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include "app_globl.h"
#include "photosave.h"
#include "Utils.h"
/*立即拍照*/
exeAsktakephotonow::exeAsktakephotonow(sp_gateway *m):BaseCmd(m)
{
    m_CmdName = "asktakephotonow";
    m_Cmd = CMD_T2P_DATAPASSUP;
    photoLen = 100*1024;
    photoBuffer = new char [100*1024];
}
exeAsktakephotonow:: ~exeAsktakephotonow()
{
    delete [] photoBuffer;
}
int exeAsktakephotonow::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeAsktakephotonow::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_ASKTAKEPHOTONOW_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeAsktakephotonow::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}
void ChangeHexData11(string data, unsigned char * out ){


    for(int i=0;i<data.size()/2;i++)
    {

        int jji=(atoi(data.substr(2*i,1).c_str() ) <<4 )| (atoi(data.substr(2*i+1,1).c_str() )   ) ;
        out[i]=   (unsigned char)(jji) ;

    }
}
int exeAsktakephotonow::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Asktakephotonow_Down  askphoto_info;
    Datapassdown  datapass_info;
    Asktakephotonow_Up  minfo;
    int i =17;
    int j = 0;
    int flag = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    askphoto_info.uploadmode = p->td_content[++i];     //上传模式
    if(askphoto_info.uploadmode == 1)
    {
        printf("自动请求上传\n");
        flag = 1;
    }
    if(askphoto_info.uploadmode == 255)
    {
        printf("停止拍摄并上传照片\n");
        flag = 1;
    }

    askphoto_info.camerachannel = p->td_content[++i];   //摄像头通道号
    if(askphoto_info.camerachannel == 0)
    {
        printf("自动选择\n");
        flag = 1;
    }
    else
    {
        printf("通道号为: %d \n",askphoto_info.camerachannel);
        flag = 1;
    }

    askphoto_info.photosize = p->td_content[++i];    //照片尺寸
    if(askphoto_info.photosize == 0x01)
    {
        printf("尺寸为:320×240\n");
    }
    if(askphoto_info.photosize == 0x02)
    {
        printf("尺寸为:640×480\n");
    }
    if(askphoto_info.photosize == 0x03)
    {
        printf("尺寸为:800×600\n");
    }
    if(askphoto_info.photosize == 0x04)
    {
        printf("尺寸为:1024×768\n");
    }
    if(askphoto_info.photosize == 0x05)
    {
        printf("尺寸为:176×144[Qcif]\n");
    }
    if(askphoto_info.photosize == 0x06)
    {
        printf("尺寸为:352×288[Cif]\n");
    }
    if(askphoto_info.photosize == 0x07)
    {
        printf("尺寸为:704×288[HALF D1]\n");
    }
    if(askphoto_info.photosize == 0x08)
    {
        printf("尺寸为:704×576[D1]\n");
    }

    if(flag ==1)
    {
        minfo.operateresult = 0x01;//1：可以拍摄；2：拍照失败；3：SD卡故障；4：正在拍照，不能执行；5：重新连接摄像头，不能保证拍照；6：正在上传查询照片，不能执行。
        minfo.uploadmode = askphoto_info.uploadmode;    //上传模式
        minfo.camerachannel = 0x00;                 //摄像头通道号
        minfo.photosize = 0x01;                          //图片实际尺寸
             appcon.do_takephoto_now(minfo);

        int sizephoto;
        char photobuf_coach[64];
        string photonum_coach ;
        RtcTime_S rtc;
        Uploadphotoinit_Up init_minfo_coach;
        TRACE_INFO("\n摄像头状态:%d\n",check_video0_status());
        if(1 == RealTimeVideoStatus())
        {
            char snap_dev0_pic_names[30] = {0};
            memset(photobuf_coach, 0, sizeof(photobuf_coach));
            memset(snap_dev0_pic_names, 0 ,sizeof(snap_dev0_pic_names));
            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0)
                TRACE_INFO("exe snap pic error\n");
            sprintf(photobuf_coach, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
            photonum_coach  =getmaintime3string(rtc,5);
            getmaintime3char(rtc,&init_minfo_coach.photonum[0],5);
            memcpy(& init_minfo_coach.learnerorcoachid[0],(char *)coachcardinfo.card_info.uniformID,sizeof(coachcardinfo.card_info.uniformID));
            init_minfo_coach.uploadmode =  askphoto_info.uploadmode;
            memcpy( & init_minfo_coach.photonum[0],(char *)photonum_coach.c_str(),photonum_coach.size());
//            Utils::addTextIntoImage(photobuf_coach,2,MainSpeed,changedatalan(Mainlantitude),changedatalan(Mainlontitude));
            sleep(2);
            sizephoto=  appcon.GetPhotodata(photonum_coach,photobuf_coach,&photoBuffer[0],photoLen);
            init_minfo_coach.camerachannel = 0x00;
            init_minfo_coach.photosize =0x01;
            init_minfo_coach.photoeventtype = 19;
            int sizetemp=( sizephoto+293)/700;
            if((( sizephoto+293)%700)==0){
                init_minfo_coach.packgesize = htons(sizetemp);
            }else{
                init_minfo_coach.packgesize = htons(sizetemp+1);
            }
            init_minfo_coach.photodatasize = htonl(sizephoto);
            init_minfo_coach.lessonid = htonl(TrainLessonId);
            init_minfo_coach.faceidentifyreliability = 0x00;
            Utils::packageRtcGps((char *) &init_minfo_coach. addgnssdata[0]);
            appcon.do_upload_photo_init(init_minfo_coach);
            Photosave::getInstance()->insertMessage(init_minfo_coach, photobuf_coach);
            sleep(4);
            appcon.MultPacge_Tools(photonum_coach,photoBuffer,sizephoto);
        }
    }
    return 0;
}


/*查询照片应答*/
exeSearchphoto::~exeSearchphoto()
{

}

int exeSearchphoto::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;
    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}


int exeSearchphoto::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_SEARCHPHOTO_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeSearchphoto::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeSearchphoto::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Searchphoto_Down  searchphoto_info;
    Datapassdown  datapass_info;
    Searchphoto_Up minfo;
    Searchphotoresult_UP result_info;
    int i =17;
    int j = 0;
    int flag = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    searchphoto_info.searchtype = p->td_content[++i];
    if(searchphoto_info.searchtype == 1)
    {
        TRACE_INFO("按时间查询\n");
        flag = 1;
    }

    for(j=0;j<sizeof(searchphoto_info.searchstart);j++)
    {
         searchphoto_info.searchstart[j] = p->td_content[++i];   //查询开始时间
    }

    for(j=0;j<sizeof(searchphoto_info.searchend);j++)
    {
        searchphoto_info.searchend[j] = p->td_content[++i];   //查询结束时间
    }
    if(flag == 1)
    {
        minfo.operateresult = 0x01;
        appcon.do_searchphoto(minfo);
        std::string start=Utils::changeBcdData2Time((char *)searchphoto_info.searchstart,7);
        std::string stop=Utils::changeBcdData2Time((char *)searchphoto_info.searchend,7);
        vector<Uploadphotoinit_Sql*> data;
        Photosave::getInstance()->selectbyTimeNoLimit(start,stop,data);
        if(minfo.operateresult == 0x01)
        {
            result_info.uploadendflag =0x01;
            result_info.sendphotonumber =data.size();
            TRACE_ERR_CLASS("\n查询结果大小:%d\n",data.size());
            result_info.matchphotosize = data.size();
            char  numstemp[200];
            for( int iter1=0;iter1<data.size();iter1++)
            {
                memcpy(&numstemp[iter1*10],(char *)data[iter1]->photonum,10);
            }
            Tracer::getInstance()->printHex(1,"查询结果",numstemp,data.size()*10);
            appcon.do_upload_searchphoto_result(result_info,numstemp,10*data.size());
            sleep(2);
            char *photoBuffer =  new char [100*1024];
            int   photoLen = 100*1024;
//            for(vector<Uploadphotoinit_Sql*>::iterator iter=data.begin();iter!=data.end();iter++)
            TRACE_CYAN("照片数量：%d\n",data.size());

            for(int k=0;k<data.size();k++)
            {
                memset(photoBuffer, 0, sizeof(photoBuffer));
                Uploadphotoinit_Sql *info = data[k];
                Uploadphotoinit_Up mInfo3;
                memset(&mInfo3,0x00,sizeof(mInfo3));
                mInfo3= Photosave::getInstance()->uploadInitSql2Uploadphotoinit(info);
                TRACE_CYAN("\n序号：%d====查询路径:%s====== \n",k,info->photopath.c_str()  );
                char photo_temp[11];
                photo_temp[10]=0x00;
                memcpy(photo_temp, mInfo3.photonum,sizeof(mInfo3.photonum));
                int  sizephoto=  appcon.GetPhotodata(photo_temp, info->photopath ,& photoBuffer[0],photoLen);
                mInfo3.camerachannel = 0x00;
                mInfo3.photosize =0x01;
                mInfo3.photoeventtype = 0x00;
                int sizetemp=(sizephoto+293)/700;
                if(((sizephoto+293)%700)==0){
                    mInfo3.packgesize = htons(sizetemp);
                }else{
                    mInfo3.packgesize = htons(sizetemp+1);
                }
                mInfo3.photodatasize = htonl(sizephoto);
                mInfo3.lessonid = htonl(TrainLessonId);
                mInfo3.faceidentifyreliability = 0x00;
                appcon.do_upload_photo_init(mInfo3);
                sleep(4);
                std::string  timeRecord="中心查询照片数据 :";
                std::string time=Utils::getCurrentTime();
                Utils::printString(PrintLevel::INFO,timeRecord+time);//
                appcon.MultPacge_Tools( photo_temp,photoBuffer,sizephoto);
                delete info;
            }
            delete []  photoBuffer;

        }

    }

   return 0;
}
