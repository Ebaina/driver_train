﻿#include "common_response_ack.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include "exeAuthority.h"
#include "cmdbeatheart.h"
#include "app_globl.h"
#include "Tracer.h"
#include "offlinesave.h"
#include "HttpClient.h"
#include"JSONData.h"
#include "ttsutils.h"
#include <QString>
void postpay()
{
    HttpClient* client = new HttpClient();
    std::string urlname;
    std::string url;
    dictionary *iniflag;
    const char *str;
    iniflag = iniparser_load("/user/src/script/pageflag.ini");     //parser the file
    if(iniflag == NULL)
    {
        fprintf(stderr,"can not open %s","parameters.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(iniflag,stderr);                                   //save ini to stderr

    urlname =  iniparser_getstring(iniflag,"pagepara:urladress","null");
    if(urlname.length() > 10)
    {
        url = iniparser_getstring(iniflag,"pagepara:urlpara","null");
        TRACE_INFO("urladress:%s\n",urlname.c_str());
        TRACE_INFO("urlpara:%s\n",url.c_str());
    }

    if(urlname.length() > 10 && url.length()>10)
    {
        File* file = new  File("/tmp/postput.data", IO_MODE_REWR_ORNEW);
        int flag= client->httpPost(urlname,url,file,6000);
        file->close();
        if(flag==0)
        {
            JSONData json;
            JSONNode* rootNode= json.initWithContentOfFile("/tmp/postput.data");
            if(rootNode!=NULL)
            {
                JSONNode  node2 = (*rootNode)["errorcode"] ;
                int erorflag=9;
                erorflag=node2.toInt();
                TRACE_RED("errorcode:%d\n",node2.toInt());
                if(erorflag==0)
                {
                    TRACE_RED("上传成功!!!\n");
                    Configuration_pageflag_set("pagepara:urladress","0");
                    Configuration_pageflag_set("pagepara:urlpara","0");
                }
            }
        }
    }


}

int Cmd_common::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_COMMON_ACK);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int Cmd_common::format_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe*)param;

    p->ts_cmd = CMD_T2P_COMMON_ACK;
    p->ts_bodyLength = sizeof(m_MsgHead);
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    Add_Seq();
    return sizeof(m_MsgHead);
}

int Cmd_common::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    //    TRACE_INFO("消息头长度%d\n",m_head.MsgLength);
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);

    m_appGateway->nTcp_Send(buf,length);
    return 0;
}


int Cmd_common::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    down_common_Info m;
    //应答流水号
    m.REPLY_FLOW_ID = ((p->td_content[16]<<8)) | (p->td_content[17]);
    m.Response_ID = ((p->td_content[18]<<8)) | (p->td_content[19]);
    m. Response_Result = (p->td_content[20]);
    p->td_seq=m.REPLY_FLOW_ID ;
    TRACE_INFO("\n通用消息类型Response_ID：%04x=====m.REPLY_FLOW_ID:%04x======\n",m.Response_ID ,m.REPLY_FLOW_ID);
    switch(m.Response_ID){
    case CMD_T2P_POSITIONREPORT:
        if(m.Response_Result == 0)
        {
            TRACE_INFO("\n位置上传成功\n");
//            OfflineSave::getInstance()-> deleteMessageByFlowid(m.Response_ID,m.REPLY_FLOW_ID );
            m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
        }
        break;
    case CMD_T2P_AUTHORITY:
        TerminalLoginStatus=5;
        if(m.Response_Result == 0)
        {
            TRACE_INFO("鉴全成功\n");
            IsAuthority=1;
            m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
            TRACE_INFO("鉴全标志：%d\n",IsAuthority);
            //离线发送  zjy   2017.5.26
            vector<stSendCmdPiPe*> sendpipe;
            OfflineSave::getInstance()->selectMessageBySendStatus(1,sendpipe); //1  是离线数据   //0 是非离线数据
            //             vector<stSendCmdPiPe*>::iterator it= sendpipe.begin();
            for(vector<stSendCmdPiPe*>::iterator iter=sendpipe.begin();iter!=sendpipe.end();iter++)
            {
                if(TcpLinkConnectFlag == 1)
                {
                    stSendCmdPiPe *sedndata = *iter;
                    if(sedndata)
                    {
                        TRACE_INFO("\n离线发送数据：%04x\n",sedndata->ts_cmd);
                        sedndata->ts_isoffline=true;//离线数据
                        m_CmdProcessTask.Send_OneCmd(*sedndata,1,true);
                        OfflineSave::getInstance()->deleteMessageByTime(sedndata->ts_sendtime);
                        usleep(10000);
                    }
                }
            }
            sendpipe.clear();
            TRACE_INFO("离线补传\n");
            postpay();    //剩余订单上传

            return 0;
        }
        if(m.Response_Result == 1)
        {
            TRACE_INFO("鉴全上传失败\n");
            IsAuthority=0;
            return 0;
        }
        if(m.Response_Result == 2)
        {
            IsAuthority=0;
            TRACE_INFO("鉴全消息有误\n");
            return 0;
        }
        if(m.Response_Result == 3)
        {
            IsAuthority=0;
            TRACE_INFO("鉴全不支持\n");
            return 0;
        }

        break;
    case CMD_T2P_BEATHEART:
        if(m.Response_Result == 0)
        {
            TRACE_INFO("心跳上传成功\n");
            m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
            return 0;
        }
        if(m.Response_Result == 1)
        {
            TRACE_INFO("心跳上传失败\n");
            return 0;
        }
        if(m.Response_Result == 2)
        {
            TRACE_INFO("心跳消息有误\n");
            return 0;
        }
        if(m.Response_Result == 3)
        {
            TRACE_INFO("心跳不支持\n");
            return 0;
        }
        // TerminalLoginStatus=1;//
        break;
    case 0x0900:
        if(m.Response_Result == 0)
        {
            TRACE_INFO("\n学时记录上传OK\n");
            p->td_cmd=CMD_T2P_REPORTTRAINRECORD_NEW;
//            OfflineSave::getInstance()->deleteMessageByFlowid(CMD_T2P_REPORTTRAINRECORD_NEW,m.REPLY_FLOW_ID );
            m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
            return 0;
        }
        if(m.Response_Result == 1)
        {
            TRACE_INFO("\n学时记录上传失败1\n");
            return 0;
        }
        if(m.Response_Result == 2)
        {
            TRACE_INFO("\n学时记录上传失败2\n");
            return 0;
        }
        if(m.Response_Result == 3)
        {
            TRACE_INFO("\n学时记录上传失败3\n");
            return 0;
        }
        // TerminalLoginStatus=1;//
        break;
    case  CMD_T2P_UNREGISTER :
        if(m.Response_Result == 0)
        {
            //TtsUtils::getInstance()->sendVoice("注销成功");
            m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
            Isregister = 0;
            IsAuthority=0;
            return 0;
        }
        if(m.Response_Result == 1)
        {
            TtsUtils::getInstance()->sendVoice("注销失败");
            Isregister = 1;
            return 0;
        }
        if(m.Response_Result == 2)
        {
            Isregister = 1;
            return 0;
        }
        if(m.Response_Result == 3)
        {
            Isregister = 1;
            return 0;
        }
        break;
    }

    return 0;
}
