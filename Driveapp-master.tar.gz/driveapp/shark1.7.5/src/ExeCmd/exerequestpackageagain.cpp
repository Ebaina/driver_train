﻿#include "exerequestpackageagain.h"
#include "public.h"
#include "clog.h"
#include  <arpa/inet.h>
#include  "cmd.h"

int exerequestpackageagain::int_cmd(string phonenum){}
int exerequestpackageagain::format_cmd(void *param){}
int exerequestpackageagain::exe_cmd(void *param){}
int exerequestpackageagain::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    requestpackageinfo  packinfo_ack;
    packinfo_ack.origialinfoID =((p->td_content[16]<<8) && 0xff)|(p->td_content[17]&&0xff);
    packinfo_ack.requestpackagenum = p->td_content[18];
    for(int i =0;i<p->td_bodyLength-18;i++)
    {
        packinfo_ack.requestpackageID[i] =p->td_content[18+i];
    }
    printf("补传分包解析\n");
    return 0;
}
