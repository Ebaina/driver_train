﻿#include "execoach.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include  "string.h"
#include "exedatapass.h"
#include "Tracer.h"
#include "ttsutils.h"
#include "app_globl.h"
/***********登录******************/
int exeCoachLogin::int_cmd(string phonenum)
{
   int len =0;
   unsigned char pnum[32];
   m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
   m_MsgHead.v_protocol = JDTraining;

   stMsgType m;
   m.MsgDiv = 0;
   m.MsgEncrypt = 0;
   m.MsgLength = 0;
   m.MsgReserved = 0;

   unsigned short m_type;
   memcpy(&m_type,&m,sizeof(unsigned short));
   m_type = htons(m_type);
   memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
   memset(pnum,0,32);
   len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
   if(len > 8)
   {
       wlog(WIS_ERROR,"Cmd Format beartError! \n");
   }

   if(len<8){
     for(int i =7;i>len-1;i--)   //前向 补0
     {
              m_MsgHead.Dev_PhoneNum[i] = 0x00;
              wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
     }
     }
   for(int i =0;i<len;i++)   //
   {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
   }
   m_MsgHead.Msg_Seq = htons(Get_Seq());
   m_MsgHead.Reserved=0x3C;//预留字段
}

int exeCoachLogin::format_cmd(void *param)
{  
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_COACHLOGIN;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeCoachLogin::ack_cmd(void *param)
{
    printf("教练登入应答\n");
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    CoachLogin_down login_info;
    Datapassdown  datapass_info;
    int i =17;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
   datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
   // datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);
    login_info.loginresult = p->td_content[++i];

//    printf("%d\n",login_info.loginresult);
    if(login_info.loginresult == 1)
    {
        m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
        printf("登录成功\n");
        coachSuccess_flag = 1;
    }
    if(login_info.loginresult == 2)
    {
        printf("无效的教练编号\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_COACHNUM);//无效的教练编号
        sleep(2);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }
    if(login_info.loginresult == 3)
    {
        printf("准教车型不符\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::ERROR_TRAINTYPE);//准教车型不符
        sleep(2);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }
    if(login_info.loginresult == 9)
    {
        printf("其他错误\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::OTHER_ERROR);//其他错误
        sleep(2);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }

    for(int j = 0;j<sizeof(login_info.coachid);j++)
    {
        login_info.coachid[j] = p->td_content[++i];  //教练编号
    }

    login_info.isreadaddtext = p->td_content[++i];  //是否报读信息
    if(login_info.isreadaddtext == 0)
    {
        printf("根据全局设置是否报读\n");
    }
    if(login_info.isreadaddtext == 1)
    {
        printf("需要报读\n");
    }
    if(login_info.isreadaddtext == 2)
    {
        printf("不必报读\n");
    }

    login_info.addtextlength = p->td_content[++i];  //附加消息长度
    if(login_info.addtextlength != 0)
    {
        for(int j=0;j<login_info.addtextlength;j++)
        {
            login_info.addtextcontent[j] = p->td_content[++i];  //附加消息内容
        }
    }
    else
    {
        printf("附加消息为0\n");
    }
    return 0;
}

int exeCoachLogin::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}



/***********登出******************/
int exeCoachLogout::int_cmd(string phonenum)
{
   int len =0;
   unsigned char pnum[32];
   m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
   m_MsgHead.v_protocol = JDTraining;
   stMsgType m;
   m.MsgDiv = 0;
   m.MsgEncrypt = 0;
   m.MsgLength = 0;
   m.MsgReserved = 0;
   unsigned short m_type;
   memcpy(&m_type,&m,sizeof(unsigned short));
   m_type = htons(m_type);
   memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
   memset(pnum,0,32);
   len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
   if(len > 8)
   {
       wlog(WIS_ERROR,"Cmd Format beartError! \n");
   }

   if(len<8){
     for(int i =7;i>len-1;i--)   //前向 补0
     {
              m_MsgHead.Dev_PhoneNum[i] = 0x00;
              wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
     }
     }
   for(int i =0;i<len;i++)   //
   {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
   }
   m_MsgHead.Msg_Seq = htons(Get_Seq());

   m_MsgHead.Reserved=0x3C;//预留字段

}

int exeCoachLogout::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_COACHLOGOUTCMD;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
     return sizeof(m_MsgHead);
}
int exeCoachLogout::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
//    TRACE_ERR("\n登出报文：[\n");
//for(int j=0;j<length;j++){

// TRACE_ERR("%02x",buf[j]);


//}
//   TRACE_ERR("\n]\n");
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeCoachLogout::ack_cmd(void *param)
{
    printf("教练登出应答\n");
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    CoachLogout_Down logout_info;
    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
  //  datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    logout_info.logoutresult= p->td_content[++i];    //登出结果
    if(logout_info.logoutresult == 1)
    {   m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
        printf("登出成功\n");
    }
    if(logout_info.logoutresult == 2)
    {
        printf("登出失败\n");
    }
    for(j=0;j<sizeof(logout_info.coachid);j++)
    {
        logout_info.coachid[j] = p->td_content[++i];    //教练编号
    }

    return 0;
}

