﻿#include "exelearner.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include "Tracer.h"
#include "app_globl.h"
#include "ttsutils.h"
#include "offlinesave.h"
#include "ui_interface.h"
/*上报学时记录*/
#include "Utils.h"
int exeReportTrainRecord::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeReportTrainRecord::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_REPORTTRAINRECORD_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeReportTrainRecord::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeReportTrainRecord::ack_cmd(void *param)
{
    return 0;
}

/*命令上报学时记录*/
int exeAskReportTrainRecord::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeAskReportTrainRecord::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_ASK_REPORTTRAINRECORD_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}
int exeAskReportTrainRecord::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeAskReportTrainRecord::ack_cmd(void *param)
{
    printf("命令上报学时记录\n");
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    AskReportLearnMessage_Down learnmessage_info;
    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }

    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
  //  datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    learnmessage_info.searchtype = p->td_content[++i];     //查询方式
    if(learnmessage_info.searchtype == 1)
    {
        //
        TRACE_INFO("\n按时间上传\n");
        for(j=0;j<sizeof(learnmessage_info.searchstart);j++)
        {
            learnmessage_info.searchstart[j] = p->td_content[++i];     //查询起始时间
        }
        for(j=0;j<sizeof(learnmessage_info.searchend);j++)
        {
            learnmessage_info.searchend[j] = p->td_content[++i];    //查询终止时间
        }
        AskReportLearnMessage_Up  ask_reportLearnMessage;
        ask_reportLearnMessage.operateresult=0x01;
        appcon.do_ask_reportrain_record(ask_reportLearnMessage);
        std::string starttime=Utils::changeBcdData2Time((char *) learnmessage_info.searchstart ,7);
        std::string stoptime=Utils::changeBcdData2Time((char *) learnmessage_info.searchend ,7);
        vector<stSendCmdPiPe*>  data;
        OfflineSave::getInstance()->selectMessageByTypeId(515,starttime,stoptime,10,0,data);
        for(int i=0;i<data.size();i++)  //
        {
            //stSendCmdPiPe* info=new stSendCmdPiPe;
            stSendCmdPiPe* info=data[i];
            info->ts_isoffline=true;
            m_CmdProcessTask.Send_OneCmd(*info,1,true);//test   6.8  16:47
       }
        ask_reportLearnMessage.operateresult=0x04;
        appcon.do_ask_reportrain_record(ask_reportLearnMessage);


    }
    if(learnmessage_info.searchtype == 2)
    {

        learnmessage_info.searchnumbers = ((p->td_content[++i]&0xff)<<8) | (p->td_content[++i]&0xff);
        TRACE_INFO("\n按条数上传:%d\n",learnmessage_info.searchnumbers);//临时改成10
        AskReportLearnMessage_Up  ask_reportLearnMessage;
        ask_reportLearnMessage.operateresult=0x01;
        appcon.do_ask_reportrain_record(ask_reportLearnMessage);
        vector<stSendCmdPiPe*>  data;

        OfflineSave::getInstance()->selectMessageByCounts(515,  10, data);
        for(int i=0;i<data.size();i++)
        {
            //stSendCmdPiPe* info=new stSendCmdPiPe;
            stSendCmdPiPe* info=data[i];
//            Utils::printString(PrintLevel::INFO,info->ts_sendtime);
//            Tracer::getInstance()->printHex(1,"学时记录",info->ts_content,info->ts_bodyLength);
//            TRACE_CYAN("\n学时记录ID：%d=====%p\n",i,info);
             info->ts_isoffline=true;
             m_CmdProcessTask.Send_OneCmd(*info,1,true);//test   6.8  16:47
//            delete info;
        }
        ask_reportLearnMessage.operateresult=0x04;
        appcon.do_ask_reportrain_record(ask_reportLearnMessage);
//        for(int i=0;i<data.size();i++)
//        {
//          delete data[i];
//        }
//         TRACE_IF("\n学时记录ID \n" );
        data.clear();
//         TRACE_IF("\n学时记录ID \n" );
    }
    TRACE_CYAN("\n===================================\n");
    return 0;
}



/*学员登入*/
int exeLearnerLogin::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeLearnerLogin::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_LERNERLOGIN_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeLearnerLogin::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeLearnerLogin::ack_cmd(void *param)
{
    printf("学员登录应答\n");
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;

    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }

   datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
  //  datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    learner_login_info.loginresult = p->td_content[++i];

    if(learner_login_info.loginresult == 1)
    {
        printf("登录成功\n");
       m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
       stuSuccess_flag = 1;
    }
    if(learner_login_info.loginresult == 2)
    {
        TRACE_INFO("无效的学员编号\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_STUDENT);//无效的学员编号
        sleep(2);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }
    if(learner_login_info.loginresult == 3)
    {
        TRACE_INFO("禁止登录的学员n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::FORBID_STUDENT);//禁止登录的学员
        sleep(2);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }
    if(learner_login_info.loginresult == 4)
    {
        TRACE_INFO("区域外教学提醒\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::OUT_AREA_ERROR);//区域外教学提醒
        sleep(3);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }
    if(learner_login_info.loginresult == 5)
    {
        TRACE_INFO("准教车型与培训车型不符\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::ERROR_TYEPECAR);//准教车型与培训车型不符
        sleep(4);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }
    if(learner_login_info.loginresult == 9)
    {
        TRACE_INFO("其他错误\n");
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::OTHER_ERROR);//其他错误
        sleep(2);
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::INVALID_RECORD);//产生的学时将无效
    }

    for(j=0;j<sizeof(learner_login_info.learnerid);j++)
    {
        learner_login_info.learnerid[j] = p->td_content[++i];    //学员编号
    }

    learner_login_info.maintraintime = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //总培训学时
    TRACE_GREEN("总培训学时: %d ",learner_login_info.maintraintime);
    learner_login_info.finishtime = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //当前培训部分已完成学时
    TRACE_GREEN("当前培训部分已完成学时: %d ",learner_login_info.finishtime);
    learner_login_info.maintrainmile = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //总培训里程
    TRACE_GREEN("总培训里程: %d ",learner_login_info.maintrainmile);
    learner_login_info.finishmile =  ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //当前培训部分已完成里程
    TRACE_GREEN("当前培训部分已完成里程: %d ",learner_login_info.finishmile);
    learner_login_info.isreadaddtext = p->td_content[++i];    //是否报读附加消息
    if(learner_login_info.isreadaddtext == 0)
    {
        TRACE_INFO("不必报读\n");
    }
    if(learner_login_info.isreadaddtext == 1)
    {
        TRACE_INFO("需要报读\n");
    }

    learner_login_info.addtextlength = p->td_content[++i]&0xff;    //附加消息长度

    if(learner_login_info.addtextlength == 0)
    {
        TRACE_INFO("无附加数据\n");
    }
    else
    {
        for(j=0;j<learner_login_info.addtextlength;j++)
        {
            learner_login_info.addtextcontent[j] = p->td_content[++i];    //附加消息内容
        }
    }
    char para_buff[4];
    sprintf(para_buff,"%d",learner_login_info.maintraintime);
    Configuration_pageflag_set("pagepara:maintraintime",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",learner_login_info.finishtime);
    Configuration_pageflag_set("pagepara:finishtime",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",learner_login_info.maintrainmile);
    Configuration_pageflag_set("pagepara:maintrainmile",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",learner_login_info.finishmile);
    Configuration_pageflag_set("pagepara:finishmile",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    return 0;
}



/*学员登出*/
int exeLearnerLogout::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeLearnerLogout::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_LERNERLOGOUT_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeLearnerLogout::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);

    return 0;
}

int exeLearnerLogout::ack_cmd(void *param)
{
    printf("学员登出应答\n");
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    LearnerLogout_Down logout_info;
    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }

    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
  //  datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    logout_info.logoutresult = p->td_content[++i];     //学员登出结果
    if(logout_info.logoutresult == 1)
    {   m_CmdProcessTask.Remove_OneCmdFromSendList(*p);
        TRACE_INFO("登出成功\n");
    }
    if(logout_info.logoutresult == 2)
    {
        TRACE_INFO("登出失败\n");
    }

    for(j=0;j<sizeof(logout_info.learnerid);j++)
    {
        logout_info.learnerid[j] = p->td_content[++i];     //学员编号
    }

    return 0;
}
