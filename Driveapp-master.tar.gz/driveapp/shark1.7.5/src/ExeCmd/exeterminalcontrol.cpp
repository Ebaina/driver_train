﻿#include "exeterminalcontrol.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include "app_globl.h"
#include "ttsutils.h"
#include "timerupload.h"

/* 设置终端应用参数*/
int exeSetterminalappdata::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeSetterminalappdata::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_SETTERMINALAPPDATA_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeSetterminalappdata::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeSetterminalappdata::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Setterminalappdata_Down  setappdata_info;
    Datapassdown  datapass_info;
    Setterminalappdata_Up minfo;
    memset(&setappdata_info,0,sizeof(setappdata_info));
    memset(&datapass_info,0,sizeof(datapass_info));
    memset(&minfo,0,sizeof(minfo));
    char para_buff[40];
    int i =17;
    int j = 0;
    int flag_temp;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    setappdata_info.datasetid = p->td_content[++i];   //参数编号
    if(setappdata_info.datasetid == 0)
    {
        printf(" 0：设置所有已定义的参数\n");
        flag_temp = 1;
    }
   else if(setappdata_info.datasetid == 1)
    {
        printf(" 1：定时拍照时间间隔\n");
        flag_temp = 1;
    }
    else if(setappdata_info.datasetid == 2)
     {
         printf(" 2：照片上传设置\n");
         flag_temp = 1;
     }
    else if(setappdata_info.datasetid == 3)
     {
         printf(" 3：是否报读附加消息\n");
         flag_temp = 1;
     }
    else if(setappdata_info.datasetid == 4)
     {
         printf(" 4：熄火后停止学时计时的延时时间\n");
         flag_temp = 1;
     }
    else if(setappdata_info.datasetid == 5)
     {
         printf(" 5：熄火后GNSS数据包上报间隔\n");
         flag_temp = 1;
     }
    else if(setappdata_info.datasetid == 6)
     {
         printf(" 6：熄火后教练自动登出的延时时间\n");
         flag_temp = 1;
     }
    else if(setappdata_info.datasetid == 7)
     {
         printf(" 7：重新验证身份时间间隔\n");
         flag_temp = 1;
     }
    else if((220<setappdata_info.datasetid)&&(setappdata_info.datasetid<255))
     {
         printf("  220-255：自定义\n");
         flag_temp = 1;
     }

    setappdata_info.setdataspacetime = p->td_content[++i];   //定时拍照时间间隔
    takePhototime=(setappdata_info.setdataspacetime)&0xFF;
    TimerUpload::getInstance()->stopIndex(TimerSpace::BAISICTIMER);
    TRACE_CYAN("\n拍照间隔修改：%d\n",takePhototime);
    TimerUpload::getInstance()->startIndex(TimerSpace::BAISICTIMER);
    sprintf(para_buff,"%d",setappdata_info.setdataspacetime);
    Configuration_parameter_set("app_data:setdataspacetime",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.setdataspacetime));

    setappdata_info.uploadphotoset = p->td_content[++i];     //照片上传设置
    if(setappdata_info.uploadphotoset == 0)
    {
        printf("不自动请求上传\n");
    }
    else if(setappdata_info.uploadphotoset == 1)
    {
        printf("自动请求上传\n");
    }
    sprintf(para_buff,"%d",setappdata_info.uploadphotoset);
    Configuration_parameter_set("app_data:uploadphotoset",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.uploadphotoset));


    setappdata_info.isreadaddcontent = p->td_content[++i];    //是否报读附加消息
    if(setappdata_info.isreadaddcontent == 1)
    {
        printf("自动报读\n");
    }
    else if(setappdata_info.isreadaddcontent == 2)
    {
        printf("不报读 \n");
    }
    sprintf(para_buff,"%d",setappdata_info.isreadaddcontent);
    Configuration_parameter_set("app_data:isreadaddcontent",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.isreadaddcontent));

    setappdata_info.misfireenddelaytime = p->td_content[++i];  //熄火后停止学时计时的延时时间
    sprintf(para_buff,"%d",setappdata_info.misfireenddelaytime);
    Configuration_parameter_set("app_data:misfireenddelaytime",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.misfireenddelaytime));

    setappdata_info.misfireupgnssspace = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //熄火后GNSS数据包上传间隔
    sprintf(para_buff,"%d",setappdata_info.misfireupgnssspace);
    Configuration_parameter_set("app_data:misfireupgnssspace",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.misfireupgnssspace));

    setappdata_info.misfirecoachlogoutdelaytime = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff); //熄火后教练自动登出的延时时间
    sprintf(para_buff,"%d",setappdata_info.misfirecoachlogoutdelaytime);
    Configuration_parameter_set("app_data:misfirecoachlogoutdelaytime",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.misfirecoachlogoutdelaytime));

    setappdata_info.recheckidentitytime = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff); //重新验证身份时间
    sprintf(para_buff,"%d",setappdata_info.recheckidentitytime);
    Configuration_parameter_set("app_data:recheckidentitytime",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.recheckidentitytime));

    setappdata_info.coachcrosstech = p->td_content[++i];   //教练跨校教学
    if(setappdata_info.coachcrosstech == 1)
    {
        printf("允许 \n");
    }
    if(setappdata_info.coachcrosstech == 2)
    {
        printf("禁止\n");
    }
    sprintf(para_buff,"%d",setappdata_info.coachcrosstech);
    Configuration_parameter_set("app_data:coachcrosstech",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.coachcrosstech));

    setappdata_info.learnercrosslearn = p->td_content[++i];
    if(setappdata_info.learnercrosslearn == 1)
    {
        printf("允许 \n");
    }
    if(setappdata_info.learnercrosslearn == 2)
    {
        printf("禁止\n");
    }
    sprintf(para_buff,"%d",setappdata_info.learnercrosslearn);
    Configuration_parameter_set("app_data:learnercrosslearn",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.learnercrosslearn));

    setappdata_info.ackspacetime = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //响应平台同类消息时间间隔
    sprintf(para_buff,"%d",setappdata_info.ackspacetime);
    Configuration_parameter_set("app_data:ackspacetime",para_buff);
    memset(para_buff,0,sizeof(setappdata_info.ackspacetime));

    if(flag_temp == 1)
    {
        minfo.ackdata = 0x01;   //设置成功
        appcon.do_set_terminal_app_data(minfo);
    }
    else if(flag_temp == 0)
    {
        minfo.ackdata = 0x02;   //设置失败
        appcon.do_set_terminal_app_data(minfo);
    }

    return 0;
}

/* 设置禁训状态*/
int exeSetforbidtrain::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeSetforbidtrain::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_SETFORBIDTRAIN_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeSetforbidtrain::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeSetforbidtrain::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Setforbidtrain_Down  setforbidden_info;
    Datapassdown  datapass_info;
    Setforbidtrain_Up   minfo;
    memset(&setforbidden_info,0,sizeof(setforbidden_info));
    memset(&datapass_info,0,sizeof(datapass_info));
    memset(&minfo,0,sizeof(minfo));
//    short flowidtemp=0;
//    flowidtemp=p->td_content[13]<<8|p->td_content[14];
    char para_buff[4];
    int flag_temp;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    setforbidden_info.forbidtrainstatus = p->td_content[++i];     //禁训状态
    TRACE_CYAN("\n禁训状态：%d\n",setforbidden_info.forbidtrainstatus);
    if(setforbidden_info.forbidtrainstatus == 1)
    {
        printf("可用\n");
        forbidenflag =0;

    }
    else if(setforbidden_info.forbidtrainstatus ==2)
    {
        printf("禁用\n");
        TtsUtils::getInstance()->sendVoice("今日禁止训练");
        forbidenflag = 1;      //禁止训练
    }
    sprintf(para_buff,"%d",setforbidden_info.forbidtrainstatus);
    flag_temp = Configuration_parameter_set("app_data:forbidtrainstatus",para_buff);
    memset(para_buff,0,sizeof(setforbidden_info.forbidtrainstatus));
    setforbidden_info.promptinfolength = p->td_content[++i];   //提示消息长度
    if(setforbidden_info.promptinfolength != 0)
    {
        for(int j=0;j<setforbidden_info.promptinfolength;j++)
        {
            setforbidden_info.promptinfocontent[j] = p->td_content[++i];  //提示消息内容
            TRACE_INFO("%02x",setforbidden_info.promptinfocontent[j]);
        }
        if(setforbidden_info.forbidtrainstatus ==2)
        {
            Send_Voice((char *)setforbidden_info.promptinfocontent,setforbidden_info.promptinfolength);
        }
        else{
            TtsUtils::getInstance()->sendVoice("解除今日禁止训练");
        }

    }
    else
    {
        printf("提示消息内容为0\n");
    }

    if(flag_temp == 1)
    {
        minfo.operateresult = 0x01;
        minfo.forbidtrainstatus = setforbidden_info.forbidtrainstatus;
        minfo.promptinfolength = setforbidden_info.promptinfolength;
        if(setforbidden_info.promptinfolength == 0)
        {
            for(int j=0;j<setforbidden_info.promptinfolength;j++)
            {
                minfo.promptinfocontent[j] = 0;  //提示消息内容
            }
        }
        else
        {
            for(int j=0;j<setforbidden_info.promptinfolength;j++)
            {
                minfo.promptinfocontent[j] = setforbidden_info.promptinfocontent[j];  //提示消息内容
            }
        }
        appcon.do_set_forbidtrain_app(minfo);
    }
    else
    {
        minfo.operateresult = 0x02;
        minfo.forbidtrainstatus = setforbidden_info.forbidtrainstatus;
        minfo.promptinfolength = setforbidden_info.promptinfolength;
        if(setforbidden_info.promptinfolength == 0)
        {
            for(int j=0;j<setforbidden_info.promptinfolength;j++)
            {
                minfo.promptinfocontent[j] = 0;  //提示消息内容
            }
        }
        else
        {
            for(int j=0;j<setforbidden_info.promptinfolength;j++)
            {
                minfo.promptinfocontent[j] = setforbidden_info.promptinfocontent[j];  //提示消息内容
            }
        }
        appcon.do_set_forbidtrain_app(minfo);
    }

    return 0;
}

/* 查询终端应用参数*/
int exeSearchterminalappdata::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeSearchterminalappdata::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_SEARCHTERMINALAPPDATA_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeSearchterminalappdata::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeSearchterminalappdata::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Datapassdown  datapass_info;
    Searchterminalappdata_Up  minfo;
    memset(&datapass_info,0,sizeof(datapass_info));
    memset(&minfo,0,sizeof(minfo));
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);
    /*配置文件读取*/
    dictionary *ini;
    const char *str;
    char *ip;
    int n =0;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    if(ini == NULL)
    {
        fprintf(stderr,"can not open %s","example.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(ini,stderr);                                   //save ini to stderr
    minfo.setdataspacetime = iniparser_getint(ini,"app_data:setdataspacetime",-1);
    minfo.uploadphotoset = iniparser_getint(ini,"app_data:uploadphotoset",-1);
    minfo.isreadaddcontent = iniparser_getint(ini,"app_data:isreadaddcontent",-1);
    minfo.misfireenddelaytime = iniparser_getint(ini,"app_data:misfireenddelaytime",-1);
    minfo.misfireupgnssspace = htons(iniparser_getint(ini,"app_data:misfireupgnssspace",-1));
    minfo.misfirecoachlogoutdelaytime = htons(iniparser_getint(ini,"app_data:misfirecoachlogoutdelaytime",-1));
    minfo.recheckidentitytime = htons(iniparser_getint(ini,"app_data:recheckidentitytime",-1));
    minfo.coachcrosstech = iniparser_getint(ini,"app_data:coachcrosstech",-1);
    minfo.learnercrosslearn = iniparser_getint(ini,"app_data:learnercrosslearn",-1);
    minfo.ackspacetime = htons(iniparser_getint(ini,"app_data:ackspacetime",-1));

    if(datapass_info.messdata.datalength == 0)
    {
        printf("查询终端应用参数\n");
        minfo.datasetsearchresult = 0x00;      //查询成功
    }
    else
    {
        minfo.datasetsearchresult = 0x01;      //查询失败
    }

    appcon.do_search_terminal_app_data(minfo);

    return 0;
}
