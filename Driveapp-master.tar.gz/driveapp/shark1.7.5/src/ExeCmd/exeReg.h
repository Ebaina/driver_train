﻿#ifndef _REG_CMD_H_
#define _REG_CMD_H_
#include "CmdBase.h"
#include "stdtype.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/
#define CMD_T2P_REGISTER    0x0100
#define CMD_P2T_REGISTER    0x8100

/***********************************
*起始字节	字段	数据类型	描述及要求
*0	省域ID	WORD	标示终端安装车辆所在的省域，0保留，由平台取默认值。省域ID采用GB/T 2260中规定的行政区划代码6位中前2位
*2	市县域ID	WORD	标示终端安装车辆所在的市域和县域，0保留，由平台取默认值。市县域ID采用GB/T 2260中规定的行政区划代码6位中后4位
*4	制造商ID	BYTE[5]	5个字节，终端制造商编码
*9	终端型号	BYTE[20]	20个字节，此终端型号由制造商自行定义，位数不足20位的，后补“0X00”
*29	计时终端出厂序列号	BYTE[7]	7个字节，由大写字母和数字组成，此终端ID由制造商自行定义，位数不足时，后补“0X00”
*52	IMEI	BYTE[15]	国际移动设备标识，ASCII码
*67	车牌颜色	BYTE	车牌颜色，按照JT/T415-2006的5.4.12；
*未上牌时，取值为0
*68	车辆标识	STRING	车牌颜色为0时，表示车辆VIN；
*否则，表示公安交通管理部门颁发的机动车号牌
*********************************************/
typedef struct
{
    unsigned short m_Province;  //省
    unsigned short m_town;      //县域
    unsigned char  m_manufacturerID[5];  //制造商ID
    unsigned char  m_DeviceType[20];     //终端类型
    unsigned char  m_DeviceSN[7];        //设备SN
    unsigned char  m_IMEI[15];          //IMEI
    unsigned char  m_CarPlateColor;    //车牌颜色
    unsigned char  m_CarNumber[9];     //车牌标识
}__attribute__((packed, aligned(1))) stRegInfo;



/***********************************
*起始字节	字段	数据类型	描述及要求
*0	应答流水号	WORD	对应的终端注册消息的流水号
*2	结果	BYTE 	 0：成功；
**************1：车辆已被注册；
**************2：数据库中无该车辆；
**************3：终端已被注册；
**************4：数据库中无该终端。
*只有在成功后才返回以下内容
*3	平台编号	BYTE[5]	统一编号
*8	培训机构编号	BYTE[16]	统一编号
*24	计时终端编号	BYTE[16]	统一编号
*40	证书口令	BYTE[12]	终端证书口令
*52	终端证书	STRING	由计时平台向全国驾培平台申请
*********************************************/
typedef struct{
wis_u16 ackflowid; //0应答流水号
wis_u8 result;//2	结果	BYTE 	 0：成功；
wis_u8 plantformid[5];//3	平台编号	BYTE[5]	统一编号
wis_u8 traincompanyid[16];//8	培训机构编号	BYTE[16]	统一编号
wis_u8 terminalid[16];//24	计时终端编号	BYTE[16]	统一编号
wis_u8 certificatecode[12];//40	证书口令	BYTE[12]	终端证书口令
wis_u8 terminalcertificate[4096];//52	终端证书	STRING	由计时平台向全国驾培平台申请
}__attribute__((packed, aligned(1))) stRegInfo_ack;


class CmdReg : public BaseCmd
{
public:
    CmdReg(sp_gateway *m):BaseCmd(m){
        m_CmdName = "Register";
        m_Cmd = CMD_T2P_REGISTER;}
private:
    int startindex;//
    int indesameflag;
public :
    int  inputcertificatecode(int count ,int index,char * buffdata,int length);
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};
#endif
