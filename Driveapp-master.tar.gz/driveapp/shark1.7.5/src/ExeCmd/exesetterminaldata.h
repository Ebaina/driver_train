﻿#ifndef EXESETTERMINALDATA_H
#define EXESETTERMINALDATA_H

#include "CmdBase.h"
#include "stdtype.h"


# define CMD_T2P_ASKSETTERMINALDATA           0x0104    //查询终端参数应答
# define CMD_P2T_SETTERMINALDATAACK           0x8103     //设置终端参数
# define CMD_P2T_SEARCHTERMINALDATA          0x8104     //查询终端参数
# define CMD_P2T_TERMINALCONTROL                0x8105     //终端控制
# define CMD_P2T_SERACHSELECTTERMINALDATA  0x8106   //查询指定终端参数

typedef struct CommunicateMainSet//通信设置
{
    wis_u32 Client_Heartbeat_Sec;// 0x0001 客户端心跳发送间隔，单位为秒(s)
    wis_u32 Tcp_Reply_Sec;// 0x0002 TCP消息应答超时时间，单位为秒(s)
    wis_u32 Tcp_Retransmission;// 0x0003 TCP消息重传次数
    wis_u32 Udp_Reply_Sec;// 0x0004 UDP消息应答超时时间，单位为秒(s)
    wis_u32 Udp_Retransmission;// 0x0005 UDP消息重传次数
    wis_u32 SMS_Reply_Sec;// 0x0006 SMS消息应答超时时间，单位为秒(s)
    wis_u32 SMS_Retransmission;// 0x0007 SMS消息重传次数
                                                        //0x0008-0x000f 保留
}__attribute__((packed, aligned(1)))  CommunicateMainSet;//通信设置

typedef struct NetMainSet//网络设置
{
    wis_u8 Mainserver_APN[32];// 0x0010 主服务器APN，无线通信拨号访问点。若网络制式为CDMA，则该处为PPP拨号号码
    wis_u8 Mainserver_User[32];// 0x0011 主服务器无线通信拨号用户名
    wis_u8 Mainserver_Password[32];// 0x0012 主服务器无线通信拨号密码
    wis_u8 Mainserver_IP[32];// 0x0013 主服务器地址，IP或域名
    wis_u8 Backupserver_APN[32];// 0x0014 备份服务器APN，无线通信拨号访问点
    wis_u8 Backupserver_User[32];// 0x0015 备份服务器无线通信拨号用户名
    wis_u8 Backupserver_Password[32];// 0x0016 备份服务器无线通信拨号密码
    wis_u8 Backupserver_IP[32];// 0x0017 备份服务器地址，IP或域名
    wis_u32 Server_TCP_Port;// 0x0018 服务器TCP端口
    wis_u32 Server_UDP_Port;// 0x0019 服务器UDP端口
                                        //0x001a-0x001f  保留
}__attribute__((packed, aligned(1)))  NetMainSet;//网络设置

typedef struct ReportMainSet//汇报设置如下
{
    wis_u32 Location_Report_Way;// 0x0020 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报
    wis_u32 Location_Report_Status;// 0x0021 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态
    wis_u32 Dri_Unlisted_Time_Report;// 0x0022 驾驶员未登录汇报时间间隔，单位为秒(s),>0
                                                                //0x0023-0x0026  保留
    wis_u32 Dormant_Time_Report;// 0x0027 休眠时汇报时间间隔，单位为秒(s),>0
    wis_u32 Emergency_Alarm_Time_Report;// 0x0028 紧急报警时汇报时间间隔，单位为秒(s),>0
    wis_u32 Default_Time_Report;// 0x0029 缺省时间汇报间隔，单位为秒(s),>0
                                                //0x002A-0x002B 保留
    wis_u32 Default_Distance_Report;// 0x002C 缺省距离汇报间隔，单位为米(m),>0
    wis_u32 Dri_Unlisted_Distance_Report;// 0x002D 驾驶员未登录汇报距离间隔，单位为米(m),>0
    wis_u32 Dormant_Distance_Report;// 0x002E 休眠时汇报距离间隔，单位为米(m),>0
    wis_u32 Emergency_Alarm_Distance_Report;// 0x002F 紧急报警时汇报距离间隔，单位为米(m),>0
    wis_u32 Inflection_Point;// 0x0030 拐点补传角度，<180°
                                                //0x0031-0x003F 保留
}__attribute__((packed, aligned(1)))  ReportMainSet;//汇报设置如下

typedef struct ListenMainSet//监听设置
{
    wis_u8 Monitoring_Platform_Phone[32];// 0x0040 监控平台电话号码
    wis_u8 Reset_Phone[32];// 0x0041 复位电话号码，可采用此电话号码拨打终端电话让终端复位
    wis_u8 Factory_Reset_Phone[32];// 0x0042 恢复出厂设置电话号码，可采用此电话号码拨打终端电话让终端恢复出厂设置
    wis_u8 Monitoring_Platform_SMS_Phone[32];// 0x0043 监控平台SMS电话号码
    wis_u8 Receiving_SMS_Alarm[32];// 0x0044 接收终端SMS文本报警号码
    wis_u32 Terminal_Phone_Way;// 0x0045 终端电话接听策略，0：自动接听；1：ACCON时自动接听，OFF时手动接听
    wis_u32 Phone_Time;// 0x0046 每次最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
    wis_u32 Phone_Time_Month;// 0x0047 当月最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
    wis_u8 Monitor_Phone[32];// 0x0048 监听电话号码
    wis_u8 Monitor_Platform_Text_Phone[32];// 0x0049 监管平台特权短信号码
                                                            //0x004A-0x004F 保留
}__attribute__((packed, aligned(1)))  ListenMainSet;//监听设置

typedef struct ViewthresholdMainSet//摄像与门限设
{
    wis_u32 Alarm_Shield_Byte;// 0x0050 报警屏蔽字。与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警被屏蔽
    wis_u32 Alarm_Send_SMS_Text;// 0x0051 报警发送文本SMS开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时发送文本SMS
    wis_u32 Alarm_Picture_Switch;// 0x0052 报警拍摄开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时摄像头拍摄
    wis_u32 Alarm_Picture_Save;//  0x0053 报警拍摄存储标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警时牌的照片进行存储，否则实时长传
    wis_u32 Key_Identification;// 0x0054 关键标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警为关键报警
    wis_u32 High_Speed;// 0x0055 最高速度，单位为公里每小时(km/h)
    wis_u32 OverSpeed_Time;// 0x0056 超速持续时间，单位为秒(s)
    wis_u32 Continue_Dri_Time;// 0x0057 连续驾驶时间门限，单位为秒(s)
    wis_u32 Day_Dri_Time;// 0x0058 当天累计驾驶时间门限，单位为秒(s)
    wis_u32 Mini_Reset_Time;// 0x0059 最小休息时间，单位为秒(s)
    wis_u32 Max_Park_Time;// 0x005A 最长停车时间，单位为秒(s)
                                                //0x005B-0x006F 保留
}__attribute__((packed, aligned(1)))  ViewthresholdMainSet;//摄像与门限设

typedef struct OtherMainSet//其他设置
{
    wis_u32 Picture;// 0x0070 图像/视频质量，1-10,1最好
    wis_u32 Lightness;// 0x0071 亮度，0-255
    wis_u32 Contrast;// 0x0072 对比度，0-127
    wis_u32 Saturation;// 0x0073 饱和度，0-127
    wis_u32 Chroma;// 0x0074 色度，0-255
                                   // 0x0075-0x007F 保留
    wis_u32 Car_Meilage;// 0x0080 车辆里程表读数，1/10km
    wis_u16 Province_ID;// 0x0081 车辆所在的省域ID
    wis_u16 City_ID;// 0x0082 车辆所在的市域ID
    wis_u8  Motor_Plate[32];// 0x0083 公安交通管理部门颁发的机动车号牌
    wis_u8  Plate_Color;// 0x0084 车牌颜色，按照JT/T415-2006的5.4.12
    wis_u32 Impulse_Ratio;//0x0085 车辆脉冲系数，车辆行驶1km距离过程中产生的脉冲信号个数
}__attribute__((packed, aligned(1)))  OtherMainSet;//其他设置




/*********************
*A.3.2.3.12　设置终端参数
*消息ID：0x8103
***********************************/
/**************************
 *设置终端参数项
**********************************/
typedef struct terminaldata{
    wis_u32 paramID;        //参数ID
    wis_u8 paramlength;         //参数长度
    wis_u8 paramdata[20];   //暂定20    参数值
}__attribute__((packed, aligned(1)))  terminaldata;

typedef struct SetTerminaldata{
wis_u8 pacagesize;        //0	参数总数	BYTE
wis_u8 subpacagesize;         //1	分包参数个数	BYTE	本数据包包含的参数个数
terminaldata param_s;    //2	参数项列表		参数项格式见表B.16
}__attribute__((packed, aligned(1)))  SetTerminaldata;

/*********************
*A.3.2.3.13　查询终端参数
*消息ID：0x8104
*查询终端参数消息体为空。
*******************/

/*********************
/*********************
*A.3.2.3.14　查询指定终端参数
*消息ID：0x8106。
*查询指定终端参数消息体数据格式见表B.18，终端采用0x0104指令应答。
*表A.18　查询指定终端参数消息体数据格式
*起始字节	字段	数据类型	描述及要求
*0	参数总数	BYTE	参数总数为n
*1	参数ID列表	BYTE[4*n]	参数顺序排列，如“参数ID1参数ID2……参数IDn”
**
***********************************/
typedef struct SearchSelectTerminalParam{
wis_u8 parametersize;        //0	参数总数	BYTE	参数总数为n
wis_u32 parameterlist[20];        //1	参数ID列表	BYTE[4*n]	参数顺序排列，如“参数ID1参数ID2……参数IDn”
}__attribute__((packed, aligned(1)))   SearchSelectTerminalParam;


/*********************
*A.3.2.3.15　查询终端参数应答
*消息ID：0x0104。
*查询终端参数应答消息体数据格式见表B.19。
*表A.19　查询终端参数应答消息体数据格式
*起始字节	字段	数据类型	描述及要求
*0	应答流水号	WORD	对应的终端参数查询消息的流水号
*2	应答参数个数	BYTE
*3	包参数个数	BYTE
*4	参数项列表		参数项格式和定义见表B.16
***********************************/
typedef struct SearchTerminalParamAck{
wis_u16 ackflowid;//0	应答流水号	WORD	对应的终端参数查询消息的流水号
wis_u8 ackparamnum;//2	应答参数个数	BYTE
wis_u8 packge;//3	包参数个数	BYTE
//terminaldata param_q;     //2	参数项列表		参数项格式见表B.16
}__attribute__((packed, aligned(1)))  SearchTerminalParamAck;

/*********************
*A.3.2.3.17　终端控制
*消息ID   ：  0x8105。
***********************************/
typedef struct {
wis_u8 cmdid;   //0	命令字	BYTE	终端控制命令字说明见表B.27
wis_u8 cmdvalue[512];   //1	命令参数	STRING	命令参数格式具体见后描述，每个字段之间采用”;”分隔，每个STRING字段先按GBK编码处理后再组成消息
}__attribute__((packed, aligned(1))) TerminalControl;

/*********************
*命令参数设置
***********************************/
typedef struct  {
wis_u8 connectcontrol;   //0：切换到指定监管平台服务器，连按到该服务器后即进入应急状态，此状态下仅有下发控制指令的监管平台可发送包括短信在内的控制指令；
                                           //1：切换回原缺省监控平台服务器，并恢复正常状态
wis_u8 dialpointname[20];   //1	一般为服务器APN，无线通信拨号访问点，若网络制式为CDMA，则该值为PPP连接拨号号码
wis_u8 dialpointuser[20];   //服务器无线通信拨号用户名
wis_u8 dialpassword[20];    //服务器无线通信拨号密码
wis_u8 address[20]; //服务器地址，IP或域名
wis_u16 TCPpoint;   //服务器TCP端口
wis_u16 UDPpoint; //服务器UDP端口
wis_u8  manufactorID[5];   //终端制造商编码
wis_u8 identifycode[256]; //监管平台下发的鉴权码，仅用于终端连接到.监管平台之后的鉴权，终端连接回原监控平台还用原鉴权码
wis_u8 hardversion[20];   //终端的硬件版本号，由制造商自定
wis_u8 firmwareversion[20];   //终端的固件版本号，由制造商自定
wis_u8 addressURL[100];    //URL地址
wis_u16 connectTimeLimit;   //单位：min，值非0表示在终端接收到升级或连接指定服务器指令后的有效期截止前，终端应连回原地址。若值为0，则表示一直连接指定服务器
}__attribute__((packed, aligned(1))) CommandParam;

int  parameter(int paramID,char buf[20],int len);

/*查询终端参数*/
class exeSearchTerminalData: public BaseCmd
{
public:
    exeSearchTerminalData(sp_gateway *m):BaseCmd(m){
        m_CmdName = "SetTerminalData";
        m_Cmd = CMD_T2P_ASKSETTERMINALDATA;
    }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};

/*设置终端参数*/
class exeSetTerminalData: public BaseCmd
{
public:
    exeSetTerminalData(sp_gateway *m):BaseCmd(m){
        m_CmdName = "SetTerminalData";
        m_Cmd = CMD_P2T_SETTERMINALDATAACK+1;
}
private:
public:
    int ack_cmd(void *param);

    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

};

/*终端控制*/
class exeTerminalDataControl: public BaseCmd
{
public:
    exeTerminalDataControl(sp_gateway *m):BaseCmd(m){
        m_CmdName = "SetTerminalData";
        m_Cmd = CMD_P2T_TERMINALCONTROL+1;
    }
private:
public:
    int ack_cmd(void *param);

    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

};


/*查询指定终端参数*/
class exeSearchSelectTerminalData: public BaseCmd
{
public:
    exeSearchSelectTerminalData(sp_gateway *m):BaseCmd(m){
        m_CmdName = "SetTerminalData";
        m_Cmd = CMD_P2T_SERACHSELECTTERMINALDATA+1;
    }
private:
public:
    int ack_cmd(void *param);

    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

};
#endif // EXESETTERMINALDATA_H
