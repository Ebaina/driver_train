﻿#ifndef EXETERMINALCONTROL_H
#define EXETERMINALCONTROL_H
#include "stdtype.h"
#include "CmdBase.h"
#include "exedatapass.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
*常量有up和down 为平台下发指令
**********************/
#define CMD_P2T_SETTERMINALAPPDATA_DOWN  0x8501
#define CMD_T2P_SETTERMINALAPPDATA_UP    0x0501
#define CMD_T2P_SETTERMINALAPPDATA_UP_NEW    0x7501
/*************************************************
*A.4.2.4　计时终端控制类消息
*A.4.2.4.1　设置计时终端应用参数
*透传消息ID：0x8501
*应答属性：0x01
*服务器端使用此消息设置计时终端的驾驶培训业务参数，设置计时终端应用参数消息数据格式见表B.56。
*表A.56　设置计时终端应用参数消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	参数编号	BYTE	参数编号与后续的字段编号一致，定义如下：
************************************************0：设置所有已定义的参数；
************************************************1：定时拍照时间间隔；
************************************************2：照片上传设置；
************************************************3：是否报读附加消息；
************************************************4：熄火后停止学时计时的延时时间；
************************************************5：熄火后GNSS数据包上报间隔；
************************************************6：熄火后教练自动登出的延时时间；
************************************************7：重新验证身份时间间隔；
******************************************220-255：自定义
*1	定时拍照时间间隔	BYTE	单位：min，默认值15。
*在学员登录后间隔固定时间拍摄照片。
*2	照片上传设置	BYTE 0：不自动请求上传；
********************1：自动请求上传
*3	是否报读附加消息	BYTE	1：自动报读；2：不报读。
*控制是否报读消息中的附加消息，如果下行消息中指定了是否报读，则遵循该消息的设置执行。
*4	熄火后停止学时计时的延时时间	BYTE	单位：min
*5	熄火后GNSS数据包上传间隔	WORD	单位：s，默认值3600，0表示不上传
*7	熄火后教练自动登出的延时时间	WORD	单位：min，默认值150
*9	重新验证身份时间	WORD	单位：min，默认值30
*11	教练跨校教学	BYTE	1：允许，默认值
******************** 2：禁止，默认值
*12	学员跨校学习	BYTE	1：允许，默认值
******************** 2：禁止
*13	响应平台同类消息时间间隔	WORD	单位：s，在该时间间隔内对平台发送的多次相同ID消息可拒绝执行回复失败
*******************************************************/
typedef struct{
wis_u8  datasetid;//0	参数编号	BYTE	参数编号与后续的字段编号一致，定义如下：
wis_u8  setdataspacetime;//1	定时拍照时间间隔	BYTE	单位：min，默认值15。
wis_u8  uploadphotoset;//2	照片上传设置	BYTE	0：不自动请求上传；
wis_u8  isreadaddcontent;//3	是否报读附加消息	BYTE	1：自动报读；2：不报读。
wis_u8  misfireenddelaytime;//4	熄火后停止学时计时的延时时间	BYTE	单位：min
wis_u16  misfireupgnssspace;//5	熄火后GNSS数据包上传间隔	WORD	单位：s，默认值3600，0表示不上传
wis_u16  misfirecoachlogoutdelaytime;//7	熄火后教练自动登出的延时时间	WORD	单位：min，默认值150
wis_u16  recheckidentitytime;//9	重新验证身份时间	WORD	单位：min，默认值30
wis_u8  coachcrosstech;//11	教练跨校教学	BYTE	1：允许，默认值
wis_u8  learnercrosslearn;//12	学员跨校学习	BYTE	1：允许，默认值
wis_u16  ackspacetime;//13	响应平台同类消息时间间隔	WORD	单位：s，在该时间间隔内对平台发送的多次相同ID消息可拒绝执行回复失败
}__attribute__((packed, aligned(1)))  Setterminalappdata_Down;//通信设置


/*************************************************
*A.4.2.4.2　设置计时终端应用参数应答
*透传消息ID：0x0501
*终端使用此消息应答计时平台下发的设置计时终端应用参数消息，设置计时终端应用参数应答消息数据格式见表B.57。
*
*表A.57　设置计时终端应用参数应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	应答代码	BYTE	1：设置成功
*2：设置失败
*******************************************************/
typedef struct{
wis_u8  ackdata;//0	应答代码	BYTE	1：设置成功
}__attribute__((packed, aligned(1)))  Setterminalappdata_Up;//通信设置



#define CMD_P2T_SETFORBIDTRAIN_DOWN  0x8502
#define CMD_T2P_SETFORBIDTRAIN_UP    0x0502
#define CMD_T2P_SETFORBIDTRAIN_UP_NEW    0x7502
/*************************************************
*A.4.2.4.3　设置禁训状态
*透传消息ID：0x8502
*应答属性:0x01
*服务器端使用此消息设置计时终端的禁训状态，设置禁训状态消息数据格式见表B.58。
*表A.58　设置禁训状态消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	禁训状态	BYTE	1：可用，默认值；
*2：禁用
*1	提示消息长度	BYTE	长度为n，无提示消息则为0
*2	提示消息内容	STRING(n)	“可用”状态
*******************************************************/
typedef struct{
wis_u8  forbidtrainstatus;//0	禁训状态	BYTE	1：可用，默认值；
wis_u8  promptinfolength;//1	提示消息长度	BYTE	长度为n，无提示消息则为0
wis_u8  promptinfocontent[40];//2	提示消息内容	STRING(n)	“可用”状态
}__attribute__((packed, aligned(1)))  Setforbidtrain_Down;//通信设置


/*************************************************
*A.4.2.4.4　设置禁训状态应答
*透传消息ID：0x0502
*终端端使用此消息应答计时平台下发的设置禁训状态消息，设置禁训状态应答消息数据格式见表B.59。
*表A.59　设置禁训状态应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	执行结果	BYTE	0：默认应答；
*1：设置成功；
*2：设置失败
*1	禁训状态	BYTE	1：可用，默认值
*2：禁用
*2	提示消息长度	BYTE	长度为n，无提示消息则为0
*3	提示消息内容	STRING(n)	“可用”状态
*******************************************************/


typedef struct{
wis_u8  operateresult;//0	执行结果	BYTE	0：默认应答；
wis_u8  forbidtrainstatus;//1	禁训状态	BYTE	1：可用，默认值
wis_u8  promptinfolength;//2	提示消息长度	BYTE	长度为n，无提示消息则为0
wis_u8  promptinfocontent[40];//3	提示消息内容	STRING(n)	“可用”状态
}__attribute__((packed, aligned(1)))  Setforbidtrain_Up;//通信设置






#define CMD_P2T_SEARCHTERMINALAPPDATA_DOWN  0x8503
#define CMD_T2P_SEARCHTERMINALAPPDATA_UP    0x0503
#define CMD_T2P_SEARCHTERMINALAPPDATA_UP_NEW    0x7503
/*************************************************
*A.4.2.4.5　查询计时终端应用参数
*透传消息ID：0x8503
*应答属性：0x01
*服务器端使用此消息查询计时终端的驾培业务参数，查询计时终端应用参数消息数据内容为空。
* *********************/




/*A.4.2.4.6　查询计时终端应用参数应答
*透传消息ID：0x0503
*计时终端使用此消息回复计时平台下发的查询计时终端应用参数消息，查询计时终端应用参数消息数据格式见表B.60。
*******************************************************/
/*************************************************
*表A.60　查询计时终端应用参数应答消息数据格式
*起始字节	字段	数据类型	描述及要求
*0	参数编号查询结果	BYTE	0，无实际意义成功；
*1，失败
*1	定时拍照时间间隔	BYTE	单位：min，默认值:15。
*在学员登录后间隔固定时间拍摄照片
*2	照片上传设置	BYTE	0：不自动请求上传；
*1：自动请求上传
*3	是否报读附加消息	BYTE	1：自动报读；2：不报读
*控制是否报读消息中的附加消息
*4	熄火后停止学时计时的延时时间	BYTE	单位：min
*5	熄火后GNSS数据包上传间隔	WORD	单位：s，默认值3600，0表示不上传
*7	熄火后教练自动登出的延时时间	WORD	单位：min，默认值150
*9	重新验证身份时间	WORD	单位：min，默认值30
*11	教练跨校教学	BYTE	1：允许
*2：禁止
*12	学员跨校学习	BYTE	1：允许
*2：禁止
*13	响应平台同类消息时间间隔	WORD	单位：s，在该时间间隔内对平台发送的多次相同ID消息可拒绝执行回复失败
*******************************************************/

typedef struct{
wis_u8  datasetsearchresult;//0	参数编号查询结果	BYTE	0，无实际意义成功；
wis_u8  setdataspacetime;//1	定时拍照时间间隔	BYTE	单位：min，默认值:15。
wis_u8  uploadphotoset;//2	照片上传设置	BYTE	0：不自动请求上传；
wis_u8  isreadaddcontent;//3	是否报读附加消息	BYTE	1：自动报读；2：不报读
wis_u8  misfireenddelaytime;//4	熄火后停止学时计时的延时时间	BYTE	单位：min
wis_u16  misfireupgnssspace;//5	熄火后GNSS数据包上传间隔	WORD	单位：s，默认值3600，0表示不上传
wis_u16  misfirecoachlogoutdelaytime;//7	熄火后教练自动登出的延时时间	WORD	单位：min，默认值150
wis_u16  recheckidentitytime;//9	重新验证身份时间	WORD	单位：min，默认值30
wis_u8  coachcrosstech;//11	教练跨校教学	BYTE	1：允许
wis_u8  learnercrosslearn;//12	学员跨校学习	BYTE	1：允许
wis_u16  ackspacetime;//13	响应平台同类消息时间间隔	WORD	单位：s，在该时间间隔内对平台发送的多次相同ID消息可拒绝执行回复失败
}__attribute__((packed, aligned(1)))  Searchterminalappdata_Up;//通信设置


//Setforbidtrain_Down


class exeSetterminalappdata: public BaseCmd
{
public:
    exeSetterminalappdata(sp_gateway *m):BaseCmd(m){
        m_CmdName = "setterminalappdata";
        m_Cmd = CMD_T2P_SETTERMINALAPPDATA_UP_NEW;
    }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};


class exeSetforbidtrain: public BaseCmd
{
public:
    exeSetforbidtrain(sp_gateway *m):BaseCmd(m){
        m_CmdName = "setforbidtrain";
        m_Cmd = CMD_T2P_SETFORBIDTRAIN_UP_NEW;
    }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};


class exeSearchterminalappdata: public BaseCmd
{
public:
    exeSearchterminalappdata(sp_gateway *m):BaseCmd(m){
        m_CmdName = "searchterminalappdata";
        m_Cmd = CMD_T2P_SEARCHTERMINALAPPDATA_UP_NEW;
    }
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};

#endif // EXETERMINALCONTROL_H
