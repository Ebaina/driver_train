﻿#ifndef CMD_H
#define CMD_H
#include "CmdBase.h"
typedef struct CMD_PIPE
{
    int ts_times;            //主动的发送次数大多为3次，中心下发指令方式，times =1
    unsigned short ts_cmd;   //发送命令，或应答中心
    unsigned short  ts_seq;   //发送命令序号，或应答中心命令
    char ts_content[1024];    //发往消息的消息体
    unsigned short ts_bodyLength;  //发往中心的消息体长度
    int ts_Counter;
    bool ts_enable;          // 发往中心指令使能
    void *p_tsCmd;         //命令执行器
    bool ts_needAck;          //指示这条指令是否需要应答，中心请求和设备主动发均经过Process
    int ts_RemoveConter;
    bool multyflag;//分包标志
    unsigned short mainpackgesize;//分包大小
    unsigned short packgeindex ;//序列号
    bool encodeflag ;//加密标志
    bool is_photo;     //是否是照片数据
    std::string   ts_sendtime; //发送时间
    bool ts_isoffline;//是否是离线数据
}stSendCmdPiPe;

typedef struct
{
    int td_tims;
    unsigned short td_cmd;   //发往设备的指令，或应答设备的指令
    unsigned short td_seq;   //发往设备的序号，或应答设备的序号
    char td_content[1024];    //发往设备的消息体
    unsigned short td_bodyLength;  //发往设备的消息体长度
    int td_Counter;
    bool td_ackEnable;       //等待应答使能
    void *p_tdCmd;        //命令执行器
    bool td_isAck;           //确定改指令是中心的应答，还是需要设备应答数据
    bool multyflag;//分包标志
    unsigned short mainpackgesize;//分包大小
    unsigned short packgeindex ;//序列号
    bool encodeflag ;//加密标志
    bool td_Enable;   //该位置是否有有效数据
}stRecvCmdPiPe;

#endif // CMD_H

