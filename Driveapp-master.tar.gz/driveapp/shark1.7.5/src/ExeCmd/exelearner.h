﻿#ifndef EXELEARNER_H
#define EXELEARNER_H

#include "stdtype.h"
#include "CmdBase.h"
#include "exedatapass.h"

/***********T2P*********
*T:Terminal  终端
*P:Platform  平台
**********************/
/* **********************************************
*起始字节	字段	数据类型	描述及要求
*0	学员编号	BYTE[16]	统一编号
*16	当前教练编号	BYTE[16]	统一编号
*32	培训课程	BCD[5]	课程编码见A4.2
*37	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
*41	基本GNSS数据包	BYTE[28]	见表B.21
***********************************************/
typedef struct LearnerLogin_Up{//学员登陆消息
    wis_u8 learnerid[16] ;// 0   学员员编号   BYTE[16]    统一编号
    wis_u8 learnerdentityid[16];// 16	当前教练编号	BYTE[16]	统一编号
    wis_u8 trainlesson[5];//  32	培训课程	BCD[5]	课程编码见A4.2
    wis_u8 lessonid[4];//37  课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
    wis_u8 gnssdata[28] ;//41	基本GNSS数据包	BYTE[28]	见表B.21
}  __attribute__((packed, aligned(1))) LearnerLogin_Up;

/**********************************************
*起始字节	字段          数据类型	描述及要求
*0	登录结果代码         BYTE	    1：登录成功；
********************************2：无效的学员编号；
********************************3：禁止登录的学员；
********************************4：区域外教学提醒；
********************************5：准教车型与培训车型不符；
********************************9：其他错误
*1	学员编号             BYTE[16]	统一编号
*17	总培训学时            WORD	单位：min
*19	当前培训部分已完成学时	WORD	单位：min
*21	总培训里程            WORD	单位：1/10km
*23	当前培训部分已完成里程	WORD	单位：1/10km
*25	是否报读附加消息      BYTE     0：不必报读；
********************************1：需要报读
*26	附加消息长度	BYTE            长度为n，无附加数据则为0
*27	附加消息	STRING              最大254Bytes
**********************************************/
typedef struct LearnerLogin_down{//学员登录消息应答
    wis_u8  loginresult;   //0   登录结果    BYTE          结果{1：登录成功；   2：无效的学员员编号； 3：准教车型不符；  9：其他错误}
    wis_u8  learnerid [16];//1   学员编号    BYTE[16] 统一编号
    wis_u16 maintraintime;//17	总培训学时	WORD	单位：min
    wis_u16 finishtime;//19	当前培训部分已完成学时	WORD	单位：min
    wis_u16 maintrainmile;//21	总培训里程	WORD	单位：1/10km
    wis_u16 finishmile;//23	当前培训部分已完成里程	WORD	单位：1/10km
    wis_u8  isreadaddtext ;//25	是否报读附加消息	BYTE	0：不必报读；  1：需要报读
    wis_u8  addtextlength ;//26	附加消息长度	BYTE	长度为n，无附加数据则为0
    wis_u8  addtextcontent[254];//27	附加消息	STRING	最大254Bytes
}  __attribute__((packed, aligned(1))) LearnerLogin_down;

/******************************************
*起始字节	字段	            数据类型	    描述及要求
*0	   学员编号	        BYTE[16]	统一编号
*16	   登出时间	        BCD[6]      YYMMDDhhmmss
*22	   学员该次登录总时间	WORD        单位：min
*24	   学员该次登录总里程	WORD        单位：1/10km
*26	   课堂ID	        DWORD       标识学员的一次培训过程，计时终端自行使用
*30	   基本GNSS数据包   	BYTE[28]	见表B.21
****************************************88*/
typedef struct LearnerLogout_Up{//学员登出消息
    wis_u8  learnerid[16];//0	学员编号	BYTE[16]	统一编号
    wis_u8  logoutime[6];//16	登出时间	BCD[6]	YYMMDDhhmmss
    wis_u16 loginmainmtime;//22	学员该次登录总时间	WORD	单位：min
    wis_u16 loginmainmile;//24	学员该次登录总里程	WORD	单位：1/10km
    wis_u32 lessonid;//26	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
    wis_u8  gnssdata[28];//30	基本GNSS数据包	BYTE[28]	见表B.21
}  __attribute__((packed, aligned(1))) LearnerLogout_Up;

/***********************************************
*起始字节	字段	数据类型	描述及要求
*0	登录结果代码	BYTE	1：登录成功；
************************2：无效的学员编号；
************************3：禁止登录的学员；
************************4：区域外教学提醒；
************************5：准教车型与培训车型不符；
************************9：其他错误
*1	学员编号	BYTE[16]	统一编号
*17	总培训学时	WORD	单位：min
*19	当前培训部分已完成学时	WORD	单位：min
*21	总培训里程	WORD	单位：1/10km
*23	当前培训部分已完成里程	WORD	单位：1/10km
*25	是否报读附加消息	BYTE	0：不必报读；
****************************1：需要报读
*26	附加消息长度	BYTE	长度为n，无附加数据则为0
*27	附加消息	STRING	最大254Bytes
************************************************/
typedef struct LearnerLogout_Down{//学员登出消息应答
    wis_u8  logoutresult;//0	登录结果代码	BYTE	1：登录成功；
    wis_u8  learnerid[16];//1	学员编号	BYTE[16]	统一编号
//    wis_u16 maintraintime;//17	总培训学时	WORD	单位：min
//    wis_u16 finishtime;//19	当前培训部分已完成学时	WORD	单位：min
//    wis_u16 maintrainmile;//21	总培训里程	WORD	单位：1/10km
//    wis_u16 finishmile;//23	当前培训部分已完成里程	WORD	单位：1/10km
//    wis_u8  isreadaddtext;//25	是否报读附加消息	BYTE	0：不必报读；
//    wis_u8  addtextlength;//26	附加消息长度	BYTE	长度为n，无附加数据则为0
//    wis_u8  addtextcontent[254];//27	附加消息	STRING	最大254Bytes
}  __attribute__((packed, aligned(1))) LearnerLogout_Down;



/************************************************************
*起始字节	字段	数据类型	描述及要求
*0	学时记录编号	BYTE[26]	见A4.1
*26	上报类型	BYTE	0x01：自动上报；0x02：应中心要求上报。如果是应中心要求上传，则本次上传作业的作业序号保持与请求上传消息的作业序号一致，后续分段上传的作业序号也保持一致。
*27	学员编号	BYTE[16]	统一编号
*43	教练编号	BYTE[16]	统一编号
*59	课堂ID	DWORD	标识学员的一次培训过程，计时平台自行使用
*63	记录产生时间	BCD[3]	格式： HHmmss，1min最后1s的时间
*66	培训课程	BCD[5]	课程编码，见A4.2
*71	记录状态	BYTE	0：正常记录；
*****************1：异常记录
*72	最大速度	WORD	1min内车辆达到的最大卫星定位速度，1/10km/h
*74	里程	WORD	车辆1min内行驶的总里程，1/10km，
*76	附加GNSS数据包	BYTE[328]	1min内第30s的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
***************************************************************/

typedef struct  ReportLearnMessage_Up{
 wis_u8  learnrecordid[26];//0	学时记录编号	BYTE[26]	见A4.1
 wis_u8  reporttype;//26	上报类型	BYTE	0x01：自动上报；0x02：应中心要求上报。如果是应中心要求上传，则本次上传作业的作业序号保持与请求上传消息的作业序号一致，后续分段上传的作业序号也保持一致。
 wis_u8  learnerid[16];//27	学员编号	BYTE[16]	统一编号
 wis_u8  coachid[16];//43	教练编号	BYTE[16]	统一编号
 wis_u32 lessonid;//59	课堂ID	DWORD	标识学员的一次培训过程，计时平台自行使用
 wis_u8  recordtime[3];//63	记录产生时间	BCD[3]	格式： HHmmss，1min最后1s的时间
 wis_u8  trainlesson[5];//66	培训课程	BCD[5]	课程编码，见A4.2
 wis_u8  recordstatus;//71	记录状态	BYTE	0：正常记录；
 wis_u16  maxspeed;//72	最大速度	WORD	1min内车辆达到的最大卫星定位速度，1/10km/h
 wis_u16  milerecord;//74	里程	WORD	车辆1min内行驶的总里程，1/10km，
 wis_u8   addgnssdata[38];//76	附加GNSS数据包	BYTE[38]	1min内第30s的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
}  __attribute__((packed, aligned(1))) ReportLearnMessage_Up;



/*******************************
*起始字节	字段	数据类型	描述及要求
*0	查询方式	BYTE	1：按时间上传；
*2：按条数上传
*1	查询起始时间	BCD[6]	YYMMDDhhmmss
*7	查询终止时间	BCD[6]	YYMMDDhhmmss
*13	查询条数	WORD
**********************************/
typedef struct  AskReportLearnMessage_Down{
wis_u8 searchtype;//0	查询方式	BYTE	1：按时间上传；
                                         //2：按条数上传
wis_u8 searchstart[6];//1	查询起始时间	BCD[6]	YYMMDDhhmmss
wis_u8 searchend[6];//7	查询终止时间	BCD[6]	YYMMDDhhmmss
wis_u16 searchnumbers;//13	查询条数	WORD
}  __attribute__((packed, aligned(1))) AskReportLearnMessage_Down;



/*******************************
*起始字节	字段	数据类型	描述及要求
*0	执行结果	BYTE	1：查询的记录正在上传；
*****************2：SD卡没有找到；
*****************3：执行成功，但无指定记录；
*****************4：执行成功，稍候上报查询结果
**********************************/

typedef struct  AskReportLearnMessage_Up{
wis_u8 operateresult;	//执行结果	BYTE	1：查询的记录正在上传；
}  __attribute__((packed, aligned(1))) AskReportLearnMessage_Up;


#define  CMD_T2P_REPORTTRAINRECORD       0x0203   //上报学时记录；
#define  CMD_T2P_REPORTTRAINRECORD_NEW       0x7203   //上报学时记录；
class exeReportTrainRecord : public BaseCmd
{
public:
    exeReportTrainRecord(sp_gateway *m):BaseCmd(m){
        m_CmdName = "reporttrainrecord";
        m_Cmd = CMD_T2P_REPORTTRAINRECORD_NEW;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);
};

#define  CMD_P2T_ASK_REPORTTRAINRECORD_DOWN       0x8205   //命令上报学时记录ACK；
#define  CMD_T2P_ASK_REPORTTRAINRECORD_UP       0x0205   //命令上报学时记录；
#define  CMD_T2P_ASK_REPORTTRAINRECORD_UP_NEW       0x7205   //命令上报学时记录；
class exeAskReportTrainRecord  : public BaseCmd
{
public:
    exeAskReportTrainRecord (sp_gateway *m):BaseCmd(m){
        m_CmdName = "askReporttrainrrecord";
        m_Cmd = CMD_T2P_ASK_REPORTTRAINRECORD_UP_NEW;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};


#define  CMD_T2P_LERNERLOGIN       0x0201   //学员登陆
#define  CMD_T2P_LERNERLOGIN_NEW      0x7201   //学员登陆
#define  CMD_P2T_LERNERLOGIN       0x8201   //学员登陆应答
class exeLearnerLogin : public BaseCmd
{
public:
    exeLearnerLogin(sp_gateway *m):BaseCmd(m){
        m_CmdName = "learnerLogin";
        m_Cmd = CMD_T2P_LERNERLOGIN_NEW;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};



#define  CMD_T2P_LERNERLOGOUT       0x0202  //学员登出
#define  CMD_T2P_LERNERLOGOUT_NEW       0x7202  //学员登出
#define  CMD_P2T_LERNERLOGOUT       0x8202  //学员登出应答
class exeLearnerLogout : public BaseCmd
{
public:
    exeLearnerLogout(sp_gateway *m):BaseCmd(m){
        m_CmdName = "LearnerLogout";
        m_Cmd = CMD_T2P_LERNERLOGOUT_NEW;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};


#endif // EXELEARNER_H
