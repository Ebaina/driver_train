﻿#include "exephotoupload.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include "app_globl.h"
#include "Tracer.h"
#include"File.h"
#include <QDateTime>
#include"Utils.h"
#include"photosave.h"
/*查询照片结果*/
int exeSearchphotoresult::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeSearchphotoresult::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_SEARCHPHOTORESULT_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeSearchphotoresult::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    Tracer::getInstance()->printHex(1,"查询结果",buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeSearchphotoresult::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Searchphotoresult_Down  searchresult_info;
    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
    //    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    searchresult_info.ackdata = p->td_content[++i];
    if(searchresult_info.ackdata == 0)
    {
        TRACE_INFO("默认应答\n");
    }
    if(searchresult_info.ackdata == 1)
    {
        TRACE_INFO("1：停止上报，终端收到“停止上报”应答后则停止查询结果的上报。\n");
    }

    return 0;
}


/*上传指定照片*/
exeUploadselectphoto::~exeUploadselectphoto()
{

}

int exeUploadselectphoto::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeUploadselectphoto::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_UPLOADSELECTPHOTO_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeUploadselectphoto::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeUploadselectphoto::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Uploadselectphoto_Down  selectphoto_info;
    Datapassdown  datapass_info;
    Uploadselectphoto_Up  minfo;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
    //    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    for(j=0;j<sizeof(selectphoto_info.photonum);j++)
    {
        selectphoto_info.photonum[j] = p->td_content[++i];
    }
    Tracer::getInstance()->printHex(1," 查询指定照片编号：",(char *)selectphoto_info.photonum,sizeof(selectphoto_info.photonum));

    char *photoBuffer;
    int  photoLen;
    photoLen = 100*1024;
    photoBuffer = new char [photoLen];
    std::string start=  Utils::code2string((char *)selectphoto_info.photonum,sizeof(selectphoto_info.photonum));
    Uploadphotoinit_Up photoinit;
    Uploadphotoinit_Sql  *photoinitsql ;
    photoinitsql  =Photosave::getInstance()->selectMessageByTime(start );

    if(photoinitsql!=NULL){
        minfo.ackdata = 0x00;// 0：找到照片，稍候上传

     }else{
         minfo.ackdata = 0x01;// 0：找到照片，稍候上传
    }
     appcon.do_upload_selectphoto(minfo);
    Utils::printString(PrintLevel::INFO,"路径："+photoinitsql->photopath);
    photoinit= Photosave::getInstance()->uploadInitSql2Uploadphotoinit(photoinitsql );
//    photoinit.photoeventtype=0;
//    appcon.do_upload_photo_init(photoinit);
//    sleep(3);
//    Utils::printString(PrintLevel::INFO,"路径："+photoinitsql->photopath);
//    int sizephoto=  appcon.GetPhotodata(start,photoinitsql->photopath,&photoBuffer[0],photoLen);

//    appcon.MultPacge_Tools(start,photoBuffer,sizephoto);
    char photo_temp[11];
    photo_temp[10]=0x00;
    memcpy(photo_temp, photoinit.photonum,sizeof(photoinit.photonum));
    int  sizephoto=  appcon.GetPhotodata(photo_temp, photoinitsql->photopath ,& photoBuffer[0],photoLen);
    photoinit.camerachannel = 0x00;
    photoinit.photosize =0x01;
    photoinit.photoeventtype = 0x00;
    int sizetemp=( sizephoto+293)/700;
    if((( sizephoto+293)%700)==0){
        photoinit.packgesize = htons(sizetemp);
    }else{
        photoinit.packgesize = htons(sizetemp+1);
    }
    photoinit.photodatasize = htonl(sizephoto);
    photoinit.lessonid = htonl(TrainLessonId);
    photoinit.faceidentifyreliability = 0x00;
    appcon.do_upload_photo_init(photoinit);
    sleep(4);
    std::string  timeRecord="中心查找指定照片数据 :";
    std::string time=Utils::getCurrentTime();
    Utils::printString(PrintLevel::INFO,timeRecord+time);//

    appcon.MultPacge_Tools(photo_temp,photoBuffer,sizephoto);

    delete []photoBuffer;//delete photoinitsql;
    return 0;
}

/*上传照片初始化*/
int exeUploadphotoinit::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeUploadphotoinit::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_UPLOADPHOTOINIT_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeUploadphotoinit::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    Utils::LogSave("photosend.txt","照片初始化",buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeUploadphotoinit::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Uploadphotoinit_Down  upinit_info;
    Datapassdown  datapass_info;
    int i =17;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
    //    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    upinit_info.ackdata = p->td_content[++i];
    if(upinit_info.ackdata == 0)
    {
        //        TRACE_INFO("接受上传\n");
        TRACE_INFO_CLASS("\n接受上传\n");
    }
    if(upinit_info.ackdata == 255)
    {
        TRACE_INFO_CLASS("\n拒绝上传，终端收到“拒绝上传”应答后则停止此照片的上传。\n");
    }

    return 0;
}


/*上传照片数据包*/
int exeUploadphotodata::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        //        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            //               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        //         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeUploadphotodata::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_UPLOADPHOTODATA_UP_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeUploadphotodata::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[1024];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16-4;                                        //分包上传
    m_head.MsgDiv = 1;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    unsigned char data2[2];
    data2[0]=(p->mainpackgesize)>>8;
    data2[1]=p->mainpackgesize;
    unsigned   char  data3[2];
    data3[0]=(p->packgeindex)>>8;
    data3[1]=p->packgeindex;

    memcpy(&p->ts_content[16],(char *)& data2[0],2);
    memcpy(&p->ts_content[18],(char *)& data3[0],2);
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    // Tracer::getInstance()->printHex(1,"照片发送",buf,length);
    Utils::LogSave("photosend.txt","照片发送",buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeUploadphotodata::ack_cmd(void *param)
{
    return 0;
}
