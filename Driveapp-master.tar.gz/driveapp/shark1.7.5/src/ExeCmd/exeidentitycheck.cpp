﻿#include "exeidentitycheck.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"

/*请求身份认证信息*/
int exeAskIdentityCheck::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeAskIdentityCheck::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_IDENTITYCHECKDATA_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeAskIdentityCheck::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeAskIdentityCheck::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Identitycheckdata_Down checkdata_info;
    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    checkdata_info.drivingpackgenum = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);  //驾培包序号

    checkdata_info.searcgresult = p->td_content[++i];   //查询结果
    if(checkdata_info.searcgresult = 0)
    {
        printf("成功\n");
    }
    else if(checkdata_info.searcgresult = 1)
    {
        printf("失败\n");
        return 0;
    }

    checkdata_info.identitychecklenth = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);  //身份认证信息长度

    for(j=0;j<checkdata_info.identitychecklenth;j++)
    {
        checkdata_info.identitycheckdata[j] = p->td_content[++i];   //身份认证信息内容
    }

    return 0;
}



/*请求统一编号信息*/
int exeAskunifynum::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_DATAPASSUP);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
      for(int i =7;i>len-1;i--)   //前向 补0
      {
               m_MsgHead.Dev_PhoneNum[i] = 0x00;
               wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
      }
      }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
         wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段
}

int exeAskunifynum::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_ASKNIFYNUM_NEW;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return sizeof(m_MsgHead);
}

int exeAskunifynum::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

int exeAskunifynum::ack_cmd(void *param)
{
    stRecvCmdPiPe *p  = (stRecvCmdPiPe*)param;
    Askunifynum_Down askuniform_info;
    Datapassdown  datapass_info;
    int i =17;
    int j = 0;
    datapass_info.messdata.messageid = ((p->td_content[i]&0xff)<<8 )|(p->td_content[++i]&0xff);   //消息ID
    datapass_info.messdata.extandmessagetype = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //扩展消息类型
    datapass_info.messdata.drivingpackgenum = ((p->td_content[++i]&0xff)<<8 )|(p->td_content[++i]&0xff);  //驾驶包序号

    for(int j=0;j<sizeof(datapass_info.messdata.terminalid);j++)
    {
        datapass_info.messdata.terminalid[j] = p->td_content[++i];   //计时终端编号
    }
    datapass_info.messdata.datalength = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000)| ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //数据长度
//    datapass_info.messdata.datalength = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);

    askuniform_info.driveingpackagenum = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);  //驾培包序号

    askuniform_info.searchresult = p->td_content[++i];   //查询结果
    if(askuniform_info.searchresult = 0)
    {
        printf("成功\n");
    }
    else if(askuniform_info.searchresult = 1)
    {
        printf("失败\n");
        return 0;
    }

    for(j=0;j<sizeof(askuniform_info.uniformnumber);j++)
    {
        askuniform_info.uniformnumber[j] = p->td_content[++i];     //统一编号
    }
    for(j=0;j<sizeof(askuniform_info.permitedcartype);j++)
    {
        askuniform_info.permitedcartype[j] = p->td_content[++i];   //准（教/考）车型   A1\A2\A3\B1\B2\C1\C2\C3\C4\D\E\F，非教学人员时用0x00填充
    }

    return 0;
}
