﻿#include "cmd_pipe.h"
#include <signal.h>
#include <semaphore.h>
#include "public.h"
#include "ManagerExe.h"
#include "CmdBase.h"
#include "cmd.h"
#include "app_globl.h"
#include "Tracer.h"
#include "Gpio.h"
#include "stdtype.h"
#include "Utils.h"
#include "offlinesave.h"
int CmdPP::UnTranMain_cmd(char *buf, int l, char *out , int l2)
{
    char my_xor =0;
    int len=0;
    l -= 2;                                          //去掉首尾
    if(l2 < l) return 0;
    for(int i=1;i<=l;i++)
    {
        if(buf[i] == 0x7d)
        {
            if(buf[i+1] == 0x01)
            {
                out[len] = 0x7d;
                len++;
                i ++;
            }
            if(buf[i+1] == 0x02)
            {
                out[len] = 0x7e;
                len++;
                i ++;
            }
        }
        else
        {
            out[len] = buf[i];
            len++;
        }
    }
    my_xor = out[len-1];
    if(my_xor == Xor(out,len-1))
    {
        l2 = len;
        //        TRACE_INFO("\nVerfy Receive Data OK!\n");
        return len-1;
    }
    return 0;
}

void CmdPP::init_pipe(void *param)
{
    p_gateway = (sp_gateway *) param;
    for(int i =0;i<sizeof(m_cmdlist)/sizeof(stSendCmdPiPe);i++)
    {
        m_cmdlist[i].ts_enable = false;
        m_cmdlist[i].is_photo = false;
    }
    for(int i=0;i<sizeof(m_cmdRecvlist)/sizeof(stRecvCmdPiPe);i++)
    {
        m_cmdRecvlist[i].td_ackEnable =false;
    }
    stCmdCount  =  0;
    pthread_create(&p_Thread,0,Timer_RefreshThread,this);
    pthread_create(&p_ThreadRecive,0,Timer_RefreshThreadReceive,this);

}

int CmdPP::Parser_Cmd(char *buf, int len,char *pos ,int *len2)
{

    int flags=0;
    int len3 = 0;
    for( int i = 0 ; i <len ; i++ )
    {
        if( buf[i] == 0x7e )
        {
            flags++;
            if(flags==1)
            {
                *len2 = i;
            }
        }
        switch(flags)
        {
        case 1:
            len3++;
            break;
        case 2:
            if( len3 < 17  )
            {
                p_gateway->SeekPoint(i+1);   //数据异常包
                TRACE_INFO("数据异常包\n");
                return 0;
            }
            else
            {
                len3++;
                p_gateway->SeekPoint(i+1);
                return len3;
            }
            break;
        default:
            break;
        }
    }
    return 0;
}

char CmdPP::Xor(char *buf, int len)
{
    char ret =0;
    for(int i =0;i<len;i++)
    {
        ret = ret ^ buf[i];
    }
    return ret;
}

int CmdPP::Proc_Ack_Data()
{
    char out[1024];
    int len,l;
    char buf[1024];
    char *p_b;
    int len2=0;
    unsigned long ct =0;
    int count = 0;
    int pos = 0;
    int len3 =sizeof(out);
    int len4 = 0;
    int commid=0;
    ct  = get_tick_count() + 100;
    len = p_gateway->ReadFifo(buf+pos,1024-pos);
    if(len > 0)
    {
        pos = pos + len;
//        Utils::LogSave("fifodata.txt","fifoData:",buf,len);
        l = Parser_Cmd(buf,len,p_b,&len2);  //找一包数据
        if(l == 0)       //没有找到数据
        {
            TRACE_INFO("没有找到数据 \n");
            return 0;
        }
        else
        {
            len4 = UnTranMain_cmd(&buf[len2], l, out, len3);
            if(len4 != 0 )
            {
                commid=   out[1]<<8|out[2];
                stRecvCmdPiPe data;
                memcpy(data.td_content,out,len4);
                data.td_bodyLength = len4;
                data.td_seq = out[13]<<8|out[14];
                data.td_cmd = commid;
                //                    TRACE_CYAN("\nFlowID=%04x=CmD=%04x\n",data.td_seq,data.td_cmd);
                Receive_OneCmd(data);
            }
        }
    }
    count ++;
    return 0;
}

void * CmdPP::Timer_RefreshThread(void *param)
{
    CmdPP * p = (CmdPP *)param;
    int timercounts =0;
    while (true)
    {
        timercounts++;
        if(timercounts==10)
        {
            for(int i = 0;i<sizeof(m_cmdlist)/sizeof(stSendCmdPiPe);i++)
            {
                //1, remove one cmd
                if((p->m_cmdlist[i].ts_enable==true) && p->m_cmdlist[i].ts_times <=0)
                {
                    p->m_cmdlist[i].ts_RemoveConter++;
                    if(p->m_cmdlist[i].ts_RemoveConter >= 12)
                    {
                        p->m_cmdlist[i].ts_RemoveConter =0;
                        p->m_cmdlist[i].ts_enable = false;
                        p->m_cmdlist[i].ts_needAck = false;
                    }
                }
                //刷新几次清出命令管理器   ts_times
                if((p->m_cmdlist[i].ts_enable==true) && p->m_cmdlist[i].ts_times>0) //命令列表，使能某个指令
                {
                    p->m_cmdlist[i].ts_Counter ++;
                    if(p->m_cmdlist[i].ts_Counter >= 12)
                    {
                        //2017-4-12 add
                        //if(p->stCmdCount >0 && (p->m_cmdlist[i].is_photo == true)) continue;   // 队列中的照片优先级最慢
                        //wlog(WIS_INFO,"Get  Exe cmd = %d",p->m_cmdlist[i].ts_cmd);
                        TRACE_ERR("\n收到命令字:%04x\n",p->m_cmdlist[i].ts_cmd);
                        BaseCmd *pp = (BaseCmd *)  find_exe(p->m_cmdlist[i].ts_cmd);
                        if(pp != NULL)
                        {
                            int cmd_temp=p->m_cmdlist[i].ts_cmd;
                            switch(cmd_temp){
                            case CMD_T2P_AUTHORITY:
                                if(IsAuthority==0)
                                {
                                    pp->exe_cmd(&p->m_cmdlist[i]);
                                }
                                break;
                            case CMD_T2P_REGISTER:
                                pp->exe_cmd(&p->m_cmdlist[i]);
                                break;
                            case CMD_T2P_BEATHEART:
                                pp->exe_cmd(&p->m_cmdlist[i]);
                                break;
                            default:
                                if(IsAuthority==1)
                                {
                                    pp->exe_cmd(&p->m_cmdlist[i]);
                                }
                                break;
                            }
                        }
                        else
                        {
                            wlog(WIS_INFO,"get invalid point");
                        }

                        p->m_cmdlist[i].ts_times--;
                        p->m_cmdlist[i].ts_Counter = 0;

                        //          离线保存
                        if((p->m_cmdlist[i].ts_times == 0)&&(p->m_cmdlist[i].ts_isoffline==false)&&(TcpLinkConnectFlag == 0))
                        {
                            p->m_cmdlist[i].ts_enable = false ;
                            p->m_cmdlist[i].packgeindex = 0;
                            p->m_cmdlist[i].mainpackgesize = 0;
                            p->m_cmdlist[i].encodeflag = 0;
                            p->m_cmdlist[i].ts_isoffline = 1;
                            switch(p->m_cmdlist[i].ts_cmd)
                            {
                            case CMD_T2P_REPORTTRAINRECORD_NEW:
                                TRACE_CYAN("\n学时数据插入\n");
                                OfflineSave::getInstance()->insertMessage(p->m_cmdlist[i]);
                                break;
                            case CMD_T2P_LERNERLOGOUT_NEW:
                                TRACE_CYAN("\n学员登出数据插入\n");
                                OfflineSave::getInstance()->insertMessage(p->m_cmdlist[i]);
                                break;
                            case CMD_T2P_COACHLOGOUTCMD:
                                TRACE_CYAN("\n教练登出数据插入\n");
                                OfflineSave::getInstance()->insertMessage(p->m_cmdlist[i]);
                                break;
                            case CMD_T2P_POSITIONREPORT:
                                TRACE_CYAN("\n位置数据插入\n");
                                OfflineSave::getInstance()->insertMessage(p->m_cmdlist[i]);
                                break;
                            }
                        }
                        //离线保存
                    }
                }
                timercounts=0;
            }
            usleep(100000);
        }
    }
}
void * CmdPP::Timer_RefreshThreadReceive(void *param)
{
    CmdPP * p = (CmdPP *)param;

    while (true)
    {
        p->Proc_Ack_Data();
        for(int i =0;i<sizeof(p->m_cmdRecvlist)/sizeof(stRecvCmdPiPe);i++)
        {
            if(p->m_cmdRecvlist[i].td_ackEnable == true)
            {
                AckReciceEventListioner::getInstance()->handleEvent(p->m_cmdRecvlist[i]);
                Utils::LogSave("Getdata.txt","GetData:",p->m_cmdRecvlist[i].td_content,p->m_cmdRecvlist[i].td_bodyLength);
                p->m_cmdRecvlist[i].td_ackEnable = false;
            }
        }
        //        usleep(10000);
    }


}
void CmdPP::Receive_OneCmd(stRecvCmdPiPe data ){

    for(int i =0;i<sizeof(m_cmdRecvlist)/sizeof(stRecvCmdPiPe);i++)
    {
        if(m_cmdRecvlist[i].td_ackEnable == false)
        {
            m_cmdRecvlist[i].td_cmd = data.td_cmd;
            m_cmdRecvlist[i].td_seq = data.td_seq;
            m_cmdRecvlist[i].td_bodyLength = data.td_bodyLength;
            if(m_cmdRecvlist[i].td_bodyLength > 1024) return;
            memcpy(m_cmdRecvlist[i].td_content,data.td_content,data.td_bodyLength);
            m_cmdRecvlist[i].td_ackEnable = true;
            break;
        }
    }
}

int  CmdPP::checkFlowID(int tscmd,stRecvCmdPiPe data,int *flowid,int *cmdts)//返回值true是应答类，false 是非应答类的（下发的数据）
{
    switch (tscmd) {
    case CMD_P2T_COMMONDOWN_ACK:
        *flowid=((data.td_content[16]<<8)) | (data.td_content[17]);
        *cmdts=((data.td_content[18]<<8)) | (data.td_content[19]);
        return   FLOWID_CHECK_STATUS::COMMOND_TYPE;
        break;
    case CMD_P2T_DATAPASSDOWN:
        *flowid=(data.td_content[13]<<8)||data.td_content[14];
        *cmdts=((data.td_content[17]<<8)) | (data.td_content[18]);
        switch(*cmdts){
        case CMD_P2T_ASKTAKEPHOTONOW_DWON:
        case CMD_P2T_ASKSEARCHPHOTO_DOWN:
        case CMD_P2T_ASK_REPORTTRAINRECORD_DOWN:
            return   FLOWID_CHECK_STATUS::DOWN_TYPE;
            break;
        case CMD_P2T_COACHLOGIN:
        case CMD_P2T_COACHLOGOUT:
        case CMD_P2T_LERNERLOGIN:
        case CMD_P2T_LERNERLOGOUT:
            return   FLOWID_CHECK_STATUS::EXTTA_TYPE;
            break;
        default:
            break;
        }
    default:
        break;
    }
    return  FLOWID_CHECK_STATUS::UNKNOW_TYPE;
}
/**********************************
*接受的命令字分为3类命令字
*1.通用回复（命令字和流水号在通用回复消息体内），
*2.扩展消息回复，此类因为回复的消息流水号不在消息体内，所以暂时不做匹配
*3.平台主动下发报文，此类报文先不做处理
***********************************/
void CmdPP::Remove_OneCmdFromSendList(stRecvCmdPiPe data)
{
    int  s=0;int h;
    for(int i =0;i<sizeof(m_cmdlist)/sizeof(stSendCmdPiPe);i++)
    {
        if(m_cmdlist[i].ts_enable == true)
        {
            if(  checkFlowID(data.td_cmd,data,&s,&h)==FLOWID_CHECK_STATUS::COMMOND_TYPE)
            {
                data.td_seq=s;
                data.td_cmd=h;
                if(((data.td_cmd ) == m_cmdlist[i].ts_cmd) && (data.td_seq == m_cmdlist[i].ts_seq))
                {
//                  TRACE_INFO_CLASS("\n回复移除3：%04x=====offline:%d========时间：%s=======\n",m_cmdlist[i].ts_cmd,m_cmdlist[i].ts_isoffline,m_cmdlist[i].ts_sendtime.c_str());
                     m_cmdlist[i].ts_enable=false;
                }
            }
            else if(checkFlowID(data.td_cmd,data,&s,&h)==FLOWID_CHECK_STATUS::EXTTA_TYPE)
            {
                data.td_seq=s;data.td_cmd=h;
//                收到的是以8开头的，例如 0x8001
//                TRACE_CYAN("\ndata.td_cmd:%04x\n",data.td_cmd);
//                TRACE_CYAN("\nm_cmdlist[i].ts_cmd:%04x\n",m_cmdlist[i].ts_cmd);
                if((data.td_cmd&0x0fff)  == (m_cmdlist[i].ts_cmd&0x0fff) )
                {
                    //                  if(m_cmdlist[i].ts_isoffline==false)
                    {
                        switch(m_cmdlist[i].ts_cmd){
                        case CMD_T2P_REPORTTRAINRECORD_NEW:
                            //                            OfflineSave::getInstance()->  deleteMessageByFlowid(m_cmdlist[i].ts_cmd,m_cmdlist[i].ts_seq );
                            OfflineSave::getInstance()->  deleteMessageByTime(m_cmdlist[i].ts_sendtime);
                            break;
                        case CMD_T2P_LERNERLOGOUT_NEW:
                            //                            TRACE_CYAN("\n数据登出\n");
                            //                                                        OfflineSave::getInstance()->  deleteMessageByFlowid(m_cmdlist[i].ts_cmd,m_cmdlist[i].ts_seq );
                            OfflineSave::getInstance()-> deleteMessageByTime(m_cmdlist[i].ts_sendtime);
                            break;
                        case CMD_T2P_COACHLOGOUTCMD:
                            //                            OfflineSave::getInstance()->  deleteMessageByFlowid(m_cmdlist[i].ts_cmd,m_cmdlist[i].ts_seq );
                            OfflineSave::getInstance()->  deleteMessageByTime(m_cmdlist[i].ts_sendtime);
                            break;
                        }
                    }
                    //                    TRACE_INFO_CLASS("\n回复移除2：%04x\n",data.td_cmd);
                    m_cmdlist[i].ts_enable=false;
                    //                    TRACE_CYAN("\nFlowID2=%04x=CmD2=%04x\n",data.td_seq,data.td_cmd);
                }
            }
            else  if( checkFlowID(data.td_cmd,data,&s,&h)==FLOWID_CHECK_STATUS::DOWN_TYPE)
            {

                //需要添加代码
            }
        }
    }
}




void CmdPP::Send_OneCmd(stSendCmdPiPe &data, int times, bool ack)
{
    for(int i =0;i<sizeof(m_cmdlist)/sizeof(stSendCmdPiPe);i++)
    {
        if(m_cmdlist[i].ts_enable == false )
        {
            memcpy(&m_cmdlist[i],&data,sizeof(stSendCmdPiPe));
            m_cmdlist[i].ts_sendtime=data.ts_sendtime;
            m_cmdlist[i].ts_seq = data.ts_content[13]<<8|data.ts_content[14];
            m_cmdlist[i].ts_times = times;
            m_cmdlist[i].ts_needAck = ack;
            m_cmdlist[i].ts_RemoveConter = data.ts_RemoveConter;
            m_cmdlist[i].ts_enable = true;
            m_cmdlist[i].ts_isoffline=data.ts_isoffline;
            stCmdCount++;
            break;
        }
    }
}
