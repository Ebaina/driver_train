﻿#include "exesetterminaldata.h"
#include "public.h"
#include "clog.h"
#include  <arpa/inet.h>
#include  "cmd.h"
#include  "string.h"
#include "verupdate.h"
#include "app_globl.h"
#include "Utils.h"
#include "ttsutils.h"
#include <QString>
#include <QDebug>
#include <QStringList>
#include <QByteArray>
#include"timerupload.h"
/*参数设置函数*/
int  parameter(int paramID,wis_u8 buf[20],int len)
{
    CommunicateMainSet communicate_info;   //通信设置
    NetMainSet           net_info;                            //网络设置
    ReportMainSet     report_info;                       //汇报设置
    ListenMainSet      listen_info;                        // 监听设置
    ViewthresholdMainSet     view_info;            //视频监控设置
    OtherMainSet      other_info;                        //其他设置
    memset(&communicate_info,0,sizeof(communicate_info));
    memset(&net_info,0,sizeof(net_info));
    memset(&report_info,0,sizeof(report_info));
    memset(&listen_info,0,sizeof(listen_info));
    memset(&view_info,0,sizeof(view_info));
    memset(&other_info,0,sizeof(other_info));
    int j=0;
    char para_buff[40] = {0};
    switch(paramID)
    {
    case  0x0001:
        communicate_info.Client_Heartbeat_Sec  =((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);   //0x0001 客户端心跳发送间隔，单位为秒(s)
//        commu_info.Client_Heartbeat_Sec= communicate_info.Client_Heartbeat_Sec;
        commu_info.Client_Heartbeat_Sec= communicate_info.Client_Heartbeat_Sec;
        sprintf(para_buff,"%d",communicate_info.Client_Heartbeat_Sec);
        Configuration_parameter_set("para:client_heartbeat_sec",para_buff);
        memset(para_buff,0,sizeof(communicate_info.Client_Heartbeat_Sec));
//        TRACE_CYAN("心跳修改：%d",HEARTREPORT);
        TimerUpload::getInstance()->stopIndex(TimerSpace::HEARTTIMER);
        TimerUpload::getInstance()->startIndex(TimerSpace::HEARTTIMER);
        break;

    case  0x0002:
        communicate_info.Tcp_Reply_Sec = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);   //0x0002 TCP消息应答超时时间，单位为秒(s)
        sprintf(para_buff,"%d",communicate_info.Tcp_Reply_Sec);
        Configuration_parameter_set("para:tcp_reply_sec ",para_buff);
        memset(para_buff,0,sizeof(communicate_info.Tcp_Reply_Sec));
        break;

    case  0x0003:
        communicate_info.Tcp_Retransmission =  ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0003 TCP消息重传次数
        sprintf(para_buff,"%d",communicate_info.Tcp_Retransmission);
        Configuration_parameter_set("para:tcp_retransmission ",para_buff);
        memset(para_buff,0,sizeof(communicate_info.Tcp_Retransmission));
        break;

    case  0x0004:
        communicate_info.Udp_Reply_Sec = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);   //0x0004 UDP消息应答超时时间，单位为秒(s)
        sprintf(para_buff,"%d",communicate_info.Udp_Reply_Sec);
        Configuration_parameter_set("para:udp_reply_sec",para_buff);
        memset(para_buff,0,sizeof(communicate_info.Udp_Reply_Sec));
        break;

    case  0x0005:
        communicate_info.Udp_Retransmission = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0005 UDP消息重传次数
        sprintf(para_buff,"%d",communicate_info.Udp_Retransmission);
        Configuration_parameter_set("para:udp_retransmission",para_buff);
        memset(para_buff,0,sizeof(communicate_info.Udp_Retransmission));
        break;

    case  0x0006:
        communicate_info.SMS_Reply_Sec = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);     //0x0006 SMS消息应答超时时间，单位为秒(s)
        sprintf(para_buff,"%d",communicate_info.SMS_Reply_Sec);
        Configuration_parameter_set("para:sms_reply_sec",para_buff);
        memset(para_buff,0,sizeof(communicate_info.SMS_Reply_Sec));
        break;

    case  0x0007:
        communicate_info.SMS_Retransmission = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);   //0x0007 SMS消息重传次数
        sprintf(para_buff,"%d",communicate_info.SMS_Retransmission);
        Configuration_parameter_set("para:sms_retransmission",para_buff);
        memset(para_buff,0,sizeof(communicate_info.SMS_Retransmission));
        break;

    case  0x0010:
        for(j=0;j<len;j++)
        {
            net_info.Mainserver_APN[j] =buf[j];    //0x0010 主服务器APN，无线通信拨号访问点。若网络制式为CDMA，则该处为PPP拨号号码
        }
        memcpy(para_buff ,(char*)net_info.Mainserver_APN,len);
        Configuration_parameter_set("para:mainserver_apn",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0011:
        for(j=0;j<len;j++)
        {
            net_info.Mainserver_User[j] =buf[j];    //0x0011 主服务器无线通信拨号用户名
        }
        memcpy(para_buff ,(char*)net_info.Mainserver_User,len);
        Configuration_parameter_set("para:mainserver_user ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0012:
        for(j=0;j<len;j++)
        {
            net_info.Mainserver_Password[j] =buf[j];      //0x0012 主服务器无线通信拨号密码
        }
        memcpy(para_buff ,(char*)net_info.Mainserver_Password,len);
        Configuration_parameter_set("para:backupserver_password ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0013:
        for(j=0;j<len;j++)
        {
            net_info.Mainserver_IP[j] = buf[j];   //0x0013 主服务器地址，IP或域名
        }
        memcpy(para_buff ,(char*)net_info.Mainserver_IP,len);
        Configuration_parameter_set("para:mainserver_ip ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0014:
        for(j=0;j<len;j++)
        {
            net_info.Backupserver_APN[j] = buf[j];   //0x0014 备份服务器APN，无线通信拨号访问点
        }
        memcpy(para_buff ,(char*)net_info.Backupserver_APN,len);
        Configuration_parameter_set("para:backupserver_apn ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0015:
        for(j=0;j<len;j++)
        {
            net_info.Backupserver_User[j] = buf[j];   //0x0015 备份服务器无线通信拨号用户名
        }
        memcpy(para_buff ,(char*)net_info.Backupserver_User,len);
        Configuration_parameter_set("para:backupserver_user ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0016:
        for(j=0;j<len;j++)
        {
            net_info.Backupserver_Password[j] = buf[j];   //  0x0016 备份服务器无线通信拨号密码
        }
        memcpy(para_buff ,(char*)net_info.Backupserver_Password,len);
        Configuration_parameter_set("para:backupserver_password ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0017:
        for(j=0;j<len;j++)
        {
            net_info.Backupserver_IP[j] = buf[j];   //  0x0017 备份服务器地址，IP或域名
        }
        memcpy(para_buff ,(char*)net_info.Backupserver_IP,len);
        Configuration_parameter_set("para:backupserver_ip ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0018:
        net_info.Server_TCP_Port = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //  0x0018 服务器TCP端口
        sprintf(para_buff,"%d",net_info.Server_TCP_Port);
        Configuration_parameter_set("para:server_tcp_port ",para_buff);
        memset(para_buff,0,sizeof(net_info.Server_TCP_Port));
        break;

    case  0x0019:
        net_info.Server_UDP_Port = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0019 服务器UDP端口
        sprintf(para_buff,"%d",net_info.Server_UDP_Port);
        Configuration_parameter_set("para:server_udp_port ",para_buff);
        memset(para_buff,0,sizeof(net_info.Server_UDP_Port));
        break;

    case  0x0020:
        report_info.Location_Report_Way = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //   0x0020 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报
        sprintf(para_buff,"%d",report_info.Location_Report_Way);
        Configuration_parameter_set("para:location_report_way ",para_buff);
        memset(para_buff,0,sizeof(report_info.Location_Report_Way));
        break;

    case  0x0021:
        report_info.Location_Report_Status = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0021 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态
        sprintf(para_buff,"%d",report_info.Location_Report_Status);
        Configuration_parameter_set("para:location_report_status",para_buff);
        memset(para_buff,0,sizeof(report_info.Location_Report_Status));
        break;

    case  0x0022:
        report_info.Dri_Unlisted_Time_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0022 驾驶员未登录汇报时间间隔，单位为秒(s),>0
        sprintf(para_buff,"%d",report_info.Dri_Unlisted_Time_Report);
        Configuration_parameter_set("para:dri_unlisted_time_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Dri_Unlisted_Time_Report));
        break;

    case  0x0027:
        report_info.Dormant_Time_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);   //0x0027 休眠时汇报时间间隔，单位为秒(s),>0
        sprintf(para_buff,"%d",report_info.Dormant_Time_Report);
        Configuration_parameter_set("para:dormant_time_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Dormant_Time_Report));
        break;

    case  0x0028:
        report_info.Emergency_Alarm_Time_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //  0x0028 紧急报警时汇报时间间隔，单位为秒(s),>0
        sprintf(para_buff,"%d",report_info.Emergency_Alarm_Time_Report);
        Configuration_parameter_set("para:emergency_alarm_time_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Emergency_Alarm_Time_Report));
        break;

    case  0x0029:
        report_info.Default_Time_Report =  ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0029 缺省时间汇报间隔，单位为秒(s),>0
//        GPSREPORT=report_info.Default_Time_Report;
//        TRACE_CYAN("位置间隔修改：%d",GPSREPORT);
        TimerUpload::getInstance()->stopIndex(TimerSpace::LOCATIONTIMER);
        TimerUpload::getInstance()->startIndex(TimerSpace::LOCATIONTIMER);
        sprintf(para_buff,"%d",report_info.Default_Time_Report);
        Configuration_parameter_set("para:default_time_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Default_Time_Report));
        break;

    case  0x002c:
        report_info.Default_Distance_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x002C 缺省距离汇报间隔，单位为米(m),>0
        sprintf(para_buff,"%d",report_info.Default_Distance_Report);
        Configuration_parameter_set("para:default_distance_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Default_Distance_Report));
        break;

    case  0x002d:
        report_info.Dri_Unlisted_Distance_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x002D 驾驶员未登录汇报距离间隔，单位为米(m),>0
        sprintf(para_buff,"%d",report_info.Dri_Unlisted_Distance_Report);
        Configuration_parameter_set("para:dri_unlisted_distance_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Dri_Unlisted_Distance_Report));
        break;

    case  0x002e:
        report_info.Dormant_Distance_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x002E 休眠时汇报距离间隔，单位为米(m),>0
        sprintf(para_buff,"%d",report_info.Dormant_Distance_Report);
        Configuration_parameter_set("para:dormant_distance_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Dormant_Distance_Report));
        break;

    case  0x002f:
        report_info.Emergency_Alarm_Distance_Report = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x002F 紧急报警时汇报距离间隔，单位为米(m),>0
        sprintf(para_buff,"%d",report_info.Emergency_Alarm_Distance_Report);
        Configuration_parameter_set("para:emergency_alarm_distance_report",para_buff);
        memset(para_buff,0,sizeof(report_info.Emergency_Alarm_Distance_Report));
        break;

    case  0x0030:
        report_info.Inflection_Point =  ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0030 拐点补传角度，<180°
        sprintf(para_buff,"%d",report_info.Inflection_Point);
        Configuration_parameter_set("para:inflection_point",para_buff);
        memset(para_buff,0,sizeof(report_info.Inflection_Point));
        break;

    case  0x0040:
        for(j=0;j<len;j++)
        {
            listen_info.Monitoring_Platform_Phone[j] = buf[j];   //  0x0017 备份服务器地址，IP或域名
        }
        memcpy(para_buff ,(char*)listen_info.Monitoring_Platform_Phone,len);
        Configuration_parameter_set("para:monitoring_platform_phone ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0041:
        for(j=0;j<len;j++)
        {
            listen_info.Reset_Phone[j] = buf[j];   // 0x0041 复位电话号码，可采用此电话号码拨打终端电话让终端复位
        }
        memcpy(para_buff ,(char*)listen_info.Reset_Phone,len);
        Configuration_parameter_set("para:reset_phone ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0042:
        for(j=0;j<len;j++)
        {
            listen_info.Factory_Reset_Phone[j] = buf[j];   // 0x0042 恢复出厂设置电话号码，可采用此电话号码拨打终端电话让终端恢复出厂设置
        }
        memcpy(para_buff ,(char*)listen_info.Factory_Reset_Phone,len);
        Configuration_parameter_set("para:factory_reset_phone ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0043:
        for(j=0;j<len;j++)
        {
            listen_info.Monitoring_Platform_SMS_Phone[j] = buf[j];   //0x0043 监控平台SMS电话号码
        }
        memcpy(para_buff ,(char*)listen_info.Monitoring_Platform_SMS_Phone,len);
        Configuration_parameter_set("para:monitoring_platform_sms_phone ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0044:
        for(j=0;j<len;j++)
        {
            listen_info.Receiving_SMS_Alarm[j] = buf[j];   //0x0044 接收终端SMS文本报警号码
        }
        memcpy(para_buff ,(char*)listen_info.Receiving_SMS_Alarm,len);
        Configuration_parameter_set("para:receiving_sms_alarm ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0045:
        listen_info.Terminal_Phone_Way = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0045 终端电话接听策略，0：自动接听；1：ACCON时自动接听，OFF时手动接听
        sprintf(para_buff,"%d",listen_info.Terminal_Phone_Way);
        Configuration_parameter_set("para:terminal_phone_way",para_buff);
        memset(para_buff,0,sizeof(listen_info.Terminal_Phone_Way));
        break;

    case  0x0046:
        listen_info.Phone_Time =  ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0046 每次最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
        sprintf(para_buff,"%d",listen_info.Phone_Time);
        Configuration_parameter_set("para:phone_time",para_buff);
        memset(para_buff,0,sizeof(listen_info.Phone_Time));
        break;

    case  0x0047:
        listen_info.Phone_Time_Month = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0047 当月最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
        sprintf(para_buff,"%d",listen_info.Phone_Time_Month);
        Configuration_parameter_set("para:phone_time_month",para_buff);
        memset(para_buff,0,sizeof(listen_info.Phone_Time_Month));
        break;

    case  0x0048:
        for(j=0;j<len;j++)
        {
            listen_info.Monitor_Phone[j] = buf[j];   //0x0048 监听电话号码
        }
        memcpy(para_buff ,(char*)listen_info.Monitor_Phone,len);
        Configuration_parameter_set("para:monitor_phone ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0049:
        for(j=0;j<len;j++)
        {
            listen_info.Monitor_Platform_Text_Phone[j] = buf[j];   //0x0049 监管平台特权短信号码
        }
        memcpy(para_buff ,(char*)listen_info.Monitor_Platform_Text_Phone,len);
        Configuration_parameter_set("para:monitor_platform_text_phone ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0050:
        view_info.Alarm_Shield_Byte = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0050 报警屏蔽字。与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警被屏蔽
        sprintf(para_buff,"%d",view_info.Alarm_Shield_Byte);
        Configuration_parameter_set("para:alarm_shield_byte",para_buff);
        memset(para_buff,0,sizeof(view_info.Alarm_Shield_Byte));
        break;

    case  0x0051:
        view_info.Alarm_Send_SMS_Text = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0051 报警发送文本SMS开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时发送文本SMS
        sprintf(para_buff,"%d",view_info.Alarm_Send_SMS_Text);
        Configuration_parameter_set("para:alarm_send_sms_text",para_buff);
        memset(para_buff,0,sizeof(view_info.Alarm_Send_SMS_Text));
        break;

    case  0x0052:
        view_info.Alarm_Picture_Switch = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  // 0x0052 报警拍摄开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时摄像头拍摄
        sprintf(para_buff,"%d",view_info.Alarm_Picture_Switch);
        Configuration_parameter_set("para:alarm_picture_switch",para_buff);
        memset(para_buff,0,sizeof(view_info.Alarm_Picture_Switch));
        break;

    case  0x0053:
        view_info.Alarm_Picture_Save = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);   //0x0053 报警拍摄存储标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警时牌的照片进行存储，否则实时长传
        sprintf(para_buff,"%d",view_info.Alarm_Picture_Save);
        Configuration_parameter_set("para:alarm_picture_save",para_buff);
        memset(para_buff,0,sizeof(view_info.Alarm_Picture_Save));
        break;

    case  0x0054:
        view_info.Key_Identification = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0054 关键标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警为关键报警
        sprintf(para_buff,"%d",view_info.Key_Identification);
        Configuration_parameter_set("para:key_identification",para_buff);
        memset(para_buff,0,sizeof(view_info.Key_Identification));
        break;

    case  0x0055:
        view_info.High_Speed = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0055 最高速度，单位为公里每小时(km/h)
        sprintf(para_buff,"%d",view_info.High_Speed);
        Configuration_parameter_set("para:high_speed",para_buff);
        memset(para_buff,0,sizeof(view_info.High_Speed));
        break;

    case  0x0056:
        view_info.OverSpeed_Time = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); // 0x0056 超速持续时间，单位为秒(s)
        sprintf(para_buff,"%d",view_info.OverSpeed_Time);
        Configuration_parameter_set("para:overspeed_time ",para_buff);
        memset(para_buff,0,sizeof(view_info.OverSpeed_Time));
        break;

    case  0x0057:
        view_info.Continue_Dri_Time = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0057 连续驾驶时间门限，单位为秒(s)
        sprintf(para_buff,"%d",view_info.Continue_Dri_Time);
        Configuration_parameter_set("para:continue_dri_time ",para_buff);
        memset(para_buff,0,sizeof(view_info.Continue_Dri_Time));
        break;

    case  0x0058:
        view_info.Day_Dri_Time = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0058 当天累计驾驶时间门限，单位为秒(s)
        sprintf(para_buff,"%d",view_info.Day_Dri_Time);
        Configuration_parameter_set("para:day_dri_time ",para_buff);
        memset(para_buff,0,sizeof(view_info.Day_Dri_Time));
        break;

    case  0x0059:
        view_info.Mini_Reset_Time = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0059 最小休息时间，单位为秒(s)
        sprintf(para_buff,"%d",view_info.Mini_Reset_Time);
        Configuration_parameter_set("para:mini_reset_time ",para_buff);
        memset(para_buff,0,sizeof(view_info.Mini_Reset_Time));
        break;

    case  0x005a:
        view_info.Max_Park_Time = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x005A 最长停车时间，单位为秒(s)
        sprintf(para_buff,"%d",view_info.Max_Park_Time);
        Configuration_parameter_set("para:max_park_time ",para_buff);
        memset(para_buff,0,sizeof(view_info.Max_Park_Time));
        break;

    case  0x0070:
        other_info.Picture = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0070 图像/视频质量，1-10,1最好
        sprintf(para_buff,"%d",other_info.Picture);
        Configuration_parameter_set("para:picture ",para_buff);
        memset(para_buff,0,sizeof(other_info.Picture));
        break;

    case  0x0071:
        other_info.Lightness = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff); //0x0071 亮度，0-255
        sprintf(para_buff,"%d",other_info.Lightness);
        Configuration_parameter_set("para:lightness ",para_buff);
        memset(para_buff,0,sizeof(other_info.Lightness));
        break;

    case  0x0072:
        other_info.Contrast = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0072 对比度，0-127
        sprintf(para_buff,"%d",other_info.Contrast);
        Configuration_parameter_set("para:contrast ",para_buff);
        memset(para_buff,0,sizeof(other_info.Contrast));
        break;

    case  0x0073:
        other_info.Saturation =  ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0073 饱和度，0-127
        sprintf(para_buff,"%d",other_info.Saturation);
        Configuration_parameter_set("para:saturation ",para_buff);
        memset(para_buff,0,sizeof(other_info.Saturation));
        break;

    case  0x0074:
        other_info.Chroma = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0074 色度，0-255
        sprintf(para_buff,"%d",other_info.Chroma);
        Configuration_parameter_set("para:chroma ",para_buff);
        memset(para_buff,0,sizeof(other_info.Chroma));
        break;

    case  0x0080:
        other_info.Car_Meilage = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0080 车辆里程表读数，1/10km
        sprintf(para_buff,"%d",other_info.Car_Meilage);
        Configuration_parameter_set("para:car_meilage ",para_buff);
        memset(para_buff,0,sizeof(other_info.Car_Meilage));
        break;

    case  0x0081:
        other_info.Province_ID = ((buf[0]<<8)&0xff00) | (buf[1]&0xff);  //0x0081 车辆所在的省域ID
        sprintf(para_buff,"%d",other_info.Province_ID);
        Configuration_parameter_set("para:province_id ",para_buff);
        memset(para_buff,0,sizeof(other_info.Province_ID));
        break;

    case  0x0082:
        other_info.City_ID = ((buf[0]<<8)&0xff00) | (buf[1]&0xff);  // 0x0082 车辆所在的市域ID
        sprintf(para_buff,"%d",other_info.City_ID);
        Configuration_parameter_set("para:city_id ",para_buff);
        memset(para_buff,0,sizeof(other_info.City_ID));
        break;

    case  0x0083:
        for(j=0;j<len;j++)
        {
            other_info.Motor_Plate[j] = buf[j];  //0x0083 公安交通管理部门颁发的机动车号牌
        }
        memcpy(para_buff ,(char*)other_info.Motor_Plate,len);
        Configuration_parameter_set("para:motor_plate ",para_buff);
        memset(para_buff,0,len);
        break;

    case  0x0084:
        other_info.Plate_Color = buf[0];   //0x0084 车牌颜色，按照JT/T415-2006的5.4.12
        sprintf(para_buff,"%d",other_info.Plate_Color);
        Configuration_parameter_set("para:plate_color ",para_buff);
        memset(para_buff,0,sizeof(other_info.Plate_Color));
        break;

    case  0x0085:
        other_info.Impulse_Ratio = ((buf[0]<<24)&0xff000000) | ((buf[1]<<16)&0xff0000) | ((buf[2]<<8)&0xff00) | (buf[3]&0xff);  //0x0085 车辆脉冲系数，车辆行驶1km距离过程中产生的脉冲信号个数
        sprintf(para_buff,"%d",other_info.Impulse_Ratio);
        Configuration_parameter_set("para:impulse_ratio ",para_buff);
        memset(para_buff,0,sizeof(other_info.Impulse_Ratio));
        break;
    }
    return 0;
}
int  para_query(int paramID,char * para_buff)
{
    CommunicateMainSet communicate_info;   //通信设置
    NetMainSet           net_info;                            //网络设置
    ReportMainSet     report_info;                       //汇报设置
    ListenMainSet      listen_info;                        // 监听设置
    ViewthresholdMainSet     view_info;            //视频监控设置
    OtherMainSet      other_info;                        //其他设置
    memset(&communicate_info,0,sizeof(communicate_info));
    memset(&net_info,0,sizeof(net_info));
    memset(&report_info,0,sizeof(report_info));
    memset(&listen_info,0,sizeof(listen_info));
    memset(&view_info,0,sizeof(view_info));
    memset(&other_info,0,sizeof(other_info));
    string str1;
    int plate_length;
    /*配置文件读取*/
    dictionary *ini;
    const char *str;
    int j=0;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    if(ini == NULL)
    {
        fprintf(stderr,"can not open %s","example.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(ini,stderr);
    switch(paramID)
    {
    case  0x0001:
        communicate_info.Client_Heartbeat_Sec =iniparser_getint(ini,"para:client_heartbeat_sec",-1);  //0x0001 客户端心跳发送间隔，单位为秒(s)
        para_buff[0] = communicate_info.Client_Heartbeat_Sec >>24;
        para_buff[1] = communicate_info.Client_Heartbeat_Sec >>16;
        para_buff[2] = communicate_info.Client_Heartbeat_Sec >>8;
        para_buff[3] = communicate_info.Client_Heartbeat_Sec ;
        return sizeof(communicate_info.Client_Heartbeat_Sec);
        break;

    case  0x0002:
        communicate_info.Tcp_Reply_Sec=iniparser_getint(ini,"para:tcp_reply_sec",-1);  //0x0002 TCP消息应答超时时间，单位为秒(s)
        para_buff[0] = communicate_info.Tcp_Reply_Sec >>24;
        para_buff[1] = communicate_info.Tcp_Reply_Sec >>16;
        para_buff[2] = communicate_info.Tcp_Reply_Sec >>8;
        para_buff[3] = communicate_info.Tcp_Reply_Sec ;
        return sizeof(communicate_info.Tcp_Reply_Sec);
        break;

    case  0x0003:
        communicate_info.Tcp_Retransmission=iniparser_getint(ini,"para:tcp_retransmission",-1); //0x0003 TCP消息重传次数
        para_buff[0] = communicate_info.Tcp_Retransmission >>24;
        para_buff[1] = communicate_info.Tcp_Retransmission >>16;
        para_buff[2] = communicate_info.Tcp_Retransmission >>8;
        para_buff[3] = communicate_info.Tcp_Retransmission ;
        return sizeof(communicate_info.Tcp_Retransmission);
        break;

    case  0x0004:
        communicate_info.Udp_Reply_Sec=iniparser_getint(ini,"para:udp_reply_sec",-1);  //0x0004 UDP消息应答超时时间，单位为秒(s)
        para_buff[0] = communicate_info.Udp_Reply_Sec >>24;
        para_buff[1] = communicate_info.Udp_Reply_Sec >>16;
        para_buff[2] = communicate_info.Udp_Reply_Sec >>8;
        para_buff[3] = communicate_info.Udp_Reply_Sec ;
        return sizeof(communicate_info.Udp_Reply_Sec);
        break;

    case  0x0005:
        communicate_info.Udp_Retransmission=iniparser_getint(ini,"para:udp_retransmission",-1); //0x0005 UDP消息重传次数
        para_buff[0] = communicate_info.Udp_Retransmission >>24;
        para_buff[1] = communicate_info.Udp_Retransmission >>16;
        para_buff[2] = communicate_info.Udp_Retransmission >>8;
        para_buff[3] = communicate_info.Udp_Retransmission ;
        return sizeof(communicate_info.Udp_Retransmission);
        break;

    case  0x0006:
        communicate_info.SMS_Reply_Sec=iniparser_getint(ini,"para:sms_reply_sec",-1);      //0x0006 SMS消息应答超时时间，单位为秒(s)
        para_buff[0] = communicate_info.SMS_Reply_Sec >>24;
        para_buff[1] = communicate_info.SMS_Reply_Sec >>16;
        para_buff[2] = communicate_info.SMS_Reply_Sec >>8;
        para_buff[3] = communicate_info.SMS_Reply_Sec ;
        return sizeof(communicate_info.SMS_Reply_Sec);
        break;

    case  0x0007:
        communicate_info.SMS_Retransmission =iniparser_getint(ini,"para:sms_retransmission",-1);    //0x0007 SMS消息重传次数
        para_buff[0] = communicate_info.SMS_Retransmission >>24;
        para_buff[1] = communicate_info.SMS_Retransmission >>16;
        para_buff[2] = communicate_info.SMS_Retransmission >>8;
        para_buff[3] = communicate_info.SMS_Retransmission ;
        return sizeof(communicate_info.SMS_Retransmission);
        break;

    case  0x0010:
        str =  iniparser_getstring(ini,"para:mainserver_apn","null");
        memcpy(net_info.Mainserver_APN,str,strlen(str)); //0x0010 主服务器APN，无线通信拨号访问点。若网络制式为CDMA，则该处为PPP拨号号码
        memcpy(para_buff ,(char*)net_info.Mainserver_APN,strlen(str));
//        printf("%s",str);
        return  strlen(str);
        break;

    case  0x0011:
        str =  iniparser_getstring(ini,"para:mainserver_user","null"); //0x0011 主服务器无线通信拨号用户名
        memcpy(net_info.Mainserver_User,str,strlen(str));
        memcpy(para_buff ,(char*)net_info.Mainserver_User,strlen(str));
        return  strlen(str);
        break;

    case  0x0012:
        str =  iniparser_getstring(ini,"para:backupserver_password","null");
        memcpy(net_info.Mainserver_Password,str,strlen(str));      //0x0012 主服务器无线通信拨号密码
        memcpy(para_buff ,(char*)net_info.Mainserver_Password,strlen(str));
        return  strlen(str);
        break;

    case  0x0013:
        str =  iniparser_getstring(ini,"para:mainserver_ip","null");
        memcpy(net_info.Mainserver_IP,str,strlen(str));    //0x0013 主服务器地址，IP或域名
        memcpy(para_buff ,(char*)net_info.Mainserver_IP,strlen(str));
        return  strlen(str);
        break;

    case  0x0014:
        str =  iniparser_getstring(ini,"para:backupserver_apn","null");
        memcpy(net_info.Backupserver_APN,str,strlen(str));   //0x0014 备份服务器APN，无线通信拨号访问点
        memcpy(para_buff ,(char*)net_info.Backupserver_APN,strlen(str));
        return  strlen(str);
        break;

    case  0x0015:
        str =  iniparser_getstring(ini,"para:backupserver_user","null");
        memcpy(net_info.Backupserver_User,str,strlen(str));  //0x0015 备份服务器无线通信拨号用户名
        memcpy(para_buff ,(char*)net_info.Backupserver_User,strlen(str));
        return  strlen(str);
        break;

    case  0x0016:
        str =  iniparser_getstring(ini,"para:backupserver_password","null");
        memcpy(net_info.Backupserver_Password,str,strlen(str));   //  0x0016 备份服务器无线通信拨号密码
        memcpy(para_buff ,(char*)net_info.Backupserver_Password,strlen(str));
        return  strlen(str);
        break;

    case  0x0017:
        str =  iniparser_getstring(ini,"para:backupserver_ip","null");
        memcpy(net_info.Backupserver_IP,str,strlen(str));  //  0x0017 备份服务器地址，IP或域名
        memcpy(para_buff ,(char*)net_info.Backupserver_IP,strlen(str));
        return  strlen(str);
        break;

    case  0x0018:
        net_info.Server_TCP_Port =iniparser_getint(ini,"para:server_tcp_port",-1); //  0x0018 服务器TCP端口
        para_buff[0] = net_info.Server_TCP_Port >>24;
        para_buff[1] = net_info.Server_TCP_Port >>16;
        para_buff[2] = net_info.Server_TCP_Port >>8;
        para_buff[3] = net_info.Server_TCP_Port ;
        return sizeof(net_info.Server_TCP_Port);
        break;

    case  0x0019:
        net_info.Server_UDP_Port=iniparser_getint(ini,"para:server_udp_port",-1); //0x0019 服务器UDP端口
        para_buff[0] = net_info.Server_UDP_Port >>24;
        para_buff[1] = net_info.Server_UDP_Port >>16;
        para_buff[2] = net_info.Server_UDP_Port >>8;
        para_buff[3] = net_info.Server_UDP_Port ;
        return sizeof(net_info.Server_UDP_Port);
        break;

    case  0x0020:
        report_info.Location_Report_Way =iniparser_getint(ini,"para:location_report_way",-1); //   0x0020 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报
        para_buff[0] = report_info.Location_Report_Way >>24;
        para_buff[1] = report_info.Location_Report_Way >>16;
        para_buff[2] = report_info.Location_Report_Way >>8;
        para_buff[3] = report_info.Location_Report_Way ;
        return sizeof(report_info.Location_Report_Way);
        break;

    case  0x0021:
        report_info.Location_Report_Status=iniparser_getint(ini,"para:location_report_status",-1);  //0x0021 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态
        para_buff[0] = report_info.Location_Report_Status >>24;
        para_buff[1] = report_info.Location_Report_Status >>16;
        para_buff[2] = report_info.Location_Report_Status >>8;
        para_buff[3] = report_info.Location_Report_Status ;
        return sizeof(report_info.Location_Report_Status);
        break;

    case  0x0022:
        report_info.Dri_Unlisted_Time_Report=iniparser_getint(ini,"para:dri_unlisted_time_report",-1);  //0x0022 驾驶员未登录汇报时间间隔，单位为秒(s),>0
        para_buff[0] = report_info.Dri_Unlisted_Time_Report >>24;
        para_buff[1] = report_info.Dri_Unlisted_Time_Report >>16;
        para_buff[2] = report_info.Dri_Unlisted_Time_Report >>8;
        para_buff[3] = report_info.Dri_Unlisted_Time_Report ;
        return sizeof(report_info.Dri_Unlisted_Time_Report);
        break;

    case  0x0027:
        report_info.Dormant_Time_Report=iniparser_getint(ini,"para:dormant_time_report",-1);   //0x0027 休眠时汇报时间间隔，单位为秒(s),>0
        para_buff[0] = report_info.Dormant_Time_Report >>24;
        para_buff[1] = report_info.Dormant_Time_Report >>16;
        para_buff[2] = report_info.Dormant_Time_Report >>8;
        para_buff[3] = report_info.Dormant_Time_Report ;
        return sizeof(report_info.Dormant_Time_Report);
        break;

    case  0x0028:
        report_info.Emergency_Alarm_Time_Report =iniparser_getint(ini,"para:emergency_alarm_time_report",-1);  //  0x0028 紧急报警时汇报时间间隔，单位为秒(s),>0
        para_buff[0] = report_info.Emergency_Alarm_Time_Report >>24;
        para_buff[1] = report_info.Emergency_Alarm_Time_Report >>16;
        para_buff[2] = report_info.Emergency_Alarm_Time_Report >>8;
        para_buff[3] = report_info.Emergency_Alarm_Time_Report ;
        return sizeof(report_info.Emergency_Alarm_Time_Report);
        break;

    case  0x0029:
        report_info.Default_Time_Report =iniparser_getint(ini,"para:default_time_report",-1); //0x0029 缺省时间汇报间隔，单位为秒(s),>0
        para_buff[0] = report_info.Default_Time_Report >>24;
        para_buff[1] = report_info.Default_Time_Report >>16;
        para_buff[2] = report_info.Default_Time_Report >>8;
        para_buff[3] = report_info.Default_Time_Report ;
        return sizeof(report_info.Default_Time_Report);
        break;

    case  0x002c:
        report_info.Default_Distance_Report=iniparser_getint(ini,"para:default_distance_report",-1);  //0x002C 缺省距离汇报间隔，单位为米(m),>0
        para_buff[0] = report_info.Default_Distance_Report >>24;
        para_buff[1] = report_info.Default_Distance_Report >>16;
        para_buff[2] = report_info.Default_Distance_Report >>8;
        para_buff[3] = report_info.Default_Distance_Report ;
        return sizeof(report_info.Default_Distance_Report);
        break;

    case  0x002d:
        report_info.Dri_Unlisted_Distance_Report=iniparser_getint(ini,"para:dri_unlisted_distance_report",-1);  //0x002D 驾驶员未登录汇报距离间隔，单位为米(m),>0
        para_buff[0] = report_info.Dri_Unlisted_Distance_Report >>24;
        para_buff[1] = report_info.Dri_Unlisted_Distance_Report >>16;
        para_buff[2] = report_info.Dri_Unlisted_Distance_Report >>8;
        para_buff[3] = report_info.Dri_Unlisted_Distance_Report ;
        return sizeof(report_info.Dri_Unlisted_Distance_Report);
        break;

    case  0x002e:
        report_info.Dormant_Distance_Report=iniparser_getint(ini,"para:dormant_distance_report",-1); //0x002E 休眠时汇报距离间隔，单位为米(m),>0
        para_buff[0] = report_info.Dormant_Distance_Report >>24;
        para_buff[1] = report_info.Dormant_Distance_Report >>16;
        para_buff[2] = report_info.Dormant_Distance_Report >>8;
        para_buff[3] = report_info.Dormant_Distance_Report ;
        return sizeof(report_info.Dormant_Distance_Report);
        break;

    case  0x002f:
        report_info.Emergency_Alarm_Distance_Report =iniparser_getint(ini,"para:emergency_alarm_distance_report",-1); //0x002F 紧急报警时汇报距离间隔，单位为米(m),>0
        para_buff[0] = report_info.Emergency_Alarm_Distance_Report >>24;
        para_buff[1] = report_info.Emergency_Alarm_Distance_Report >>16;
        para_buff[2] = report_info.Emergency_Alarm_Distance_Report >>8;
        para_buff[3] = report_info.Emergency_Alarm_Distance_Report ;
        return sizeof(report_info.Emergency_Alarm_Distance_Report);
        break;

    case  0x0030:
        report_info.Inflection_Point =iniparser_getint(ini,"para:inflection_point",-1);  //0x0030 拐点补传角度，<180°
        para_buff[0] = report_info.Inflection_Point >>24;
        para_buff[1] = report_info.Inflection_Point >>16;
        para_buff[2] = report_info.Inflection_Point >>8;
        para_buff[3] = report_info.Inflection_Point ;
        return sizeof(report_info.Inflection_Point);
        break;

    case  0x0040:
        str =  iniparser_getstring(ini,"para:monitoring_platform_phone","null");
        memcpy(listen_info.Monitoring_Platform_Phone,str,strlen(str));   //  0x0017 备份服务器地址，IP或域名
        memcpy(para_buff ,(char*)listen_info.Monitoring_Platform_Phone,strlen(str));
        return  strlen(str);
        break;

    case  0x0041:
        str =  iniparser_getstring(ini,"para:reset_phone","null");
        memcpy(listen_info.Reset_Phone,str,strlen(str));  // 0x0041 复位电话号码，可采用此电话号码拨打终端电话让终端复位
        memcpy(para_buff ,(char*)listen_info.Reset_Phone,strlen(str));
        return  strlen(str);
        break;

    case  0x0042:
        str =  iniparser_getstring(ini,"para:factory_reset_phone","null");
        memcpy(listen_info.Factory_Reset_Phone,str,strlen(str));  // 0x0042 恢复出厂设置电话号码，可采用此电话号码拨打终端电话让终端恢复出厂设置
        memcpy(para_buff ,(char*)listen_info.Factory_Reset_Phone,strlen(str));
        return  strlen(str);
        break;

    case  0x0043:
        str =  iniparser_getstring(ini,"para:monitoring_platform_sms_phone","null");
        memcpy(listen_info.Monitoring_Platform_SMS_Phone,str,strlen(str));   //0x0043 监控平台SMS电话号码
        memcpy(para_buff ,(char*)listen_info.Monitoring_Platform_SMS_Phone,strlen(str));
        return  strlen(str);
        break;

    case  0x0044:
        str =  iniparser_getstring(ini,"para:receiving_sms_alarm","null");
        memcpy(listen_info.Receiving_SMS_Alarm,str,strlen(str));  //0x0044 接收终端SMS文本报警号码
        memcpy(para_buff ,(char*)listen_info.Receiving_SMS_Alarm,strlen(str));
        return  strlen(str);
        break;

    case  0x0045:
        listen_info.Terminal_Phone_Way =iniparser_getint(ini,"para:terminal_phone_way",-1);  //0x0045 终端电话接听策略，0：自动接听；1：ACCON时自动接听，OFF时手动接听
        para_buff[0] = listen_info.Terminal_Phone_Way >>24;
        para_buff[1] = listen_info.Terminal_Phone_Way >>16;
        para_buff[2] = listen_info.Terminal_Phone_Way >>8;
        para_buff[3] = listen_info.Terminal_Phone_Way ;
        return sizeof(listen_info.Terminal_Phone_Way);
        break;

    case  0x0046:
        listen_info.Phone_Time =iniparser_getint(ini,"para:phone_time",-1); //0x0046 每次最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
        para_buff[0] = listen_info.Phone_Time >>24;
        para_buff[1] = listen_info.Phone_Time >>16;
        para_buff[2] = listen_info.Phone_Time >>8;
        para_buff[3] = listen_info.Phone_Time ;
        return sizeof(listen_info.Phone_Time);
        break;

    case  0x0047:
        listen_info.Phone_Time_Month =iniparser_getint(ini,"para:phone_time_month",-1); //0x0047 当月最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
        para_buff[0] = listen_info.Phone_Time_Month >>24;
        para_buff[1] = listen_info.Phone_Time_Month >>16;
        para_buff[2] = listen_info.Phone_Time_Month >>8;
        para_buff[3] = listen_info.Phone_Time_Month ;
        return sizeof(listen_info.Phone_Time_Month);
        break;

    case  0x0048:
        str =  iniparser_getstring(ini,"para:monitor_phone","null");
        memcpy(listen_info.Monitor_Phone,str,strlen(str));  //0x0048 监听电话号码
        memcpy(para_buff ,(char*)listen_info.Monitor_Phone,strlen(str));
        return  strlen(str);
        break;

    case  0x0049:
        str =  iniparser_getstring(ini,"para:monitor_platform_text_phone","null");
        memcpy(listen_info.Monitor_Platform_Text_Phone,str,strlen(str));    //0x0049 监管平台特权短信号码
        memcpy(para_buff ,(char*)listen_info.Monitor_Platform_Text_Phone,strlen(str));
        return  strlen(str);
        break;

    case  0x0050:
        view_info.Alarm_Shield_Byte =iniparser_getint(ini,"para:alarm_shield_byte",-1); //0x0050 报警屏蔽字。与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警被屏蔽
        para_buff[0] = view_info.Alarm_Shield_Byte >>24;
        para_buff[1] = view_info.Alarm_Shield_Byte >>16;
        para_buff[2] = view_info.Alarm_Shield_Byte >>8;
        para_buff[3] = view_info.Alarm_Shield_Byte ;
        return sizeof(view_info.Alarm_Shield_Byte);
        break;

    case  0x0051:
        view_info.Alarm_Send_SMS_Text =iniparser_getint(ini,"para:alarm_send_sms_text",-1); //0x0051 报警发送文本SMS开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时发送文本SMS
        para_buff[0] = view_info.Alarm_Send_SMS_Text >>24;
        para_buff[1] = view_info.Alarm_Send_SMS_Text >>16;
        para_buff[2] = view_info.Alarm_Send_SMS_Text >>8;
        para_buff[3] = view_info.Alarm_Send_SMS_Text ;
        return sizeof(view_info.Alarm_Send_SMS_Text);
        break;

    case  0x0052:
        view_info.Alarm_Picture_Switch =iniparser_getint(ini,"para:alarm_picture_switch",-1);  // 0x0052 报警拍摄开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时摄像头拍摄
        para_buff[0] = view_info.Alarm_Picture_Switch >>24;
        para_buff[1] = view_info.Alarm_Picture_Switch >>16;
        para_buff[2] = view_info.Alarm_Picture_Switch >>8;
        para_buff[3] = view_info.Alarm_Picture_Switch ;
        return sizeof(view_info.Alarm_Picture_Switch);
        break;

    case  0x0053:
        view_info.Alarm_Picture_Save =iniparser_getint(ini,"para:alarm_picture_save",-1);   //0x0053 报警拍摄存储标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警时牌的照片进行存储，否则实时长传
        para_buff[0] = view_info.Alarm_Picture_Save >>24;
        para_buff[1] = view_info.Alarm_Picture_Save >>16;
        para_buff[2] = view_info.Alarm_Picture_Save >>8;
        para_buff[3] = view_info.Alarm_Picture_Save ;
        return sizeof(view_info.Alarm_Picture_Save);
        break;

    case  0x0054:
        view_info.Key_Identification =iniparser_getint(ini,"para:key_identification",-1);  //0x0054 关键标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警为关键报警
        para_buff[0] = view_info.Key_Identification >>24;
        para_buff[1] = view_info.Key_Identification >>16;
        para_buff[2] = view_info.Key_Identification >>8;
        para_buff[3] = view_info.Key_Identification ;
        return sizeof(view_info.Key_Identification);
        break;

    case  0x0055:
        view_info.High_Speed =iniparser_getint(ini,"para:high_speed",-1); //0x0055 最高速度，单位为公里每小时(km/h)
        para_buff[0] = view_info.High_Speed >>24;
        para_buff[1] = view_info.High_Speed >>16;
        para_buff[2] = view_info.High_Speed >>8;
        para_buff[3] = view_info.High_Speed ;
        return sizeof(view_info.High_Speed);
        break;

    case  0x0056:
        view_info.OverSpeed_Time =iniparser_getint(ini,"para:overspeed_time",-1); // 0x0056 超速持续时间，单位为秒(s)
        para_buff[0] = view_info.OverSpeed_Time >>24;
        para_buff[1] = view_info.OverSpeed_Time >>16;
        para_buff[2] = view_info.OverSpeed_Time >>8;
        para_buff[3] = view_info.OverSpeed_Time ;
        return sizeof(view_info.OverSpeed_Time);
        break;

    case  0x0057:
        view_info.Continue_Dri_Time =iniparser_getint(ini,"para:continue_dri_time",-1); //0x0057 连续驾驶时间门限，单位为秒(s)
        para_buff[0] = view_info.Continue_Dri_Time >>24;
        para_buff[1] = view_info.Continue_Dri_Time >>16;
        para_buff[2] = view_info.Continue_Dri_Time >>8;
        para_buff[3] = view_info.Continue_Dri_Time ;
        return sizeof(view_info.Continue_Dri_Time);
        break;

    case  0x0058:
        view_info.Day_Dri_Time=iniparser_getint(ini,"para:day_dri_time",-1); //0x0058 当天累计驾驶时间门限，单位为秒(s)
        para_buff[0] = view_info.Day_Dri_Time >>24;
        para_buff[1] = view_info.Day_Dri_Time >>16;
        para_buff[2] = view_info.Day_Dri_Time >>8;
        para_buff[3] = view_info.Day_Dri_Time ;
        return sizeof(view_info.Day_Dri_Time);
        break;

    case  0x0059:
        view_info.Mini_Reset_Time=iniparser_getint(ini,"para:mini_reset_time",-1); //0x0059 最小休息时间，单位为秒(s)
        para_buff[0] = view_info.Mini_Reset_Time >>24;
        para_buff[1] = view_info.Mini_Reset_Time >>16;
        para_buff[2] = view_info.Mini_Reset_Time >>8;
        para_buff[3] = view_info.Mini_Reset_Time ;
        return sizeof(view_info.Mini_Reset_Time);
        break;

    case  0x005a:
        view_info.Max_Park_Time=iniparser_getint(ini,"para:max_park_time",-1); //0x005A 最长停车时间，单位为秒(s)
        para_buff[0] = view_info.Max_Park_Time >>24;
        para_buff[1] = view_info.Max_Park_Time >>16;
        para_buff[2] = view_info.Max_Park_Time >>8;
        para_buff[3] = view_info.Max_Park_Time ;
        return sizeof(view_info.Max_Park_Time);
        break;

    case  0x0070:
        other_info.Picture=iniparser_getint(ini,"para:picture",-1); //0x0070 图像/视频质量，1-10,1最好
        para_buff[0] = other_info.Picture >>24;
        para_buff[1] = other_info.Picture >>16;
        para_buff[2] = other_info.Picture >>8;
        para_buff[3] = other_info.Picture ;
        return sizeof(other_info.Picture);
        break;

    case  0x0071:
        other_info.Lightness=iniparser_getint(ini,"para:lightness",-1); //0x0071 亮度，0-255
        para_buff[0] = other_info.Lightness >>24;
        para_buff[1] = other_info.Lightness >>16;
        para_buff[2] = other_info.Lightness >>8;
        para_buff[3] = other_info.Lightness ;
        return sizeof(other_info.Lightness);
        break;

    case  0x0072:
        other_info.Contrast =iniparser_getint(ini,"para:contrast",-1);  //0x0072 对比度，0-127
        para_buff[0] = other_info.Contrast >>24;
        para_buff[1] = other_info.Contrast >>16;
        para_buff[2] = other_info.Contrast >>8;
        para_buff[3] = other_info.Contrast ;
        return sizeof(other_info.Contrast);
        break;

    case  0x0073:
        other_info.Saturation=iniparser_getint(ini,"para:saturation",-1); //0x0073 饱和度，0-127
        para_buff[0] = other_info.Saturation >>24;
        para_buff[1] = other_info.Saturation >>16;
        para_buff[2] = other_info.Saturation >>8;
        para_buff[3] = other_info.Saturation ;
        return sizeof(other_info.Saturation);
        break;

    case  0x0074:
        other_info.Chroma=iniparser_getint(ini,"para:chroma",-1);  //0x0074 色度，0-255
        para_buff[0] = other_info.Chroma >>24;
        para_buff[1] = other_info.Chroma >>16;
        para_buff[2] = other_info.Chroma >>8;
        para_buff[3] = other_info.Chroma ;
        return sizeof(other_info.Chroma);
        break;

    case  0x0080:
        other_info.Car_Meilage =iniparser_getint(ini,"para:car_meilage",-1);  //0x0080 车辆里程表读数，1/10km
        para_buff[0] = other_info.Car_Meilage >>24;
        para_buff[1] = other_info.Car_Meilage >>16;
        para_buff[2] = other_info.Car_Meilage >>8;
        para_buff[3] = other_info.Car_Meilage ;
        return sizeof(other_info.Car_Meilage);
        break;

    case  0x0081:
        other_info.Province_ID=iniparser_getint(ini,"para:province_id",-1); //0x0081 车辆所在的省域ID
        para_buff[0] = other_info.Province_ID >>8;
        para_buff[1] = other_info.Province_ID ;
        return sizeof(other_info.Province_ID);
        break;

    case  0x0082:
        other_info.City_ID=iniparser_getint(ini,"para:city_id",-1); // 0x0082 车辆所在的市域ID
        para_buff[0] = other_info.City_ID >>8;
        para_buff[1] = other_info.City_ID ;
        return sizeof(other_info.City_ID);
        break;

    case  0x0083:
        str =  iniparser_getstring(ini,"para:motor_plate","null");
        str1 =  str;
        plate_length = Utils::string2code(str1,para_buff,str1.length()/2) -1;
//        memcpy(other_info.Motor_Plate,str,strlen(str));  //0x0083 公安交通管理部门颁发的机动车号牌
//        memcpy(para_buff ,(char*)other_info.Motor_Plate,plate_length);
        return  plate_length;

        break;

    case  0x0084:
        other_info.Plate_Color =iniparser_getint(ini,"para:plate_color",-1);   //0x0084 车牌颜色，按照JT/T415-2006的5.4.12
        para_buff[0] = other_info.Plate_Color ;
        return sizeof(other_info.Plate_Color);
        break;

    case  0x0085:
        other_info.Impulse_Ratio =iniparser_getint(ini,"para:impulse_ratio",-1);  //0x0085 车辆脉冲系数，车辆行驶1km距离过程中产生的脉冲信号个数
        para_buff[0] = other_info.Impulse_Ratio >>24;
        para_buff[1] = other_info.Impulse_Ratio >>16;
        para_buff[2] = other_info.Impulse_Ratio >>8;
        para_buff[3] = other_info.Impulse_Ratio ;
        return sizeof(other_info.Impulse_Ratio);
        break;
    }
    return 0;
}
int query_all(char temp_buf [1024],char size[2])
{
    CommunicateMainSet communicate_info;   //通信设置
    NetMainSet           net_info;                            //网络设置
    ReportMainSet     report_info;                       //汇报设置
    ListenMainSet      listen_info;                        // 监听设置
    ViewthresholdMainSet     view_info;            //视频监控设置
    OtherMainSet      other_info;                        //其他设置
    memset(&communicate_info,0,sizeof(communicate_info));
    memset(&net_info,0,sizeof(net_info));
    memset(&report_info,0,sizeof(report_info));
    memset(&listen_info,0,sizeof(listen_info));
    memset(&view_info,0,sizeof(view_info));
    memset(&other_info,0,sizeof(other_info));
    /*配置文件读取*/
    dictionary *ini;
    const char *str;
    int len =0;
    string str1;
    char para_buff[30];
    int pack_size = 0;
    int pos = 0;
    int paramID;
    int j=0;
    int flag = 0;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    if(ini == NULL)
    {
        fprintf(stderr,"can not open %s","parameters.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(ini,stderr);
    for(paramID=0;paramID<150;paramID++)
    {
        switch(paramID)
        {
        case  0x0001:
            communicate_info.Client_Heartbeat_Sec =iniparser_getint(ini,"para:client_heartbeat_sec",-1);  //0x0001 客户端心跳发送间隔，单位为秒(s)
            para_buff[0] = communicate_info.Client_Heartbeat_Sec >>24;
            para_buff[1] = communicate_info.Client_Heartbeat_Sec >>16;
            para_buff[2] = communicate_info.Client_Heartbeat_Sec >>8;
            para_buff[3] = communicate_info.Client_Heartbeat_Sec ;
            len = sizeof(communicate_info.Client_Heartbeat_Sec);
            flag = 1;
            break;

        case  0x0002:
            communicate_info.Tcp_Reply_Sec=iniparser_getint(ini,"para:tcp_reply_sec",-1);  //0x0002 TCP消息应答超时时间，单位为秒(s)
            para_buff[0] = communicate_info.Tcp_Reply_Sec >>24;
            para_buff[1] = communicate_info.Tcp_Reply_Sec >>16;
            para_buff[2] = communicate_info.Tcp_Reply_Sec >>8;
            para_buff[3] = communicate_info.Tcp_Reply_Sec ;
            len =  sizeof(communicate_info.Tcp_Reply_Sec);
            flag = 1;
            break;

        case  0x0003:
            communicate_info.Tcp_Retransmission=iniparser_getint(ini,"para:tcp_retransmission",-1); //0x0003 TCP消息重传次数
            para_buff[0] = communicate_info.Tcp_Retransmission >>24;
            para_buff[1] = communicate_info.Tcp_Retransmission >>16;
            para_buff[2] = communicate_info.Tcp_Retransmission >>8;
            para_buff[3] = communicate_info.Tcp_Retransmission ;
            len = sizeof(communicate_info.Tcp_Retransmission);
            flag = 1;
            break;

        case  0x0004:
            communicate_info.Udp_Reply_Sec=iniparser_getint(ini,"para:udp_reply_sec",-1);  //0x0004 UDP消息应答超时时间，单位为秒(s)
            para_buff[0] = communicate_info.Udp_Reply_Sec >>24;
            para_buff[1] = communicate_info.Udp_Reply_Sec >>16;
            para_buff[2] = communicate_info.Udp_Reply_Sec >>8;
            para_buff[3] = communicate_info.Udp_Reply_Sec ;
            len =  sizeof(communicate_info.Udp_Reply_Sec);
            flag = 1;
            break;

        case  0x0005:
            communicate_info.Udp_Retransmission=iniparser_getint(ini,"para:udp_retransmission",-1); //0x0005 UDP消息重传次数
            para_buff[0] = communicate_info.Udp_Retransmission >>24;
            para_buff[1] = communicate_info.Udp_Retransmission >>16;
            para_buff[2] = communicate_info.Udp_Retransmission >>8;
            para_buff[3] = communicate_info.Udp_Retransmission ;
            len = sizeof(communicate_info.Udp_Retransmission);
            flag = 1;
            break;

        case  0x0006:
            communicate_info.SMS_Reply_Sec=iniparser_getint(ini,"para:sms_reply_sec",-1);      //0x0006 SMS消息应答超时时间，单位为秒(s)
            para_buff[0] = communicate_info.SMS_Reply_Sec >>24;
            para_buff[1] = communicate_info.SMS_Reply_Sec >>16;
            para_buff[2] = communicate_info.SMS_Reply_Sec >>8;
            para_buff[3] = communicate_info.SMS_Reply_Sec ;
            len = sizeof(communicate_info.SMS_Reply_Sec);
            flag = 1;
            break;

        case  0x0007:
            communicate_info.SMS_Retransmission =iniparser_getint(ini,"para:sms_retransmission",-1);    //0x0007 SMS消息重传次数
            para_buff[0] = communicate_info.SMS_Retransmission >>24;
            para_buff[1] = communicate_info.SMS_Retransmission >>16;
            para_buff[2] = communicate_info.SMS_Retransmission >>8;
            para_buff[3] = communicate_info.SMS_Retransmission ;
            len =  sizeof(communicate_info.SMS_Retransmission);
            flag = 1;
            break;

        case  0x0010:
            str =  iniparser_getstring(ini,"para:mainserver_apn","null");
            memcpy(net_info.Mainserver_APN,str,strlen(str)); //0x0010 主服务器APN，无线通信拨号访问点。若网络制式为CDMA，则该处为PPP拨号号码
            memcpy(para_buff ,(char*)net_info.Mainserver_APN,strlen(str));
            len =   strlen(str);
            flag = 1;
            break;

        case  0x0011:
            str =  iniparser_getstring(ini,"para:mainserver_user","null"); //0x0011 主服务器无线通信拨号用户名
            memcpy(net_info.Mainserver_User,str,strlen(str));
            memcpy(para_buff ,(char*)net_info.Mainserver_User,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0012:
            str =  iniparser_getstring(ini,"para:backupserver_password","null");
            memcpy(net_info.Mainserver_Password,str,strlen(str));      //0x0012 主服务器无线通信拨号密码
            memcpy(para_buff ,(char*)net_info.Mainserver_Password,strlen(str));
            len =   strlen(str);
            flag = 1;
            break;

        case  0x0013:
            str =  iniparser_getstring(ini,"para:mainserver_ip","null");
            memcpy(net_info.Mainserver_IP,str,strlen(str));    //0x0013 主服务器地址，IP或域名
            memcpy(para_buff ,(char*)net_info.Mainserver_IP,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0014:
            str =  iniparser_getstring(ini,"para:backupserver_apn","null");
            memcpy(net_info.Backupserver_APN,str,strlen(str));   //0x0014 备份服务器APN，无线通信拨号访问点
            memcpy(para_buff ,(char*)net_info.Backupserver_APN,strlen(str));
            len =   strlen(str);
            flag = 1;
            break;

        case  0x0015:
            str =  iniparser_getstring(ini,"para:backupserver_user","null");
            memcpy(net_info.Backupserver_User,str,strlen(str));  //0x0015 备份服务器无线通信拨号用户名
            memcpy(para_buff ,(char*)net_info.Backupserver_User,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0016:
            str =  iniparser_getstring(ini,"para:backupserver_password","null");
            memcpy(net_info.Backupserver_Password,str,strlen(str));   //  0x0016 备份服务器无线通信拨号密码
            memcpy(para_buff ,(char*)net_info.Backupserver_Password,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0017:
            str =  iniparser_getstring(ini,"para:backupserver_ip","null");
            memcpy(net_info.Backupserver_IP,str,strlen(str));  //  0x0017 备份服务器地址，IP或域名
            memcpy(para_buff ,(char*)net_info.Backupserver_IP,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0018:
            net_info.Server_TCP_Port =iniparser_getint(ini,"para:server_tcp_port",-1); //  0x0018 服务器TCP端口
            para_buff[0] = net_info.Server_TCP_Port >>24;
            para_buff[1] = net_info.Server_TCP_Port >>16;
            para_buff[2] = net_info.Server_TCP_Port >>8;
            para_buff[3] = net_info.Server_TCP_Port ;
            len = sizeof(net_info.Server_TCP_Port);
            flag = 1;
            break;

        case  0x0019:
            net_info.Server_UDP_Port=iniparser_getint(ini,"para:server_udp_port",-1); //0x0019 服务器UDP端口
            para_buff[0] = net_info.Server_UDP_Port >>24;
            para_buff[1] = net_info.Server_UDP_Port >>16;
            para_buff[2] = net_info.Server_UDP_Port >>8;
            para_buff[3] = net_info.Server_UDP_Port ;
            len = sizeof(net_info.Server_UDP_Port);
            flag = 1;
            break;

        case  0x0020:
            report_info.Location_Report_Way =iniparser_getint(ini,"para:location_report_way",-1); //   0x0020 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报
            para_buff[0] = report_info.Location_Report_Way >>24;
            para_buff[1] = report_info.Location_Report_Way >>16;
            para_buff[2] = report_info.Location_Report_Way >>8;
            para_buff[3] = report_info.Location_Report_Way ;
            len = sizeof(report_info.Location_Report_Way);
            flag = 1;
            break;

        case  0x0021:
            report_info.Location_Report_Status=iniparser_getint(ini,"para:location_report_status",-1);  //0x0021 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态
            para_buff[0] = report_info.Location_Report_Status >>24;
            para_buff[1] = report_info.Location_Report_Status >>16;
            para_buff[2] = report_info.Location_Report_Status >>8;
            para_buff[3] = report_info.Location_Report_Status ;
            len = sizeof(report_info.Location_Report_Status);
            flag = 1;
            break;

        case  0x0022:
            report_info.Dri_Unlisted_Time_Report=iniparser_getint(ini,"para:dri_unlisted_time_report",-1);  //0x0022 驾驶员未登录汇报时间间隔，单位为秒(s),>0
            para_buff[0] = report_info.Dri_Unlisted_Time_Report >>24;
            para_buff[1] = report_info.Dri_Unlisted_Time_Report >>16;
            para_buff[2] = report_info.Dri_Unlisted_Time_Report >>8;
            para_buff[3] = report_info.Dri_Unlisted_Time_Report ;
            len = sizeof(report_info.Dri_Unlisted_Time_Report);
            flag = 1;
            break;

        case  0x0027:
            report_info.Dormant_Time_Report=iniparser_getint(ini,"para:dormant_time_report",-1);   //0x0027 休眠时汇报时间间隔，单位为秒(s),>0
            para_buff[0] = report_info.Dormant_Time_Report >>24;
            para_buff[1] = report_info.Dormant_Time_Report >>16;
            para_buff[2] = report_info.Dormant_Time_Report >>8;
            para_buff[3] = report_info.Dormant_Time_Report ;
            len = sizeof(report_info.Dormant_Time_Report);
            flag = 1;
            break;

        case  0x0028:
            report_info.Emergency_Alarm_Time_Report =iniparser_getint(ini,"para:emergency_alarm_time_report",-1);  //  0x0028 紧急报警时汇报时间间隔，单位为秒(s),>0
            para_buff[0] = report_info.Emergency_Alarm_Time_Report >>24;
            para_buff[1] = report_info.Emergency_Alarm_Time_Report >>16;
            para_buff[2] = report_info.Emergency_Alarm_Time_Report >>8;
            para_buff[3] = report_info.Emergency_Alarm_Time_Report ;
            len = sizeof(report_info.Emergency_Alarm_Time_Report);
            flag = 1;
            break;

        case  0x0029:
            report_info.Default_Time_Report =iniparser_getint(ini,"para:default_time_report",-1); //0x0029 缺省时间汇报间隔，单位为秒(s),>0
            para_buff[0] = report_info.Default_Time_Report >>24;
            para_buff[1] = report_info.Default_Time_Report >>16;
            para_buff[2] = report_info.Default_Time_Report >>8;
            para_buff[3] = report_info.Default_Time_Report ;
            len = sizeof(report_info.Default_Time_Report);
            flag = 1;
            break;

        case  0x002c:
            report_info.Default_Distance_Report=iniparser_getint(ini,"para:default_distance_report",-1);  //0x002C 缺省距离汇报间隔，单位为米(m),>0
            para_buff[0] = report_info.Default_Distance_Report >>24;
            para_buff[1] = report_info.Default_Distance_Report >>16;
            para_buff[2] = report_info.Default_Distance_Report >>8;
            para_buff[3] = report_info.Default_Distance_Report ;
            len = sizeof(report_info.Default_Distance_Report);
            flag = 1;
            break;

        case  0x002d:
            report_info.Dri_Unlisted_Distance_Report=iniparser_getint(ini,"para:dri_unlisted_distance_report",-1);  //0x002D 驾驶员未登录汇报距离间隔，单位为米(m),>0
            para_buff[0] = report_info.Dri_Unlisted_Distance_Report >>24;
            para_buff[1] = report_info.Dri_Unlisted_Distance_Report >>16;
            para_buff[2] = report_info.Dri_Unlisted_Distance_Report >>8;
            para_buff[3] = report_info.Dri_Unlisted_Distance_Report ;
            len = sizeof(report_info.Dri_Unlisted_Distance_Report);
            flag = 1;
            break;

        case  0x002e:
            report_info.Dormant_Distance_Report=iniparser_getint(ini,"para:dormant_distance_report",-1); //0x002E 休眠时汇报距离间隔，单位为米(m),>0
            para_buff[0] = report_info.Dormant_Distance_Report >>24;
            para_buff[1] = report_info.Dormant_Distance_Report >>16;
            para_buff[2] = report_info.Dormant_Distance_Report >>8;
            para_buff[3] = report_info.Dormant_Distance_Report ;
            len = sizeof(report_info.Dormant_Distance_Report);
            flag = 1;
            break;

        case  0x002f:
            report_info.Emergency_Alarm_Distance_Report =iniparser_getint(ini,"para:emergency_alarm_distance_report",-1); //0x002F 紧急报警时汇报距离间隔，单位为米(m),>0
            para_buff[0] = report_info.Emergency_Alarm_Distance_Report >>24;
            para_buff[1] = report_info.Emergency_Alarm_Distance_Report >>16;
            para_buff[2] = report_info.Emergency_Alarm_Distance_Report >>8;
            para_buff[3] = report_info.Emergency_Alarm_Distance_Report ;
            len = sizeof(report_info.Emergency_Alarm_Distance_Report);
            flag = 1;
            break;

        case  0x0030:
            report_info.Inflection_Point =iniparser_getint(ini,"para:inflection_point",-1);  //0x0030 拐点补传角度，<180°
            para_buff[0] = report_info.Inflection_Point >>24;
            para_buff[1] = report_info.Inflection_Point >>16;
            para_buff[2] = report_info.Inflection_Point >>8;
            para_buff[3] = report_info.Inflection_Point ;
            len = sizeof(report_info.Inflection_Point);
            flag = 1;
            break;

        case  0x0040:
            str =  iniparser_getstring(ini,"para:monitoring_platform_phone","null");
            memcpy(listen_info.Monitoring_Platform_Phone,str,strlen(str));   //  0x0017 备份服务器地址，IP或域名
            memcpy(para_buff ,(char*)listen_info.Monitoring_Platform_Phone,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0041:
            str =  iniparser_getstring(ini,"para:reset_phone","null");
            memcpy(listen_info.Reset_Phone,str,strlen(str));  // 0x0041 复位电话号码，可采用此电话号码拨打终端电话让终端复位
            memcpy(para_buff ,(char*)listen_info.Reset_Phone,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0042:
            str =  iniparser_getstring(ini,"para:factory_reset_phone","null");
            memcpy(listen_info.Factory_Reset_Phone,str,strlen(str));  // 0x0042 恢复出厂设置电话号码，可采用此电话号码拨打终端电话让终端恢复出厂设置
            memcpy(para_buff ,(char*)listen_info.Factory_Reset_Phone,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0043:
            str =  iniparser_getstring(ini,"para:monitoring_platform_sms_phone","null");
            memcpy(listen_info.Monitoring_Platform_SMS_Phone,str,strlen(str));   //0x0043 监控平台SMS电话号码
            memcpy(para_buff ,(char*)listen_info.Monitoring_Platform_SMS_Phone,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0044:
            str =  iniparser_getstring(ini,"para:receiving_sms_alarm","null");
            memcpy(listen_info.Receiving_SMS_Alarm,str,strlen(str));  //0x0044 接收终端SMS文本报警号码
            memcpy(para_buff ,(char*)listen_info.Receiving_SMS_Alarm,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0045:
            listen_info.Terminal_Phone_Way =iniparser_getint(ini,"para:terminal_phone_way",-1);  //0x0045 终端电话接听策略，0：自动接听；1：ACCON时自动接听，OFF时手动接听
            para_buff[0] = listen_info.Terminal_Phone_Way >>24;
            para_buff[1] = listen_info.Terminal_Phone_Way >>16;
            para_buff[2] = listen_info.Terminal_Phone_Way >>8;
            para_buff[3] = listen_info.Terminal_Phone_Way ;
            len = sizeof(listen_info.Terminal_Phone_Way);
            flag = 1;
            break;

        case  0x0046:
            listen_info.Phone_Time =iniparser_getint(ini,"para:phone_time",-1); //0x0046 每次最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
            para_buff[0] = listen_info.Phone_Time >>24;
            para_buff[1] = listen_info.Phone_Time >>16;
            para_buff[2] = listen_info.Phone_Time >>8;
            para_buff[3] = listen_info.Phone_Time ;
            len = sizeof(listen_info.Phone_Time);
            flag = 1;
            break;

        case  0x0047:
            listen_info.Phone_Time_Month =iniparser_getint(ini,"para:phone_time_month",-1); //0x0047 当月最长通话时间，单位为秒(s),0为不允许通话，0xFFFFFFFF为不限制
            para_buff[0] = listen_info.Phone_Time_Month >>24;
            para_buff[1] = listen_info.Phone_Time_Month >>16;
            para_buff[2] = listen_info.Phone_Time_Month >>8;
            para_buff[3] = listen_info.Phone_Time_Month ;
            len = sizeof(listen_info.Phone_Time_Month);
            flag = 1;
            break;

        case  0x0048:
            str =  iniparser_getstring(ini,"para:monitor_phone","null");
            memcpy(listen_info.Monitor_Phone,str,strlen(str));  //0x0048 监听电话号码
            memcpy(para_buff ,(char*)listen_info.Monitor_Phone,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0049:
            str =  iniparser_getstring(ini,"para:monitor_platform_text_phone","null");
            memcpy(listen_info.Monitor_Platform_Text_Phone,str,strlen(str));    //0x0049 监管平台特权短信号码
            memcpy(para_buff ,(char*)listen_info.Monitor_Platform_Text_Phone,strlen(str));
            len =  strlen(str);
            flag = 1;
            break;

        case  0x0050:
            view_info.Alarm_Shield_Byte =iniparser_getint(ini,"para:alarm_shield_byte",-1); //0x0050 报警屏蔽字。与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警被屏蔽
            para_buff[0] = view_info.Alarm_Shield_Byte >>24;
            para_buff[1] = view_info.Alarm_Shield_Byte >>16;
            para_buff[2] = view_info.Alarm_Shield_Byte >>8;
            para_buff[3] = view_info.Alarm_Shield_Byte ;
            len = sizeof(view_info.Alarm_Shield_Byte);
            flag = 1;
            break;

        case  0x0051:
            view_info.Alarm_Send_SMS_Text =iniparser_getint(ini,"para:alarm_send_sms_text",-1); //0x0051 报警发送文本SMS开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时发送文本SMS
            para_buff[0] = view_info.Alarm_Send_SMS_Text >>24;
            para_buff[1] = view_info.Alarm_Send_SMS_Text >>16;
            para_buff[2] = view_info.Alarm_Send_SMS_Text >>8;
            para_buff[3] = view_info.Alarm_Send_SMS_Text ;
            len = sizeof(view_info.Alarm_Send_SMS_Text);
            flag = 1;
            break;

        case  0x0052:
            view_info.Alarm_Picture_Switch =iniparser_getint(ini,"para:alarm_picture_switch",-1);  // 0x0052 报警拍摄开关，与位置信息汇报消息中的报警标识相对应，相应位为1则相应报警时摄像头拍摄
            para_buff[0] = view_info.Alarm_Picture_Switch >>24;
            para_buff[1] = view_info.Alarm_Picture_Switch >>16;
            para_buff[2] = view_info.Alarm_Picture_Switch >>8;
            para_buff[3] = view_info.Alarm_Picture_Switch ;
            len = sizeof(view_info.Alarm_Picture_Switch);
            flag = 1;
            break;

        case  0x0053:
            view_info.Alarm_Picture_Save =iniparser_getint(ini,"para:alarm_picture_save",-1);   //0x0053 报警拍摄存储标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警时牌的照片进行存储，否则实时长传
            para_buff[0] = view_info.Alarm_Picture_Save >>24;
            para_buff[1] = view_info.Alarm_Picture_Save >>16;
            para_buff[2] = view_info.Alarm_Picture_Save >>8;
            para_buff[3] = view_info.Alarm_Picture_Save ;
            len = sizeof(view_info.Alarm_Picture_Save);
            flag = 1;
            break;

        case  0x0054:
            view_info.Key_Identification =iniparser_getint(ini,"para:key_identification",-1);  //0x0054 关键标识，与位置信息汇报消息中的报警标识相对应，相应位为1则对相应报警为关键报警
            para_buff[0] = view_info.Key_Identification >>24;
            para_buff[1] = view_info.Key_Identification >>16;
            para_buff[2] = view_info.Key_Identification >>8;
            para_buff[3] = view_info.Key_Identification ;
            len = sizeof(view_info.Key_Identification);
            flag = 1;
            break;

        case  0x0055:
            view_info.High_Speed =iniparser_getint(ini,"para:high_speed",-1); //0x0055 最高速度，单位为公里每小时(km/h)
            para_buff[0] = view_info.High_Speed >>24;
            para_buff[1] = view_info.High_Speed >>16;
            para_buff[2] = view_info.High_Speed >>8;
            para_buff[3] = view_info.High_Speed ;
            len = sizeof(view_info.High_Speed);
            flag = 1;
            break;

        case  0x0056:
            view_info.OverSpeed_Time =iniparser_getint(ini,"para:overspeed_time",-1); // 0x0056 超速持续时间，单位为秒(s)
            para_buff[0] = view_info.OverSpeed_Time >>24;
            para_buff[1] = view_info.OverSpeed_Time >>16;
            para_buff[2] = view_info.OverSpeed_Time >>8;
            para_buff[3] = view_info.OverSpeed_Time ;
            len = sizeof(view_info.OverSpeed_Time);
            flag = 1;
            break;

        case  0x0057:
            view_info.Continue_Dri_Time =iniparser_getint(ini,"para:continue_dri_time",-1); //0x0057 连续驾驶时间门限，单位为秒(s)
            para_buff[0] = view_info.Continue_Dri_Time >>24;
            para_buff[1] = view_info.Continue_Dri_Time >>16;
            para_buff[2] = view_info.Continue_Dri_Time >>8;
            para_buff[3] = view_info.Continue_Dri_Time ;
            len = sizeof(view_info.Continue_Dri_Time);
            flag = 1;
            break;

        case  0x0058:
            view_info.Day_Dri_Time=iniparser_getint(ini,"para:day_dri_time",-1); //0x0058 当天累计驾驶时间门限，单位为秒(s)
            para_buff[0] = view_info.Day_Dri_Time >>24;
            para_buff[1] = view_info.Day_Dri_Time >>16;
            para_buff[2] = view_info.Day_Dri_Time >>8;
            para_buff[3] = view_info.Day_Dri_Time ;
            len = sizeof(view_info.Day_Dri_Time);
            flag = 1;
            break;

        case  0x0059:
            view_info.Mini_Reset_Time=iniparser_getint(ini,"para:mini_reset_time",-1); //0x0059 最小休息时间，单位为秒(s)
            para_buff[0] = view_info.Mini_Reset_Time >>24;
            para_buff[1] = view_info.Mini_Reset_Time >>16;
            para_buff[2] = view_info.Mini_Reset_Time >>8;
            para_buff[3] = view_info.Mini_Reset_Time ;
            len = sizeof(view_info.Mini_Reset_Time);
            flag = 1;
            break;

        case  0x005a:
            view_info.Max_Park_Time=iniparser_getint(ini,"para:max_park_time",-1); //0x005A 最长停车时间，单位为秒(s)
            para_buff[0] = view_info.Max_Park_Time >>24;
            para_buff[1] = view_info.Max_Park_Time >>16;
            para_buff[2] = view_info.Max_Park_Time >>8;
            para_buff[3] = view_info.Max_Park_Time ;
            len = sizeof(view_info.Max_Park_Time);
            flag = 1;
            break;

        case  0x0070:
            other_info.Picture=iniparser_getint(ini,"para:picture",-1); //0x0070 图像/视频质量，1-10,1最好
            para_buff[0] = other_info.Picture >>24;
            para_buff[1] = other_info.Picture >>16;
            para_buff[2] = other_info.Picture >>8;
            para_buff[3] = other_info.Picture ;
            len = sizeof(other_info.Picture);
            flag = 1;
            break;

        case  0x0071:
            other_info.Lightness=iniparser_getint(ini,"para:lightness",-1); //0x0071 亮度，0-255
            para_buff[0] = other_info.Lightness >>24;
            para_buff[1] = other_info.Lightness >>16;
            para_buff[2] = other_info.Lightness >>8;
            para_buff[3] = other_info.Lightness ;
            len = sizeof(other_info.Lightness);
            flag = 1;
            break;

        case  0x0072:
            other_info.Contrast =iniparser_getint(ini,"para:contrast",-1);  //0x0072 对比度，0-127
            para_buff[0] = other_info.Contrast >>24;
            para_buff[1] = other_info.Contrast >>16;
            para_buff[2] = other_info.Contrast >>8;
            para_buff[3] = other_info.Contrast ;
            len = sizeof(other_info.Contrast);
            flag = 1;
            break;

        case  0x0073:
            other_info.Saturation=iniparser_getint(ini,"para:saturation",-1); //0x0073 饱和度，0-127
            para_buff[0] = other_info.Saturation >>24;
            para_buff[1] = other_info.Saturation >>16;
            para_buff[2] = other_info.Saturation >>8;
            para_buff[3] = other_info.Saturation ;
            len = sizeof(other_info.Saturation);
            flag = 1;
            break;

        case  0x0074:
            other_info.Chroma=iniparser_getint(ini,"para:chroma",-1);  //0x0074 色度，0-255
            para_buff[0] = other_info.Chroma >>24;
            para_buff[1] = other_info.Chroma >>16;
            para_buff[2] = other_info.Chroma >>8;
            para_buff[3] = other_info.Chroma ;
            len = sizeof(other_info.Chroma);
            flag = 1;
            break;

        case  0x0080:
            other_info.Car_Meilage =iniparser_getint(ini,"para:car_meilage",-1);  //0x0080 车辆里程表读数，1/10km
            para_buff[0] = other_info.Car_Meilage >>24;
            para_buff[1] = other_info.Car_Meilage >>16;
            para_buff[2] = other_info.Car_Meilage >>8;
            para_buff[3] = other_info.Car_Meilage ;
            len = sizeof(other_info.Car_Meilage);
            flag = 1;
            break;

        case  0x0081:
            other_info.Province_ID=iniparser_getint(ini,"para:province_id",-1); //0x0081 车辆所在的省域ID
            para_buff[0] = other_info.Province_ID >>8;
            para_buff[1] = other_info.Province_ID ;
            len = sizeof(other_info.Province_ID);
            flag = 1;
            break;

        case  0x0082:
            other_info.City_ID=iniparser_getint(ini,"para:city_id",-1); // 0x0082 车辆所在的市域ID
            para_buff[0] = other_info.City_ID >>8;
            para_buff[1] = other_info.City_ID ;
            len = sizeof(other_info.City_ID);
            flag = 1;
            break;

        case  0x0083:
            str =  iniparser_getstring(ini,"para:motor_plate","null");
            str1 =  str;
            len = Utils::string2code(str1,para_buff,str1.length()/2) - 1;
//            memcpy(other_info.Motor_Plate,str,strlen(str));  //0x0083 公安交通管理部门颁发的机动车号牌
//            memcpy(para_buff ,(char*)other_info.Motor_Plate,strlen(str));
//            len =  strlen(str);
            flag = 1;
            break;
        case  0x0084:
            other_info.Plate_Color =iniparser_getint(ini,"para:plate_color",-1);   //0x0084 车牌颜色，按照JT/T415-2006的5.4.12
            para_buff[0] = other_info.Plate_Color ;
            len = sizeof(other_info.Plate_Color);
            flag = 1;
            break;

        case  0x0085:
            other_info.Impulse_Ratio =iniparser_getint(ini,"para:impulse_ratio",-1);  //0x0085 车辆脉冲系数，车辆行驶1km距离过程中产生的脉冲信号个数
            para_buff[0] = other_info.Impulse_Ratio >>24;
            para_buff[1] = other_info.Impulse_Ratio >>16;
            para_buff[2] = other_info.Impulse_Ratio >>8;
            para_buff[3] = other_info.Impulse_Ratio ;
            len = sizeof(other_info.Impulse_Ratio);
            flag = 1;
            break;
        }
        if(flag == 1)
        {
            int tempid = htonl(paramID);
            memcpy(&temp_buf[pos],&tempid,4);
            pos = pos +4;
            temp_buf[pos] = len;
            pos = pos +1;
            memcpy(&temp_buf[pos],para_buff,len);
            pos = pos +len;
            flag = 0;
            pack_size++;
        }
    }
    size[0] = pack_size;
    return pos;
}

/*查询终端参数*/
int exeSearchTerminalData::int_cmd(string phonenum)
{
    int len =0;
    unsigned char pnum[32];
    m_MsgHead.Msg_ID = htons(CMD_T2P_ASKSETTERMINALDATA);
    m_MsgHead.v_protocol = JDTraining;

    stMsgType m;
    m.MsgDiv = 0;
    m.MsgEncrypt = 0;
    m.MsgLength = 0;
    m.MsgReserved = 0;

    unsigned short m_type;
    memcpy(&m_type,&m,sizeof(unsigned short));
    m_type = htons(m_type);
    memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
    memset(pnum,0,32);
    len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
    if(len > 8)
    {
        wlog(WIS_ERROR,"Cmd Format beartError! \n");
    }

    if(len<8){
        for(int i =7;i>len-1;i--)   //前向 补0
        {
            m_MsgHead.Dev_PhoneNum[i] = 0x00;
            wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
        }
    }
    for(int i =0;i<len;i++)   //
    {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
    }
    m_MsgHead.Msg_Seq = htons(Get_Seq());

    m_MsgHead.Reserved=0x3C;//预留字段

}


int exeSearchTerminalData::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_ASKSETTERMINALDATA;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    Add_Seq();
    return sizeof(m_MsgHead);
}


int exeSearchTerminalData::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    SearchTerminalParamAck minfo;
    char  temp_buf [1024];
    short flowidtemp=0;
    flowidtemp=p->td_content[13]<<8|p->td_content[14];
    char pack_size[2];
    int pos = 0;
    if(p->td_bodyLength == 16)
    {
        TRACE_INFO("查询计时终端参数\n");
        pos = query_all(temp_buf,pack_size);
    }
    minfo.ackflowid = htons(flowidtemp);
    minfo.ackparamnum = pack_size[0];
    minfo.packge = pack_size[0];
    int counts=pos/700;
    if(pos>700){
        for(int i=0;i<counts;i++)
        {
            if(i==counts-1){
                appcon.do_search_select_terminaldata(minfo,counts,i+1,&temp_buf[i*700],(pos%700));
            }else{
                appcon.do_search_select_terminaldata(minfo,counts,i+1,&temp_buf[i*700],700);
            }
        }
    }else{
        appcon.do_search_select_terminaldata(minfo,0,0,temp_buf,pos);
    }


    return 0;
}


int exeSearchTerminalData::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[1024];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;                                        //分包上传
    if(p->encodeflag)
    {
        m_head.MsgDiv = 1;//test  6.12
    }else
    {
        m_head.MsgDiv = 0;//test  6.12
    }
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    if(p->encodeflag)
    {
        unsigned char data2[2];
        data2[0]=(p->mainpackgesize)>>8;
        data2[1]=p->mainpackgesize;
        unsigned   char  data3[2];
        data3[0]=(p->packgeindex)>>8;
        data3[1]=p->packgeindex;
        memcpy(&p->ts_content[16],(char *)& data2[0],2);
        memcpy(&p->ts_content[18],(char *)& data3[0],2);
    }
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
    m_appGateway->nTcp_Send(buf,length);
    return 0;
}



/*设置终端参数*/
int exeSetTerminalData::int_cmd(string phonenum){}
int exeSetTerminalData::format_cmd(void *param){}
int exeSetTerminalData::exe_cmd(void *param){}
int exeSetTerminalData::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    SetTerminaldata s_data;
    common_Info   minfo;
    int i =16;
    int j = 0;
    short flowidtemp=0;
    flowidtemp=p->td_content[13]<<8|p->td_content[14];
    s_data.pacagesize = p->td_content[i];  //参数总数
    s_data.subpacagesize = p->td_content[++i];   //分包参数个数
    for(j=0;j<s_data.pacagesize;j++)
    {

        TRACE_INFO("\n参数标志2\n"  );
        s_data.param_s.paramID =((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000) | ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);  //参数ID

        TRACE_INFO("参数ID:%02x",s_data.param_s.paramID);

        s_data.param_s.paramlength = p->td_content[++i];  //参数长度
        for(int j =0;j<s_data.param_s.paramlength;j++)
        {
            s_data.param_s.paramdata[j] = p->td_content[++i];  //参数值
        }
        parameter(s_data.param_s.paramID,s_data.param_s.paramdata,int(s_data.param_s.paramlength));   //参数设置
    }

    minfo.REPLY_FLOW_ID = htons(flowidtemp);
    minfo.Response_ID = htons(CMD_P2T_SETTERMINALDATAACK);
    minfo.Response_Result = 0x00;
    appcon.do_common_response(minfo);

    return 0;
}




/*终端控制 */
int exeTerminalDataControl::int_cmd(string phonenum){}
int exeTerminalDataControl::format_cmd(void *param){}
int exeTerminalDataControl::exe_cmd(void *param){}
int exeTerminalDataControl::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    TerminalControl terminalcon_info;
    CommandParam commandpara_info;
    common_Info   minfo;
    int i =16;
    int j = 0;
    int m = 0;   //分号区分位
    int k = 0;
    string urlname;
    string filename;
    vector<string>  result;
    int flag_result;
    short flowidtemp=0;
    flowidtemp=p->td_content[13]<<8|p->td_content[14];
    char para_buff[256];
    terminalcon_info.cmdid = p->td_content[i];   //命令字
    int url_len,dialpointname_len,dialpointuser_len,dialpassword_len,address_len,manufactorID_len,hardversion_len,firmwareversion_len;
    int identifycode_len;

    if(terminalcon_info.cmdid == 1)
    {
        printf("无线升级:\n");
        printf("URL地址;拨号点名称;拨号用户名;拨号密码;IP地址;TCP端口;UDP端口;制造商ID;硬件版本;固件版本;连接到指定服务器时限\n");
        //    QString str(p->td_content+16);
        //"http://121.42.184.43/DriveApp", "1", "1", "1", "114.215.173.239", "#)", "#)", "01235", "1.0", "1.6.2",
        QByteArray array(p->td_content+17,p->td_bodyLength-17);
        QList<QByteArray>  list=  array.split(';');
        qDebug()<< list;
        memset(&commandpara_info,0x00,sizeof(commandpara_info));
        if(list.size()>9){
            QByteArray  arr=   list.at(0).trimmed();
            urlname=arr.data();
            memcpy(commandpara_info.addressURL, arr,arr.size()); //URL地址;
            Configuration_parameter_set("control:addressURL ",(char*)commandpara_info.addressURL);
            arr=   list.at(1).trimmed();
            memcpy(commandpara_info.dialpointname, arr,arr.size());   //拨号点名称;
            Configuration_parameter_set("control:dialpointname ",(char*)commandpara_info.dialpointname);

            arr=   list.at(2).trimmed();
            memcpy(commandpara_info.dialpointuser, arr,arr.size());   //拨号用户名;
            Configuration_parameter_set("control:dialpointuser ",(char*)commandpara_info.dialpointuser);

            arr=   list.at(3).trimmed();
            memcpy(commandpara_info.dialpassword, arr,arr.size());    //拨号密码;
            Configuration_parameter_set("control:dialpassword ",(char*)commandpara_info.dialpassword);

            arr=   list.at(4).trimmed();
            memcpy(commandpara_info.address, arr,arr.size());   //IP地址;
            Configuration_parameter_set("control:address ",(char*)commandpara_info.address);

            arr=   list.at(5).trimmed();
            if(arr.size()==2){
                commandpara_info.TCPpoint=   arr.data()[0]<<8| arr.data()[1];
                memset(para_buff,0x00,255);
                sprintf(para_buff,"%d",commandpara_info.TCPpoint);
                Configuration_parameter_set("control:TCPpoint ",para_buff);
            }
            arr=   list.at(6).trimmed();
            if(arr.size()==2){
                commandpara_info.UDPpoint=   arr.data()[0]<<8| arr.data()[1];
                memset(para_buff,0x00,255);
                sprintf(para_buff,"%d",commandpara_info.UDPpoint);
                Configuration_parameter_set("control:UDPpoint ",para_buff);

            }
            TRACE_INFO("\nTcp:%d===Udp:%d\n",commandpara_info.TCPpoint,commandpara_info.UDPpoint);
            //
            TRACE_ERR("\nbiaozhi2\n");

            arr=   list.at(7).trimmed();
            TRACE_ERR("\nbiaozhi3\n");
            memcpy(commandpara_info.manufactorID, arr,arr.size());  //制造商ID;
            Configuration_parameter_set("control:manufactorID ",(char*)commandpara_info.manufactorID);

            arr=   list.at(8).trimmed();
            memcpy(commandpara_info.hardversion, arr,arr.size());  //硬件版本;
            Configuration_parameter_set("control:hardversion ",(char*)commandpara_info.hardversion);

            arr=   list.at(9).trimmed();
            memcpy(commandpara_info.firmwareversion, arr,arr.size());  //固件版本;
            Configuration_parameter_set("control:firmwareversion ",(char*)commandpara_info.firmwareversion);
            arr=   list.at(9).trimmed();
            if(arr.size()==2){
            commandpara_info.connectTimeLimit=arr.data()[0]<<8|arr.data()[1];  //
            sprintf(para_buff,"%d",commandpara_info.connectTimeLimit);
            Configuration_parameter_set("control:connectTimeLimit",para_buff);
             }

        }else{
            return STATUS_ERROR;
        }
        //        //memset(para_buff,0,256);
        //        //memcpy(para_buff ,(char*)commandpara_info.addressURL,url_len);
        //        Configuration_parameter_set("control:addressURL ",(char*)commandpara_info.addressURL);
        //        memset(para_buff,0,url_len);
        //        urlname = (char *)commandpara_info.addressURL;
        //        TRACE_ERR("\nbiaozhi4\n");
        //        memcpy(para_buff ,(char*)commandpara_info.dialpointname,dialpointname_len);
        //        Configuration_parameter_set("control:dialpointname ",para_buff);
        //        memset(para_buff,0,dialpointname_len);
        //        TRACE_ERR("\nbiaozhi6\n");
        //        memcpy(para_buff ,(char*)commandpara_info.dialpointuser,dialpointuser_len);
        //        Configuration_parameter_set("control:dialpointuser ",para_buff);
        //        memset(para_buff,0,dialpointuser_len);

        //        memcpy(para_buff ,(char*)commandpara_info.dialpassword,dialpassword_len);
        //        Configuration_parameter_set("control:dialpassword ",para_buff);
        //        memset(para_buff,0,dialpassword_len);

        //        memcpy(para_buff ,(char*)commandpara_info.address,address_len);
        //        Configuration_parameter_set("control:address ",para_buff);
        //        memset(para_buff,0,address_len);

        //        sprintf(para_buff,"%d",commandpara_info.TCPpoint);
        //        Configuration_parameter_set("control:TCPpoint ",para_buff);
        //        memset(para_buff,0,sizeof(commandpara_info.TCPpoint));

        //        sprintf(para_buff,"%d",commandpara_info.UDPpoint);
        //        Configuration_parameter_set("control:UDPpoint ",para_buff);
        //        memset(para_buff,0,sizeof(commandpara_info.UDPpoint));
        //        TRACE_ERR("\nbiaozhi8\n");
        //        memcpy(para_buff ,(char*)commandpara_info.manufactorID,manufactorID_len);
        //        Configuration_parameter_set("control:manufactorID ",para_buff);
        //        memset(para_buff,0,manufactorID_len);

        //        memcpy(para_buff ,(char*)commandpara_info.hardversion,hardversion_len);
        //        Configuration_parameter_set("control:hardversion ",para_buff);
        //        memset(para_buff,0,hardversion_len);

        //        memcpy(para_buff ,(char*)commandpara_info.firmwareversion,firmwareversion_len);
        //        Configuration_parameter_set("control:firmwareversion ",para_buff);
        //        memset(para_buff,0,firmwareversion_len);
        //        TRACE_ERR("\nbiaozhi9\n");


        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
        TRACE_INFO("url: %s \n",urlname.c_str());
        result = Utils::splitString(urlname,"/");
        filename = "/user/"+result[result.size()-1];
        UpdateFlag = 1;
        flag_result = verUpdate::getInstance()->httpPostDownLoad(urlname,filename);
        UpdateFlag = 2;
        if(flag_result == 0 )
        {
            TtsUtils::getInstance()->sendVoice("固件更新成功，稍后重启");
            string a = result[result.size()-1];
            memcpy(para_buff ,(char*)a.c_str(),a.length());
            Configuration_parameter_set("control:filename",para_buff);
            memset(para_buff,0,a.length());
            sleep(4);
            system("reboot");
        }
        else if(flag_result == 1)
        {
            TtsUtils::getInstance()->sendVoice("固件更新失败");
        }

    }

#if  0
    if(terminalcon_info.cmdid == 1)
    {
        printf("无线升级:\n");
        printf("URL地址;拨号点名称;拨号用户名;拨号密码;IP地址;TCP端口;UDP端口;制造商ID;硬件版本;固件版本;连接到指定服务器时限\n");
        for(j = 0;j<p->td_bodyLength-17;j++)
        {
            if(p->td_content[i+1] == 0x3b)
            {
                ++m;
                ++i;
                k = 0;
            }
            if(m == 0)
            {
                if(p->td_content[i+1] == 0x3b){             }
                else
                {
                    commandpara_info.addressURL[k++] =  p->td_content[++i];   //  URL地址
                    printf("%02x",commandpara_info.addressURL[k]);
                    url_len = k;
                }
            }
            if(m == 1)
            {
                if(p->td_content[i+1] == 0x3b){             }
                else
                {
                    commandpara_info.dialpointname[k++] = p->td_content[++i];    //拨号点名称
                    printf("拨号点名称:%02x \n",commandpara_info.dialpointname[k]);
                    dialpointname_len = k;
                }
            }
            if(m == 2)
            {
                if(p->td_content[i+1] == 0x3b){              }
                else
                {
                    commandpara_info.dialpointuser[k++] = p->td_content[++i];    //拨号用户名
                    printf("拨号用户名: %02x\n",commandpara_info.dialpointuser[k]);
                    dialpointuser_len = k;
                }
            }
            if(m == 3)
            {
                if(p->td_content[i+1] == 0x3b) { }
                else
                {
                    commandpara_info.dialpassword[k++] = p->td_content[++i];    //拨号密码
                    printf("拨号密码 : %02x\n",commandpara_info.dialpassword[k]);
                    dialpassword_len = k;
                }
            }
            if(m == 4)
            {
                if(p->td_content[i+1] == 0x3b){              }
                else
                {
                    commandpara_info.address[k++] = p->td_content[++i];    //IP地址
                    printf("IP地址 : %02x\n",commandpara_info.address[k]);
                    address_len = k;
                }
            }
            if(m == 5)
            {
                if(p->td_content[i+1] == 0x3b){          }
                else
                {
                    commandpara_info.TCPpoint =  ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);    //UDP端口
                    printf("UDP端口 : %02x\n",commandpara_info.TCPpoint);
                }
            }
            if(m == 6)
            {
                if(p->td_content[i+1] == 0x3b){            }
                else
                {
                    commandpara_info.UDPpoint = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);    //TCP端口
                    printf("TCP端口 : %02x\n",commandpara_info.UDPpoint);
                }
            }
            if(m == 7)
            {
                if(p->td_content[i+1] == 0x3b){                }
                else
                {
                    commandpara_info.manufactorID[k++] = p->td_content[++i];    //制造商ID
                    printf("制造商ID : %02x\n",commandpara_info.manufactorID[k]);
                    manufactorID_len = k;
                }
            }
            if(m == 8)
            {
                if(p->td_content[i+1] == 0x3b) {       }
                else
                {
                    commandpara_info.hardversion[k++] = p->td_content[++i];    //硬件版本
                    printf("硬件版本 : %02x\n",commandpara_info.hardversion[k]);
                    hardversion_len = k;
                }
            }
            if(m == 9)
            {
                if(p->td_content[i+1] == 0x3b){            }
                else
                {
                    commandpara_info.firmwareversion[k++] = p->td_content[++i];    //固件版本
                    printf("固件版本 : %02x\n",commandpara_info.firmwareversion[k]);
                    firmwareversion_len = k;
                }
            }
            if(m == 10)
            {
                if(p->td_content[i+1] == 0x3b){             }
                else
                {
                    commandpara_info.connectTimeLimit = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);    //连接到指定服务器时限
                    printf("连接到指定服务器时限 : %02x\n",commandpara_info.connectTimeLimit);
                    break;
                }
            }
        }
     memset(&commandpara_info,0x00,sizeof(commandpara_info));
        memset(para_buff,0,256);
        memcpy(para_buff ,(char*)commandpara_info.addressURL,url_len);
        Configuration_parameter_set("control:addressURL ",para_buff);
        memset(para_buff,0,url_len);
        urlname = (char *)commandpara_info.addressURL;

        memcpy(para_buff ,(char*)commandpara_info.dialpointname,dialpointname_len);
        Configuration_parameter_set("control:dialpointname ",para_buff);
        memset(para_buff,0,dialpointname_len);

        memcpy(para_buff ,(char*)commandpara_info.dialpointuser,dialpointuser_len);
        Configuration_parameter_set("control:dialpointuser ",para_buff);
        memset(para_buff,0,dialpointuser_len);

        memcpy(para_buff ,(char*)commandpara_info.dialpassword,dialpassword_len);
        Configuration_parameter_set("control:dialpassword ",para_buff);
        memset(para_buff,0,dialpassword_len);

        memcpy(para_buff ,(char*)commandpara_info.address,address_len);
        Configuration_parameter_set("control:address ",para_buff);
        memset(para_buff,0,address_len);

        sprintf(para_buff,"%d",commandpara_info.TCPpoint);
        Configuration_parameter_set("control:TCPpoint ",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.TCPpoint));

        sprintf(para_buff,"%d",commandpara_info.UDPpoint);
        Configuration_parameter_set("control:UDPpoint ",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.UDPpoint));

        memcpy(para_buff ,(char*)commandpara_info.manufactorID,manufactorID_len);
        Configuration_parameter_set("control:manufactorID ",para_buff);
        memset(para_buff,0,manufactorID_len);

        memcpy(para_buff ,(char*)commandpara_info.hardversion,hardversion_len);
        Configuration_parameter_set("control:hardversion ",para_buff);
        memset(para_buff,0,hardversion_len);

        memcpy(para_buff ,(char*)commandpara_info.firmwareversion,firmwareversion_len);
        Configuration_parameter_set("control:firmwareversion ",para_buff);
        memset(para_buff,0,firmwareversion_len);

        sprintf(para_buff,"%d",commandpara_info.connectTimeLimit);
        Configuration_parameter_set("control:connectTimeLimit",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.connectTimeLimit));

        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
        TRACE_INFO("url: %s \n",urlname.c_str());
        result = Utils::splitString(urlname,"/");
        filename = "/user/"+result[result.size()-1];
        UpdateFlag = 1;
        flag_result = verUpdate::getInstance()->httpPostDownLoad(urlname,filename);
        UpdateFlag = 2;
        if(flag_result == 0 )
        {
            string a = result[result.size()-1];
            memcpy(para_buff ,(char*)a.c_str(),a.length());
            Configuration_parameter_set("control:filename",para_buff);
            memset(para_buff,0,a.length());
            system("reboot");
        }
        else if(flag_result == 1)
        {
            TtsUtils::getInstance()->sendVoice("固件更新失败");
        }
    }
#endif
    if(terminalcon_info.cmdid == 2)
    {
        printf("控制终端连接指定服务器:\n");
        printf("连接控制;监管平台鉴权码;拨号点名称;拨号用户名;拨号密码;IP地址;TCP端口;UDP端口;连接到指定服务器时限\n");
        for(j = 0;j<p->td_bodyLength-17;j++)
        {
            if(p->td_content[i+1] == 0x3b)
            {
                m++;
                ++i;
                k = 0;
            }
            if(m == 0)
            {
                if(p->td_content[i+1] == 0x3b){  }
                else
                {
                    commandpara_info.connectcontrol = p->td_content[++i];//<<8)&0xff00) | (p->td_content[++i]&0xff);   //  连接控制
                    printf("连接控制 : %02x\n",commandpara_info.connectcontrol );
                }
            }
            if(m == 1)
            {
                if(p->td_content[i+1] == 0x3b){   }
                else
                {
                    commandpara_info.identifycode[++k] = p->td_content[++i];    //监管平台鉴权码
                    printf("监管平台鉴权码 : %02x\n",commandpara_info.identifycode[k]);
                    identifycode_len = k;
                }
            }
            if(m == 2)
            {
                if(p->td_content[i+1] == 0x3b){     }
                else
                {
                    commandpara_info.dialpointname[++k] = p->td_content[++i];    //拨号点名称
                    printf("拨号点名称 : %02x\n",commandpara_info.dialpointname[k]);
                    dialpointname_len = k;
                }
            }
            if(m == 3)
            {
                if(p->td_content[i+1] == 0x3b){   }
                else
                {
                    commandpara_info.dialpointuser[++k] = p->td_content[++i];    //拨号用户名
                    printf("拨号用户名 : %02x\n",commandpara_info.dialpointuser[k]);
                    dialpointuser_len = k;
                }
            }
            if(m == 4)
            {
                if(p->td_content[i+1] == 0x3b) {   }
                else
                {
                    commandpara_info.dialpassword[++k] = p->td_content[++i];    //拨号密码
                    printf("拨号密码 : %02x\n",commandpara_info.dialpassword[k]);
                    dialpassword_len = k;
                }
            }
            if(m == 5)
            {
                if(p->td_content[i+1] == 0x3b){      }
                else
                {
                    commandpara_info.address[++k] = p->td_content[++i];    //IP地址
                    printf("IP地址 : %02x\n",commandpara_info.address[k]);
                    address_len = k;
                }
            }
            if(m == 6)
            {
                if(p->td_content[i+1] == 0x3b){  }
                else
                {
                    commandpara_info.TCPpoint =  ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);    //UDP端口
                    printf("UDP端口 : %02x\n",commandpara_info.TCPpoint);
                }
            }
            if(m == 7)
            {
                if(p->td_content[i+1] == 0x3b){  }
                else
                {
                    commandpara_info.UDPpoint = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);    //TCP端口
                    printf("TCP端口 : %02x\n",commandpara_info.UDPpoint);
                }
            }
            if(m == 8)
            {
                if(p->td_content[i+1] == 0x3b){ }
                else
                {
                    commandpara_info.connectTimeLimit = ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);    //连接到指定服务器时限
                    printf("连接到指定服务器时限 : %02x\n",commandpara_info.connectTimeLimit);
                    return 0;
                }
            }
        }

        sprintf(para_buff,"%d",commandpara_info.connectcontrol);
        Configuration_parameter_set("control:connectcontrol ",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.connectcontrol));

        memcpy(para_buff ,(char*)commandpara_info.identifycode,identifycode_len);
        Configuration_parameter_set("control:identifycode ",para_buff);
        memset(para_buff,0,identifycode_len);

        memcpy(para_buff ,(char*)commandpara_info.dialpointname,dialpointname_len);
        Configuration_parameter_set("control:dialpointname ",para_buff);
        memset(para_buff,0,dialpointname_len);

        memcpy(para_buff ,(char*)commandpara_info.dialpointuser,dialpointuser_len);
        Configuration_parameter_set("control:dialpointuser ",para_buff);
        memset(para_buff,0,dialpointuser_len);

        memcpy(para_buff ,(char*)commandpara_info.dialpassword,dialpassword_len);
        Configuration_parameter_set("control:dialpassword ",para_buff);
        memset(para_buff,0,dialpassword_len);

        memcpy(para_buff ,(char*)commandpara_info.address,address_len);
        Configuration_parameter_set("control:address ",para_buff);
        memset(para_buff,0,address_len);

        sprintf(para_buff,"%d",commandpara_info.TCPpoint);
        Configuration_parameter_set("control:TCPpoint",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.TCPpoint));

        sprintf(para_buff,"%d",commandpara_info.UDPpoint);
        Configuration_parameter_set("control:UDPpoint",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.UDPpoint));

        sprintf(para_buff,"%d",commandpara_info.connectTimeLimit);
        Configuration_parameter_set("control:connectTimeLimit",para_buff);
        memset(para_buff,0,sizeof(commandpara_info.connectTimeLimit));

        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
    }
    if(terminalcon_info.cmdid == 3)
    {
        printf("终端关机\n");                                          // five interface to do
        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
    }
    if(terminalcon_info.cmdid == 4)
    {
        printf("终端复位\n");
        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
    }
    if(terminalcon_info.cmdid == 5)
    {
        printf("终端恢复出厂设置\n");
        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
    }
    if(terminalcon_info.cmdid == 6)
    {
        printf("关闭数据通信\n");
        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
    }
    if(terminalcon_info.cmdid == 7)
    {
        printf("关闭所有无线通信\n");
        minfo.REPLY_FLOW_ID = htons(flowidtemp);
        minfo.Response_ID = htons(CMD_P2T_TERMINALCONTROL);
        minfo.Response_Result = 0x00;
        appcon.do_common_response(minfo);
    }
    return 0;
}




/*查询指定终端参数*/
int exeSearchSelectTerminalData::int_cmd(string phonenum){}
int exeSearchSelectTerminalData::format_cmd(void *param){}
int exeSearchSelectTerminalData::exe_cmd(void *param){}
int exeSearchSelectTerminalData::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    SearchSelectTerminalParam selectparam_info;
    SearchTerminalParamAck minfo;
    int i =16;
    char para_buf[20];
    char  temp_buf [1024];
    short flowidtemp=0;
    flowidtemp=p->td_content[13]<<8|p->td_content[14];
    int len;
    int pos = 0;
    selectparam_info.parametersize = p->td_content[i]&0xff;  //参数总数
    for(int j = 0;j<selectparam_info.parametersize;j++)
    {
        memset(para_buf,0,sizeof(para_buf));
        selectparam_info.parameterlist[j] = ((p->td_content[++i]<<24)&0xff000000) | ((p->td_content[++i]<<16)&0xff0000) | ((p->td_content[++i]<<8)&0xff00) | (p->td_content[++i]&0xff);   //参数ID
        len = para_query(selectparam_info.parameterlist[j],para_buf);
        int tempid = htonl(selectparam_info.parameterlist[j]);
        memcpy(&temp_buf[pos],&tempid,4);
        pos = pos +4;
        temp_buf[pos] = len;
        pos = pos +1;
        memcpy(&temp_buf[pos],para_buf,len);
        pos = pos +len;
    }
    printf("查询指定终端参数解析成功\n");
    minfo.ackflowid = htons(flowidtemp);
    minfo.ackparamnum = selectparam_info.parametersize;
    minfo.packge = selectparam_info.parametersize;
    appcon.do_search_select_terminaldata(minfo,0,0,temp_buf,pos);
    //    for(int index=0;index<pos;index++)
    //    {
    //        printf("数值为%02x",temp_buf[index]);
    //    }

    return 0;
}
