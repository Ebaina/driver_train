﻿#ifndef EXECOACHLOGIN_H
#define EXECOACHLOGIN_H
#include "stdtype.h"
#include "CmdBase.h"
#include "exedatapass.h"

/****************************************
*起始字节	字段	          数据类型	             描述及要求
*     0  	         教练员编号	          BYTE [16]	统一编号
*     16	         教练员身份证号	      BYTE [18]	ASCII码，不足18位前补0x00
*     34	         准教车型				  BYTE [2]	A1\A2\A3\B1\B2\C1\C2\C3\C4\D\E\F
*     36	         基本GNSS数据包BYTE[28]	见表B.21
*********************************************/
typedef struct CoachLogin_Up{//教练登陆消息
    wis_u8 coachid[16] ;// 0   教练员编号   BYTE[16]    统一编号
    wis_u8 coachdentityid[18];//16  教练员身份证号 BYTE[18]    ASCII码，不足18位前补0x00
    wis_u8 traincartype[2];//34  准教车型    BYTE[2] A1/A2/A3/B1/B2/C1/C2/C3/C4/D/E/F
    wis_u8 gnssdata[28] ;//36  基本GNSS数据包   BYTE[28]    见表B.21
}  __attribute__((packed, aligned(1))) CoachLogin_Up;



/****************************************
*起始字节	字段	数据类型	描述及要求
*0	登录结果	BYTE	 1：登录成功；
*********************2：无效的教练员编号；
*********************3：准教车型不符；d
*********************9：其他错误
*1	教练编号	BYTE[16]	统一编号
*17	是否报读附加消息BYTE  0：根据全局设置决定是否报读；
***********************1：需要报读；
***********************2：不必报读
*18	附加消息长度	BYTE	长度为n，无附加数据则为0
*19	附加消息	STRING
*********************************************/

typedef struct CoachLogin_down{//教练登录消息应答
    wis_u8 loginresult;//0   登录结果    BYTE          结果{1：登录成功；   2：无效的教练员编号； 3：准教车型不符；  9：其他错误}
    wis_u8 coachid [16];//1   教练编号    BYTE[16] 统一编号
    wis_u8 isreadaddtext;//17  是否报读附加消息    BYTE     结果{0：根据全局设置决定是否报读； 1：需要报读；  2：不必报读 }
    wis_u8 addtextlength;//18  附加消息长度  BYTE 长度为n，无附加数据则为0
    wis_u8 addtextcontent[16];//19  附加消息    STRING
}  __attribute__((packed, aligned(1))) CoachLogin_down;




/****************************************
*起始字节	字段	数据类型	描述及要求
*0	教练编号	BYTE[16]	统一编号
*16	基本GNSS数据包	BYTE[28]	见表B.21
*********************************************/

typedef struct CoachLogout_Up{//教练登出消息
    wis_u8 coachid[16];//0   教练编号    BYTE[16]    统一编号
    wis_u8 gnssdata[28]; //  16  基本GNSS数据包   BYTE[28]    见表B.21
}  __attribute__((packed, aligned(1))) CoachLogout_Up;






/****************************************
*起始字节	字段	数据类型	描述及要求
*0	登出结果	BYTE	1：登出成功；
****************2：登出失败
*1	教练编号	BYTE[16]	统一编号
*********************************************/

typedef struct CoachLogout_Down{//教练登出消息应答
    wis_u8 logoutresult;//0   登出结果    BYTE  结果 {1：登出成功； 2：登出失败}
    wis_u8 coachid[16];//1   教练编号    BYTE[16]    统一编号
}  __attribute__((packed, aligned(1))) CoachLogout_Down;



#define  CMD_T2P_COACHLOGIN   0x0101   //教练登陆
#define  CMD_P2T_COACHLOGIN   0x8101   //教练登陆应答
class exeCoachLogin : public BaseCmd
{
public:
    exeCoachLogin(sp_gateway *m):BaseCmd(m){
        m_CmdName = "coachlogin";
        m_Cmd = CMD_T2P_COACHLOGIN;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};



#define  CMD_T2P_COACHLOGOUT   0x0102   //教练登出
#define  CMD_P2T_COACHLOGOUT   0x8102   //教练登出应答
#define  CMD_T2P_COACHLOGOUTCMD   0x7102   //教练登出cmd
class exeCoachLogout : public BaseCmd
{
public:
    exeCoachLogout(sp_gateway *m):BaseCmd(m){
        m_CmdName = "coachlogout";
        m_Cmd = CMD_T2P_COACHLOGOUTCMD;}
private:
public:
    int int_cmd(string phonenum);

    int format_cmd(void *param);

    int exe_cmd(void *param);

    int ack_cmd(void *param);

};

#endif // EXECOACHLOGIN_H
