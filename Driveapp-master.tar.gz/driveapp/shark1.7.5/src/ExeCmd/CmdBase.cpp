﻿#include "CmdBase.h"
#include "stdtype.h"

char BaseCmd::Xor(char *buf, int len)
{
    char ret =0;
   for(int i =0;i<len;i++)
   {
       ret = ret ^ buf[i];
   }
   return ret;
}

int BaseCmd::Trans_cmd(char *buf, int l, char *out, int l2)
{
     char m_xor =0;
     int len =0;
    *out++ = 0x7e;
    len ++;
    if(l2 <= l) return 0;
     m_xor = Xor(buf,l);

    for(int i =0;i<l;i++)
    {
        if(buf[i] == 0x7e)
        {
            *out++ = 0x7d;
            *out++ = 0x02;
            len +=2;
        }
        else if(buf[i] == 0x7d)
        {
            *out++ = 0x7d;
            *out++ = 0x01;
            len +=2;
        }
        else
        {
                *out++ = buf[i];
                len++;
        }
    }

    if(m_xor == 0x7e)
    {
        *out++ = 0x7d;
        *out++ = 0x02;
        len +=2;
    }
    else if(m_xor == 0x7d)
    {
        *out++ = 0x7d;
        *out++ = 0x01;
        len +=2;
    }
    else
    {
            *out++ = m_xor;
            len++;
    }

    *out++ = 0x7e;
    len++;
    return  len;
}

int BaseCmd::UnTrans_cmd(char *buf, int l, char *out, int l2)
{
    char my_xor =0;
    char tembuff[1024];

    l-=2; //去掉首尾
    if(l2 >= l) return 0;
    int len=0;
    for(int i=1;i<l;i++)
    {
        if(buf[i]==0x7d)
        {
            if(buf[i+1] == 0x01)
            {
                tembuff[len] = 0x7d;
                len ++;
                i++;
            }
            if(buf[i+1]==0x02)
            {
                tembuff[len] = 0x7e;
                len++;
                i++;
            }
        }
        else
        {
            tembuff[len] = buf [i];
            len++;
        }
    }
    my_xor = tembuff[len];
    if(my_xor == Xor(tembuff,len))
    {
       out = tembuff;
        l2 = len;
        return len;
    }

    return 0;
}

