﻿#include "exeReg.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include "cmd.h"
#include  "string.h"
#include "app_globl.h"
#include "File.h"
#include "Tracer.h"
#include "rsa_op.h"
stRegInfo_ack  reginfo_ack;

int CmdReg:: inputcertificatecode(int count ,int index,char * buffdata,int length){
    if((index==1)&&(index!=0)){
          this->startindex=0;
        }
    if((index<count)&&(index!=0)){
         memcpy(& reginfo_ack.terminalcertificate[  this->startindex],buffdata,length);
          this->startindex=startindex+length;
//           this->indesameflag=index;
        return   this-> startindex;
    }
    if((index==count) ){
           memcpy(&reginfo_ack.terminalcertificate[  this->startindex],buffdata,length);
//          std::string   password="GgSiLEtTNDS2";
         //  TRACE_CYAN("Flag4:%d\n",  this-> startindex );
//         TRACE_GREEN("shuju:%s\n",password.c_str());
//         std::string   ca= (char *)reginfo_ack.terminalcertificate;
//           std::string   ca= "MIIKLQIBAzCCCfcGCSqGSIb3DQEHAaCCCegEggnkMIIJ4DCCCdwGCSqGSIb3DQEHAaCCCc0EggnJMIIJxTCCBHwGCyqGSIb3DQEMCgEDoIIEDjCCBAoGCiqGSIb3DQEJFgGgggP6BIID9jCCA/IwggLaoAMCAQICBgFX0YCGLDANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwJDTjERMA8GA1UECh4IVv1OpE/hkBoxDDAKBgNVBAsTA1BLSTEzMDEGA1UEAx4qAE8AcABlAHIAYQB0AGkAbwBuACAAQwBBACAAZgBvAHIAIFb9TqRP4ZAaMB4XDTE2MTAxNzA3MTcyM1oXDTI2MTAxNTA3MTcyM1owQTELMAkGA1UEBhMCQ04xFTATBgNVBAoeDIuhZfZ+yHrvi8FOZjEbMBkGA1UEAxMSeHcwMDE3MTIyNTU1NTkyODM0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAk4tZw2NoQrO3mc4g4396f4Kmol9+vs75STqTmex4bSi9nxNvMhImOxt/Q9hG74eOkMlj0e9ci3H5OV3SwwlMiBORv8HQtViaitkE5EVXwaLK2ftO2tQ5EK3lQU8pptZuVdrLFgTY/GmrVESQO9rZEzJL8QSx5zh9lGoCkKQ5Lvn6T5XxeD4bs9rfuhzHgP0GL1IP8pAp2A2TMaQLIJP7HAfWWCavVE//O0iNb5g+YvtKc2Tqw0unYGfuqRjJGEi3pB2O8751FgwILHwWbSxMiFAYyTscDzp33OTLzLcGjIX5Kxc2QONFo8gqlzw6wEyuGu33uiFkcn2UFkk0A90YZwIDAQABo4HNMIHKMB8GA1UdIwQYMBaAFFyqjorSazJMB8Bjazw0/H5+sq57MB0GA1UdDgQWBBRVtZp4awiO5WK6NHwzhOxWT27wBjBdBgNVHR8EVjBUMFKgUKBOpEwwSjEXMBUGA1UEAx4OAEMAUgBMADEAMAAwADAxDzANBgNVBAseBgBDAFIATDERMA8GA1UECh4IVv1OpE/hkBoxCzAJBgNVBAYTAkNOMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgD4MBEGCWCGSAGG+EIBAQQEAwIAoDANBgkqhkiG9w0BAQsFAAOCAQEARuBa8M/dGec/IysTACdpAbxMhQSnXrX7K3iy/yD9g2p2rgTTq9Y4gRGmCUbe03GF8joQUO6o4dHKoDMoaCXh+63/jCujsnKxPoUliaWNEKfMWeNL+V1CcEbksGQ60GUEluAzOY3AGk9+yXkkP1/jJlgFkYLGuXs0Zm6Rr3d78+CFnx4NmTDLG9678j9QZdjfTmU+nTgwlRyD9qGXsRlpbXIXqqrH3g/18EYdZh5qUnN5+S5tPNH57WeMlHvhb7AY7VY66koXkH0krWDUbIwSLH19ABOE/80rihCX+OxvOZ9Ywnp6OzpH6iyJGqcwlTRxgUlAX6dpx1ynK/bKGEG6kzFbMBkGCSqGSIb3DQEJFDEMHgoAQQBMAEkAQQBTMD4GCSqGSIb3DQEJFTExBC9mNiA0NiA1OCA4ZiBjYSBmMyA0MiBiMyA1NiAwMCBkMSBiYyAyZCBlMyA5NSBkYjCCBUEGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBBjAOBAi/bKP7ONpSPgICBAAEggTImUXkXeK67Tj4o+Fwp9FO9+hP+3ljyMBCG5qLbtMv759Aj10+cVo0r2tmsy2JiqX7maY04+wJoYjaNbF6WF/sc/NfaJ5zc5/hmR7M29FxuUXm/eNm+ww8TO5mqEcOEayRS2RLgEDQUKKbyTaouB0bfwHj+6M7r7+NgQsQG9wx1AfXMm2dqRrucyWI0eXeoTjerOgq/WEdnvbNnIRrnEG8iHnz05r9abRaeKlzM/wyU19NepjwOcRkEg/fi8y9rHroloC/BbbOc4It0vqbGNrB+0WsrGqrA6P9h7BLaIfHkK6v3493j6ngeU1cNa9sI/vBq+hYp9Zly9wwYoaNKIP+db3njBBHaztSWh/gcoiOTUwaok668QSPVcUM02BLqwLfOqtIXTf1b3EmrGNtuvMja0RaTbjeIiPtaLEU8V8KtbwDSDbWc+HcgVCVyaBbRhWjBL3dqi3GuYSwFyaZwHLZWTSfpyKaoqAsKTou4qx+cKptrbHNS3ne3pAVSx86mPztFATrbg3y19rVzp/2G04cDpMEq5/OSPbFejMb+Zvz3xAb0yUCizk6K+b+GViZgE7eV+YvN9pLCITyqCvj8mJBjb64gT+CNU30InvZSgImWuJaygoFJkKjIErr9n7gXW3NNUHwG9wBdE2Sehvnd6GLoXadTLYqQakJ7htb8VeWnLCoxyfgI/r5g75NwqMXbWtiX6rb2AJKHPToAGFnRIV0F7tP11/yy7Nuuk/q6qrB5onlelfYqDqf2LMtj1OV7YwBJkBD90w1ZpSP1RZYbsq8XIHJJkiUJmKQPze5+B21Q5edD5O52II64042OOnz9/yWCnSVughDnYP/30Aa6ysEm6RWmWQBcNX8yjlVijZaQaTzO0TGbTCOyrl8sUJmInAAqu1j+Nko7SllkjSBpp3LFoAnxUlf6hidUYoqa3H9wxYIBELc7MrP1QKJS6PFwuU8XFRMOJV1VEUJVbTiHx1Ey/jI1RJfgbF1e/JeBQLRujrhwenpKUqvryga6hxDZu4HJig08qS7JTOdwwwwVJsWSC+53Gt7JdgrY41saBSvcedW4GqFJtAn1cSlQfITfo0IV5mz8uwCr7r4HCzArZQ+vKNpuHynGA8towab9uMXTAEnJdywVbd/FYY6b4DQDMWXUrzPzY4XfOq6P/zFMA1+t87yhi5M3pviWss0qWlqVEkNdcRztdkWfKu16ST3bEyOoSvzs0d7FA99U6wsqMazCs4bxl7JB8SLrfD2JM6CZm+hF8PVpAl6vOZnb+7QIYa6brWc8s3DtVCyzGbcdJXuGH9LDle8FiIpx3tDQRE6upyQBMCHQzILhLKW82nhK82Ofi4CYb8G2PN302/mJKgQMwEjsGDbuf+HB56Ii1A766xq7z0mlK8XDwTy2kE1pz0A+MQLyfAw44Vkafn7wKq31bQUNeJ+joxkPrFoK5VZcRyo/ZE47WFdb5qveD6OArgvlzcUpK03sdIojKlzVPOSixjitOtFPOT8xnUWyj1iD/h2FuqGUEtVX8QQQiST4Nly4FnURDriOHCmdALvg6ZAhPDqXtC05GnTE8bmOckxFRlyvF+VdQB7HHb9KzQ4anffP/ZAhB4XptZXYsc442Fki5VAQRprmS8hMUAwPgYJKoZIhvcNAQkVMTEEL2Y2IDQ2IDU4IDhmIGNhIGYzIDQyIGIzIDU2IDAwIGQxIGJjIDJkIGUzIDk1IGRiMC0wITAJBgUrDgMCGgUABBRdlw2Gdlh49Q9HcPUEM7uIRGqYBgQI3i3mMb2wlC8=";
//        RsaOperater::getInstance() ->writePrivateKeyFileFromPkcs12(reginfo_ack.terminalcertificate,4096 ,reginfo_ack.certificatecode,12 );
//TRACE_YELLOW("CA:%s\n",  (char *)reginfo_ack.terminalcertificate);
//TRACE_YELLOW("CAS:%s\n",  ca.c_str());
//        RsaOperater::getInstance() ->writePrivateKeyFileFromPkcs12( ca,password );
//                   RsaOperater::getInstance()->writePrivateKeyFileFromPkcs12((char *)reginfo_ack.terminalcertificate,sizeof(reginfo_ack.terminalcertificate),(char *)reginfo_ack.certificatecode,sizeof(reginfo_ack.certificatecode));
//       this->indesameflag=index;
//        TRACE_INFO("terminalcertificate:[\n");
        TRACE_INFO_CLASS("车辆注册成功\n");

//TRACE_ERR_CLASS("\n==========ss=============\n");
//        char reg_success_data[15]={0x0E,0x01 ,0x01 ,0xD6 ,0xD5 ,0xB6 ,0xCB ,0xD7 ,0xA2 ,0xB2, 0xE1 ,0xB3 ,0xC9 ,0xB9 ,0xA6};
//        Send_Voice(reg_success_data,15);
        TerminalLoginStatus=1;//biaozhi
        Isregister=1;
        shark_authority_up amInfo;
        amInfo.timestamp=htonl(0x58aaa9bd);
        ChangeHexStr2Char(Keyencode,&amInfo.encryptdata[0]);
        appcon.do_authority(amInfo);
        return   this->startindex;
    }
}

int CmdReg::int_cmd(string phonenum)
{
   int len =0;
   unsigned char pnum[32];
   m_MsgHead.Msg_ID = htons(CMD_T2P_REGISTER);
   m_MsgHead.v_protocol = JDTraining;

   stMsgType m;
   m.MsgDiv = 0;
   m.MsgEncrypt = 0;
   m.MsgLength = 0;
   m.MsgReserved = 0;

   unsigned short m_type;
   memcpy(&m_type,&m,sizeof(unsigned short));
   m_type = htons(m_type);
   memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
   memset(pnum,0,32);
   len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
   if(len > 8)
   {
       wlog(WIS_ERROR,"Cmd Format beartError! \n");
   }

   if(len<8){
     for(int i =7;i>len-1;i--)   //前向 补0
     {
              m_MsgHead.Dev_PhoneNum[i] = 0x00;
              wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
     }
     }
   for(int i =0;i<len;i++)   //
   {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
   }
   m_MsgHead.Msg_Seq = htons(Get_Seq());

   m_MsgHead.Reserved=0x3C;//预留字段


}

int CmdReg::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_REGISTER;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
//      p->ts_seq=0;//过检临时增加   2017.6.9
    return sizeof(m_MsgHead);
}

int CmdReg::ack_cmd(void *param)
{
    stRecvCmdPiPe *p = (stRecvCmdPiPe *) param;
    int i=0;
    int mess_type = ((p->td_content[3]<<8))|(p->td_content[4]);
        reginfo_ack.result =0xFF;//temp临时添加

    //     Tracer::getInstance()->printHex(1,"收到数据数据：", p->td_content,p->td_bodyLength);
    if(((mess_type<<13)&0x01)==0)
    {
        short flowidtemp =((p->td_content[13]<<8))|(p->td_content[14]) ;  //流水号ID
        int cout =((p->td_content[16]<<8))|(p->td_content[17]);
        int index =((p->td_content[18]<<8))|(p->td_content[19]);
//        common_Info minfo;
//        TRACE_CYAN("\nDat=====:%d\n",flowidtemp);
//        minfo.REPLY_FLOW_ID = htons(flowidtemp);
//        minfo.Response_ID = htons(CMD_P2T_REGISTER);
//        minfo.Response_Result = 0x00;
//       appcon.do_common_response(minfo);
       sleep(1);
       reginfo_ack.ackflowid = ((p->td_content[20]<<8))|(p->td_content[21]);
        if(index==1){
            reginfo_ack.result = p->td_content[22];   //结果
        }
                    TRACE_ERR_CLASS("count:%d\n",cout);
                    TRACE_ERR_CLASS("index:%d\n",index);
//        TRACE_INFO("flowid:%02x\n", reginfo_ack.ackflowid);
//        TRACE_INFO("result:%d\n",reginfo_ack.result);
        if(index==1) {
             Isregister=5;//620  zjy
            if(reginfo_ack.result == 0)
            {    TRACE_INFO_CLASS("plantformid:[\n");
                memset(&reginfo_ack.terminalcertificate[0],0x00,sizeof(reginfo_ack.terminalcertificate));
                memset(&reginfo_ack.certificatecode[0],0x00,sizeof(reginfo_ack.certificatecode));

                for(i=0;i<sizeof(reginfo_ack.plantformid);i++)
                {
                    TRACE_INFO("%02x", p->td_content[23+i]);
                    reginfo_ack.plantformid[i] = p->td_content[23+i];  //平台ID
                }
                TRACE_INFO_CLASS("\n]\n");
                int len1 = sizeof(reginfo_ack.plantformid)+23;
                TRACE_INFO("traincompanyid:[\n");
                for(i=0;i<sizeof(reginfo_ack.traincompanyid);i++)
                {TRACE_INFO ("%02x", p->td_content[len1+i]);
                    reginfo_ack.traincompanyid[i] = p->td_content[len1+i];  //培训机构编号
                } TRACE_INFO("\n]\n");
                int len2 = sizeof(reginfo_ack.traincompanyid)+len1;
                TRACE_INFO("terminalid:[\n");
                for(i=0;i<sizeof(reginfo_ack.terminalid);i++)
                {TRACE_INFO("%02x", p->td_content[len2+i]);
                    reginfo_ack.terminalid[i] = p->td_content[len2+i];  //计时终端编号
                } TRACE_INFO("\n]\n");
                int len3 = sizeof(reginfo_ack.terminalid)+len2;
                TRACE_INFO("certificatecode:[\n");
                for(i=0;i<sizeof(reginfo_ack.certificatecode);i++)
                {  //TRACE_INFO("%02x", p->td_content[len3+i]);
                    reginfo_ack.certificatecode[i] = p->td_content[len3+i];  //证书口令
                } //TRACE_INFO("\n]\n");
//            Tracer::getInstance()->printHex(1,"password ", (char*) reginfo_ack.certificatecode,sizeof(reginfo_ack.certificatecode));
                int len4 = sizeof(reginfo_ack.certificatecode)+len3;
              if(  this->indesameflag!=index){

                switch(index){
                case 1:
                     this->indesameflag=index;
                    this->inputcertificatecode(cout,index,&p->td_content[len4],p->td_bodyLength-len4);
                    break;
                case 0:
                    break;
//                default:
//                     this->inputcertificatecode(cout,index,&p->td_content[20],p->td_bodyLength-20);
                    break;
                }
}
                return 0;
            }
        }
        else{
         if(  this->indesameflag!=index){
            switch(index){
            case 1:
                break;
            case 0:
                break;
            default:
                  this->indesameflag=index;
                 this->inputcertificatecode(cout,index,&p->td_content[20],p->td_bodyLength-20);
                break;
            }
         }
        }
    }
    else
    {
        reginfo_ack.ackflowid =((p->td_content[16]<<8))|(p->td_content[17]); ;  //流水号ID
        reginfo_ack.result = p->td_content[18];   //结果
        if(reginfo_ack.result==1)
        {
            TRACE_INFO("车辆已被注册\n");
            char car_exsit_data[15]={0x0E, 0x01, 0x01 ,0xB3 ,0xB5 ,0xC1, 0xBE ,0xD2 ,0xD1, 0xB1 ,0xBB ,0xD7, 0xA2 ,0xB2 ,0xE1};
            Send_Voice(car_exsit_data,15);
            Isregister=0;
            return 0;
        }
        if(reginfo_ack.result==2)
        {
            TRACE_INFO("数据库中无该车辆\n");
            char car_no_data[21]={0x14, 0x01, 0x01, 0xBA, 0xF3 ,0xCC ,0xA8, 0xCA ,0xFD ,0xBE ,0xDD ,0xBF ,0xE2 ,0xCE ,0xDE ,0xB8 ,0xC3 ,0xB3 ,0xB5 ,0xC1, 0xBE};
            Send_Voice(car_no_data,21);
            Isregister=0;
            return 0;
        }
        if(reginfo_ack.result==3)
        {
            TRACE_INFO("终端已被注册\n");
            char terminal_exsit_data[15]={0x0E, 0x01, 0x01, 0xD6 ,0xD5 ,0xB6 ,0xCB, 0xD2, 0xD1 ,0xB1, 0xBB ,0xD7, 0xA2 ,0xB2 ,0xE1};
            Send_Voice(terminal_exsit_data,15);
            Isregister=0;
            return 0;
        }
        if(reginfo_ack.result==4)
        {
            TRACE_INFO("数据库中无该终端\n");
            char no_terminal_data[21]={0x14 ,0x01 ,0x01 ,0xBA ,0xF3 ,0xCC ,0xA8, 0xCA ,0xFD, 0xBE ,0xDD, 0xBF, 0xE2 ,0xCE, 0xDE, 0xB8 ,0xC3 ,0xD6, 0xD5 ,0xB6 ,0xCB};
            Send_Voice(no_terminal_data,21);
            Isregister=0;
            return 0;
        }
    }

    return 0;
}

int CmdReg::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);//to    do留待后期修改
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));

    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
//    Tracer::getInstance()->printHex(1,"注册",buf,length);
    m_appGateway->nTcp_Send(buf,length);
    IsAuthority = 0;                      //注册信息发完后，鉴权   test
    return 0;
}

