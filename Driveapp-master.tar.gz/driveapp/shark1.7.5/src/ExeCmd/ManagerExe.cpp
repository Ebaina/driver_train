﻿#include "ManagerExe.h"
#include "wis_mutex.h"


vector<pExe> p_list;

static WisMutex m_pMutex;
void * find_exe(unsigned short cmd)
{
    //void *p;
    BaseCmd *p_Base;
    m_pMutex.lock();
    for(int i=0; i<p_list.size();i++)
    {
        //p = p_list.at(i);
//        printf("find cmd  size = %d \n",p_list.size());
        p_Base = (BaseCmd *) p_list.at(i);
//        printf("find Get cmd = %d,cmd =%d\n",p_Base->Get_Cmd(),cmd);
        if(p_Base->Get_Cmd()== cmd)
        {
            //p = p_Base;
//            printf("find cmd = %d \n",p_Base->Get_Cmd());
            m_pMutex.unlock();
            return p_Base;
        }
    }
    m_pMutex.unlock();
    printf("not find exe in p_list  \n");
    return NULL;
}

void save_exe(void *ptr)
{
    p_list.push_back(ptr);
    //printf("save_exe- ----");
}

void remove_exe(unsigned short cmd)
{
    BaseCmd *p_Base;
    m_pMutex.lock();
    for(int i=0;i<p_list.size();i++)
    {
        p_Base = (BaseCmd *) p_list.at(i);
        if(p_Base->Get_Cmd() == cmd)
        {
            //p = p_Base;
//            printf("remove : name = %d \n",p_Base->Get_Cmd());
            vector< void * >::iterator k = p_list.begin() + i;
            p_list.erase(k);
            delete p_Base;
//            printf("remove : now have content size = %d",p_list.size());
            //m_pMutex.unlock();
            //return p_Base;
        }
    }
    m_pMutex.unlock();
}
