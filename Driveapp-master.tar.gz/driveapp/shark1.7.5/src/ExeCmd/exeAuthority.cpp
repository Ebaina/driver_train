﻿#include "exeAuthority.h"
#include "public.h"
#include "clog.h"
#include <arpa/inet.h>
#include  "cmd.h"
#include  "string.h"
#include"Tracer.h"
int exeAuthority::int_cmd(string phonenum)
{
   int len =0;
   unsigned char pnum[32];
   m_MsgHead.Msg_ID = htons(CMD_T2P_AUTHORITY);
   m_MsgHead.v_protocol = JDTraining;

   stMsgType m;
   m.MsgDiv = 0;
   m.MsgEncrypt = 1;
   m.MsgLength = 0;
   m.MsgReserved = 0;

   unsigned short m_type;
   memcpy(&m_type,&m,sizeof(unsigned short));
   m_type = htons(m_type);
   memcpy(&m_MsgHead.m,&m_type,sizeof(unsigned short));
   memset(pnum,0,32);
   len = fun_char2bcd((unsigned char*)phonenum.c_str(),pnum,phonenum.length());
   if(len > 8)
   {
       wlog(WIS_ERROR,"Cmd Format beartError! \n");
   }

   if(len<8){
     for(int i =7;i>len-1;i--)   //前向 补0
     {
              m_MsgHead.Dev_PhoneNum[i] = 0x00;
              wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[i]);
     }
     }
   for(int i =0;i<len;i++)   //
   {   m_MsgHead.Dev_PhoneNum[len-i-1] = pnum[len-i-1];
        wlog(WIS_INFO,"num  =%x ", m_MsgHead.Dev_PhoneNum[len-i-1]);
   }
   m_MsgHead.Msg_Seq = htons(Get_Seq());

   m_MsgHead.Reserved=0x3C;//预留字段


}

int exeAuthority::format_cmd(void *param)
{
    stSendCmdPiPe *p  = (stSendCmdPiPe*)param;
    p->ts_cmd = CMD_T2P_AUTHORITY;
    p->ts_Counter = 8;
    p->ts_needAck = true;
    p->ts_seq  = Get_Seq();//
    p->ts_RemoveConter = 0;
    p->p_tsCmd = this;
    memcpy(p->ts_content,(char*)&m_MsgHead,sizeof(m_MsgHead));
    p->ts_bodyLength = sizeof(m_MsgHead);
    Add_Seq();
    return  sizeof(m_MsgHead);
}

int exeAuthority::ack_cmd(void *param)
{
    return 0;
}

int exeAuthority::exe_cmd(void *param)
{
    stSendCmdPiPe *p = (stSendCmdPiPe *) param;
    char buf[512];
    int length = sizeof(buf);
    stMsgType m_head ;
    m_head.MsgLength = p->ts_bodyLength-16;
    m_head.MsgDiv = 0;
    m_head.MsgEncrypt = 0;
    m_head.MsgReserved = 0;
    unsigned short m_type;
    memcpy(&m_type,&m_head,sizeof(unsigned short));
    m_type = htons(m_type);                                               //to    do留待后期修改

//    printf("Myhead:%04x ",m_type);
    memcpy(&p->ts_content[3],&m_type,sizeof(unsigned short));
    length = Trans_cmd(p->ts_content,p->ts_bodyLength, buf,length);
//    printf("Send bodylength:%d\n",p->ts_bodyLength);

//        TRACE_ERR("\鉴全:[");
//        for(int i=0;i< length;i++){
//            TRACE_ERR("%02X",(buf[i]));
//        }
//        TRACE_ERR("]\n");

    m_appGateway->nTcp_Send(buf,length);
    return 0;
}

