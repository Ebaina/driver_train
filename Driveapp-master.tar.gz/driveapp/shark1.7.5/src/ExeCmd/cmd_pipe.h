﻿#ifndef _CMD_PIPE_H
#define _CMD_PIPE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

#include "ctime.h"
#include "clog.h"
#include "gateway.h"
#include "CmdBase.h"
#include "cmd.h"

#include "Event.h"
using namespace std;

extern long counter;

static void timer_notify(int signum);

namespace FLOWID_CHECK_STATUS {
enum CMDTYPE{
   COMMOND_TYPE, //通用类型
   EXTTA_TYPE,   //扩展类型
   DOWN_TYPE,    //下行类型
   UNKNOW_TYPE     //未知类型

};
}
class CmdPP
{
public:
     CmdPP() {}
private:
    CTimerpp m_timer;
    stSendCmdPiPe m_cmdlist[100];        //各自缓冲100条
    int  stCmdCount;                                  // 多少条缓存的非照片指令
    stRecvCmdPiPe m_cmdRecvlist[100];    //各自缓存100条
    pthread_t p_Thread;
    pthread_t p_ThreadRecive;

    sp_gateway * p_gateway;
    static void *Timer_RefreshThread(void *param);
    static void *Timer_RefreshThreadReceive(void *param);

    int Parser_Cmd(char *buf,int len,char *pos,int *len2);

public:
    void chooseGetAckType(char * indata,int length);//选择格式化对象
    void init_pipe(void *param);
    int UnTranMain_cmd(char *buf, int l, char *out, int l2);
    int Proc_Ack_Data();
    char Xor(char *buf, int len);
    //填充一个发送结构
    //该指令在命令管理器中发送几次，是否需要等待应答
    void  Receive_OneCmd(stRecvCmdPiPe data);
    void  Send_OneCmd(stSendCmdPiPe &data,int times,bool ack);
    //处理收到应答，将发送队列中的待发送数据清除
    int   checkFlowID(int tscmd,stRecvCmdPiPe data,int *flowid,int *cmdts);//返回值true是应答类，false 是非应答类的（下发的数据）
    void  Remove_OneCmdFromSendList(stRecvCmdPiPe data);
};

#endif
