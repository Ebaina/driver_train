﻿#include "snap_v4l2.h"

_snapshot snapshot;

int open_video0()
{
    if ((snapshot.videoFd = ::open(snapshot.nodeName, O_RDWR)) <=0) {
        fprintf(stderr, "Error opening V4L interface\n");
        return -1;
    }

    struct v4l2_capability cap;
    if (ioctl(snapshot.videoFd, VIDIOC_QUERYCAP, &cap) ==0 ) {
        if ((cap.capabilities & V4L2_CAP_VIDEO_CAPTURE) == V4L2_CAP_VIDEO_CAPTURE) {
            //fprintf(stderr,"Device %s: supports capture.\n",snapshot.nodeName);
        }

        if ((cap.capabilities & V4L2_CAP_STREAMING) == V4L2_CAP_STREAMING) {
            //fprintf(stderr,"Device %s: supports streaming.\n",snapshot.nodeName);
        }
    }

    struct v4l2_fmtdesc fmtdesc;
    fmtdesc.index=0;
    fmtdesc.type=V4L2_BUF_TYPE_VIDEO_CAPTURE;
    while(ioctl(snapshot.videoFd,VIDIOC_ENUM_FMT,&fmtdesc)!=-1) {
        //fprintf(stderr,"\t%d.%s\n",fmtdesc.index+1,fmtdesc.description);
        fmtdesc.index++;
    }

    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));

    fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG;
    fmt.fmt.pix.height = snapshot.height;
    fmt.fmt.pix.width = snapshot.width;
    fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;

    if(ioctl(snapshot.videoFd, VIDIOC_S_FMT, &fmt) !=0) {
        fprintf(stderr, "Unable to set format\n");
        return -1;
    }

    if(ioctl(snapshot.videoFd, VIDIOC_G_FMT, &fmt) !=0) {
        fprintf(stderr, "Unable to get format\n");
        return -1;
    }

    TRACE_ERR("init %s [OK]\n",snapshot.nodeName);
    return 0;

}

void closeVideo0()
{
    if(snapshot.videoFd != -1) {
        ::close(snapshot.videoFd);
    }
}

int startVideo0()
{
    if(setupBuffers() != 0)
    {
        return -1;
    }
    if(streamOn() != 0) {
        return -1;
    }
    return 0;
}

void stopVideo0()
{
    streamOff();
    clearBuffers();
}

int captureFrame(char buffer[320*240])
{
    int ret,i=10;
    struct v4l2_buffer buf;

    memset(&buf, 0, sizeof(buf));
    buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    buf.memory = V4L2_MEMORY_USERPTR;

    while(i--) {
        ret = ioctl(snapshot.videoFd, VIDIOC_DQBUF, &buf);
        if (ret < 0) {
            return -1;
        }

        ret = ioctl(snapshot.videoFd, VIDIOC_QBUF, &buf);
        if (ret < 0) {
            return -1;
        }
    }

    ret = ioctl(snapshot.videoFd, VIDIOC_DQBUF, &buf);
    if (ret < 0) {
        return -1;
    }

    memcpy(buffer, snapshot.buffers[buf.index].start, buf.bytesused);

    ret = ioctl(snapshot.videoFd, VIDIOC_QBUF, &buf);
    if (ret < 0) {
        return -1;
    }

    return buf.bytesused;
}

int setupBuffers()
{
    int err = -1;

    struct v4l2_requestbuffers reqbuf;
    reqbuf.count    = 3;
    reqbuf.type     = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    reqbuf.memory   = V4L2_MEMORY_MMAP;
    if ((err = ::ioctl(snapshot.videoFd, VIDIOC_REQBUFS, &reqbuf)) < 0) {
         fprintf(stderr,"ioctl(VIDIOC_REQBUFS) failed, errno:\n");
        return -1;
    }

    snapshot.bufferCount = reqbuf.count;
    snapshot.buffers = new V4l2Buffer[snapshot.bufferCount];

    struct v4l2_buffer buf;
    for (uint i = 0; i < reqbuf.count; i++) {
        memset(&buf, 0, sizeof(buf));
        buf.type    = reqbuf.type;
        buf.index   = i;
        buf.memory  = reqbuf.memory;
        err = ::ioctl(snapshot.videoFd, VIDIOC_QUERYBUF, &buf);

        snapshot.buffers[i].length = buf.length;

        snapshot.buffers[i].start = mmap(NULL ,buf.length,PROT_READ |PROT_WRITE, MAP_SHARED, snapshot.videoFd, buf.m.offset);
        if (snapshot.buffers[i].start == MAP_FAILED) {
             fprintf(stderr,"buffer map error\n");
            return -1;
        }

        err = ::ioctl(snapshot.videoFd, VIDIOC_QBUF, &buf);
    }

    return 0;
}

void clearBuffers()
{
    if(snapshot.buffers) {
        for(int i=0; i<snapshot.bufferCount; i++) {
            munmap(snapshot.buffers[i].start,snapshot.buffers[i].length);
        }
        free(snapshot.buffers);
        snapshot.buffers = NULL;
    }
}

int streamOn()
{
    int cmd = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    int ret = ::ioctl(snapshot.videoFd, VIDIOC_STREAMON, &cmd);
    if (ret < 0) {
         fprintf(stderr,"ioctl(VIDIOC_STREAMON) failed, errno \n");
        return -1;
    }
    return 0;
}

int streamOff()
{
    int cmd = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    int ret = ioctl(snapshot.videoFd, VIDIOC_STREAMOFF, &cmd);
    if (ret < 0) {
         fprintf(stderr,"ioctl(VIDIOC_STREAMOFF) failed, errno \n");
        return -1;
    }

    return true;
}

