#ifndef SNAP_H
#define SNAP_H

#include <iostream>
#include <unistd.h>
#include <time.h>
#include "snap_v4l2.h"
#include "Tracer.h"

int exe_dev0_snap_pics(char snap_pic_names[20]);

#endif // SNAP_H

