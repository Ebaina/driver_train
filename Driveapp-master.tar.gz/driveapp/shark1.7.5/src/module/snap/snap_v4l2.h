#ifndef SNAP_V4L2_H
#define SNAP_V4L2_H

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/select.h>
#include <linux/videodev.h>
#include <stdlib.h>
#include "Tracer.h"

struct V4l2Buffer {
    void * start;
    unsigned int length;
};

typedef struct _snapshot
{
    V4l2Buffer *buffers;
    int videoFd;
    int width = 320;
    int height = 240;
    char *nodeName = "/dev/video0";
    int bufferCount = 3;
}_snapshot;

extern _snapshot snapshot;

int open_video0();
void closeVideo0();
int startVideo0();
void stopVideo0();
int captureFrame(char buffer[320*240]);
int setupBuffers();
void clearBuffers();
int streamOn();
int streamOff();

#endif // SNAP_V4L2_H

