﻿#ifndef CHECKVIDEO_H
#define CHECKVIDEO_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

int check_video0_status();
int check_video1_status();//


#ifdef __cplusplus
}
#endif

#endif // CHECKVIDEO_H

