﻿#include "snap.h"

int exe_dev0_snap_pics(char snap_pic_names[20])
{
    static char *folder = "/mnt/mmcblk0p1";
    struct tm *tmp;
    int frame_size;
    int fd;
    char frame_buf[320*240];
    char buffer1[128] = {0}, buffer2[128] = {0}, buffer3[18] = {0};

    if(open_video0() != 0)
    {
        TRACE_ERR("open video0 failed!!!!!!!!!!!!!!!!!!!!\n");
        return -1;
    }
    sleep(1);
    if(startVideo0() != 0)
    {
        TRACE_ERR("star video0 failed!!!!!!!!!!!!!!!!!!!!!!!\n");
        return -1;
    }

    memset(buffer1, 0, sizeof(buffer1));
    memset(buffer2, 0, sizeof(buffer2));
    memset(buffer3, 0, sizeof(buffer3));
    time_t t;
    t = time(NULL);
    tmp = localtime(&t);
    if (tmp == NULL) {
        return -1;
    }

    if (strftime(buffer1, sizeof(buffer1), "%%s/%Y%m%d%H%M%S.jpg", tmp) == 0) {
        return -1;
    }

    strftime(buffer3, sizeof(buffer3), "%Y%m%d%H%M%S.jpg", tmp);
    memcpy(snap_pic_names, buffer3, sizeof(buffer3));
    snprintf(buffer2, sizeof(buffer2), buffer1, folder);

    if( (fd = open(buffer2, O_CREAT|O_WRONLY|O_TRUNC, S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH)) < 0 ) {
        printf("could not open the file %s\n", buffer2);
        return -1;
    }

    frame_size = captureFrame(frame_buf);

    if( write(fd, frame_buf, frame_size) < 0 ) {
        printf("could not write to file %s\n", buffer2);
        close(fd);
        return -1;
    }

    close(fd);
    free(frame_buf);
    stopVideo0();
    closeVideo0();
}



