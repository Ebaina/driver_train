﻿#include "checkvideo.h"

int check_video0_status()
{

    if(access("/dev/video0", R_OK) == 0)
        return 0;
    else
        return -1;
}

int check_video1_status()
{

    if(access("/dev/video1", R_OK) == 0)
        return 0;
    else
        return -1;
}
