﻿#ifndef TIMERUPLOAD_H
#define TIMERUPLOAD_H
#include "Timer.h"
namespace TimerSpace {
enum TIMERTYPE{
   RANDOMTIMER=0,BAISICTIMER=1,HEARTTIMER=2,LOCATIONTIMER=3,RECORDTIMER=4
};
}
class TimerUpload:public CTimerProtocol{
private:
    char *photoBuffer;
    int  photoLen;
public:
    TimerUpload();
    ~TimerUpload();
    static TimerUpload* getInstance()
    {
        static TimerUpload instance;
        return &instance;
    }
    void timePhoto();
    void timerandomPhoto();

    void Ahtytimer();
    void Hearttimer();
    void onGPSTimer();
    void onRecordTimer() ;
    void startTest();
    void startIndex(int index);
    void stopIndex(int index);
    void stopTest();

    void culculateDistance(void);//计算里程
   void Init_Data();
   void voiceWaring(int re_min);
private:
    CTimer* hearttimer;
    CTimer* reordtimer;
    CTimer* gpstimer;
    CTimer* authorytimer;
    CTimer* phototimer;
    CTimer* randomphototimer;
    CTimer* distancetimer;
    int gpsCount;
    int photoCounts;
};
#endif // TIMERUPLOAD_H
