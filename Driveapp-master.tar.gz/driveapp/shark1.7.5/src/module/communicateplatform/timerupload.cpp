﻿#include "timerupload.h"
#include "Timer.h"
#include "app_globl.h"
#include "cmd.h"
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "photosave.h"
#include "public.h"
#include "ui_interface.h"
#include<iostream>
#include<sstream>
#include"RtcFacade.h"
#include "studytimedb.h"
#include "rtcutils.h"
#include "displayinterface.h"
#include "offlinesave.h"
#include "Utils.h"
#include "ttsutils.h"
#include "public.h"
#include "gpsdataoperate.h"
WIS_UI::DisplayInterface  * displayInterface;
int min_record = 0;
double MinGetDistanceTemp = 0;
wis_u16 MaxSpeed = 0;
void ChangeHexDataMain(string data, unsigned char * out )
{
    char *offset;
    for(int i=0;i<data.size()/2;i++)
    {
        int data1  =   strtol(data.substr(2*i,2).c_str(), &offset, 16);
        out[i]=   (unsigned char)(data1) ;
    }
}
char digits[]=
{
    '0', '1', '2', '3', '4', '5',
    '6', '7', '8', '9', 'a', 'b',
    'c', 'd', 'e', 'f', 'g', 'h',
    'i', 'j', 'k', 'l', 'm', 'n',
    'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z'
};

TimerUpload::TimerUpload()
{
    /* 创建定时器 */
    hearttimer=new CTimer(0x31,this);
    gpstimer=new CTimer(0x32,this);
    reordtimer=new CTimer(0x33,this);
    authorytimer=new CTimer(0x34,this);
    phototimer=new CTimer(0x35,this);
    randomphototimer=new CTimer(0x36,this);
    distancetimer=new  CTimer(0x47,this);
    photoLen = 100*1024;
    photoBuffer = new char [photoLen];
}
TimerUpload::~TimerUpload()
{
    delete [] photoBuffer;
}

void TimerUpload::timePhoto()
{
    int sizephoto;
    char photobuf_coach[64];
    string photonum_coach ;
    photoCounts=0;
    Uploadphotoinit_Up init_minfo_coach;
    memset(&init_minfo_coach,0x00,sizeof(init_minfo_coach));
    RtcTime_S  rtc;
    TRACE_INFO("\n定时拍照\n" );
    if((IsLearnerLogin==1)&&(IsAuthority==1)&&(StartTrainFlag==1)){
        TRACE_INFO("\n摄像头状态:%d\n",check_video0_status());
        if(1 == RealTimeVideoStatus())
        {
            char snap_dev0_pic_names[30] = {0};
            memset(photobuf_coach, 0, sizeof(photobuf_coach));
            memset(snap_dev0_pic_names, 0 ,sizeof(snap_dev0_pic_names));
            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0){
                printf("exe snap pic error\n");
            }
            sprintf(photobuf_coach, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
            photonum_coach  =getmaintime3string(rtc,5);
            getmaintime3char(rtc,&init_minfo_coach.photonum[0],5);
            Tracer::getInstance() ->printHex(1,"照片编号",snap_dev0_pic_names,sizeof(snap_dev0_pic_names));
            memcpy(& init_minfo_coach.learnerorcoachid[0],(char *)studentcardinfo.card_info.uniformID,sizeof(studentcardinfo.card_info.uniformID));
            init_minfo_coach.uploadmode =  0x01;// 原来是0x01
            memcpy( & init_minfo_coach.photonum[0],(char *)photonum_coach.c_str(),photonum_coach.size());
            //            Utils::addTextIntoImage(photobuf_coach,2, MainSpeed,changedatalan(Mainlantitude),changedatalan(Mainlontitude));
            sleep(2);
            sizephoto=  appcon.GetPhotodata(photonum_coach,photobuf_coach,&photoBuffer[0],photoLen);
            init_minfo_coach.camerachannel = 0x00;
            init_minfo_coach.photosize =0x01;
            init_minfo_coach.photoeventtype = 0x05;
            int sizetemp=sizephoto/700;
            if((sizephoto%700)==0){
                init_minfo_coach.packgesize = htons(sizetemp);
            }else{
                init_minfo_coach.packgesize = htons(sizetemp+1);
            }
            init_minfo_coach.photodatasize = htonl(sizephoto);
            init_minfo_coach.lessonid = htonl(TrainLessonId);
            Utils::packageRtcGps((char *) &init_minfo_coach. addgnssdata[0]);
            init_minfo_coach.faceidentifyreliability = 0x00;
            appcon.do_upload_photo_init(init_minfo_coach);
            Photosave::getInstance()->insertMessage(init_minfo_coach, photobuf_coach);
            sleep(4);
            TRACE_INFO_CLASS("\n照片定时上传初始化\n");
            appcon.MultPacge_Tools(photonum_coach,photoBuffer,sizephoto);
        }
    }

}
void TimerUpload::timerandomPhoto()
{
    int sizephoto;
    char photobuf_coach[64];
    string photonum_coach ;
    photoCounts=0;
    Uploadphotoinit_Up init_minfo_coach;
    memset(&init_minfo_coach,0x00,sizeof(init_minfo_coach));
    RtcTime_S  rtc;
    if((IsLearnerLogin==1)&&(IsAuthority==1)&&(StartTrainFlag==1)){
        TRACE_INFO("\n摄像头状态:%d\n",check_video0_status());
        if(1 == RealTimeVideoStatus())
        {
            char snap_dev0_pic_names[30] = {0};
            memset(photobuf_coach, 0, sizeof(photobuf_coach));
            memset(snap_dev0_pic_names, 0 ,sizeof(snap_dev0_pic_names));
            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0){
                printf("exe snap pic error\n");
            }
            sprintf(photobuf_coach, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
            photonum_coach  =getmaintime3string(rtc,5);
            getmaintime3char(rtc,&init_minfo_coach.photonum[0],5);
            Tracer::getInstance() ->printHex(1,"照片编号",snap_dev0_pic_names,sizeof(snap_dev0_pic_names));
            memcpy(& init_minfo_coach.learnerorcoachid[0],(char *)studentcardinfo.card_info.uniformID,sizeof(studentcardinfo.card_info.uniformID));
            init_minfo_coach.uploadmode =  0x01;// 原来是0x01
            memcpy( & init_minfo_coach.photonum[0],(char *)photonum_coach.c_str(),photonum_coach.size());
            //            Utils::addTextIntoImage(photobuf_coach,2,MainSpeed,changedatalan(Mainlantitude),changedatalan(Mainlontitude));
            sleep(2);
            sizephoto=  appcon.GetPhotodata(photonum_coach,photobuf_coach,&photoBuffer[0],photoLen);
            init_minfo_coach.camerachannel = 0x00;
            init_minfo_coach.photosize =0x01;
            init_minfo_coach.photoeventtype = 19;//培训过程中拍照
            int sizetemp=sizephoto/700;
            if((sizephoto%700)==0){
                init_minfo_coach.packgesize = htons(sizetemp);
            }else{
                init_minfo_coach.packgesize = htons(sizetemp+1);
            }
            init_minfo_coach.photodatasize = htonl(sizephoto);
            init_minfo_coach.lessonid = htonl(TrainLessonId);
            Utils::packageRtcGps((char *) &init_minfo_coach. addgnssdata[0]);
            init_minfo_coach.faceidentifyreliability = 0x00;
            appcon.do_upload_photo_init(init_minfo_coach);
            sleep(4);
            TRACE_INFO_CLASS("\n照片定时上传初始化\n");
            appcon.MultPacge_Tools(photonum_coach,photoBuffer,sizephoto);
        }
    }

}

void TimerUpload::Ahtytimer()
{
    if(Isregister == 1)
        if((IsAuthority==0)&&(TcpLinkConnectFlag==1)&&(netStatus.net_state==0)){
            shark_authority_up amInfo;
            amInfo.timestamp=htonl(0x58aaa9bd);
            ChangeHexStr2Char(Keyencode,&amInfo.encryptdata[0]);
            appcon.do_authority(amInfo);
        }
}
void TimerUpload::Hearttimer()
{
    if((Isregister==1)){
        appcon.do_beatheart();
        TRACE_INFO("send heart data!\n");
    }
}
int carspeedtemp;
void TimerUpload::onGPSTimer()
{
    minmea_sentence_rmc rmc_frame=*(GpsDataOperate::getInstance()->getData());
    //    if((Isregister==1)&&(IsAuthority==1))
    if((Isregister==1))
    {
        PositionReport_up locationmInfo;
        memset(&locationmInfo,0x00,sizeof(locationmInfo));
        locationmInfo.alarmflag=htonl(0x00000000);
        locationmInfo.status=htonl(0x00000002);
        locationmInfo.latitude=htonl(Mainlantitude);
        locationmInfo.longitude=htonl(Mainlontitude);
        locationmInfo.carspeed=htons(MainSpeed*10);
        GMT8_Time   gtime;
        RtcTime_S  rtcTime;
        RtcFacade::getInstance()->readTime(rtcTime);
        gtime.year=rtcTime.m_year;
        gtime.month=rtcTime.m_month;
        gtime.day=rtcTime.m_date;
        gtime.hour=rtcTime.m_hour;
        gtime.minute=rtcTime.m_minute;
        gtime.second=rtcTime.m_second;
        Utils::time2BCD(gtime,(char *)&locationmInfo.timestamps[0],6);
        locationmInfo.satelitespeed=htons(carspeedtemp*10);
        locationmInfo.direction=htons(rmc_frame.course.value/100);//方向角度
        appcon.do_report_position(locationmInfo);
    }

}

void TimerUpload::onRecordTimer()
{
    if(remaining_min > 0)
        //    if((Isregister==1)&&(IsLearnerLogin==1)&&(IsAuthority==1)&&(StartTrainFlag==1))
        if((Isregister==1)&&(IsLearnerLogin==1)&&(StartTrainFlag==1))
        {
            ReportLearnMessage_Up mInfo;
            memset(&mInfo,0x00,sizeof(mInfo));
            RtcTime_S rtc;
            // TrainRecordNum=TrainRecordNum+1;
            TrainCouts=TrainCouts+1;
            TrainRecordNum=  RtcUtils::getInstance()->getDayMinutes(rtc);
            // valueToHexCh(TrainRecordNum);
            std::string reocordindex ;
            std::stringstream ss11;
            ss11<<TrainRecordNum;
            ss11>>reocordindex;
            std::string temui;
            int leng=reocordindex.size();
            if(leng!=4){
                for(int y=0;y<4-leng;y++){
                    temui.append("0");
                } temui.append(reocordindex);
            }else{
                temui.append(reocordindex);
            }
            std::string monthdat=  getmaintime3string(rtc,2);
            ChangeHexDataMain(subjectID,&  mInfo.trainlesson[0]);
            mInfo. lessonid =htonl(TrainLessonId); ;

            mInfo. addgnssdata[0]=0x00 ;
            mInfo. addgnssdata[1]=0x00 ;
            mInfo. addgnssdata[2]=0x00 ;
            mInfo. addgnssdata[3]=0x00 ;//报警标识

            mInfo. addgnssdata[4]=0x00 ;
            mInfo. addgnssdata[5]=0x00 ;
            mInfo. addgnssdata[6]=0x00 ;
            mInfo. addgnssdata[7]=0x02 ;//状态

            mInfo. addgnssdata[8]=Mainlantitude>>24 ;
            mInfo. addgnssdata[9]=Mainlantitude>>16 ;
            mInfo. addgnssdata[10]=Mainlantitude>>8 ;
            mInfo. addgnssdata[11]=Mainlantitude ;//纬度

            mInfo. addgnssdata[12]=Mainlontitude >>24;
            mInfo. addgnssdata[13]=Mainlontitude >>16;
            mInfo. addgnssdata[14]=Mainlontitude>>8 ;
            mInfo. addgnssdata[15]=Mainlontitude ;//经度

            mInfo. addgnssdata[16]=(wis_u8)((MainSpeed*10)>>8);
            mInfo. addgnssdata[17]=(wis_u8)(MainSpeed*10) ;//行驶记录速度

            mInfo. addgnssdata[18]=positionReport_up.carspeed>>8;
            mInfo. addgnssdata[19]=positionReport_up.carspeed ;//卫星定位速度

            mInfo. addgnssdata[20]=0x00 ;
            mInfo. addgnssdata[21]=0x00 ;//方向

            getmaintime(rtc,&mInfo. addgnssdata[22]);
            mInfo.recordstatus=0x01;
            mInfo.maxspeed=htons((unsigned short)MaxSpeed*10);//单位
            unsigned short dist=(MainGetDistance-MinGetDistanceTemp)/100;
            TRACE_INFO_CLASS("\n一分钟最大速度:%d======一分钟里程:%d\n",MaxSpeed/10,dist);
            mInfo.milerecord=htons(   dist);   //单位百米
            getmaintime3char(rtc,& mInfo.recordtime[0],3);
            memcpy(mInfo.learnrecordid,(char *)Device_Num.c_str(),Device_Num.size());
            char yeardata[2]={0x31,0x37};
            memcpy(&mInfo.learnrecordid[16],(char *)&yeardata[0] ,2);
            memcpy(&mInfo.learnrecordid[18],(char *)&monthdat.c_str()[0] ,4);
            memcpy(&mInfo.learnrecordid[22],(char *)temui.c_str(),4);
            mInfo.reporttype=0x01;
            memcpy(&mInfo.learnerid[0],(char *)studentcardinfo.card_info.uniformID,sizeof(studentcardinfo.card_info.uniformID));
            memcpy(&mInfo.coachid[0],(char *)coachcardinfo.card_info.uniformID,sizeof(coachcardinfo.card_info.uniformID));

            mInfo.addgnssdata[28]=0x05;
            mInfo.addgnssdata[29]=0x02;
            mInfo.addgnssdata[30]=(wis_u8)(MainRpm>>8);
            mInfo.addgnssdata[31]=(wis_u8)(MainRpm);

            mInfo.addgnssdata[32]=0x01;
            mInfo.addgnssdata[33]=0x04;
            mInfo.addgnssdata[34]=0x00;
            mInfo.addgnssdata[35]=0x00;
            mInfo.addgnssdata[36]=0x00;
            mInfo.addgnssdata[37]=0x00;
            appcon.do_reportrain_record(mInfo);
            MaxSpeed=0;
            StudyTimeDb::getInstance()->insertMessage(mInfo);
            MinGetDistanceTemp = MainGetDistance;
            TRACE_INFO(" \n学时记录产生 \n");
        }
    remaining_min--;
    if(StartTrainFlag==1)
        voiceWaring(remaining_min);
}

void TimerUpload::startTest()
{
    /* 启用定时器 */
    hearttimer->start(commu_info.Client_Heartbeat_Sec,TIME_UNIT_SECOND, ctimer_selector(TimerUpload::Hearttimer));
    gpstimer->start (report_info.Default_Time_Report, TIME_UNIT_SECOND, ctimer_selector(TimerUpload:: onGPSTimer));
    reordtimer->start(60, TIME_UNIT_SECOND, ctimer_selector(TimerUpload::onRecordTimer));
    authorytimer->start(4, TIME_UNIT_SECOND, ctimer_selector(TimerUpload::Ahtytimer));
    phototimer->start(takePhototime , TIME_UNIT_MINUTE, ctimer_selector(TimerUpload::timePhoto));
    randomphototimer->start(20 , TIME_UNIT_MINUTE, ctimer_selector(TimerUpload::timerandomPhoto));
    distancetimer->start(1, TIME_UNIT_SECOND, ctimer_selector(TimerUpload::culculateDistance));
}

void TimerUpload::startIndex(int index)
{
    switch(index){
    case TimerSpace::RECORDTIMER:
        reordtimer->start(60, TIME_UNIT_SECOND, ctimer_selector(TimerUpload::onRecordTimer));
        break;
    case TimerSpace::RANDOMTIMER:
        randomphototimer->start(4, TIME_UNIT_MINUTE, ctimer_selector(TimerUpload::timerandomPhoto));
        break;
    case TimerSpace::BAISICTIMER:
        phototimer->start(takePhototime, TIME_UNIT_MINUTE, ctimer_selector(TimerUpload::timePhoto));
        break;
    case TimerSpace::HEARTTIMER:
        hearttimer->start(commu_info.Client_Heartbeat_Sec,TIME_UNIT_SECOND, ctimer_selector(TimerUpload::Hearttimer));
        break;
    case TimerSpace::LOCATIONTIMER:
        gpstimer->start (report_info.Default_Time_Report, TIME_UNIT_SECOND, ctimer_selector(TimerUpload:: onGPSTimer));
        break;
    }
}

void TimerUpload::stopIndex(int index)
{
    switch(index){
    case TimerSpace::RECORDTIMER:
        reordtimer->stop();
        break;
    case TimerSpace::RANDOMTIMER:
        randomphototimer->stop();
        break;
    case TimerSpace::BAISICTIMER:
        phototimer->stop();
        break;
    case TimerSpace::HEARTTIMER:
        hearttimer->stop();
        break;
    case TimerSpace::LOCATIONTIMER:
        gpstimer->stop();
        break;
    }
}

void TimerUpload::stopTest()
{
    /* 停止定时器 */
    hearttimer->stop();
    gpstimer->stop();
    reordtimer->stop();
    authorytimer->stop();
    phototimer->stop();
    randomphototimer->stop();
    distancetimer->stop();
    sleep(2);
}

int maxseconds = 0;
void TimerUpload::culculateDistance()
{
    minmea_sentence_rmc rmc_frame=*(GpsDataOperate::getInstance()->getData2());
    double MainGetDistanceTemp = 0;
    maxseconds++;
    carspeedtemp= (rmc_frame.speed.value/1000)*1.86;
    if(MaxSpeed < 220)
    {
        if(MaxSpeed <carspeedtemp)
        {
            MaxSpeed = carspeedtemp;
        }
    }
    if(maxseconds==60)
    {
        MaxSpeed=0;
    }

    if((rmc_frame.latitude.value/10)>0 && (rmc_frame.longitude.value/10)>0)
    {
        MainGetDistanceTemp = Distance(MainStartLat,MainStartLong,rmc_frame.latitude.value/10,rmc_frame.longitude.value/10);
        if(MainGetDistanceTemp<100)     //  一秒中的距离不超过100米
        {
            Mainlantitude = changedatalan(rmc_frame.latitude.value/10)*1000000;
            Mainlontitude = changedatalan(rmc_frame.longitude.value/10)*1000000;
            //            TRACE_INFO("\n经度为：%d\n，纬度为：%d\n",Mainlantitude,Mainlontitude);
        }
    }
    MainStartLat = rmc_frame.latitude.value/10;//开始纬度
    MainStartLong = rmc_frame.longitude.value/10;//开始经度

    if(IsLearnerLogin == 1)
    {
        if(StartTrainFlag == 1)
        {
            if(MainGetDistanceTemp<100)      //  一秒中的距离不超过100米
            {
                MainGetDistance=MainGetDistanceTemp+MainGetDistance;
                TRACE_RED("\n里程: %lf\n",MainGetDistance);
            }
        }
    }
    else
    {
        MainGetDistance = 0;
    }
}

void TimerUpload::Init_Data()
{
    TerminalLoginStatus=0;
}

void TimerUpload::voiceWaring(int re_min)
{
    if(re_min == 30)
    {
        TtsUtils::getInstance()->sendVoice("剩余半小时学时");
    }
    if(re_min == 15)
    {
        TtsUtils::getInstance()->sendVoice("剩余十五分钟学时");
    }
    if(re_min == 10)
    {
        TtsUtils::getInstance()->sendVoice("剩余十分钟学时");
    }
    if(re_min == 5)
    {
        TtsUtils::getInstance()->sendVoice("剩余五分钟学时");
    }
    if(re_min <= 0)
    {
        TtsUtils::getInstance()->sendVoice("剩余学时小于零,停止学时记录上报");
    }
}

