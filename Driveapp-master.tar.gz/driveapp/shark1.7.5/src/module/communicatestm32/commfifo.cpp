﻿#include "commfifo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include "Tracer.h"
#include "Utils.h"
CommFifo::CommFifo()
{
    len_fifo = MAX_FIFO_LEN;
    pBuffer = new char[MAX_FIFO_LEN + 1];
    pIn = pBuffer;
    pOut = pBuffer;
    count = 0;
    pMtx = new WisMutex();
}

CommFifo::~CommFifo()
{
    pMtx->~WisMutex();
    pIn = NULL;
    pOut = NULL;
    delete pBuffer;
}

int CommFifo::WriteFifo(char *data, int len)
{
    int a;
    pMtx->lock();
    if(count >= len_fifo)
    {
        TRACE_INFO("count::::%d,,,len_fifo===%d\n",count,len_fifo);
       pOut = pIn = &pBuffer[0];
       count = 0;
       Utils::LogSaveFlag("stm32data.txt","card_fifo:");
    }
    if(&pBuffer[len_fifo] - pIn >= len)
    {
        memcpy(pIn,data,len);
        pIn += len;
        count += len;
    }
    else
    {
        a = &pBuffer[len_fifo] - pIn;
        memcpy(pIn,data,a);
        pIn = pBuffer;
        memcpy(pIn,&data[a],len-a);
        pIn += len -a;
        count += len;
    }
//    printf("len_fifo= %d,fifo count = %d \n",len_fifo,count);
    pMtx->unlock();
}

int CommFifo::ReadFifo(char *cp,int cp_len)
{
    int ret = 0;
    int a = 0;
    pMtx->lock();
    if(cp_len < count)
    {
        if((&pBuffer[len_fifo] - pOut) >= cp_len)
        {
            memcpy(cp,pOut,cp_len);
        }
        else
        {
            a = (&pBuffer[len_fifo] - pOut);
            memcpy(cp,pOut,a);
            memcpy(cp+a,&pBuffer,cp_len-a);
        }
        ret = cp_len;
    }
    else
    {
        if((&pBuffer[len_fifo] - pOut) > count)
        {
            memcpy(cp,pOut,count);
        }
        else
        {
            a = (&pBuffer[len_fifo]-pOut);
//         printf("This a = %d , pBuffer[Max] = 0x%x , pOut = 0x%x", a, &pBuffer[len_fifo],pOut);
            memcpy(cp,pOut,a);
            memcpy(&cp[a],&pBuffer[0],count-a);
        }
        ret = count;
    }
    pMtx->unlock();
    return ret;
}

int CommFifo::SeekPoint(int len)
{
    if(&pBuffer[len_fifo]-pOut > len )
      {
          pOut += len;
          count -= len;
      }
      else
      {
        int a = len - (&pBuffer[len_fifo] - pOut);
        pOut = pBuffer;
        pOut += a;
        count -= len;
      }
}

