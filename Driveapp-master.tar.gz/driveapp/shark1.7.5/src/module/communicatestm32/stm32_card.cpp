﻿#include "stm32_card.h"
#include "stdio.h"
#include "communicatestm32.h"
#include "public.h"
#include "Tracer.h"
stm32_card::stm32_card()
{

}
stm32_card::~stm32_card()
{

}
stm32_info  stm32_card::cardParse(char * data ,int len)
{
    int i = 2;
    int j = 0;
    stm32_info  stm_info;

    stm_info.length = len;   //卡信息长度
    memcpy(stm_info.card_info.cardno,(char *)&data[0],10);
    stm_info.card_info.authority = data[10];    //  人员权限
    memcpy( stm_info.card_info.name,(char *)&data[16],32);
    memcpy( stm_info.card_info.uniformID,(char *)&data[48],16);
    //       memcpy( stm_info.card_info.cardType,(char *)&data[64],1);
    memcpy( stm_info.card_info.idcard,(char *)&data[65],20);
    memcpy( stm_info.card_info.money,(char *)&data[85],4);
    stm_info.card_info.traintype=data[89];
     memcpy( stm_info.card_info.fingerprint,(char *)&data[96],512);
    stm_info.card_info.lesson2value= data[608]<<24|data[609]<<16|data[610]<<8|data[611];
    stm_info.card_info.lesson3value= data[612]<<24|data[613]<<16|data[614]<<8|data[615];
    TRACE_INFO("\n刷卡标志！\n");
//    for(int y=0;y<512;y++){
//        TRACE_INFO("%02x",stm_info.card_info.fingerprint[y]);
//    }
//    TRACE_INFO("\]\n");
    return stm_info;
}

int stm32_card::card(void *param)
{
    stm32_message_info *p  =  (stm32_message_info*)param;
    int len = 0;
    len += 9;
    char * tempdata;
    p->messageID = GET_RFCARD_DATA;
    p->messagelength = len;
    p->verfycode = CRC8_Table(tempdata,p->messagelength);
}
std::string stm32_card:: GetTrainType(int index){

    std::string     car_typehex ;
    //                learnerLogin_Up.
    switch(index){
    case 1:car_typehex.append("4131");
        break;
    case 2:car_typehex.append("4132");
        break;
    case 3:car_typehex.append("4133");
        break;
    case 4:car_typehex.append("4231");
        break;
    case 5:car_typehex.append("4232");
        break;
    case 6:car_typehex.append("4331");
        break;
    case 7:car_typehex.append("4332");
        break;
    case 8:car_typehex.append("4333");
        break;
    case 9:car_typehex.append("4334");
        break;
    case 10:car_typehex.append("4335");
        break;
    case 11:car_typehex.append("3044");  //11
        break;
    case 12:car_typehex.append("0045");  //12
        break;
    case 13:car_typehex.append("0046");  //13
        break;
    case 14:car_typehex.append("004D");  //14
        break;
    case 15:car_typehex.append("004E");  //15
        break;
    case 16:car_typehex.append("0050");  //16
        break;

    }
return   car_typehex;

}


std::string stm32_card:: GetCarType(int index){

    std::string     car_typehex ;
    //                learnerLogin_Up.
    switch(index){
    case 0:car_typehex.append("00");
        break;
    case 1:car_typehex.append("01");
        break;
    case 2:car_typehex.append("02");
        break;
    case 3:car_typehex.append("03");
        break;
    case 4:car_typehex.append("11");
        break;
    case 5:car_typehex.append("12");
        break;
    case 6:car_typehex.append("21");
        break;
    case 7:car_typehex.append("22");
        break;
    case 8:car_typehex.append("23");
        break;
    case 9:car_typehex.append("24");
        break;
    case 10:car_typehex.append("25");
        break;
    case 11:car_typehex.append("31");  //11
        break;
    case 12:car_typehex.append("32");  //12
        break;
    case 13:car_typehex.append("33");  //13
        break;
    case 14:car_typehex.append("41");  //14
        break;
    case 15:car_typehex.append("42");  //15
        break;
    case 16:car_typehex.append("43");  //16
        break;

    }
return   car_typehex;

}
