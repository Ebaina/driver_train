﻿#ifndef COMMFIFO_H
#define COMMFIFO_H
#include "wis_fifo.h"
#define MAX_FIFO_LEN 1024

class CommFifo
{

public:
    CommFifo();
     ~CommFifo();
    static CommFifo * getInstance()
    {
        static CommFifo instance;
        return &instance;
    }

private:
    char *pBuffer;
    char *pIn;
    char *pOut;
    int count;
    int len_fifo;
    WisMutex *pMtx;

public:
    int ReadFifo(char *cp,int cp_len);
    int SeekPoint(int len);
    int WriteFifo(char *data,int len);
};

#endif // COMMFIFO_H


