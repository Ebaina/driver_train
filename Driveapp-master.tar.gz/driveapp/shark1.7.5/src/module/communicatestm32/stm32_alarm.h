﻿#ifndef STM32_ALARM_H
#define STM32_ALARM_H

#include "stdtype.h"

#define    GET_ALARM_DATA    0x0004     //NUC972获取报警信息数据报文
#define    GET_ALARM_DATA_ACK    0x8004     //STM32响应NUC972 报文
/***************
  * 汽车报警信息
***************/
typedef struct  stm32_alarm_info
{
    wis_u8  alarm_type;  //报警类型
    wis_u8  alarm_len;      //信息长度
    wis_u8  alarm_message[32];  //报警内容
}__attribute__((packed, aligned(1))) stm32_alarm_info;

class stm32_alarm
{
public:
    stm32_alarm();
    ~stm32_alarm();

    int alarm_ack(char *data, int len);
    int alarm(char *data, int len);
};


#endif // STM32_ALARM_H
