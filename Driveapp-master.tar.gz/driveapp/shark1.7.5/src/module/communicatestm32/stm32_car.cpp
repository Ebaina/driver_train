﻿#include "stm32_car.h"

stm32_car::stm32_car()
{

}

stm32_car:: ~ stm32_car()
{

}

int stm32_car::car_ack(char * data ,int len)
{
        int i = 1;
        stm32_car_info  car_info;
        car_info.CAR_SPEED = data[i];             //汽车速度

        car_info.CAR_RPM   =  data[++i];            //  汽车转速

        car_info.CAR_MILE  =  data[++i];          //汽车里程

        car_info.CAR_OIL   = data[++i];              //汽车油耗
}
int stm32_car::car(char *data, int len)
{

}
