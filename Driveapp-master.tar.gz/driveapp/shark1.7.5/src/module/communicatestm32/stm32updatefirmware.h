#ifndef STM32UPDATEFIRMWARE_H
#define STM32UPDATEFIRMWARE_H
#include "MsgQueue.h"

class stm32UpdateFirmware :QueueMsg_S
{
public:
    stm32UpdateFirmware();
    ~stm32UpdateFirmware();

};

#endif // STM32UPDATEFIRMWARE_H
