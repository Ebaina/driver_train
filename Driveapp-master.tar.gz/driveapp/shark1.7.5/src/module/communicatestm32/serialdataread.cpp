#include "serialdataread.h"
#include "app_globl.h"
#include "Tracer.h"
#include "ComPort.h"
#define COM_PORT	"/dev/ttyS1"
SerialDataRead::SerialDataRead()
{
   this->comportStm32=new ComPort();
   this->comportStm32->setAttribute(COM_ATTR_BAUDRATE, 115200);
   this-> comportStm32->open(COM_PORT, IO_MODE_RDWR_ONLY);
}

SerialDataRead::~SerialDataRead()
{

}

int SerialDataRead::serialRecive(char *buff, int l_buff, long timeout)
{
    this->comportStm32->readData(buff,l_buff,timeout);
}


int SerialDataRead::serialSend(char *buff, int l_buff)
{

    this->comportStm32->writeData(buff,l_buff,1000);
    return 0;
}
