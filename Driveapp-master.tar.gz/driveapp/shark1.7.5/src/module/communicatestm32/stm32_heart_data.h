﻿#ifndef STM32_HEART_DATA_H
#define STM32_HEART_DATA_H
#include "stdtype.h"


#define    HEART_DATA_ACK    0x8000     //STM32响应NUC972链接终端报文（暂时不用）
#define    HEART_DATA           0x0000     //NUC972 心跳维持链接STM32报文
/***************
  * 972心跳信息发送
***************/
typedef struct  stm32_heart_info
{
    wis_u8 car_type;                //0x00 控制单片机停止发送CAR数据     0x01控制单片机发送CAR数据
    wis_u8 alarm_type;           //0x00 控制单片机停止发送报警数据    0x01控制单片机发送报警数据
    wis_u8  rfcard_type;          //0x00 控制单片机停止发送射频卡数据   0x01控制单片机发送射频卡数据
    wis_u8  voltage_type;         //0x00 控制单片机停止发送电压数据    0x01控制单片机发送电压数据
}__attribute__((packed, aligned(1))) stm32_heart_info;

class STM32_HEART_DATA
{
public:
    STM32_HEART_DATA();
    ~STM32_HEART_DATA();

    int stm32_heart_data_ack(char *data, int len);
    int stm32_heart_data(void *param);

};

#endif // STM32_HEART_DATA_H
