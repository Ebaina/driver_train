﻿#include "stm32_connect.h"

stm32_connect::stm32_connect()
{

}

stm32_connect::~stm32_connect()
{

}

int stm32_connect::stm_connect_ack(char * data ,int len)
{
        int i = 1;
        stm32_connect_info  connect_info;
        connect_info.TYPE  =  (data[i]&0xff)<<8 | data[++i]&0xff;          //产品型号

        connect_info.VERSION = (data[++i]&0xff)<<8 | data[++i]&0xff;         //  终端上报固件版本号

        connect_info.HARDWARE  =  (data[++i]&0xff)<<24 | (data[++i]&0xff)<<16 |(data[++i]&0xff)<<8 | data[++i]&0xff;          //硬件版本

        connect_info.TERMINALID  =   (data[++i]&0xff)<<24 | (data[++i]&0xff)<<16 |(data[++i]&0xff)<<8 | data[++i]&0xff;        //终端编号
}
int stm32_connect::stm_connect(char *data, int len)
{

}
