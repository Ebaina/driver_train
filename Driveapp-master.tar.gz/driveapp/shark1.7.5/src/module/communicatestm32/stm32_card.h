﻿#ifndef STM32_CARD_H
#define STM32_CARD_H
#include "stdtype.h"
#include <string>

#define    GET_RFCARD_DATA    0x0005     //NUC972获取射频卡信息数据报文
#define    GET_RFCARD_DATA_ACK    0x8005     //STM32响应NUC972 报文
/***************
  * 卡信息结构
***************/
typedef struct  stm32_card_info
{
    char  cardno[10];//  cardno
    char authority;  //  权限 1:学员    2:教练员    3:考核员    4:安全员    5:其他
    char name[32];      //  姓名
    char uniformID[16];  //  统一编号
    char cardType;     //  证件类型   1:身份证       2:护照       3:军官证       4:其他
    char idcard[20];  //  证件号
    char money[4];    //  卡内金额数值型
    char traintype ;    //  训练车型
    wis_u8  fingerprint[512];   // 指纹数据
    int  lesson2value;//  科目2学时
    int  lesson3value;//  科目3学时

}__attribute__((packed, aligned(1))) stm32_card_info;

/***************
  * 射频卡基本信息
***************/
typedef struct  stm32_info
{
    int length;                       //长度
    stm32_card_info card_info;     //卡信息结构

}__attribute__((packed, aligned(1))) stm32_info;


class stm32_card
{
public:
    stm32_card();
    ~stm32_card();
    static stm32_card * getInstance()
    {
        static stm32_card instance;
        return &instance;
    }

    stm32_info    cardParse(char *data, int len);
    int card(void *param);
//    parsecard(char *data, int len);
    std::string   GetTrainType(int index);
    std::string  GetCarType(int index);
};

#endif // STM32_CARD_H
