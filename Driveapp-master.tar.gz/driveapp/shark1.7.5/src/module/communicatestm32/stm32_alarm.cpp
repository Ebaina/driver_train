﻿#include "stm32_alarm.h"

stm32_alarm::stm32_alarm()
{

}
stm32_alarm::~stm32_alarm()
{

}


int stm32_alarm::alarm_ack(char * data ,int len)
{
        int i = 1;
        stm32_alarm_info  alarm_info;
        alarm_info.alarm_type = data[i];             //汽车速度

        alarm_info.alarm_len   =  data[++i];            //  汽车转速

        for(int j = 0; j<alarm_info.alarm_len;j++)
        {
            alarm_info.alarm_message[j]  =  data[++i];          //汽车里程
        }


}
int stm32_alarm::alarm(char *data, int len)
{

}
