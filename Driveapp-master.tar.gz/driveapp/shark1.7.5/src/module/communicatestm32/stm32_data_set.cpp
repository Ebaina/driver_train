﻿#include "stm32_data_set.h"
#include "communicatestm32.h"
#include "public.h"
stm32_data_set::stm32_data_set()
{

}

stm32_data_set::~stm32_data_set()
{

}


int stm32_data_set::stm_data_set_ack(char *data, int len)
{
    int i = 1;
    stm32_result_set_info stm_result_info;

    stm_result_info.TYPE_result = data[i];                          //产品型号

    stm_result_info.VERSION_result = data[++i];               //终端上报固件版本号

    stm_result_info.HARDWARE_result = data[++i];           //硬件版本

    stm_result_info.TERMINALID_result = data[++i];        //终端编号

}

int stm32_data_set::stm_data_set(void *param)
{
    stm32_message_info *p  =  (stm32_message_info*)param;
    int len = 0;
    len += 9;
    char * tempdata;
    stm32_data_set_info  stm_data_info;
    p->messageID = SET_STM32_DATA;
    stm_data_info.TYPE = 0x11;                                 //产品型号

    stm_data_info.VERSION = 0x22;                          //终端上报固件版本号

    stm_data_info.HARDWARE = 0x3333;                //硬件版本

    stm_data_info.TERMINALID = 0x1234;             //终端编号

    memcpy(p->message_content,(char*)&stm_data_info,sizeof(stm_data_info));
    p->messagelength = len+sizeof(stm_data_info);
    memcpy(tempdata ,(char*)p,p->messagelength-3);
    p->verfycode = CRC8_Table(tempdata,p->messagelength-3);

}
