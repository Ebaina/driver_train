﻿#include "communicatestm32.h"
#include "Thread.h"
#include "uart.h"
#include "Mutex.h"
#include "public.h"
#include "ComPort.h"
#include "Timer.h"
#include "app_globl.h"
#include "AES.h"
#include "rtcutils.h"
#include "stm32_card.h"
#include "stm32_heart_data.h"
#include "stm32_car.h"
#include "stm32_connect.h"
#include "stm32_data_set.h"
#include "stm32_alarm.h"
#include  "statusreportinterface.h"
#include <string>
#include "commfifo.h"
#include "ui_interface.h"
#include  "test.h"
#include "Utils.h"
#include "ttsutils.h"
#include"stringutils.h"
#include"photogetutils.h"
#include "taskschedulerthread.h"
#include "offlinesave.h"
#include "postutils.h"
using namespace std;
Wisfifo comFifo;
pthread_t  m_thread2Handle;
pthread_t  mSTM32Communicate_threadHandle;
pthread_t  mSTM32Communicate_ReadHandle;
stm32_card  *p_stm_card;
stm32_car   *p_stm_car;
STM32_HEART_DATA *p_stm_heart_data;
#define COM_PORT	"/dev/ttyS1"
stm32_message_info message_info;
ComPort* pCom=NULL;
u8 seeknum=0;
int FingerFlag=0;
unsigned long currentms =0;
unsigned int timeout = 50;
unsigned int count11 = 100;
int pos = 0;
bool mvUartState;
char rcv[512];
char aeskey[] =  //AES密钥
{
        0x2b, 0x7e, 0x15, 0x16,
        0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88,
        0x09, 0xcf, 0x4f, 0x3c
        };
CommunicateStm32::CommunicateStm32()
{
    stm32thread = new TaskSchedulerThread();
    photoLen = 100*1024;
    photoBuffer = new char [100*1024];
}
CommunicateStm32::~CommunicateStm32()
{
    delete [] photoBuffer;
    delete  stm32thread;
    pthread_join(mSTM32Communicate_threadHandle,NULL);
    pthread_join(mSTM32Communicate_ReadHandle,NULL);

}

void CommunicateStm32:: parseUpdata(char * data ,int length )
{
    Uploadphotoinit_Up init_minfo_coach;
    Uploadphotoinit_Up init_minfo_learner;
    RtcTime_S rtc;
    char photobuf_coach[64];
    char photobuf_learner[64];
    string photonum_coach ;
    string photonum_learner;
    int Tempcount=0;

    char fingerPlease[8]={0xC2, 0xBC, 0xC8 ,0xEB ,0xD6, 0xB8 ,0xCE ,0xC6  };
    char fingerinputok[8]={ 0xC2 ,0xBC ,0xC8 ,0xEB ,0xB3 ,0xC9 ,0xB9 ,0xA6 };

    char authority_fail_data19[19] = {0x12 ,0x01 ,0x01 ,0xC1 ,0xAC, 0xBD ,0xD3, 0xD5 ,0xFD ,0xC3 ,0xA6,0xCE, 0xDE ,0xB7 ,0xA8 ,0xB5, 0xC7, 0xC2 ,0xBC};
    wis_u16 commid = ((wis_u16)data[0]<<8) | data[1];
    int sizephoto;

    char needcoach17[17]={0x10,0x01 ,0x01 ,0xC7 ,0xEB ,0xBD ,0xCC ,0xC1 ,0xB7 ,0xD4 ,0xB1 ,0xCF ,0xC8 ,0xC7 ,0xA9 ,0xB5 ,0xBD};
    char needstuadent17[17]={0x0E ,0x01 ,0x01 ,0xC7 ,0xEB ,0xD1 ,0xA7 ,0xD4 ,0xB1 ,0xCF ,0xC8 ,0xC7 ,0xA9 ,0xCD ,0xCB };

    unsigned char datatest[200];
    int fingerscore;
//    TRACE_INFO("\n命令子:%04x\n",commid);
    //    AES  aes(aeskey);
    //    aes.InvCipher((void *)&data[2],length-2);//AES解密
    switch (commid)
    {
    case HEART_DATA_ACK:                                                    //STM32响应NUC972链接终端报文（暂时不用）
        printf("getdata00!\n");

        break;
    case CONNECT_ACK:                                                        //STM32响应NUC972链接终端报文
        printf("getdata01!\n");
        break;
    case SET_STM32_DATA_ACK:                                           //STM32响应NUC972焼写STM32基本数据报文
        printf("getdata02!\n");
        break;
    case GET_CAR_DATA_ACK:                                                //STM32响应NUC972 获取汽车数据信息报文
//        printf("getdata03!\n");
//        p_stm_car->car_ack(data,length);
        break;
    case GET_ALARM_DATA_ACK:                                           //STM32响应NUC972 获取报警信息数据报文
        printf("getdata04!\n");
        break;
    case GET_RFCARD_DATA_ACK:                                         //STM32响应NUC972 获取射频卡信息数据报文
        TRACE_INFO("getdata05!\n");
        unsigned char   modeltemptype;
        modeltemptype=data[12];
        TRACE_INFO("\nRfcardlogoutFlag:%d=======RfcardReadFlag=%d\n",RfcardlogoutFlag,RfcardReadFlag);
//        if((RfcardlogoutFlag == 0)&&( RfcardReadFlag==0)&&( forbidenflag == 0))
//        {
//          switch(modeltemptype)
//          {
//          case 0x31://
//              if(IsLearnerLogin==1)
//              {
//              TtsUtils::getInstance()->sendVoice("仅能支持一名学员同时在一辆车上签到");
//              }
//                break;
//          }
//       }
        if((RfcardReadFlag==1)&&(IsAuthority == 0) )
        {
            TRACE_ERR("\n鉴全失败！！！！！！\n");
            Send_Voice(authority_fail_data19,19);
        }
        TRACE_ERR("\nforbidenflag:%d\n",forbidenflag);
        if(forbidenflag == 1)
        {
            TtsUtils::getInstance()->sendVoice("今日不能培训");
        }

        if((RfcardReadFlag == 1)&&(IsAuthority == 1))
        {
            switch(modeltemptype){
            case 0x34://admin
                stm32_info admincardinfo;
                admincardinfo=stm32_card::getInstance()->cardParse(&data[2],length-2);
                break;

            case 0x32://coach
                if(IsCoachLogin==0){
                    TrainLessonId  =  RtcUtils::getInstance()->getUtcTimeSeconds();
                    coachcardinfo=stm32_card::getInstance()->cardParse(&data[2],length-2);
                    printf("\n教练登入标志\n");
                    MainCoachPhotoPath=   PhotoGetUtils::getInstance()->getCoachPath(Device_Num,QString((char*)coachcardinfo.card_info.uniformID).toStdString());
                    UI_CoachLogin_Up ui_CoachLogin_Up;
                    memcpy( &ui_CoachLogin_Up. coachid[0],(char *)coachcardinfo.card_info.uniformID,16);
                    memcpy( &ui_CoachLogin_Up. coachdentityid[0],(char *)coachcardinfo.card_info.idcard,18);
                    std::string  trainTypetemp=  stm32_card::getInstance()->GetTrainType(coachcardinfo.card_info.traintype);
                    ChangeHexStr2Char(trainTypetemp,&ui_CoachLogin_Up.traincartype[0]);
                    m_loginInterface->coachLogin(ui_CoachLogin_Up);
                    TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::COACH_LOGIN_FINGER);
                    usleep(1000);
                    if( PSDownChar(DEV_ADDR,CHAR_BUFFER_A,&coachcardinfo.card_info.fingerprint[0],512)==PS_OK) {
                        TRACE_INFO("\指纹加载成功\n");
                        Delay(1000);
                        TRACE_INFO("Search: Please Repress finger......\n");
                        Tempcount=0;
                        while((PSGetImage(DEV_ADDR)==PS_NO_FINGER))
                        {
                            if(DEVICE_USB==0)
                                PSReadInfo(DEV_ADDR,1,datatest);
                            Delay(200000);
                            Tempcount++;
                            if(Tempcount >= 50 )
                            {
                                if(PSCloseDevice()==1)
                                {
                                    TRACE_INFO("Close device ok!\n");
                                }
                                reset_finger();
                                module_init();                     //指纹模块初始化   //后面加卡数据
                                break;
                            }
                        }

                        if(PSGenChar(DEV_ADDR,CHAR_BUFFER_B)!=PS_OK)
                        {
                            TRACE_INFO("Gen Char fail!\n");
                        }
                    }
                    else
                    {
                        if(PSCloseDevice()==1)
                        {
                            TRACE_INFO("Close device FFok!\n");
                        }
                        reset_finger();
                        module_init();                     //指纹模块初始化   //后面加卡数据
                    }

                    if(PSMatch(DEV_ADDR,&fingerscore)==0)
                    {
                        TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::FINGER_SUCCESS);
                        usleep(1000);
                        CoachLogin_Up mInfo ;
                        memcpy( &mInfo. coachid[0],(char *)coachcardinfo.card_info.uniformID,16);
                        memcpy( &mInfo. coachdentityid[0],(char *)coachcardinfo.card_info.idcard,18);

                        mInfo. traincartype[0]=ui_CoachLogin_Up.traincartype[0];//34  准教车型    BYTE[2] A1/A2/A3/B1/B2/C1/C2/C3/C4/D/E/F
                        mInfo. traincartype[1]=ui_CoachLogin_Up.traincartype[1];
                        Utils::packageGps((char *)mInfo. gnssdata);
                        printf("Coach Login!\n");

                        appcon.do_coachlogin(mInfo);
                        IsCoachLogin=1;                              //教练登入标志
                        m_loginInterface->coachFingerprintAck(1);
                        TRACE_INFO("\n摄像头0状态:%d\n",check_video0_status());
                        if(1 == RealTimeVideoStatus())
                        {
                            char snap_dev0_pic_names[30] = {0};
                            memset(photobuf_coach, 0, sizeof(photobuf_coach));
                            memset(snap_dev0_pic_names, 0 ,sizeof(snap_dev0_pic_names));
                            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0)
                                TRACE_INFO("exe snap pic error\n");
                            sprintf(photobuf_coach, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
                            photonum_coach  =getmaintime3string(rtc,5);
                            getmaintime3char(rtc,& init_minfo_coach.photonum[0],5);
                            memcpy(& init_minfo_coach.learnerorcoachid[0],(char *)coachcardinfo.card_info.uniformID,sizeof(coachcardinfo.card_info.uniformID));
                            init_minfo_coach.uploadmode =  0x01;
                            memcpy( & init_minfo_coach.photonum[0],(char *)photonum_coach.c_str(),photonum_coach.size());
                            sizephoto =  appcon.GetPhotodata(photonum_coach,photobuf_coach,&photoBuffer[0],photoLen);
                            TRACE_INFO("照片：%d!\n",sizephoto);
                            init_minfo_coach.camerachannel = 0x00;
                            init_minfo_coach.photosize =0x01;
                            init_minfo_coach.photoeventtype = 0x14;
                            int sizetemp=(sizephoto+293)/700;//293 =照片编号（10个）+扩增消息头+校验串
                            if((sizephoto%700)==0){
                                init_minfo_coach.packgesize = htons(sizetemp);
                            }else{
                                init_minfo_coach.packgesize = htons(sizetemp+1);
                            }
                            init_minfo_coach.photodatasize = htonl(sizephoto);
                            init_minfo_coach.lessonid = htonl(TrainLessonId);
                            init_minfo_coach.faceidentifyreliability = 0x00;
                            Utils::packageRtcGps((char *) &init_minfo_coach. addgnssdata[0]);
                            appcon.do_upload_photo_init(init_minfo_coach);
                            sleep(4);
                            appcon.MultPacge_Tools(photonum_coach,photoBuffer,sizephoto);
                        }

                       Configuration_parameter_set("devicedata:pageflag","1");
                       copage_set();

                    }   else{
                        m_loginInterface->coachFingerprintAck(0);
                        IsCoachLogin=0; //
                        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::FINGER_FALURE);//指纹验证失败，请重新刷卡
                        usleep(1000);
                        Configuration_parameter_set("devicedata:pageflag","0");
                    }                      //  指纹比对
                }
                break;


            case 0x31://learner
                if((IsCoachLogin==1)&&(IsLearnerLogin == 0))
                {
                    TrainLessonId  =  RtcUtils::getInstance()->getUtcTimeSeconds();
                    studentcardinfo=stm32_card::getInstance()->cardParse(&data[2],length-2);
                    UI_LearnerLogin_Up learnerLogin_Up;
                    memcpy( &learnerLogin_Up.learnerid[0],(char *)studentcardinfo.card_info.uniformID,16);
                    learnerLogin_Up.cardtype = (unsigned char  )studentcardinfo.card_info.cardType;
                    memcpy( &learnerLogin_Up.learnerdentityid[0], (char *)studentcardinfo.card_info.idcard,18);
                    std::string     car_typehex ;
                    car_typehex=stm32_card::getInstance()->GetTrainType(studentcardinfo.card_info.traintype);
                    memset(learnerLogin_Up.coachid,0x00,sizeof(learnerLogin_Up.coachid));
                    memcpy( &learnerLogin_Up.coachid[0] ,( char *)&coachcardinfo.card_info.uniformID[0],16);
                    MainStudentPhotoPath=   PhotoGetUtils::getInstance()->getStudentPath(Device_Num,QString((char*)studentcardinfo.card_info.uniformID).toStdString());
                    ChangeHexStr2Char(car_typehex,&learnerLogin_Up.trancar_type[0]);
                    m_loginInterface->learnerLogin(learnerLogin_Up);
                    TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::STUDENT_LOGIN_FINGER);
                    if( PSDownChar(DEV_ADDR,CHAR_BUFFER_A,&studentcardinfo.card_info.fingerprint[0],512)==PS_OK)
                    {
                        TRACE_INFO("\指纹加载成功\n");
                        Delay(1000);
                        TRACE_INFO("Search: Please Repress finger......\n");
                        Tempcount=0;
                        while((PSGetImage(DEV_ADDR)==PS_NO_FINGER))
                        {
                            if(DEVICE_USB==0)
                                PSReadInfo(DEV_ADDR,1,datatest);
                            Delay(200000);
                            Tempcount++;
                            if(Tempcount >= 50 )
                            {
                                if(PSCloseDevice()==1)
                                {
                                    TRACE_INFO("Close device ok!\n");
                                }
                                reset_finger();
                                module_init();                     //指纹模块初始化   //后面加卡数据
                                break;
                            }
                        }

                        if(PSGenChar(DEV_ADDR,CHAR_BUFFER_B)!=PS_OK)
                        {
                            TRACE_INFO("Gen Char fail!\nthread");
                        }
                    }
                    else
                    {
                        if(PSCloseDevice()==1)
                        {
                            TRACE_INFO("Close device ok!\n");
                        }
                        reset_finger();
                        module_init();                   //指纹模块初始化
                    }
                    UI_Learner_Info ui_Learner_Info;
                    memcpy(&ui_Learner_Info.learnerid[0],(char *)studentcardinfo.card_info.uniformID,16);
                    ui_Learner_Info.   maintraintime=0;//17	总培训学时	WORD	单位：min
                    ui_Learner_Info.   finishtime=0;//19	当前培训部分已完成学时	WORD	单位：min
                    ui_Learner_Info.   maintrainmile=300;//21	总培训里程	WORD	单位：1/10km
                    ui_Learner_Info.   finishmile=0;//23	当前培训部分已完成里程	WORD	单位：1/10km

                    usleep(100000);
                    if(PSMatch(DEV_ADDR,&fingerscore)==0)
                    {
                        TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::FINGER_SUCCESS);
                        usleep(1000);
                        LearnerLogin_Up learnermInfo;
                        memcpy( &learnermInfo.learnerid[0],(char *)studentcardinfo.card_info.uniformID,16);
                        learnerLogin_Up.cardtype = (unsigned char  )studentcardinfo.card_info.cardType;
                        memcpy( &learnermInfo.learnerdentityid, (char *)coachcardinfo.card_info.uniformID,16);

                        ChangeHexData(subjectID,&   learnermInfo.trainlesson[0]);
                        learnermInfo. lessonid[0]=TrainLessonId>>24 ;
                        learnermInfo. lessonid[1]=TrainLessonId>>16 ;
                        learnermInfo. lessonid[2]=TrainLessonId>>8 ;
                        learnermInfo. lessonid[3]=TrainLessonId ;//课堂ID

                        Utils::packageGps((char *)learnermInfo. gnssdata);

//                        TRACE_INFO("学员登陆标志\n");
                        appcon.do_learnerlogin(learnermInfo);

                        IsLearnerLogin=1;                                     //学员登入标志位
                        m_loginInterface->learnerFingerprintAck(1,ui_Learner_Info);

                        if(1 == RealTimeVideoStatus())
                        {
                            char snap_dev0_pic_names[30] = {0};
                            memset(photobuf_learner, 0, sizeof(photobuf_learner));
                            memset(snap_dev0_pic_names, 0 ,sizeof(snap_dev0_pic_names));
                            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0)
                                printf("exe snap pic error\n");
                            sprintf(photobuf_learner, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
                            photonum_learner  =getmaintime3string(rtc,5);
                            memcpy(& init_minfo_learner.learnerorcoachid[0],(char *)studentcardinfo.card_info.uniformID,16);
                            memcpy( & init_minfo_learner.photonum[0],(char *)photonum_learner.c_str(),photonum_learner.size());
                            sizephoto=   appcon.GetPhotodata(photonum_learner,photobuf_learner,photoBuffer,photoLen);
                            init_minfo_learner.uploadmode =  0x01;
                            init_minfo_learner.camerachannel = 0x00;
                            init_minfo_learner.photosize = 0x01;
                            init_minfo_learner.photoeventtype = 0x11;
                            int sizetemp=(sizephoto+293)/700;//293 =照片编号（10个）+扩增消息头+校验串
                            if((sizephoto%700)==0){
                                init_minfo_learner.packgesize = htons(sizetemp);
                            }else{
                                init_minfo_learner.packgesize = htons(sizetemp+1);//tons(sizetemp+1)
                            }
                            init_minfo_learner.photodatasize =htonl(sizephoto);
                            init_minfo_learner.lessonid =htonl(TrainLessonId); ;
                            init_minfo_learner.faceidentifyreliability = 0x00;
                            Utils::packageRtcGps((char *) &init_minfo_learner. addgnssdata[0]);
                            appcon.do_upload_photo_init(init_minfo_learner);
                            sleep(4);
                            appcon.MultPacge_Tools(photonum_learner,photoBuffer,sizephoto);
                        }
                        Trainminutes = 0;
                        remaining_min = 0;
                        TrainCouts=0;
                        MainGetDistance = 0;
                        Configuration_parameter_set("devicedata:pageflag","2");
                        stupage_set();
                        POSTutils::getInstance()->downLoadGET(Device_Num,QString((char*)studentcardinfo.card_info.uniformID).toStdString());
                    }
                    else
                    {
                        m_loginInterface->learnerFingerprintAck(0,ui_Learner_Info);
                        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::FINGER_FALURE);//指纹验证失败，请重新刷卡
                        usleep(1000);
                        IsLearnerLogin=0;

                    }                      //  指纹比对
                    TRACE_INFO("GetLearner!\n");
                }
                else if(IsCoachLogin == 0)
                {
                    Send_Voice(needcoach17,17);
                    usleep(1000);
                    //请先登陆教练信息
                }
                break;

            case 4:
                read_moudelNum();                //读取指纹模块编号
                Send_Voice(fingerPlease,8);
                usleep(1000);
                if( entry()==0  )                      //  指纹录入
                {
                    TRACE_INFO("Success\n");
                    Send_Voice(fingerinputok,8);
                    usleep(1000);
                }
                break;
            }
        }

        if((RfcardlogoutFlag == 1)&&( RfcardReadFlag == 0))
        {
            switch(modeltemptype)
            {
            case 1://admin

                break;

            case 0x32://coach
                if((IsLearnerLogin==0)&&(IsCoachLogin == 1)){
                    CoachLogout_Up  coachmInfo;
                    TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::COACH_LOGOUT_FINGER);
                    coachcardinfo=stm32_card::getInstance()->cardParse(&data[2],length-2);
                    memcpy(&coachmInfo.coachid[0],(char *)&coachcardinfo.card_info.uniformID[0],sizeof(coachcardinfo.card_info.uniformID));
                    if( PSDownChar(DEV_ADDR,CHAR_BUFFER_A,&coachcardinfo.card_info.fingerprint[0],512)==PS_OK)
                    {
                        printf("\指纹加载成功\n");
                        Delay(1000);
                        printf("Search: Please Repress finger......\n");
                        Tempcount=0;
                        while((PSGetImage(DEV_ADDR)==PS_NO_FINGER))
                        {
                            if(DEVICE_USB==0)
                                PSReadInfo(DEV_ADDR,1,datatest);
                            Delay(200000);
                            Tempcount++;
                            if(Tempcount >= 50 )
                            {
                                if(PSCloseDevice()==1)
                                {
                                    printf("Close device ok!\n");
                                }
                                reset_finger();
                                module_init();                     //指纹模块初始化   //后面加卡数据
                                break;
                            }
                        }
                        if(PSGenChar(DEV_ADDR,CHAR_BUFFER_B)!=PS_OK)
                        {
                            printf("Gen Char fail!\n");
                        }
                    }
                    else
                    {
                        if(PSCloseDevice()==1)
                        {
                            printf("Close device ok!\n");
                        }
                        reset_finger();
                        module_init();                   //指纹模块初始化
                    }

                    if(PSMatch(DEV_ADDR,&fingerscore)==0)
                    {
                        Utils::packageGps((char *)coachmInfo. gnssdata);
                        getmaintime(rtc,&coachmInfo. gnssdata[22]);
                        sleep(1);
                        printf("教练登出:%d\n",RfcardReadFlag);
                        TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::COACH_LOGOUT_FINGER_SUCCESSE);
                        usleep(100);
                        m_loginInterface->logoutAck( UI_HEADER::LT_COACH);
                        IsCoachLogin=0;                                 //教练登出标志
                        RfcardlogoutFlag = 0;
                        appcon.do_coachlogout(coachmInfo);
                        //暂时禁用
                        TRACE_INFO("\n摄像头状态:%d\n",check_video0_status());
                        if(1 == RealTimeVideoStatus())
                        {
                            char snap_dev0_pic_names[30] = {0};
                            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0)
                                printf("exe snap pic error\n");
                            sprintf(photobuf_coach, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
                            photonum_coach  =getmaintime3string(rtc,5);
                            memcpy(& init_minfo_coach.learnerorcoachid[0],(char *)coachcardinfo.card_info.uniformID,16);
                            memcpy( & init_minfo_coach.photonum[0],(char *)photonum_coach.c_str(),photonum_coach.size());
                            sizephoto=   appcon.GetPhotodata(photonum_coach,photobuf_coach,photoBuffer,photoLen);
                            init_minfo_coach.uploadmode =  0x01;
                            init_minfo_coach.camerachannel = 0x00;
                            init_minfo_coach.photosize = 0x01;
                            init_minfo_coach.photoeventtype = 0x15;
                            int sizetemp=(sizephoto+293)/700;//293 =照片编号（10个）+扩增消息头+校验串
                            if((sizephoto%700)==0){
                                init_minfo_coach.packgesize = htons(sizetemp);
                            }else{
                                init_minfo_coach.packgesize = htons(sizetemp+1);//tons(sizetemp+1)
                            }
                            init_minfo_coach.photodatasize =htonl( sizephoto);
                            init_minfo_coach.lessonid =htonl(TrainLessonId); ;
                            Utils::packageRtcGps((char *) &init_minfo_coach. addgnssdata[0]);
                            init_minfo_coach.faceidentifyreliability = 0x00;
                            appcon.do_upload_photo_init(init_minfo_coach);
                            sleep(4);
                            appcon.MultPacge_Tools(photonum_coach,photoBuffer,sizephoto);
                        }
                        Configuration_parameter_set("devicedata:pageflag","0");
                    }
                    else
                    {
                        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::FINGER_FALURE);//指纹验证失败，请重新刷卡
                    }

                }
                else
                {
                    //语音提示   请学员先退出
                    Send_Voice(needstuadent17,17); usleep(1000);
                }
                break;

            case 0x31://learner

                if(IsLearnerLogin==1)
                {
                    stm32_info stucardinfo;
                    stucardinfo=stm32_card::getInstance()->cardParse(&data[2],length-2);
                    string upcardno = POSTutils::getInstance()->cardnumber;
//                    string cardno  = Utils::code2string(stucardinfo.card_info.cardno,sizeof(stucardinfo.card_info.cardno));
                    char a[11] = {0};
                    memcpy(a,stucardinfo.card_info.cardno,10);
                    string cardno  = a;
                    TRACE_INFO("学员卡:%s\n",upcardno.c_str());
                    TRACE_INFO("学员卡号:%s\n",cardno.c_str());
                    if(upcardno.compare(cardno) != 0)
                    {
                        TtsUtils::getInstance()->sendVoice("学员卡不匹配，无法登出!");
                        break;
                    }
                    RtcTime_S  rtc1;
                    TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::STUDENT_LOGOUT_FINGER);
                    if( PSDownChar(DEV_ADDR,CHAR_BUFFER_A,&studentcardinfo.card_info.fingerprint[0],512)==PS_OK)
                    {
                        printf("\指纹加载成功\n");
                        Delay(1000);
                        printf("Search: Please Repress finger......\n");
                        Tempcount=0;
                        while((PSGetImage(DEV_ADDR)==PS_NO_FINGER))
                        {
                            if(DEVICE_USB==0)
                                PSReadInfo(DEV_ADDR,1,datatest);
                            Delay(200000);
                            Tempcount++;
                            if(Tempcount >= 50 )
                            {
                                if(PSCloseDevice()==1)
                                {
                                    printf("Close device ok!\n");
                                }
                                reset_finger();
                                module_init();                     //指纹模块初始化   //后面加卡数据
                                break;
                            }
                        }
                        if(PSGenChar(DEV_ADDR,CHAR_BUFFER_B)!=PS_OK)
                        {
                            printf("Gen Char fail!\n");
                        }
                    }
                    else
                    {
                        if(PSCloseDevice()==1)
                        {
                            printf("Close device ok!\n");
                        }
                        reset_finger();
                        module_init();                   //指纹模块初始化
                    }

                    if(PSMatch(DEV_ADDR,&fingerscore)==0)
                    {
                        TtsUtils::getInstance()->sendVoiceStatus(TRAIN_VOICE::STUDENTH_LOGOUT_FINGER_SUCCESSE);
                        usleep(100);

                        LearnerLogout_Up leanermInfo;
                        getmaintime(rtc1,&  leanermInfo.logoutime[0]);
                        memcpy( &leanermInfo.learnerid[0],(char *)studentcardinfo.card_info.uniformID,16);
                        leanermInfo.lessonid=htonl(TrainLessonId );
                        leanermInfo.loginmainmile=htons((unsigned short) MainGetDistance/100.00);
                        leanermInfo.loginmainmtime=htons((unsigned short)Trainminutes);
                        TrainCouts = (unsigned short)Trainminutes;
                        Utils::packageGps((char *)leanermInfo. gnssdata);
                        sleep(1);
                        leanermInfo.loginmainmtime=htons(TrainCouts);
                        IsLearnerLogin=0;
                        appcon.do_learnerlogout(leanermInfo);
                        printf("学员登出:%d\n",RfcardReadFlag);
                        m_loginInterface->logoutAck( UI_HEADER::LT_LEARNER);

                        learner_login_info.finishmile=0;
                        learner_login_info.finishtime = 0;
                        learner_login_info.maintraintime = 0;
                        //暂时禁用
                        TRACE_INFO("\n摄像头状态:%d\n",check_video0_status());
                        if(1 == RealTimeVideoStatus())
                        {
                            char snap_dev0_pic_names[30] = {0};
                            if(exe_dev0_snap_pics(snap_dev0_pic_names) != 0)
                                printf("exe snap pic error\n");
                            sprintf(photobuf_learner, "/mnt/mmcblk0p1/%s", snap_dev0_pic_names);
                            photonum_learner  =getmaintime3string(rtc,5);
                            memcpy(& init_minfo_learner.learnerorcoachid[0],(char *)studentcardinfo.card_info.uniformID,16);
                            memcpy( & init_minfo_learner.photonum[0],(char *)photonum_learner.c_str(),photonum_learner.size());
                            sizephoto=   appcon.GetPhotodata(photonum_learner,photobuf_learner,photoBuffer,photoLen);
                            init_minfo_learner.uploadmode =  0x01;
                            init_minfo_learner.camerachannel = 0x00;
                            init_minfo_learner.photosize = 0x01;
                            init_minfo_learner.photoeventtype = 0x12;
                            int sizetemp=(sizephoto+293)/700;//293 =照片编号（10个）+扩增消息头+校验串
                            if((sizephoto%700)==0){
                                init_minfo_learner.packgesize = htons(sizetemp);
                            }else{
                                init_minfo_learner.packgesize = htons(sizetemp+1);//tons(sizetemp+1)
                            }
                            init_minfo_learner.photodatasize =htonl( sizephoto);
                            init_minfo_learner.lessonid =htonl(TrainLessonId); ;
                            //    init_minfo_learner.addgnssdata = ;
                            init_minfo_learner.faceidentifyreliability = 0x00;
                            Utils::packageRtcGps((char *) &init_minfo_learner. addgnssdata[0]);
                            appcon.do_upload_photo_init(init_minfo_learner);
                            sleep(4);
                            appcon.MultPacge_Tools(photonum_learner,photoBuffer,sizephoto);
                        }

                        Configuration_parameter_set("devicedata:pageflag","1");
                        POSTutils::getInstance()->httpPutPAY(studentcardinfo.card_info.uniformID);
                    }
                    else{
                        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::FINGER_FALURE);//指纹验证失败，请重新刷卡
                    }
                }
                break;

            default:

                break;
            }

            break;
        }
    case GET_GPS_DATA_ACK:                                                //STM32响应NUC972 获取GPS信息数据报文
                printf("getdata06!\n");
                //                p_stm_card->card_ack(data,length);
                break;
            case GET_VOLTAGE_DATA_ACK:                                        //STM32响应NUC972 获取汽车电压数据报文
                printf("getdata07!\n");
                break;
            case SET_SYSET_DATA_ACK:                                              //STM32响应NUC972下发配置下发STM32配置项
                printf("getdata08!\n");
                break;
            case UPDATE_FIRMWARE_ACK:                                       //STM32响应NUC972下发固件更新报文
                printf("getdata8f01!\n");
                break;
            default:
                break;
        }
}

int CommunicateStm32::Parser_Comdata(char *buf, int len,int *len2)
{
    int len3 = 0;
    int len4=0;//报文临时判断长度,用于截取判断报文尾
    int  a_flag = 0;
    if (len>6)
    {  //整体判断长度需要大于6，不然没有意义
        for( int i = 0 ; i <len ; i++ )
        {
            if((buf[i] == 0xAA )&&(buf[i+1] == 0xBB ))
            {
                a_flag = 1;
                len4 = ((wis_u16)buf[i+2]<<8) | buf[i+3];
                if(len4 +i > len)
                {
                    CommFifo::getInstance()->SeekPoint(i);
                    return 0;
                }
                if(buf[i+len4 -2] == 0x99 && buf[i+len4 -1] == 0xFF)
                {
                    //                    TRACE_INFO("STM32->N972  Here1");
                    if( Get_CheckRcv(&buf[i],len4))
                    {
                        *len2= i;
                        len3=len4;
                        if( ( RfcardReadFlag==1)||(RfcardlogoutFlag==1))//1打开  0关闭
                        {
                            memcpy(this->stm32buf,&buf[i+4],len3-5);
                            this->stm32len=len3-5;
//                            Tracer::getInstance()->printHex(1,"Comdata",this->stm32buf,this->stm32len);                     //"\nFlag IN!\n");
                            TaskSchedulerThread::AsyncTask* task = new TaskSchedulerThread::AsyncTask(std::bind( &CommunicateStm32::parseUpdata, this, this->stm32buf,this->stm32len));
                            this->stm32thread->tasks().push(task);
                            Utils::LogSaveFlag("stm32data.txt","task push:");
                        }
                        CommFifo::getInstance()->SeekPoint(i+len4);
                        return  len3;
                    }
                    else
                    {
                        //                     TRACE_INFO("STM32->N972  Error2");
                        CommFifo::getInstance()->SeekPoint(i+len4);
                        return 0;
                    }
                }
                else
                {
                    //                    TRACE_INFO("STM32->N972  Error3");
                    CommFifo::getInstance()->SeekPoint(i+2);
                }
            }
        }
        if(a_flag == 0 )
        {
            //            TRACE_INFO("STM32->N972  Error4");
            CommFifo::getInstance()->SeekPoint(len);
        }
    }
    return 0;
}

void  *CommunicateStm32::ThreadSTM32_Recv(void *param)
{
    while(1)
    {
        sint32 ret1;
        char buf[1024];
        unsigned long ct =0;
        memset(buf,0,sizeof(buf));
        if (pCom!=NULL)
        {
            ret1=pCom->readData(&buf[0],1024,100);
            if(ret1!=-1)
            {
                CommFifo::getInstance()->WriteFifo(buf,ret1);
            }
        }
        usleep(10000);
    }
    return NULL;
}
void * CommunicateStm32::ThreadSTMRead32_Recv(void *param)
{
    CommunicateStm32  *commStm32=( CommunicateStm32 *)param;
    while(1)
    {
        char buf[1024];
        int len,l;
        int pos = 0;
        int len3=0;
        memset(buf,0,sizeof(buf));
        len = CommFifo::getInstance()->ReadFifo(buf,1024);
        if(len > 0)
        {
            pos = pos + len;
            l =commStm32->Parser_Comdata(buf,len,&len3);  //找一包数据
        }
        usleep(1000);
    }
    return NULL;
}

void  CommunicateStm32:: setloginInterface( WIS_UI::LoginInterface * loginInterface){
    m_loginInterface=loginInterface;
}

void CommunicateStm32::Init_Data()
{
    pthread_create(&mSTM32Communicate_threadHandle,0,&CommunicateStm32:: ThreadSTM32_Recv,m_loginInterface);
    pthread_create(&mSTM32Communicate_ReadHandle,0,&CommunicateStm32:: ThreadSTMRead32_Recv,this);

    pCom = new ComPort();
    wis_s32 ret;
    pCom->setAttribute(COM_ATTR_BAUDRATE, 115200);
    ret=pCom->open(COM_PORT, IO_MODE_RDWR_ONLY);
    if (pCom!=NULL)
    {
        const char* hello="stm32 Init OK!";
        ret=pCom->writeData(hello, strlen(hello));
    }
}


void CommunicateStm32 :: sendDowndata(int commid)
{
    int len;
    message_info.message_head = 0xaabb;
    message_info.endcode = 0x99ff;
    switch (commid) {
    case HEART_DATA:                                                               //NUC972 心跳维持链接STM32报文
        printf("senddata00!\n");
        p_stm_heart_data->stm32_heart_data(&message_info);
        break;
    case CONNECT:                                                               //NUC972链接STM32终端报文
        printf("senddata01!\n");
        break;
    case SET_STM32_DATA:                                                              //NUC972焼写STM32基本数据报文
        printf("senddata02!\n");
        break;
    case GET_CAR_DATA:                                                              //NUC972获取汽车数据信息报文
        printf("senddata03!\n");
        break;
    case GET_ALARM_DATA:                                                              //NUC972获取报警信息数据报文
        printf("senddata04!\n");
        break;
    case GET_RFCARD_DATA:                                                              //NUC972获取射频卡信息数据报文
        printf("senddata05!\n");
        p_stm_card->card(&message_info);
        break;
    case GET_GPS_DATA:                                                              //NUC972获取GPS信息数据报文
        printf("senddata06!\n");
        break;
    case GET_VOLTAGE_DATA:                                                     //NUC972获取汽车电压数据报文
        printf("senddata07!\n");
        break;
    case SET_SYSET_DATA:                                                           //NUC972下发配置下发STM32配置项
        printf("senddata08!\n");
        break;
    case UPDATE_FIRMWARE:                                                             //NUC972下发STM32固件更新报文
        printf("senddata0f01!\n");
        break;
    default:
        break;
    }
}

void CommunicateStm32 :: copage_set()
{
    char para_buff[1025] = {0};

    memcpy(para_buff ,(char*)coachcardinfo.card_info.cardno,sizeof(coachcardinfo.card_info.cardno));
    Configuration_pageflag_set("pagepara:cocardno",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    string coachname = Utils::code2string(coachcardinfo.card_info.name,sizeof(coachcardinfo.card_info.name));
    memcpy(para_buff ,(char*)coachname.c_str(),coachname.length());
    Configuration_pageflag_set("pagepara:coname",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    memcpy(para_buff ,(char*)coachcardinfo.card_info.uniformID,sizeof(coachcardinfo.card_info.uniformID));
    Configuration_pageflag_set("pagepara:couniformID",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    memcpy(para_buff ,(char*)coachcardinfo.card_info.idcard,sizeof(coachcardinfo.card_info.idcard));
    Configuration_pageflag_set("pagepara:coidcard",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",coachcardinfo.card_info.traintype);
    Configuration_pageflag_set("pagepara:cotraintype",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    string coachfinger = Utils::code2string((char *)coachcardinfo.card_info.fingerprint,sizeof(coachcardinfo.card_info.fingerprint));
    memcpy(para_buff ,(char*)coachfinger.c_str(),coachfinger.length());
    Configuration_pageflag_set("pagepara:cofingerprint",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",coachcardinfo.card_info.lesson2value);
    Configuration_pageflag_set("pagepara:colesson2value",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",coachcardinfo.card_info.lesson3value);
    Configuration_pageflag_set("pagepara:colesson3value",para_buff);
    memset(para_buff,0,sizeof(para_buff));
}

void CommunicateStm32 :: stupage_set()
{
    char para_buff[1025] = {0};

    memcpy(para_buff ,(char*)studentcardinfo.card_info.cardno,sizeof(studentcardinfo.card_info.cardno));
    Configuration_pageflag_set("pagepara:stucardno",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    string stuname = Utils::code2string(studentcardinfo.card_info.name,sizeof(studentcardinfo.card_info.name));
    memcpy(para_buff ,(char*)stuname.c_str(),stuname.length());
    Configuration_pageflag_set("pagepara:stuname",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    memcpy(para_buff ,(char*)studentcardinfo.card_info.uniformID,sizeof(studentcardinfo.card_info.uniformID));
    Configuration_pageflag_set("pagepara:stuuniformID",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    memcpy(para_buff ,(char*)studentcardinfo.card_info.idcard,sizeof(studentcardinfo.card_info.idcard));
    Configuration_pageflag_set("pagepara:stuidcard",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",studentcardinfo.card_info.traintype);
    Configuration_pageflag_set("pagepara:stutraintype",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    string stufinger = Utils::code2string((char*)studentcardinfo.card_info.fingerprint,sizeof(studentcardinfo.card_info.fingerprint));
    memcpy(para_buff ,(char*)stufinger.c_str(),stufinger.length());
    Configuration_pageflag_set("pagepara:stufingerprint",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",studentcardinfo.card_info.lesson2value);
    Configuration_pageflag_set("pagepara:stulesson2value",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",studentcardinfo.card_info.lesson3value);
    Configuration_pageflag_set("pagepara:stulesson3value",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",TrainLessonId);
    Configuration_pageflag_set("pagepara:stuTrainLessonId",para_buff);
    memset(para_buff,0,sizeof(para_buff));

    sprintf(para_buff,"%d",subjectcode);
    Configuration_pageflag_set("pagepara:lessonID",para_buff);   //课程编码保存
    memset(para_buff,0,sizeof(para_buff));
}
