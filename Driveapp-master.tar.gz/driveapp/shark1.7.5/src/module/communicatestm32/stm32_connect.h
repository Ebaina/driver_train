﻿#ifndef STM32_CONNECT_H
#define STM32_CONNECT_H
#include "stdtype.h"


#define    CONNECT    0x0001     //NUC972链接STM32终端报文
#define    CONNECT_ACK    0x8001     //STM32响应NUC972链接终端报文
/***************
  * 链接信息设置
***************/
typedef struct  stm32_connect_info
{
    wis_u16  TYPE;  //产品型号
    wis_u16  VERSION;      //终端上报固件版本号
    wis_u32  HARDWARE;  //硬件版本
    wis_u32  TERMINALID;     //终端编号
}__attribute__((packed, aligned(1))) stm32_connect_info;

class stm32_connect
{
public:
    stm32_connect();
    ~stm32_connect();

    int stm_connect_ack(char *data, int len);
    int stm_connect(char *data, int len);
};

#endif // STM32_CONNECT_H
