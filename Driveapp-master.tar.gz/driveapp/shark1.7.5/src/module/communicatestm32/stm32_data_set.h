﻿#ifndef STM32_DATA_SET_H
#define STM32_DATA_SET_H
#include "stdtype.h"



#define    SET_STM32_DATA    0x0002     //NUC972焼写STM32基本数据报文
#define    SET_STM32_DATA_ACK    0x8002     //STM32响应NUC972报文
/***************
  * stm32信息设置
***************/
typedef struct  stm32_data_set_info
{
    wis_u16  TYPE;  //产品型号
    wis_u16  VERSION;      //终端上报固件版本号
    wis_u32  HARDWARE;  //硬件版本
    wis_u32  TERMINALID;     //终端编号
}__attribute__((packed, aligned(1))) stm32_data_set_info;



typedef struct  stm32_result_set_info
{
    wis_u8  TYPE_result;  //产品型号
    wis_u8  VERSION_result;      //终端上报固件版本号
    wis_u8  HARDWARE_result;  //硬件版本
    wis_u8  TERMINALID_result;     //终端编号
}__attribute__((packed, aligned(1))) stm32_result_set_info;


class stm32_data_set
{
public:
    stm32_data_set();
    ~stm32_data_set();

    int stm_data_set_ack(char *data, int len);
    int stm_data_set(void *param);
};

#endif // STM32_DATA_SET_H
