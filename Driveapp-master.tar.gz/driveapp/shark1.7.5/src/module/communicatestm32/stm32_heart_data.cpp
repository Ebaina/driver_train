﻿#include "stm32_heart_data.h"
#include "communicatestm32.h"
#include "public.h"
STM32_HEART_DATA::STM32_HEART_DATA()
{

}
STM32_HEART_DATA::~STM32_HEART_DATA()
{

}

int STM32_HEART_DATA::stm32_heart_data_ack(char * data ,int len)
{

}

int STM32_HEART_DATA::stm32_heart_data(void *param)
{
    stm32_message_info *p  =  (stm32_message_info*)param;
    int len = 0;
    len += 9;
    char * tempdata;
    stm32_heart_info  heart_info;
    p->messageID = HEART_DATA;
    heart_info.car_type = 0x00;          //0x01    0x00 控制单片机停止发送CAR数据      0x01控制单片机发送CAR数据
    heart_info.alarm_type = 0x00;     //0x01   0x00 控制单片机停止发送报警数据     0x01控制单片机发送CAR数据
    heart_info.rfcard_type =  0x00;    //0x01   0x00 控制单片机停止发送射频卡数据   0x01控制单片机发送射频卡数据
    heart_info.voltage_type = 0x00;   //0x01   0x00 控制单片机停止发送电压数据      0x01控制单片机发送电压数据
    memcpy(p->message_content,(char*)&heart_info,sizeof(heart_info));
    p->messagelength = len+sizeof(heart_info);
    memcpy(tempdata ,(char*)p,p->messagelength-3);
    p->verfycode = CRC8_Table(tempdata,p->messagelength-3);
}
