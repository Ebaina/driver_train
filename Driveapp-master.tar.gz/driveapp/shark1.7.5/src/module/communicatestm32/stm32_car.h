﻿#ifndef STM32_CAR_H
#define STM32_CAR_H
#include "stdtype.h"


#define    GET_CAR_DATA    0x0003     //NUC972获取汽车数据信息报文
#define    GET_CAR_DATA_ACK    0x8003     //STM32响应NUC972 报文
/***************
  * 汽车信息
***************/
typedef struct  stm32_car_info
{
    wis_u8  CAR_SPEED;  //汽车速度
    wis_u8  CAR_RPM;      //汽车转速
    wis_u8  CAR_MILE;  //汽车里程
    wis_u8  CAR_OIL;     //汽车油耗
}__attribute__((packed, aligned(1))) stm32_car_info;

class stm32_car
{
public:
    stm32_car();
    ~ stm32_car();

    int car_ack(char *data, int len);
    int car(char *data, int len);
};

#endif // STM32_CAR_H
