﻿#ifndef COMMUNICATESTM32_H
#define COMMUNICATESTM32_H
#include "Thread.h"
#include "uart.h"
#include "Mutex.h"
#include "ui_interface.h"
#include "wis_fifo.h"
//和STM32通信接口

#define    GET_GPS_DATA    0x0006     //NUC972获取GPS信息数据报文
#define    GET_GPS_DATA_ACK    0x8006     //STM32响应NUC972 报文
#define    GET_VOLTAGE_DATA    0x0007     //NUC972获取汽车电压数据报文
#define    GET_VOLTAGE_DATA_ACK    0x8007     //STM32响应NUC972 报文
#define    SET_SYSET_DATA    0x0008     //SNUC972下发配置下发STM32配置项
#define    SET_SYSET_DATA_ACK    0x8008     //STM32响应NUC972 报文
#define    UPDATE_FIRMWARE    0x0F01     //NUC972下发STM32固件更新报文
#define    UPDATE_FIRMWARE_ACK    0x8F01     //STM32响应NUC972下发固件更新报文

/***************
  * 报文信息
***************/
typedef struct  stm32_message_info
{
    wis_u16 message_head;                 //帧头  0xAABB
    wis_u32 messagelength;               //报文总长度
    wis_u16 messageID;                      //消息类型代码
    wis_u8   message_content[512];   //消息报文
    wis_u8  verfycode;                      //校验码
    wis_u16 endcode ;                    //结束符
}__attribute__((packed, aligned(1))) stm32_message_info;


class TaskSchedulerThread;
class CommunicateStm32
{
private:
     char *photoBuffer;
     int  photoLen;
     char  stm32buf[800];
     int   stm32len;
private :
    WIS_UI::LoginInterface * m_loginInterface;
    public:
    CommunicateStm32();
    ~CommunicateStm32();
    void Init_Data();
    void  setloginInterface( WIS_UI::LoginInterface * loginInterface);
    void sendDowndata(int commid);
  public :
    void parseUpdata(char * data ,int length );
    void copage_set();
    void stupage_set();
    int Parser_Comdata(char *buf, int len,int *len2 );
   private :
    TaskSchedulerThread  *stm32thread ;
    static void  *ThreadSTM32_Recv(void *param);
    static void *ThreadSTMRead32_Recv(void *param);
};

#endif // COMMUNICATESTM32_H
