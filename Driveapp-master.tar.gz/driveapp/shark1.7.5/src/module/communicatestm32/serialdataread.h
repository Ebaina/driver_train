#ifndef SERIALDATAREAD_H
#define SERIALDATAREAD_H

#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <sys/time.h>
#include  <string.h>
#include  <sys/types.h>
#include  <sys/socket.h>
#include  <sys/ioctl.h>
#include  <sys/ipc.h>
#include  <sys/msg.h>
#include  <netinet/in.h>
#include  <arpa/inet.h>
#include  <pthread.h>
#include  <netdb.h>
#include "clog.h"
#include "wis_fifo.h"
#include "ComPort.h"
#define SERIAL_BUFFER_SEND_SIZE 1024*16
#define SERIAL_BUFFER_RECV_SIZE 1024*16

#define MAX_SERILA_BUFFER  1024

typedef void (*Recv_callback)(char *buf,int len,void *param);

class SerialDataRead
{
public:
    SerialDataRead();
    ~SerialDataRead();

    static SerialDataRead* getInstance()
    {
        static SerialDataRead instance;
        return &instance;
    }
private:
    Recv_callback p_fun;
    void *m_param;
    pthread_t p_rcvThread;
    pthread_t p_watchThread;
    ComPort *  comportStm32;
    static void *nTcp_RcvThread(void *param);
    static void *nTcp_WatchMan(void *param);


public:

    int serialSend(char *buff,int l_buff);

    int serialRecive(char* buff,int l_buff,long timeout);


};

#endif // SERIALDATAREAD_H

