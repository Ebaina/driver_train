#include "gpsdataoperate.h"
#include <string.h>

GpsDataOperate::GpsDataOperate()
{
      readindex=0;
      writeindex=0;
      rmcfr1.valid=false;
}

minmea_sentence_rmc  *GpsDataOperate::getData(void)
{
    minmea_sentence_rmc   * minirmc=NULL;
    if(readindex<writeindex)
    {
        minirmc =&rmcfr[readindex%100];
        readindex++;
    }
    return minirmc ;
}

minmea_sentence_rmc *GpsDataOperate::getData2()
{
      return &rmcfr1 ;
}
  void GpsDataOperate:: setData(const minmea_sentence_rmc &data )
{
       lock.lock();
       memcpy(&rmcfr[writeindex%100],&data,sizeof(data));
       memcpy(&rmcfr1,&data,sizeof(data));
       writeindex++;
       lock.unLock();
}
