#ifndef GPSDATAOPERATE_H
#define GPSDATAOPERATE_H
#include "minmea.h"
#include "Mutex.h"
class GpsDataOperate
{
public:
    GpsDataOperate();
    static GpsDataOperate* getInstance()
    {
        static GpsDataOperate instance;
        return &instance;
    }
public:
       minmea_sentence_rmc   *getData(void);
        minmea_sentence_rmc   *getData2(void);
       void  setData(const minmea_sentence_rmc &data );
private :
    minmea_sentence_rmc rmcfr[100];
    minmea_sentence_rmc rmcfr1;
    int readindex;
    int writeindex;
    MutexLock lock;
};

#endif // GPSDATAOPERATE_H
