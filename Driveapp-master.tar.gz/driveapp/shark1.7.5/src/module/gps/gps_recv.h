﻿#ifndef GPS_RECV_H
#define GPS_RECV_H
#include "minmea.h"
#include <string>
using  std::string;
/***************
  * GPS信息数据
***************/

extern   int   gps_get(char sentence[512]);

extern bool parse_sentence(string m_strRecv);
class GPS_recv
{
public:
    static GPS_recv * getInstance()
    {
        static GPS_recv instance;
        return &instance;
    }
    GPS_recv();
    ~GPS_recv();

    void init_gps(void);
};

#endif // GPS_RECV_H
