﻿#include "gps_recv.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "Thread.h"
#include "uart.h"
#include "Mutex.h"
#include "public.h"
#include "ComPort.h"
#include "app_globl.h"
#include <string>
#include "gpsdataoperate.h"

#define INDENT_SPACES "  "
using  std::string;
pthread_t  mGPS_threadHandle;
#define COM_PORT10	"/dev/ttyS10"
ComPort* pCom10=NULL;
unsigned long current_ms =0;
unsigned int gps_time_out = 50;
int pos_gps = 0;
GPS_recv::GPS_recv()
{
}
GPS_recv::~GPS_recv()
{

}

bool parse_sentence(string m_strRecv )
{
    int i,j;
    char  strNEMA[80];
    char * NEMAdata;
    //先判断是否接收到数据
    if (m_strRecv.empty())
        return FALSE;
    //若字符串不是以'$'开头的,必须删掉这部分不完整的
    if (m_strRecv[0] != '$')
    {
        i = m_strRecv.find('\n', 0);
        if (i == -1)
            return FALSE;                                       //尾部未接收完整,必须等接收完后才能删除
        m_strRecv.erase(0, i+1);                               //尾部已接收完整(尾部为/r/n结束),删除不完整的部分
    }
    //截取完整的NMEA-0183输出语句(m_strRecv中可能有多条语句,每条间以/r/n分隔)
    for (;;)
    {
        i = m_strRecv.find('\n', 0);
        if (i == -1)
            break;                                              //所有的完整输出语句都已经处理完毕,退出循环
        //截取完整的NMEA-0183输出语句
        NEMAdata   =(char *) m_strRecv.substr(0,i-1).data();
        //        printf("Enterdata:[%s]\n",NEMAdata);
        m_strRecv.erase(0, i+1);
        strcpy(strNEMA ,NEMAdata);
        gps_get(NEMAdata);
    }
}


void *ThreadGPS_get(void *param)
{
    while(1)
    {
        sint32 ret1;
        usleep(400000);
        char buf[512];
        int i = 0;
        int j = 0;
        current_ms = get_tick_count() + gps_time_out;
        memset(buf,0,sizeof(buf));
        string gpsbuff;
        if (pCom10!=NULL)
        {
            do
            {
                ret1=pCom10->readData(&buf[pos_gps],512-pos_gps,100);
                if(ret1 > 0)
                {
                    pos_gps += ret1;
                }
            }while(get_tick_count() < current_ms);
            gpsbuff=buf;
            if(pos_gps > 0)
                parse_sentence(gpsbuff);
            pos_gps = 0;
            current_ms = 0;
            ret1 = 0;
        }
    }
    return NULL;
}


int gps_get(char  * sentence)
{
    switch (minmea_sentence_id(sentence, false))
    {
    case MINMEA_SENTENCE_RMC: {
            minmea_sentence_rmc  rmc_frame;
//        printf("sentence:[%s]\n", sentence);
        if (minmea_parse_rmc(&rmc_frame, sentence)) {
            //            printf(INDENT_SPACES "$xxRMC: raw coordinates and speed: (%d/%d,%d/%d) %d/%d\n",
            //                   rmc1_frame.latitude.value, rmc1_frame.latitude.scale,
            //                   rmc1_frame.longitude.value, rmc1_frame.longitude.scale,
            //                   rmc1_frame.speed.value, rmc1_frame.speed.scale);
            //            printf(INDENT_SPACES "$xxRMC fixed-point coordinates and speed scaled to three decimal places: (%d,%d) %d\n",
            //                   minmea_rescale(&rmc1_frame.latitude, 1000),
            //                   minmea_rescale(&rmc1_frame.longitude, 1000),
            //                   minmea_rescale(&rmc1_frame.speed, 1000));
            //            printf(INDENT_SPACES "$xxRMC floating point degree coordinates and speed: (%f,%f) %f\n",
            //                   minmea_tocoord(&rmc1_frame.latitude),
            //                   minmea_tocoord(&rmc1_frame.longitude),
            //                   minmea_tofloat(&rmc1_frame.speed));
//            printf("latitude:%d\n", ( rmc_frame.latitude.value));
//            printf("longitude:%d\n", ( rmc_frame.longitude.value));
//            positionReport_up.carspeed=rmc1_frame.speed.value/1000;
            positionReport_up.carspeed=(rmc_frame.speed.value/1000)*1.86;
            positionReport_up.satelitespeed=(rmc_frame.speed.value/1000)*1.86;
            positionReport_up.direction=rmc_frame.course.value/100;
            GpsDataOperate::getInstance()->setData(rmc_frame);
//            printf("speed:%d\n", ( rmc1_frame.speed.value/1000));

        }
        else {
            printf(INDENT_SPACES "$xxRMC sentence is not parsed\n");
        }
    } break;

    case MINMEA_SENTENCE_GGA: {                                             //GPS数据的经纬度，卫星数
        //        struct minmea_sentence_gga frame;
        minmea_sentence_gga gga_frame;
//        printf("flagdata:[%s]\n", sentence);
        if (minmea_parse_gga(&gga_frame, sentence)) {
//            printf(INDENT_SPACES "$xxGGA: fix quality: %d\n", frame.fix_quality);
//            positionReport_up.latitude=(gga_frame.latitude.value) ;
//            positionReport_up.longitude=(gga_frame.longitude.value) ;
//            printf("latitude1:%d\n", (positionReport_up.latitude));
//            printf("longitude1:%d\n", ( positionReport_up.longitude));
//            printf("value1:%d\n", (gga_frame.latitude.value));
//            printf("value2:%d\n", ( gga_frame.longitude.value));

//            positionReport_up.timestamps=
//                        printf("timestamps:%d\n",gga_frame.time.hours);
//            printf("satellites_tracked:%d\n",gga_frame.satellites_tracked);
        }
        else {
            printf(INDENT_SPACES "$xxGGA sentence is not parsed\n");
        }
    } break;

        //    case MINMEA_SENTENCE_GST: {
        //        struct minmea_sentence_gst frame;
        //        if (minmea_parse_gst(&frame, sentence)) {
        //            printf(INDENT_SPACES "$xxGST: raw latitude,longitude and altitude error deviation: (%d/%d,%d/%d,%d/%d)\n",
        //                   frame.latitude_error_deviation.value, frame.latitude_error_deviation.scale,
        //                   frame.longitude_error_deviation.value, frame.longitude_error_deviation.scale,
        //                   frame.altitude_error_deviation.value, frame.altitude_error_deviation.scale);
        //            printf(INDENT_SPACES "$xxGST fixed point latitude,longitude and altitude error deviation"
        //                                 " scaled to one decimal place: (%d,%d,%d)\n",
        //                   minmea_rescale(&frame.latitude_error_deviation, 10),
        //                   minmea_rescale(&frame.longitude_error_deviation, 10),
        //                   minmea_rescale(&frame.altitude_error_deviation, 10));
        //            printf(INDENT_SPACES "$xxGST floating point degree latitude, longitude and altitude error deviation: (%f,%f,%f)",
        //                   minmea_tofloat(&frame.latitude_error_deviation),
        //                   minmea_tofloat(&frame.longitude_error_deviation),
        //                   minmea_tofloat(&frame.altitude_error_deviation));
        //        }
        //        else {
        //            printf(INDENT_SPACES "$xxGST sentence is not parsed\n");
        //        }
        //    } break;

        //    case MINMEA_SENTENCE_GSV: {
        //        struct minmea_sentence_gsv frame;
        //        if (minmea_parse_gsv(&frame, sentence)) {
        //            printf(INDENT_SPACES "$xxGSV: message %d of %d\n", frame.msg_nr, frame.total_msgs);
        //            printf(INDENT_SPACES "$xxGSV: sattelites in view: %d\n", frame.total_sats);
        //            for (int i = 0; i < 4; i++)
        //                printf(INDENT_SPACES "$xxGSV: sat nr %d, elevation: %d, azimuth: %d, snr: %d dbm\n",
        //                       frame.sats[i].nr,
        //                       frame.sats[i].elevation,
        //                       frame.sats[i].azimuth,
        //                       frame.sats[i].snr);
        //        }
        //        else {
        //            printf(INDENT_SPACES "$xxGSV sentence is not parsed\n");
        //        }
        //    } break;

            case MINMEA_SENTENCE_VTG: {
                struct minmea_sentence_vtg frame;
                if (minmea_parse_vtg(&frame, sentence)) {
//                    printf(INDENT_SPACES "$xxVTG: true track degrees = %f\n",
//                           minmea_tofloat(&frame.true_track_degrees));
//                    printf(INDENT_SPACES "        magnetic track degrees = %f\n",
//                           minmea_tofloat(&frame.magnetic_track_degrees));
//                    printf(INDENT_SPACES "        speed knots = %f\n",
//                           minmea_tofloat(&frame.speed_knots));
//                    printf(INDENT_SPACES "        speed kph = %f\n",
//                           minmea_tofloat(&frame.speed_kph));

                }
                else {
                    printf(INDENT_SPACES "$xxVTG sentence is not parsed\n");
                }
            } break;

        //    case MINMEA_INVALID: {
        //        printf(INDENT_SPACES "$xxxxx sentence is not valid\n");
        //    } break;

    default: {
        //        printf(INDENT_SPACES "$xxxxx sentence is not parsed\n");
    } break;
    }

}

void  GPS_recv::init_gps(void)
{
    pthread_create(&mGPS_threadHandle,0,ThreadGPS_get,NULL);
    pCom10 = new ComPort();
    wis_s32 ret;
    pCom10->setAttribute(COM_ATTR_BAUDRATE, 9600);
    ret=pCom10->open(COM_PORT10, IO_MODE_RDWR_ONLY);
    if (pCom10!=NULL)
    {
//        const char* GPS_SET="$CCSIR,3,0*4B\r\n";
//        ret=pCom10->writeData(GPS_SET, strlen(GPS_SET),100);
//        if(ret > 0)
//            TRACE_INFO("GPS模块输入成功\n");
    }
}

