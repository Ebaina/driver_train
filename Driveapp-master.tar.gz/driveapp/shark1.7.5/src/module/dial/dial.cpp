﻿#include "dial.h"
#include "app_globl.h"
static FILE *dstream = NULL;
static int m_relink =0;
static int mCnt = 0;
static sem_t relinkSem;
//pthread_mutex_t mRelinkSem;
ttyusb dial_port_manage;

//驾考板子电源PF14  ae  174
//充电桩           ad  173

void dialup(char *arg)
{
    char dbuf[512];
    memset(dbuf,0,sizeof(dbuf));
    sprintf(dbuf,"/app/4g/dial.sh %s",arg);
    if(dstream != NULL)
    {
        pclose(dstream);
    }
    dstream = popen(dbuf,"r");
}

void dialoff()
{
    if(dstream != NULL)
    {
        pclose(dstream);
    }
    dstream = NULL;
}

int ifconfig_check()
{
    FILE   *stream;
    char   buf[1024];
    char   *find;
    memset(buf,0,sizeof(buf));
    stream = popen("ifconfig ppp0", "r");
    fread( buf, sizeof(char), sizeof(buf), stream);
    pclose(stream);
    find = strstr(buf,DIAL_OK);
    if(find != NULL) return 1;
    return 0;
}

int ping_check()
{
    FILE   *stream;
    char   buf[1024];
    char   *find;

//    memset(buf,0,sizeof(buf));
//    stream = popen(PING_ADD1, "r");
//    fread( buf, sizeof(char), sizeof(buf), stream);
//    find = strstr(buf,PING_OK);
//    printf("%s \n",buf);
//    pclose(stream);
//    if(find != NULL)
//        return 1;

//    memset(buf,0,sizeof(buf));
//    stream = popen(PING_ADD2, "r");
//    fread( buf, sizeof(char), sizeof(buf), stream);
//    find = strstr(buf,PING_OK);
//    pclose(stream);
//    if(find != NULL)
//        return 1;

    memset(buf,0,sizeof(buf));
    stream = popen(PING_ADD3, "r");
    fread( buf, sizeof(char), sizeof(buf), stream);
    find = strstr(buf,PING_OK);
    pclose(stream);
    if(find != NULL)
    {
       // printf("ping check, network is ok!\n");
        return 1;
    }
    else
    {
        printf("ping check, network is unreachable!\n");
        return 0;
    }
}


void  *dial_manage(void *args)
{
#if 1
    char formatbuf[128];
    netStatus.net_mode = NET_MODE_NONE;
    netStatus.net_state = NET_STATE_OFFLINE;
    netStatus.net_signal = SIGNAL_L0;

    sem_init(&relinkSem,0,0);
    sem_post(&relinkSem);

    int i = 0;
    int ret =0;
    while(1)
    {
        if(0 == sem_trywait(&relinkSem))
        {
            m_relink = 0;
//            dial_port_manage.ini_ttyusb(mobile_param.status_port);    //ttyusb port 2;
            dialoff();
            netStatus.net_state = NET_STATE_CONNECTING;
            memset(formatbuf,0,sizeof(formatbuf));

            sprintf(formatbuf,"%d %s %s %s %d ",mobile_param.nettype,mobile_param.dial_num,mobile_param.passwd,mobile_param.apn,mobile_param.dial_port);

            TRACE_INFO("exe shell = %s\n", formatbuf);
            dialup(formatbuf);
            netStatus.net_state = NET_STATE_CONNECTING;
            TRACE_INFO("dialup=============================================\n");
            sleep(5);
            i = 10;
            TRACE_INFO("do ping check=============================================\n");
            do
            {
                ret = ping_check();
                if(ret)
                {
                    m_relink = 0;
                    netStatus.net_state = NET_STATE_ONLINE;                    
                    break;
                }
                sleep(2);
            }while(i-- <1);
        }
        mCnt++;
        ret =0;

        if(mCnt == 5)
        {
            ret =  ping_check();
            if(ret)
            {
                m_relink = 0;
                netStatus.net_state = NET_STATE_ONLINE;
//                TRACE_INFO("ping  OK!\n");
            }
            else
            {
                m_relink++;
                if(m_relink > 2)
                {
                    dialoff();
                    netStatus.net_state = NET_STATE_OFFLINE;
//                    dial_port_manage.deinit_ttyusb();
                    system("killall pppd");
                    system("killall 3gpd-wcdma");
                    system("killall chat");
                    sleep(2);
                    m_relink = 0;
                   // power_4g_off();
                    sleep(2);
                    //power_4g_on();
                    sleep(5);
                    sem_post(&relinkSem);
                }
            }
            mCnt =0;
        }
        sleep(1);
    }
    return 0;
#endif
}

int get_4g_signal_quality()
{
    int ret=-1;
    if(netStatus.net_state == NET_STATE_ONLINE)
    {
        dial_port_manage.ini_ttyusb(mobile_param.status_port);
        ret = dial_port_manage.get_signal(100);
        dial_port_manage.deinit_ttyusb();
//        TRACE_INFO("real time signal level============================%d\n",ret);
        if(ret>0 && ret<32)
            return ret;
        else
            return -1;
    }
    else
        return -1;
}
