﻿#ifndef DIAL_H
#define DIAL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>

#include "power_4g.h"
#include "ttyusb.h"
#include "iniparser.h"

#define DIAL_ERROR  "error fetching"
#define DIAL_OK     "Link encap:Point-to-Point Protocol"
#define PING_OK     "64 bytes from"
#define PING_ADD1    "ping www.baidu.com -c 2"
#define PING_ADD2	 "ping www.163.com -c 2"
#define PING_ADD3    "ping 114.114.114.114 -c 2"

#define APN_NAME_LENGTH 20
#define MOBILE_USER_LENGTH 20
#define MOBILE_PASSWD_LENGTH 20
#define MOBILE_DIAL_LENGTH  10

#define NODE_PATH_NET     "/tmp/net"
#define NET_STATE_ONLINE     0       //4g online
#define NET_STATE_OFFLINE    1       //4g offline
#define NET_STATE_CONNECTING 2       //4g connecting

#define NODE_PATH_MODE    "/tmp/mode"
#define NET_MODE_NONE 0

#define NET_MODE_GSM 0
#define NET_MODE_UTRNA 2
#define NET_MODE_GSMEGPRS 3
#define NET_MODE_HSDPA 4
#define NET_MODE_HSUPA 5
#define NET_MODE_HSUDPA 6
#define NET_MODE_E_UTRAN 7

#define NET_MODE_2G  1     //work at 2g net
#define NET_MODE_3G  2     //work at 3g net
#define NET_MODE_4G  3     //work at 4g net

#define NODE_PATH_SIGNAL  "/tmp/signal"
#define SIGNAL_L0  0
#define SIGNAL_L1  1
#define SIGNAL_L2  2
#define SIGNAL_L3  3
#define SIGNAL_L4  4
#define SIGNAL_L5  5

typedef struct st4gNetStatus
{
    unsigned char net_mode;
    unsigned char net_state ;
    unsigned char net_signal;
}st4gNetStatus;



typedef struct stmobile_net_setting{
    bool is_enable;
    int  nettype;//0移动 1联通 2电信
    char *apn;
    char *dial_num;
    char *user_name;
    char *passwd;
    int  dial_port;//0-6
    int  status_port;//0-6
}stmobile_net_setting;

void dialup(char* arg);

void dialoff();

int ifconfig_check();

int ping_check();

void  *dial_manage(void *args);

int get_4g_signal_quality();
extern stmobile_net_setting mobile_param;


#endif // DIAL_H

