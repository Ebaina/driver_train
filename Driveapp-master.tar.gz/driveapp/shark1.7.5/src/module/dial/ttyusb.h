#ifndef TTYUSB_H
#define TTYUSB_H
#include "uart.h"
#include "Tracer.h"

class ttyusb
{
public:
    ttyusb();
    ~ttyusb();

    bool ini_ttyusb(int port);

    void deinit_ttyusb();

    int get_signal(unsigned long timeout);

    int get_net_mode(unsigned long timeout);

    unsigned long get_tick_count();

    CUART mUartItem;

    bool isOpen;

    int m_port;
};

#endif // TTYUSB_H

