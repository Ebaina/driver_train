#include "power_4g.h"

int power_4g_off()
{

    //驾考是174
    FILE *stream = NULL;
    char buf_cmd[128];
    char buf[256];

    memset(buf_cmd,0,sizeof(buf_cmd));
    memset(buf,0,sizeof(buf));
    sprintf(buf_cmd,"echo out > /sys/class/gpio/gpio174/direction");
    stream = popen(buf_cmd,"rw");
    pclose(stream);

    memset(buf_cmd,0,sizeof(buf_cmd));
    memset(buf,0,sizeof(buf));
    sprintf(buf_cmd,"echo 0 > /sys/class/gpio/gpio174/value");
    stream = popen(buf_cmd,"rw");
    pclose(stream);

    return 0;
}

int power_4g_on()
{
    FILE *stream = NULL;
    char buf_cmd[128];
    char buf[256];

    memset(buf_cmd,0,sizeof(buf_cmd));
    memset(buf,0,sizeof(buf));
    sprintf(buf_cmd,"echo 1 > /sys/class/gpio/gpio174/value");
    stream = popen(buf_cmd,"rw");
    pclose(stream);

    return 0;
}
