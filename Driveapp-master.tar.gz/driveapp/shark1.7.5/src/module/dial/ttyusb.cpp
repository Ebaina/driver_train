﻿#include "ttyusb.h"
#include <time.h>
#include <stdlib.h>
#include <printf.h>
#include "cstring"

static tagUARTParam ttyUSB =
{ "/dev/ttyUSB", 115200, 8, 'N', 1, FLOW_CONTROL_NONE };

ttyusb::ttyusb()
{
    isOpen = false;
}

ttyusb::~ttyusb()
{
    deinit_ttyusb();
}

bool ttyusb::ini_ttyusb(int port)
{
    String m = "/dev/ttyUSB";
    char m2 = '0'+port;
    if(isOpen) return true;
    m_port = port;
    ttyUSB.dev = m + m2;
    //ttyUSB.dev += port + '0';
   // TRACE_INFO("ini_ttyusb %s \n",ttyUSB.dev.c_str());
    isOpen =false;
    isOpen = mUartItem.open(ttyUSB);

    return isOpen;
}

void ttyusb::deinit_ttyusb()
{
    if(isOpen)
    mUartItem.close();
    isOpen = false;
}

unsigned long ttyusb::get_tick_count()
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC,&ts);

    return(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

int ttyusb::get_signal(unsigned long timeout)
{
    char CSQ[] = "AT+CSQ\r\n";
    char buf[128];
    int len = 0;
    int pos = 0;
    char *p1,*p2;
    unsigned long currentms =0;
    unsigned int count = 100;
    memset(buf,0,sizeof(buf));
    if(!isOpen)
    {
        TRACE_ERR("Not open ttyusb! \n");
        ini_ttyusb(m_port);
        return -1;
    }
    mUartItem.send(CSQ,8,500);
    currentms = get_tick_count() + timeout;
//    printf("signal Get Current time ++++++ = %u",currentms);
    do
    {
         if(pos > 128) break;
         len = mUartItem.recv(&buf[pos],128-pos,200);
         if(len > 0)
         {
             pos += len;
         }
         if(count-- <= 0) break;
    }while(get_tick_count() < currentms);
//    printf("signal Get Current time ------- %u",get_tick_count());
    pos =0;
    p1 = strstr(buf,"+CSQ:");
    if(p1 == NULL)
        return -1;
    p2 = strstr(buf,",");
    if(p2 == NULL )
        return -1;
        p1 = p1 + 5;
    *p2 = '\0';
    return atoi(p1);
}

int ttyusb::get_net_mode(unsigned long timeout)
{
    char CSQ[] = "AT+COPS?\r\n";
    char buf[128];
    int len = 0;
    int pos = 0;
    int count = 100;
    char *p1,*p2;
    unsigned long currentms =0;
    memset(buf,0,sizeof(buf));
    if(!isOpen)
    {
        printf("Not open ttyusb! \n");
        return -1;
    }
    mUartItem.send(CSQ,10,500);
    currentms = get_tick_count() + timeout;
//    printf("Get Current time ++++++ = %u",currentms);
    pos = 100;
    do
    {
         if(pos > 128) break;
         len = mUartItem.recv(&buf[pos],128-pos,200);
         if(len > 0)
         {
             pos += len;
         }
         if(count-- <= 0) break;
    }while(get_tick_count() < currentms);
//    printf("Get Current time ------- %u",get_tick_count());
    pos =0;
    p1 = strstr(buf,"\"");
    if(p1 == NULL) return -1;
    p2 = strstr(p1+1,"\"");
    if(p2 == NULL ) return -1;
    p1 = strstr(p2,",");
    if(p1 == NULL) return -1;
    p1 = p1 + 1;
    return atoi(p1);
}

