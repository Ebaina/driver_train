#ifndef POWER_4G_H
#define POWER_4G_H

#include <stdio.h>
#include <string.h>

#if __cplusplus
extern "C" {
#endif

#define POWER_4G 173

int power_4g_on();
int power_4g_off();

#if __cplusplus
}
#endif

#endif // POWER_4G_H

