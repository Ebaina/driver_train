﻿#ifndef PHOTOSAVE_H
#define PHOTOSAVE_H

#include "string"
#include "cmd.h"
#include "exephotoupload.h"
#include "vector"
using namespace std;
typedef struct Uploadphotoinit_Sql{
int id;
wis_u8 photonum[10]; //0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
wis_u8 learnerorcoachid[16]; //10	学员或教练员编号	BYTE [16]	统一编号
wis_u8 uploadmode; //26	上传模式	BYTE	1：自动请求上传；
wis_u8 camerachannel; //27	摄像头通道号	BYTE	0：自动
wis_u8 photosize; //28	图片尺寸	BYTE	0x01：320×240；
wis_u8 photoeventtype; //29	发起图片的事件类型	BYTE	发起图片的事件类型，定义如下：
wis_u16 packgesize; //30	总包数	WORD
wis_u32 photodatasize; //32	照片数据大小	DWORD
wis_u32 lessonid; //36	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
wis_u8  addgnssdata[38]; //40	附加GNSS数据包	BYTE[38]	照片拍摄时的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
wis_u8  faceidentifyreliability; //78	人脸识别置信度	BYTE	0-100，数值越大置信度越高
std::string photopath;
std::string creattime;
}__attribute__((packed, aligned(1))) Uploadphotoinit_Sql;
class Photosave
{
public:
    Photosave();
    ~Photosave();
    static Photosave* getInstance()
    {
        static Photosave instance;
        return &instance;
    }
public :
    int initDatabase(void);//数据库初始化，判断是否存在数据没有则创建数据库

    int insertMessage( Uploadphotoinit_Up &data,string photopath);//插入数据库数据

    int updateSendStatusById(string id);//更新发送状态

    int updateSendBytime(std::string &time);//根据发送时间更新状态。



    int selectMatchCounts(string starttime,string stoptime );//根据开始时间、结束时间和发送状态查询记录条数


    int selectbyTimeWithLimit(string starttime,string stoptime ,int index,int count,vector<Uploadphotoinit_Sql*> &data );//根据开始时间、结束时间和发送状态查询指定记录条数

    int selectbyTimeNoLimit(string starttime,string stoptime  ,vector<Uploadphotoinit_Sql*> &data );//根据开始时间、结束时间和发送状态查询指定记录条数



    int selectMessageByStatus(string id);//
   Uploadphotoinit_Sql  *  selectMessageByTime(std::string &time);//查询数据
    bool   selectAllMessage(vector<Uploadphotoinit_Sql*>  &data );//查询数据
    bool  selectMessageBySendStatus(int status,vector<Uploadphotoinit_Sql*> &data );//查询未发送成功的数据


    int deleteMessageById(std::string id);//
    int deleteMessageByTime(std::string time);
    int deleteAllMessage(void);//

    std::string  changStruct2String(Uploadphotoinit_Up  data);
    Uploadphotoinit_Sql *   changString2Struct( vector<std::string>   &result);
    bool  stringToBool(std::string &value);
    int   stringToInt(std::string &value);
    unsigned short  stringToUnsignedShort(std::string &value);
    unsigned char stringToUnsignedChar(  string &value);

   Uploadphotoinit_Up uploadInitSql2Uploadphotoinit(Uploadphotoinit_Sql *indata );



private:
     std::string  filename="/mnt/mmcblk0p1/SendMessageInfo.db";
};

#endif // Photosave_H



