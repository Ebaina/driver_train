#ifndef DATAOPERATER
#define DATAOPERATER

#include "stdtype.h"
#include <iostream>
#include <vector>



/**
 *  \file   dataoperater.h
 *  \class  DataOperater
 *  \brief  数据库中间层操作对象
 */

class DataOperater{
public:
  virtual  int initDatabase();//数据库初始化，判断是否存在数据没有则创建数据库

  virtual  int insertMessage(void*param);//插入数据库数据

  virtual  int selectMessageByStatus(string id);//
  virtual int selectMessageByTime(std::string time,void*param);//查询数据


  virtual  int deleteMessageById(string id);//
  virtual  int deleteAllMessage(void);//



};

#endif

