﻿#include "offlinesave.h"
#include "Utils.h"
#include "SqliteWrapper.h"
#include "Tracer.h"
#include <sstream>
OfflineSave::OfflineSave()
{

}

OfflineSave::~OfflineSave()
{

}

int OfflineSave::initDatabase()
{
    std::string createtable=
            "create table if not exists messageinfo ("\
            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL COLLATE RTRIM ,"\
            "ts_times  TEXT(8),"\
            "ts_cmd  TEXT(8),"\
            "ts_seq  TEXT(8),"\
            "ts_content  TEXT(2048),"\
            "ts_bodyLength  TEXT(8),"\
            "ts_Counter  TEXT(8),"\
            "ts_enable  TEXT(1),"\
            "ts_needAck  TEXT(1),"\
            "ts_RemoveConter  TEXT(4),"\
            "multyflag  TEXT(1),"\
            "mainpackgesize  TEXT(8),"\
            "packgeindex  TEXT(8),"\
            "encodeflag  TEXT(1),"\
            "is_photo  TEXT(1),"\
            "is_sendok  TEXT(1),"\
            "creattime  TEXT(16)"\
            ");";
    SqlResult_S result;
  int flag=  SqliteWrapper::getInstance()->exec(createtable,&result);
    // SqliteWrapper::getInstance()->close();


    return flag;
}

int OfflineSave::insertMessage(stSendCmdPiPe data)
{   SqlResult_S result;
    std::string sql= changStruct2String(data);
    //    bool  sendokflag=false;//是否发送成功标志
    //    sql.append(",'"+(Utils::boolToString(false))+"'");//是否发送成功标志
    sql.append(",'"+(Utils::getCurrentTime())+"'");
    std::string insertsql=
            "insert into messageinfo "
            "("
            "ts_times "\
            ",ts_cmd  "\
            ",ts_seq "\
            ",ts_content "\
            ",ts_bodyLength  "\
            ",ts_Counter  "\
            ",ts_enable  "\
            ",ts_needAck "\
            ",ts_RemoveConter "\
            ",multyflag  "\
            ",mainpackgesize  "\
            ",packgeindex "\
            ",encodeflag  "\
            ",is_photo  "\
            ",is_sendok  "\
            ",creattime "\
            ") "\
            "values"\
            "("\
            +sql +
            ");";
    SqliteWrapper::getInstance()->exec(insertsql, &result);
    return STATUS_OK;
}

int OfflineSave::updateSendBytime(string time)
{
    SqlResult_S result;

    SqliteWrapper::getInstance()->exec("UPDATE messageinfo SET is_sendok = '1' WHERE creattime ="+time+";", &result);

    return STATUS_OK;
}

bool   OfflineSave::selectAllMessage(vector<stSendCmdPiPe*>  &data )
{   SqlResult_S result;
    bool flag=  SqliteWrapper::getInstance()->getOpenStatus();
    if  (flag==true)
    {
        //        SqliteWrapper::getInstance()->exec("UPDATE messageinfo SET is_sendok = '1' WHERE creattime ="+time+";", &result);
        //        SqliteWrapper::getInstance()->exec("select * from messageinfo;", &result);
        //        vector<string> temp;
        //        int size=result.m_resultStrVect.size()/17;
        //        for(sint32 i=0; i<size; i++)
        //        {
        //            stSendCmdPiPe *info=new stSendCmdPiPe ;
        //            info={0};
        //            for(int j=0;j<17;j++){
        //                temp.push_back(result.m_resultStrVect[17*i+j]);
        //            }
        //            info= this->changString2Struct (  temp );
        //            if(info!=NULL)
        //            {
        //                data.push_back(info);
        //            }
        //            temp.clear();
        //        }
        //        //    vector<std::string>(temp).swap(temp);
        //       // SqliteWrapper::getInstance()->close();
    }else{
        //SqliteWrapper::getInstance()->close();
        return false;
    }
    return true;
}

bool OfflineSave::selectMessageBySendStatus(int status,vector<stSendCmdPiPe*> &data )
{
    bool flag_open;
    std::string status_str=Utils::intToString(status);
    SqlResult_S result;
    flag_open = SqliteWrapper::getInstance()->getOpenStatus();
    if(flag_open)
    {
        SqliteWrapper::getInstance()->exec("select * from messageinfo where is_sendok ="+status_str+" ;", &result);//and creattime > date('now','start of day')
        vector<string> temp;
        int size=result.m_resultStrVect.size()/17;
        for(sint32 i=0; i<size; i++)
        {
            stSendCmdPiPe *info=new stSendCmdPiPe  ;
            memset(info,0,sizeof(*info));
            for(int j=0;j<17;j++){
                temp.push_back(result.m_resultStrVect[17*i+j]);
            }
            info= this->changString2Struct(temp);
            if(info!=NULL)
            {
                data.push_back(info);
            }
            temp.clear();
        }
        //  vector<std::string>(temp).swap(temp);
        // SqliteWrapper::getInstance()->close();
    }
    else{
        //SqliteWrapper::getInstance()->close();
        return false;

    }
    return true;
}

bool OfflineSave::selectMessageByTypeId(int idtype, string start, string stop,int count ,int index,vector<stSendCmdPiPe*> &data)
{
    bool flag_open;
    SqlResult_S result;
    flag_open = SqliteWrapper::getInstance()->getOpenStatus();
    if(flag_open)
    {
        std::string sql="select *  from messageinfo  where ts_cmd='"+Utils::intToString(idtype)+ "'and creattime Between '"+start+"'  and  '"+stop+"' order by id limit '"+Utils::intToString(count)+"' offset  '"+Utils::intToString(index)+"';" ;
//        TRACE_ERR("sql:%s\n",sql.c_str());
        SqliteWrapper::getInstance()->exec( sql, &result);
        vector<string> temp;
        int size=result.m_resultStrVect.size()/17;
        for(sint32 i=0; i<size; i++)
        {
            stSendCmdPiPe *info=new stSendCmdPiPe  ;
            memset(info,0,sizeof(*info));
            for(int j=0;j<17;j++){
                temp.push_back(result.m_resultStrVect[17*i+j]);
            }
            info= this->changString2Struct(temp);
            if(info!=NULL)
            {
                data.push_back(info);
            }
            temp.clear();
        }
        // SqliteWrapper::getInstance()->close();
    }
    else{
        //SqliteWrapper::getInstance()->close();
        return false;

    }
    return true;
}

bool OfflineSave::selectMessageByCounts(int idtype, int count, vector<stSendCmdPiPe *> &data)
{
    bool flag_open;
    SqlResult_S result;
    flag_open = SqliteWrapper::getInstance()->getOpenStatus();
    if(flag_open)
    {
        std::string sql="select *  from messageinfo  where ts_cmd='"+Utils::intToString(idtype)+ "'  order by id limit '"+Utils::intToString(count)+"' offset  '0';" ;
//        TRACE_ERR("sql:%s\n",sql.c_str());
        SqliteWrapper::getInstance()->exec( sql, &result);
        vector<string> temp;
        int size=result.m_resultStrVect.size()/17;
        for(sint32 i=0; i<size; i++)
        {
            stSendCmdPiPe *info=new stSendCmdPiPe  ;
            memset(info,0,sizeof(*info));
            for(int j=0;j<17;j++){
                temp.push_back(result.m_resultStrVect[17*i+j]);
            }
            info= this->changString2Struct(temp);
            if(info!=NULL)
            {
                data.push_back(info);
            }
            temp.clear();
        }
        // SqliteWrapper::getInstance()->close();
    }
    else{
        //SqliteWrapper::getInstance()->close();
        return false;

    }
    return true;
}

int OfflineSave::deleteMessageById(std::string id)
{
    SqlResult_S result;
    bool flag=  SqliteWrapper::getInstance()->getOpenStatus();
    std::string sql="delete from messageinfo where id = "+id+";";
    if  (flag==true)
    {
        SqliteWrapper::getInstance()->exec(sql, &result);
        // SqliteWrapper::getInstance()->close();
    }else{STATUS_ERROR;}
    return STATUS_OK;
}

int OfflineSave::deleteMessageByTime(std::string &time)
{
    SqlResult_S result;
    if(time.length()>3){
    bool flag=     SqliteWrapper::getInstance()->getOpenStatus();
    std::string  ji="\'";
    std::string sql="delete from messageinfo where creattime = "+ ji+time+ ji+"  ;";
//    TRACE_INFO("\n删除：%s\n",sql.c_str());
    if(flag){
        SqliteWrapper::getInstance()->exec(sql, &result);
        // SqliteWrapper::getInstance()->close();
    }else{
        return STATUS_ERROR;
    }
    return STATUS_OK;
   }else{
     return STATUS_ERROR;
    }

}
int OfflineSave::deleteMessageByFlowid(int tscmd,int  flowid)
{
    SqlResult_S result;
//    if(time.length()>3)
    {
    bool flag=     SqliteWrapper::getInstance()->getOpenStatus();
    std::string  ji="\'";
    std::string flow=Utils::intToString(flowid);
    std::string cmd=Utils::intToString(tscmd);
    std::string sql="delete from messageinfo where ts_seq = "+ ji+flow+ ji+"and ts_cmd="+ ji+cmd+ ji+";";
//    TRACE_INFO("\n删除：%s\n",sql.c_str());
    if(flag){
        SqliteWrapper::getInstance()->exec(sql, &result);
        // SqliteWrapper::getInstance()->close();
    }else{
        return STATUS_ERROR;
    }
    return STATUS_OK;
   }
//    else{
//     return STATUS_ERROR;
//    }

}

int OfflineSave::deleteAllMessage()
{
    SqlResult_S result;
    bool flag=      SqliteWrapper::getInstance()->getOpenStatus();
    if(flag){  SqliteWrapper::getInstance()->exec("delete * from messageinfo;", &result);
        SqliteWrapper::getInstance()->exec("update sqlite_sequence SET seq = 0 where name ='messageinfo'", &result);
        // SqliteWrapper::getInstance()->close();
    }else{
        //   SqliteWrapper::getInstance()->close();
        return  STATUS_ERROR;
    }
    return STATUS_OK;
}

std::string OfflineSave::changStruct2String(stSendCmdPiPe &data)
{
    std::string outdata;
    outdata.append("'"+Utils::intToString(data.ts_times)+"',");            //主动的发送次数大多为3次，中心下发指令方式，times =1
    outdata.append("'"+Utils::unsignedShortToString( (data.ts_cmd))+"',");  //发送命令，或应答中心
    outdata.append("'"+Utils::unsignedShortToString( (data.ts_seq))+"',");   //发送命令序号，或应答中心命令
    outdata.append("'"+Utils::code2string(data.ts_content,sizeof(data.ts_content))+"',");    //发往消息的消息体
    outdata.append("'"+Utils::unsignedShortToString(data.ts_bodyLength)+"',");  //发往中心的消息体长度
    outdata.append("'"+Utils::intToString(data.ts_Counter)+"',");
    outdata.append("'"+Utils::boolToString(data.ts_enable)+"',");        // 发往中心指令使能
    //   void *p_tsCmd;         //命令执行器
    outdata.append("'"+Utils::boolToString(data.ts_needAck)+"',");          //指示这条指令是否需要应答，中心请求和设备主动发均经过Process
    outdata.append("'"+Utils::intToString(data.ts_RemoveConter)+"',");
    outdata.append("'"+Utils::boolToString(data.multyflag)+"',");//分包标志
    outdata.append("'"+Utils::unsignedShortToString(data.mainpackgesize)+"',");//分包大小
    outdata.append("'"+Utils::unsignedShortToString(data.packgeindex) +"',");//序列号
    outdata.append("'"+Utils::boolToString( data.encodeflag ) +"',");//加密标志
    outdata.append("'"+Utils::boolToString( data.is_photo )+"'," );     //是否是照片数据
    outdata.append("'"+Utils::boolToString( data.ts_isoffline )+"'" );     //是否上传成功
    return outdata;
}

stSendCmdPiPe *  OfflineSave::changString2Struct(  vector<std::string> &result)
{
    stSendCmdPiPe *data=new stSendCmdPiPe ;
    if(result.size()==17){
        (data->ts_times)=this->stringToInt(result[1]);            //主动的发送次数大多为3次，中心下发指令方式，times =1
        data->ts_cmd= (this->stringToUnsignedShort(result[2]));   //发送命令，或应答中心
        data->ts_seq= (this->stringToUnsignedShort(result[3]));   //发送命令序号，或应答中心命令
        char info[1024];
        int len=Utils::string2code(result[4],info,result[4].length()/2);
        memcpy(data->ts_content,(char *)info,len);   //发往消息的消息体
        data->ts_bodyLength=this->stringToUnsignedShort(result[5]);  //发往中心的消息体长度
        data->ts_Counter=this->stringToInt(result[6]);
        data->ts_enable=this->stringToBool(result[7]);         // 发往中心指令使能
        data->ts_needAck=this->stringToBool(result[8]);           //指示这条指令是否需要应答，中心请求和设备主动发均经过Process
        data->ts_RemoveConter=this->stringToInt(result[9]);
        data->multyflag=this->stringToBool(result[10]); //分包标志
        data->mainpackgesize=this->stringToUnsignedShort(result[11]); //分包大小
        data->packgeindex=this->stringToUnsignedShort(result[12]); //序列号
        data->encodeflag=this->stringToBool(result[13]); //加密标志
        data->is_photo=  this->stringToBool(result[14]);    //是否是照片数据
        data->ts_isoffline=  this->stringToBool(result[15]);    //是否是照片数据
        data->ts_sendtime=  (result[16]);    //发送时间
        return data;
    }else{
        return NULL;
    }
}

int OfflineSave::stringToInt(  string &value)
{
    if( Utils::trimAllBlank(value).length()>0){
        int number;
        std::stringstream ss;
        ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;

}

unsigned short OfflineSave::stringToUnsignedShort(  string &value)
{
    unsigned short number;
    if( Utils::trimAllBlank(value).length()>0){
        std::stringstream ss;
        ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;
}

bool OfflineSave::stringToBool( string &value)
{     int v1=this->stringToInt(value);
      if(v1==1){
          return true;
      }else{
          return false;
      }
}

