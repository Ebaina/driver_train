#ifndef PHOTODB_H
#define PHOTODB_H

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <iostream>
#include <vector>
#include <string.h>

#include "sqlite3.h"

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

class photodb
{
public:
    photodb();
    ~photodb();
private:
    sqlite3 *photo_db;
    unsigned int maxInfoNum; //表中最大存放数量
    unsigned int maxFindNum; //最大查询数量
    pthread_t p_ID;
    static void *watchPhotoNums(void *param);
public:
    bool initDatabase(unsigned int max_info_num, unsigned int max_find_num);
    bool createPhotoTable(unsigned int photoID, char *photoName, unsigned int photoType, unsigned int cameraChannel);
    bool photoInfoInsert(char *picname, unsigned int photoType, unsigned int cameraChannel, unsigned long long int time);
    unsigned int photoSelectByTime(unsigned long long int timeStart, unsigned long long int timeEnd);
    bool photodbclose();
    bool printInfo();
    bool deleteFirstData();
    int getTotalNum();
    void startWatchThread();
    int findPhotoBytime(unsigned long long int timeStart, unsigned long long int timeEnd);
    int sqlFindResultVect(void*para, int columns, char **column_value, char **column_name);
    vector<string> sql_result_vect;   // 查询结果
};

#ifdef __cplusplus
}
#endif

#endif // PHOTODB_H
