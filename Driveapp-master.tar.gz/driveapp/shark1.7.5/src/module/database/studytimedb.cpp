﻿#include "studytimedb.h"
#include "Utils.h"
#include "SqliteWrapper.h"
#include "Tracer.h"
#include <sstream>
StudyTimeDb::StudyTimeDb()
{

}

StudyTimeDb::~StudyTimeDb()
{

}

int StudyTimeDb::initDatabase()
{
    std::string createtable=
            "create table if not exists studytime ("\
            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL COLLATE RTRIM ,"\
            "learnrecordid TEXT(40)	,"\
            "reporttype    TEXT(8)    ,"\
            "learnerid	 TEXT(40)	,"\
            "coachid		 TEXT(40)	,"\
            "lessonid		 TEXT(40)	,"\
            "recordtime	 TEXT(12)	,"\
            "trainlesson	 TEXT(40)    ,"\
            "recordstatus	 TEXT(8)	,"\
            " maxspeed	 TEXT(8)	,"\
            " milerecord	 TEXT(8)	,"\
            " addgnssdata	 TEXT(80)	,"\
            "creattime  TEXT(16)"\
            ");";
    SqlResult_S result;
   bool flag = SqliteWrapper::getInstance()->getOpenStatus();
    if(flag){
        SqliteWrapper::getInstance()->exec(createtable,&result);
        // SqliteWrapper::getInstance()->close();

        return flag;
    }
    else{
        // SqliteWrapper::getInstance()->close();
        return STATUS_ERROR;}

}

int StudyTimeDb::insertMessage(const ReportLearnMessage_Up &data)
{   SqlResult_S result;
    std::string sql= changStruct2String(data);
    //    bool  sendokflag=false;//是否发送成功标志
    sql.append(",'"+(Utils::getCurrentTime())+"'");
    std::string insertsql=
            "insert into studytime "
            "("
            "learnrecordid "\
            ",reporttype    "\
            ",learnerid	 "\
            ",coachid		 "\
            ",lessonid	 "\
            ",recordtime	 "\
            ",trainlesson	 "\
            ",recordstatus "\
            ",maxspeed  "\
            ",milerecord	 "\
            ",addgnssdata	 "\
            ",creattime"\
            ") "\
            "values"\
            "("\
            +sql +
            ");";
    bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
    if(flag){ SqliteWrapper::getInstance()->exec(insertsql, &result);
        // SqliteWrapper::getInstance()->close();
    }
    else{
        // SqliteWrapper::getInstance()->close();
        return     STATUS_ERROR;
    }
}

bool StudyTimeDb::selectAllMessage( vector<ReportLearnMessage_Up_DATABASE*>  &data)
{   SqlResult_S result;
    bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
    if(flag){
        SqliteWrapper::getInstance()->exec("select * from studytime;", &result);
        vector<string>  temp;
        int size=result.m_resultStrVect.size()/13;
        for(sint32 i=0; i<size; i++)
        {
            ReportLearnMessage_Up_DATABASE   *info = new ReportLearnMessage_Up_DATABASE;
            info->reportmessage={0};
            for(int j=0;j<13;j++){
                temp.push_back(result.m_resultStrVect[13*i+j]);
            }
            int flag= this->changString2Struct(temp,info);\
            if(flag==STATUS_OK)
            {
                data.push_back(info);
            }
            temp.clear();
        }
        //vector<std::string>(temp).swap(temp);
        // SqliteWrapper::getInstance()->close();
    }
    else{
        // SqliteWrapper::getInstance()->close();
        return false;}
    return true;
}

int StudyTimeDb::deleteMessageById(string id)
{
    SqlResult_S result;
    bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
    if(flag){  std::string sql="DELETE FROM studytime WHERE ID =  "+id+";";
        SqliteWrapper::getInstance()->exec(sql, &result);
        // SqliteWrapper::getInstance()->close();
        return STATUS_OK;
    }
    else{
        // SqliteWrapper::getInstance()->close();
        return STATUS_ERROR;
    }

}

int StudyTimeDb::deleteAllMessage()
{
    SqlResult_S result;
    bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
    if(flag){ SqliteWrapper::getInstance()->exec("delete  from studytime;", &result);
        SqliteWrapper::getInstance()->exec("update sqlite_sequence SET seq = 0 where name ='studytime'", &result);
        // SqliteWrapper::getInstance()->close();
        return STATUS_OK;
    }else{
        // SqliteWrapper::getInstance()->close();
        return STATUS_ERROR;
    }

}

std::string StudyTimeDb::changStruct2String(ReportLearnMessage_Up data)
{
    std::string outdata;
    outdata.append("'"+Utils::code2string((char *)data.learnrecordid,sizeof(data.learnrecordid))+"',"); //0	学时记录编号	BYTE[26]	见A4.1
    outdata.append("'"+Utils::unsignedCharToString(data.reporttype)+"',");;//26	上报类型	BYTE	0x01：自动上报；0x02：应中心要求上报。如果是应中心要求上传，则本次上传作业的作业序号保持与请求上传消息的作业序号一致，后续分段上传的作业序号也保持一致。
    outdata.append("'"+Utils::code2string((char *)data.learnerid,sizeof(data.learnerid))+"',");//27	学员编号	BYTE[16]	统一编号
    outdata.append("'"+Utils::code2string((char *)data.coachid,sizeof(data.coachid))+"',");//43	教练编号	BYTE[16]	统一编号
    outdata.append("'"+Utils::longToString(data.lessonid)+"',");//59	课堂ID	DWORD	标识学员的一次培训过程，计时平台自行使用
    outdata.append("'"+Utils::code2string((char *)data.recordtime,sizeof(data.recordtime))+"',");//63	记录产生时间	BCD[3]	格式： HHmmss，1min最后1s的时间
    outdata.append("'"+Utils::code2string((char *)data.trainlesson,sizeof(data.trainlesson))+"',");//66	培训课程	BCD[5]	课程编码，见A4.2
    outdata.append("'"+Utils::unsignedCharToString(data.recordstatus)+"',");//71	记录状态	BYTE	0：正常记录；
    outdata.append("'"+Utils::unsignedShortToString(data.maxspeed) +"',");//72	最大速度	WORD	1min内车辆达到的最大卫星定位速度，1/10km/h
    outdata.append("'"+Utils::unsignedShortToString(data.milerecord) +"',");//74	里程	WORD	车辆1min内行驶的总里程，1/10km，
    outdata.append("'"+Utils::code2string((char *)data.addgnssdata,sizeof(data.addgnssdata))+"'");//76	附加GNSS数据包	BYTE[38]	1min内第30s的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
    return outdata;
}

int  StudyTimeDb::changString2Struct(  vector<std::string>   &result, ReportLearnMessage_Up_DATABASE *data)
{
    if(result.size()==13){
        char info[40]={0};
        int len=0;
        data->id=result[0];
        len=Utils::string2code(result[1],info,result[1].length()/2);
        memcpy(data->reportmessage.learnrecordid,(char *)info,len);//1-0	学时记录编号	BYTE[26]	见A4.1
        data->reportmessage.reporttype  =(unsigned char)(this->stringToInt(result[2]));  	  //2-26	上报类型	BYTE	0x01：自动上报；0x02：应中心要求上报。如果是应中心要求上传，则本次上传作业的作业序号保持与请求上传消息的作业序号一致，后续分段上传的作业序号也保持一致。
        len=Utils::string2code(result[3],info,result[3].length()/2);
        memcpy(data->reportmessage.learnerid,(char *)info,len);                   //3-27	学员编号	BYTE[16]	统一编号
        len=Utils::string2code(result[4],info,result[4].length()/2);
        memcpy(data->reportmessage.coachid,(char *)info,len);                  //4-43	教练编号	BYTE[16]	统一编号
        data->reportmessage.lessonid	=  this->stringToLong(result[5]);  	                      //5-59	课堂ID	DWORD	标识学员的一次培训过程，计时平台自行使用
        len=Utils::string2code(result[6],info,result[6].length()/2);
        memcpy(data->reportmessage.recordtime	,(char *)info,len);                        //6-63	记录产生时间	BCD[3]	格式： HHmmss，1min最后1s的时间
        len=Utils::string2code(result[7],info,result[7].length()/2);
        memcpy(data->reportmessage.trainlesson,(char *)info,len);  //7-66	培训课程	BCD[5]	课程编码，见A4.2
        data->reportmessage.recordstatus =(unsigned char)(std::stoi(result[8] ));                       //8-71	记录状态	BYTE	0：正常记录；
        data->reportmessage.maxspeed	    =this->stringToUnsignedShort(result[9]);                         //9-72	最大速度	WORD	1min内车辆达到的最大卫星定位速度，1/10km/h
        data->reportmessage.milerecord	= this->stringToUnsignedShort(result[10]);                       //10-74	里程	WORD	车辆1min内行驶的总里程，1/10km，
        len=Utils::string2code(result[11],info,result[11].length()/2);
        memcpy(data->reportmessage.addgnssdata,(char *)info,len); //11-76	附加GNSS数据包	BYTE[38]	1min内第30s的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
        data->creattime=result[12];
        return STATUS_OK;
    }else{
        // SqliteWrapper::getInstance()->close();
        return STATUS_ERROR;
    }
}
int StudyTimeDb::stringToInt(  string &value)
{
    if( Utils::trimAllBlank(value).length()>0){
        int number;
        std::stringstream ss;
        ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;

}

unsigned short StudyTimeDb::stringToUnsignedShort(  string &value)
{
    unsigned short number;
    if( Utils::trimAllBlank(value).length()>0){
        std::stringstream ss;ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;
}

long StudyTimeDb::stringToLong(string &value)
{
    long number;
    if( Utils::trimAllBlank(value).length()>0){
        std::stringstream ss;ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;
}

bool StudyTimeDb::stringToBool( string &value)
{     int v1=this->stringToInt(value);
      if(v1==1){
          return true;
      }else{
          return false;
      }
}

