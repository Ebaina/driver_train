﻿#ifndef OFFLINESAVE_H
#define OFFLINESAVE_H
#include "string"
#include "cmd.h"
#include "vector"
namespace SEND_STATUS {
enum STATUS{
  SEND_YES=1,
  SEND_NO=0
};
};
class OfflineSave
{
public:
    OfflineSave();
    ~OfflineSave();
    static OfflineSave* getInstance()
    {
        static OfflineSave instance;
        return &instance;
    }
public :
    int initDatabase(void);//数据库初始化，判断是否存在数据没有则创建数据库

    int insertMessage(stSendCmdPiPe  data);//插入数据库数据

    int updateSendStatusById(string id);//更新发送状态

    int updateSendBytime(std::string time);//根据发送时间更新状态。

    int selectMessageByStatus(string id);//
    int selectMessageByTime(std::string time,stSendCmdPiPe  out);//查询数据
    bool   selectAllMessage(vector<stSendCmdPiPe*>  &data );//查询数据
    bool  selectMessageBySendStatus(int status,vector<stSendCmdPiPe*> &data );//查询未发送成功的数据


    bool selectMessageByTypeId(int  idtype,std::string start,std::string stop,int count ,int index,vector<stSendCmdPiPe*> &data);
    bool selectMessageByCounts(int  idtype  ,int count,vector<stSendCmdPiPe*> &data);


//    int selectAllMessage( );//查询数据
    int  deleteMessageByFlowid(int tscmd,int  flowid);
    int deleteMessageById(std::string id);//
    int deleteMessageByTime(std::string &time);
    int deleteAllMessage(void);//

    std::string  changStruct2String(stSendCmdPiPe  &data);
    stSendCmdPiPe *   changString2Struct( vector<std::string>   &result);
    bool  stringToBool(std::string &value);
    int   stringToInt(std::string &value);
    unsigned short  stringToUnsignedShort(std::string &value);
private:
     std::string  filename="/mnt/mmcblk0p1/SendMessageInfo.db";
};

#endif // OFFLINESAVE_H
