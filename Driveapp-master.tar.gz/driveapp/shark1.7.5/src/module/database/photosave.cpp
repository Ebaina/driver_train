﻿#include "photosave.h"
#include "Utils.h"
#include "SqliteWrapper.h"
#include "Tracer.h"
#include <sstream>
Photosave::Photosave()
{

}

Photosave::~Photosave()
{

}

int Photosave::initDatabase()
{
    std::string createtable=
            "create table if not exists photoinfo ("\
            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL COLLATE RTRIM ,"\
            "photonum  TEXT(10),"\
            "learnerorcoachid  TEXT(16),"\
            "uploadmode  TEXT(1),"\
            "camerachannel  TEXT(1),"\
            "photosize  TEXT(1),"\
            "photoeventtype  TEXT(1),"\
            "packgesize  TEXT(2),"\
            "photodatasize  TEXT(4),"\
            "lessonid  TEXT(4),"\
            "addgnssdata  TEXT(38),"\
            "faceidentifyreliability  TEXT(1),"\
            "photopath  TEXT(50),"\
            "creattime  TEXT(16)"\
            ");";
    SqlResult_S result;
    bool flag = SqliteWrapper::getInstance()->getOpenStatus();
     if(flag){ SqliteWrapper::getInstance()->exec(createtable,&result);
    // SqliteWrapper::getInstance()->close();
     }
     else{
         // SqliteWrapper::getInstance()->close();
         return STATUS_ERROR;}
    return STATUS_OK;
}

int Photosave::insertMessage(Uploadphotoinit_Up &data,string photopath)
{
    SqlResult_S result;
    std::string sql= changStruct2String(data);
    //    bool  sendokflag=false;//是否发送成功标志
    sql.append(",'"+photopath+"'");      //照片地址
    sql.append(",'"+(Utils::getCurrentTime())+"'"); //产生时间
    std::string insertsql=
            "insert into photoinfo "
            "("
            "photonum "\
            ",learnerorcoachid  "\
            ",uploadmode "\
            ",camerachannel "\
            ",photosize  "\
            ",photoeventtype  "\
            ",packgesize  "\
            ",photodatasize "\
            ",lessonid "\
            ",addgnssdata  "\
            ",faceidentifyreliability  "\
            ",photopath "\
            ",creattime "\
            ") "\
            "values"\
            "("\
            +sql +
            ");";
//     bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
//   if(flag) {
       TRACE_CYAN("\n照片插入：%s\n",insertsql.c_str());
       SqliteWrapper::getInstance()->exec(insertsql, &result);
    // SqliteWrapper::getInstance()->close();
//   }
//   else{
//         // SqliteWrapper::getInstance()->close();
//       return STATUS_ERROR;}
   return STATUS_OK;
}

int Photosave::updateSendBytime(string &time)
{
    SqlResult_S result;
     bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
     if(flag) { SqliteWrapper::getInstance()->exec("UPDATE messageinfo SET is_sendok = '1' WHERE creattime ="+time+";", &result);
    // SqliteWrapper::getInstance()->close();
     }
 else{  // SqliteWrapper::getInstance()->close();
         return STATUS_ERROR;}
    return STATUS_OK;
}

int Photosave::selectMatchCounts(string starttime, string stoptime )
{
    SqlResult_S result;
    bool flag=    SqliteWrapper::getInstance()->getOpenStatus();
  if(flag) { std::string sql="select count (*)   from photoinfo  where creattime Between '"+starttime+"'  and  '"+stoptime+"'" +";";
    TRACE_INFO("sql：%s", sql.c_str());
    SqliteWrapper::getInstance()->exec(sql, &result);
    result.m_resultStrVect[0];
    TRACE_INFO("count数据：%s", result.m_resultStrVect[0].c_str());
    // SqliteWrapper::getInstance()->close();
  }
     else{
        // SqliteWrapper::getInstance()->close();
      return STATUS_ERROR;}



    return  STATUS_OK;
}

/***************根据开始时间、结束时间和发送状态查询指定记录条数***************************
*函数名称：selectbyTimeWithLimit
* 传参：4个
* string starttime,开始时间
* string stoptime,结束时间
* int index, 开始索引
* int count  //查询总数
* vector<Uploadphotoinit_Up*> &data    查询的照片初始化数据
* 返回:查询记录条数
*************************************************************************************/
int Photosave::selectbyTimeWithLimit(string starttime, string stoptime, int index, int count,vector<Uploadphotoinit_Sql*> &data )
{
    SqlResult_S result;
    bool flag=    SqliteWrapper::getInstance()->getOpenStatus();
   if(flag) {
     std::string sql="select *  from photoinfo  where creattime Between '"+starttime+"'  and  '"+stoptime+"' order by id limit '"+Utils::intToString(count)+"' offset  '"+Utils::intToString(index)+"';" ;
    SqliteWrapper::getInstance()->exec(sql, &result);
    vector<string> temp;
    int size=result.m_resultStrVect.size()/result.m_columns;
    for(sint32 i=0; i<size; i++)
    {
        Uploadphotoinit_Sql *info=new Uploadphotoinit_Sql  ;
        memset(info,0,sizeof(*info));
        for(int j=0;j< result.m_columns;j++){
            temp.push_back(result.m_resultStrVect[ result.m_columns*i+j]);
        }
        info= this->changString2Struct(temp);
        if(info!=NULL)
        {
            data.push_back(info);
        }
        temp.clear();
    }
    // SqliteWrapper::getInstance()->close();
     return size ;
   }else{
         // SqliteWrapper::getInstance()->close();
       return STATUS_ERROR;}

}

int Photosave::selectbyTimeNoLimit(string starttime, string stoptime, vector<Uploadphotoinit_Sql *> &data)
{
    SqlResult_S result;
    bool flag=    SqliteWrapper::getInstance()->getOpenStatus();
   if(flag) {
     std::string sql="select *  from photoinfo  where creattime Between '"+starttime+"'  and  '"+stoptime+"' order by id    ;" ;
    SqliteWrapper::getInstance()->exec(sql, &result);
    vector<string> temp;
    int size=result.m_resultStrVect.size()/result.m_columns;
    for(sint32 i=0; i<size; i++)
    {
        Uploadphotoinit_Sql *info=new Uploadphotoinit_Sql  ;
        memset(info,0,sizeof(*info));
        for(int j=0;j< result.m_columns;j++){
            temp.push_back(result.m_resultStrVect[ result.m_columns*i+j]);
        }
        info= this->changString2Struct(temp);
        if(info!=NULL)
        {
            data.push_back(info);
        }
        temp.clear();
    }
    // SqliteWrapper::getInstance()->close();
     return size ;
   }else{
         // SqliteWrapper::getInstance()->close();
       return STATUS_ERROR;}

}

Uploadphotoinit_Sql  * Photosave::selectMessageByTime(string &time  )
{
     Uploadphotoinit_Sql  *out=new Uploadphotoinit_Sql ;
    SqlResult_S result;
    bool flag=    SqliteWrapper::getInstance()->getOpenStatus();
   if(flag) {
    std::string sql="select *  from photoinfo  where photonum = '"+time+"' ;" ;
    TRACE_CYAN("指定时间照片：%s\n",sql.c_str());
    SqliteWrapper::getInstance()->exec(sql, &result);
    if(result.m_resultStrVect.size()>0){
     vector<std::string> temp;
       TRACE_CYAN("指定时间size：%d\n",result.m_columns);
      for(int j=0;j< result.m_columns;j++){
         temp.push_back(result.m_resultStrVect[j]);
     }
      if(out!=NULL){
       out= this->changString2Struct(temp);
         TRACE_CYAN("指定路径：%s\n",out->photopath.c_str());}
       temp.clear();
     }
      return out ;
   }else{
         // SqliteWrapper::getInstance()->close();
       return NULL;}

}




bool   Photosave::selectAllMessage(vector<Uploadphotoinit_Sql*>  &data )
{
    SqlResult_S result;
   bool flag=     SqliteWrapper::getInstance()->getOpenStatus();
   if(flag) {   SqliteWrapper::getInstance()->exec("select * from messageinfo;", &result);
    vector<string> temp;
    int size=result.m_resultStrVect.size()/17;
    for(sint32 i=0; i<size; i++)
    {
        Uploadphotoinit_Sql *info=new Uploadphotoinit_Sql ;
        memset(info,0,sizeof(*info));
        for(int j=0;j<17;j++){
            temp.push_back(result.m_resultStrVect[17*i+j]);
        }
        info= this->changString2Struct (temp);
        if(info!=NULL)
        {
            data.push_back(info);
        }
        temp.clear();
    }
    //    vector<std::string>(temp).swap(temp);
    // SqliteWrapper::getInstance()->close();
   }else{
         // SqliteWrapper::getInstance()->close();
       return false;}
    return true;
}

bool Photosave::selectMessageBySendStatus(int status,vector<Uploadphotoinit_Sql*> &data )
{
    bool flag_open;
    std::string status_str=Utils::intToString(status);
    SqlResult_S result;
    flag_open = SqliteWrapper::getInstance()->getOpenStatus();
    if(flag_open)
     {   SqliteWrapper::getInstance()->exec("select * from messageinfo where is_sendok ="+status_str+" and creattime > date('now','start of day');", &result);
    vector<string> temp;
    int size=result.m_resultStrVect.size()/17;
    for(sint32 i=0; i<size; i++)
    {
        Uploadphotoinit_Sql *info=new Uploadphotoinit_Sql  ;
        memset(info,0,sizeof(*info));
        for(int j=0;j<17;j++){
            temp.push_back(result.m_resultStrVect[17*i+j]);
        }
        info= this->changString2Struct(temp);
        if(info!=NULL)
        {
            data.push_back(info);
        }
        temp.clear();
    }
    //  vector<std::string>(temp).swap(temp);
    // SqliteWrapper::getInstance()->close();
    }
    else{
          // // SqliteWrapper::getInstance()->close();
        return false;}
    return true;
}

int Photosave::deleteMessageById(std::string id)
{
    SqlResult_S result;
   bool flag=     SqliteWrapper::getInstance()->getOpenStatus();
   if(flag){ std::string sql="delete from messageinfo where id = "+id+";";
    SqliteWrapper::getInstance()->exec(sql, &result);
    // SqliteWrapper::getInstance()->close();
   }
    else{
         // SqliteWrapper::getInstance()->close();
       return false;}
    return STATUS_OK;
}

int Photosave::deleteMessageByTime(std::string time)
{
    SqlResult_S result;
   bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
     if(flag){  std::string  ji="\'";
    std::string sql="delete from messageinfo where creattime = "+ ji+time+ ji+";";
    SqliteWrapper::getInstance()->exec(sql, &result);
    // SqliteWrapper::getInstance()->close();
     }
 else{
           // SqliteWrapper::getInstance()->close();
         return false;}
    return STATUS_OK;
}

int Photosave::deleteAllMessage()
{
    SqlResult_S result;
     bool flag=   SqliteWrapper::getInstance()->getOpenStatus();
   if(flag){ SqliteWrapper::getInstance()->exec("delete * from messageinfo;", &result);
    SqliteWrapper::getInstance()->exec("update sqlite_sequence SET seq = 0 where name ='messageinfo'", &result);
    // SqliteWrapper::getInstance()->close();
   }
   else{
         // SqliteWrapper::getInstance()->close();
 return STATUS_ERROR;
   }
    return STATUS_OK;
}

std::string Photosave::changStruct2String(Uploadphotoinit_Up data)
{
    std::string outdata;
//    packgesize; // 	WORD
//    photodatasize; //  	DWORD
//    lessonid; //36 	DWORD

    outdata.append("'"+Utils::code2string((char *)data.photonum,sizeof(data.photonum))+"',");            //0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
    outdata.append("'"+Utils::code2string((char *)data.learnerorcoachid,sizeof(data.learnerorcoachid))+"',");  //10	学员或教练员编号	BYTE [16]	统一编号
    outdata.append("'"+Utils::unsignedCharToString(data.uploadmode)+"',");   //26	上传模式	BYTE	1：自动请求上传；
    outdata.append("'"+Utils::unsignedCharToString(data.camerachannel)+"',");    //27	摄像头通道号	BYTE	0：自动
    outdata.append("'"+Utils::unsignedCharToString(data.photosize)+"',");  //28	图片尺寸	BYTE	0x01：320×240；
    outdata.append("'"+Utils::unsignedCharToString(data.photoeventtype)+"',");//29	发起图片的事件类型	BYTE	发起图片的事件类型，定义如下：
    outdata.append("'"+Utils::unsignedShortToString(htons(data.packgesize))+"',");        //30	总包数	WORD
    outdata.append("'"+Utils::intToString(htonl(data.photodatasize))+"',");          //32	照片数据大小	DWORD
    outdata.append("'"+Utils::intToString(htonl(data.lessonid))+"',");//36	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
    outdata.append("'"+Utils::code2string((char *)data.addgnssdata,sizeof(data.addgnssdata))+"',");//40	附加GNSS数据包	BYTE[38]	照片拍摄时的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
    outdata.append("'"+Utils::unsignedCharToString(data.faceidentifyreliability)+"'");//78	人脸识别置信度	BYTE	0-100，数值越大置信度越高
    return outdata;
}

Uploadphotoinit_Sql *  Photosave::changString2Struct(  vector<std::string> &result)
{
    Uploadphotoinit_Sql *data=new Uploadphotoinit_Sql ;
    if(result.size()==14){
        data->id=this->stringToInt(result[0]);
        Utils::string2code(result[1],(char *)data->photonum,result[1].length()/2);            //0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
        Utils::string2code(result[2],(char *)data->learnerorcoachid,result[2].length()/2);    //10	学员或教练员编号	BYTE [16]	统一编号
        data->uploadmode=this->stringToUnsignedChar(result[3]);   //26	上传模式	BYTE	1：自动请求上传；
        data->camerachannel=this->stringToUnsignedChar(result[4]);  //27	摄像头通道号	BYTE	0：自动
        data->photosize=this->stringToUnsignedChar(result[5]);  //28	图片尺寸	BYTE	0x01：320×240；
        data->photoeventtype=this->stringToUnsignedChar(result[6]);                    //29	发起图片的事件类型	BYTE	发起图片的事件类型
        data->packgesize=htons(this->stringToUnsignedShort(result[7]));                //30	总包数	WORD
        data->photodatasize=htonl(this->stringToInt(result[8]));           //32	照片数据大小	DWORD
        data->lessonid=htonl(this->stringToInt(result[9]));    //36	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
        Utils::string2code(result[10],(char *)data->addgnssdata,result[10].length()/2);           //40	附加GNSS数据包	BYTE[38]	照片拍摄时的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
        data->faceidentifyreliability=this->stringToUnsignedChar(result[11]);  //78	人脸识别置信度	BYTE	0-100，数值越大置信度越高
        data->photopath=result[12];
        data->creattime=result[13];
        return data;
    }else{
        return NULL;
    }
}

int Photosave::stringToInt(  string &value)
{
    if( Utils::trimAllBlank(value).length()>0){
        int number;
        std::stringstream ss;
        ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;

}

unsigned short Photosave::stringToUnsignedShort(  string &value)
{
    unsigned short number;
    if( Utils::trimAllBlank(value).length()>0){
        std::stringstream ss;
        ss.str("");
        ss << value;//可以是其他数据类型
        ss >> number; //string -> int
        return number;
    }else  return 0;
}

unsigned char Photosave::stringToUnsignedChar(  string &value)
{
    unsigned char number;
    int intnum;
    if( Utils::trimAllBlank(value).length()>0){
        std::stringstream ss;
        ss.str("");
        ss << value;//可以是其他数据类型
        ss >> intnum; //string -> int
        number=(unsigned char )intnum;
        return number;
    }else  return 0;
}

Uploadphotoinit_Up  Photosave::uploadInitSql2Uploadphotoinit(Uploadphotoinit_Sql*indata)
{
     Uploadphotoinit_Up outdata;
     memcpy( (char *)outdata.photonum ,(char *)indata->photonum,sizeof(indata->photonum)); //0	照片编号	BYTE[10]	计时终端自行编号，仅使用0-9
     memcpy( (char *)outdata .learnerorcoachid,(char *)indata->learnerorcoachid,sizeof(indata->learnerorcoachid)); //10	学员或教练员编号	BYTE [16]	统一编号
     outdata . uploadmode=indata->uploadmode; //26	上传模式	BYTE	1：自动请求上传；
     outdata . camerachannel=indata->camerachannel; //27	摄像头通道号	BYTE	0：自动
     outdata . photosize=indata->photodatasize; //28	图片尺寸	BYTE	0x01：320×240；
     outdata . photoeventtype=indata->photoeventtype; //29	发起图片的事件类型	BYTE	发起图片的事件类型，定义如下：
     outdata . packgesize=indata->packgesize; //30	总包数	WORD
     outdata . photodatasize=indata->photodatasize; //32	照片数据大小	DWORD
     outdata . lessonid=indata->lessonid; //36	课堂ID	DWORD	标识学员的一次培训过程，计时终端自行使用
     memcpy( (char *)outdata .  addgnssdata,(char *)indata->addgnssdata,sizeof(indata->addgnssdata)); //40	附加GNSS数据包	BYTE[38]	照片拍摄时的卫星定位数据，见表B.21、表B24，由位置基本信息+位置附加信息项中的里程和发动机转速组成
     outdata .  faceidentifyreliability=indata->faceidentifyreliability; //78	人脸识别置信度	BYTE	0-100，数值越大置信度越高
     return outdata;
}

bool Photosave::stringToBool( string &value)
{     int v1=this->stringToInt(value);
      if(v1==1){
          return true;
      }else{
          return false;
      }
}

