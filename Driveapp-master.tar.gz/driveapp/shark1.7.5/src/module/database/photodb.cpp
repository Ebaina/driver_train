#include "photodb.h"

photodb::photodb()
{
    photo_db = NULL;
    maxInfoNum = 10;
    maxFindNum = 100;
}

photodb::~photodb()
{
    this->photodbclose();
}

bool photodb::photodbclose()
{
    if(photo_db!=NULL)
    {
        sqlite3_close(photo_db);
        photo_db = NULL;
    }
    return true;
}

bool photodb::initDatabase(unsigned int max_info_num, unsigned int max_find_num)
{
    maxInfoNum = max_info_num;
    maxFindNum = max_find_num;
    int rc;
    rc = sqlite3_open("/nfs/test_app/sqlite/photo.db", &photo_db);
    if(rc)
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(photo_db));
        sqlite3_close(photo_db);
        return false;
    }
    else
    {
        printf("already have opened a sqlite3 database named photo.db\n");
        return true;
    }
}

bool photodb::createPhotoTable(unsigned int photoID,
                               char *photoName, unsigned int photoType, unsigned int cameraChannel)
{
    char* errMsg=NULL;
    char *sql = "CREATE TABLE photoInfo"
                "(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "name VARCHAR(18), "
                "type INT, "
                "channel INT,"
                "time BIGINT);" ;
    if(sqlite3_exec(photo_db ,sql ,NULL ,NULL ,&errMsg) != SQLITE_OK)
    {
        printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, errMsg);
        return false;
    }
    printf("%s %s %d %s, create table ok!\n", __FILE__, __FUNCTION__, __LINE__,sql);
    return true;
}

bool photodb::photoInfoInsert(char *name, unsigned int type, unsigned int channel, unsigned long long int time)
{

    char* errMsg = NULL;
    char cmd[128];
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "INSERT INTO photoInfo "
                 "(name, type, channel, time) "
                 "VALUES(%s ,%d ,%d, %llu);",
            name, type, channel, time);
    //printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, cmd);

    if (sqlite3_exec(photo_db, cmd, NULL, NULL, &errMsg ) != SQLITE_OK)
    {
        printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, errMsg);
        return false;
    }
    //printf("%s %s %d, insert info ok!\n", __FILE__, __FUNCTION__, __LINE__);
    return true;
}

bool photodb::printInfo()
{
    int nrow = 0, ncolumn = 0;
    char **azResult; //二维数组存放结果
    char *errMsg = NULL;

    char *sql = NULL;
    sql = "SELECT * FROM photoInfo ";
    sqlite3_get_table( photo_db , sql , &azResult , &nrow , &ncolumn , &errMsg );

    int i = 0 , j = 0;
    printf( "row:%d column=%d \n" , nrow , ncolumn );
    printf( "\nThe result of querying is : \n" );

    for( i=0 ; i<( nrow + 1 ) * ncolumn ; i++ )
    {
        j++;
        printf( "%-20s", azResult[i] );
        if(j == ncolumn)
        {
            j = 0;
            printf("\n");
        }
    }
}

bool photodb::deleteFirstData()
{
    char* errMsg = NULL;
    char cmd[128];
    memset(cmd, 0, sizeof(cmd));

    sprintf(cmd, "delete from photoInfo where rowid in(select rowid from photoInfo limit 1);");

    printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, cmd);

    if (sqlite3_exec(photo_db, cmd, NULL, NULL, &errMsg ) != SQLITE_OK)
    {
        printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, errMsg);
        return false;
    }
    printf("%s %s %d, delete info ok!\n", __FILE__, __FUNCTION__, __LINE__);
    return true;
}

int photodb::getTotalNum()
{
    char* errMsg = NULL;
    int nrow = 0, ncolumn = 0;
    char **azResult;
    char *sql = NULL;

    sql = "SELECT id FROM photoInfo ";
    sqlite3_get_table( photo_db , sql , &azResult , &nrow , &ncolumn , &errMsg );
        //printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, errMsg);
    return nrow;
}

void photodb::startWatchThread()
{
    pthread_create(&p_ID, 0, watchPhotoNums, this);
}

void *photodb::watchPhotoNums(void *param)
{
    photodb *p = (photodb *)param;
    while(1)
    {
        if(p->getTotalNum() > p->maxInfoNum)
        {
           // printf("table max store num=========================================%d\n", p->maxInfoNum);
            p->deleteFirstData();
        }
        sleep(5);
//        printf("\n\n");
//        p->printInfo();
//        printf("\n\n");
    }
}

int photodb::findPhotoBytime(unsigned long long int timeStart, unsigned long long int timeEnd)
{
   int nrow = 0, ncolumn = 0;
    char* errMsg = NULL;
    char **findResult;
    char cmd[128];
    memset(cmd, 0, sizeof(cmd));

    sprintf(cmd, "select name from photoInfo where (time >= %llu) and (time <= %llu) order by time;", timeStart, timeEnd);

    printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, cmd);

    if (sqlite3_get_table( photo_db , cmd , &findResult , &nrow , &ncolumn , &errMsg ) != SQLITE_OK)
    {
        printf("%s %s %d, %s\n", __FILE__, __FUNCTION__, __LINE__, errMsg);
        return false;
    }
    printf("%s %s %d, find info ok!\n", __FILE__, __FUNCTION__, __LINE__);

    int i = 0 , j = 0;
    printf( "row:%d column=%d \n" , nrow , ncolumn );
    printf( "\nThe result of querying is : \n" );

    for( i=0 ; i<( nrow + 1 ) * ncolumn ; i++ )
    {
        j++;
        printf( "%-20s", findResult[i] );
        if(j == ncolumn)
        {
            j = 0;
            printf("\n");
        }
    }

     sql_result_vect.empty();
     for(int i=1; i<=nrow; i++)
     {
         sql_result_vect.push_back(findResult[i]);
         //printf( "push[%d] = %s\n", i , findResult[i] );
     }
    return nrow;
}
