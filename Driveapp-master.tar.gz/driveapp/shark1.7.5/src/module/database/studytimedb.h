#ifndef StudyTimeDb_H
#define StudyTimeDb_H
#include "string"
#include "exelearner.h"
#include "cmd.h"
#include "vector"
typedef struct  ReportLearnMessage_Up_DATABASE{
std::string id;//序号
ReportLearnMessage_Up  reportmessage;//内容
std::string creattime;//创建时间
}  __attribute__((packed, aligned(1))) ReportLearnMessage_Up_DATABASE;


class StudyTimeDb
{
public:
    StudyTimeDb();
    ~StudyTimeDb();
    static StudyTimeDb* getInstance()
    {
        static StudyTimeDb instance;
        return &instance;
    }
public :
    int initDatabase(void);//数据库初始化，判断是否存在数据没有则创建数据库

    int insertMessage(const ReportLearnMessage_Up  &data);//插入数据库数据

    int updateSendStatusById(const string &id);//更新发送状态
    int selectMessageByStatus(const string &id);//
    int selectMessageByTime(std::string time,ReportLearnMessage_Up  &out);//查询数据
    bool selectAllMessage( vector<ReportLearnMessage_Up_DATABASE*>  &data);//查询数据
    int deleteMessageById(const string id);//
    int deleteAllMessage(void);//

    std::string  changStruct2String(ReportLearnMessage_Up  data);
    int   changString2Struct( vector<std::string>   &result,ReportLearnMessage_Up_DATABASE  *data);
    bool  stringToBool(std::string &value);
    int   stringToInt(std::string &value);
    unsigned short  stringToUnsignedShort(std::string &value);
    long  stringToLong(std::string &value);
private:
  std::string  filename="/mnt/mmcblk0p1/SendMessageInfo.db";
};

#endif // StudyTimeDb_H
