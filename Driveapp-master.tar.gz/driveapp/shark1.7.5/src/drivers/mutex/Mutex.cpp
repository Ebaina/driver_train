/******************************************************************************
*******************************************************************************/
#include "Mutex.h"

MutexLock::MutexLock()
{
	pthread_mutex_init(&m_mutex,NULL);
}

MutexLock::~MutexLock()
{
	pthread_mutex_destroy(&m_mutex);
}

/**
 *  \brief  互斥锁上锁
 *  \note   none
 */
int MutexLock::lock()
{
	return pthread_mutex_lock(&m_mutex);
}
/**
 *  \brief  互斥锁解锁
 *  \note   none
 */
int MutexLock::unLock()
{
	return pthread_mutex_unlock(&m_mutex);
}
/**
 *  \brief  互斥锁尝试上锁
 *  \note   none
 */
int MutexLock::tryLock()
{
	return pthread_mutex_trylock(&m_mutex);
}

AutoLock::AutoLock(MutexLock* mutexLock):
m_mutexLock(mutexLock)
{
	m_mutexLock->lock();
}

AutoLock::~AutoLock()
{
	m_mutexLock->unLock();
}

MutexCond::MutexCond(MutexLock* lock)
{
    m_lock = lock;
    pthread_cond_init(&m_cond,NULL);
}

MutexCond::~MutexCond()
{
}
/**
 *  \brief  等待条件变量
 *  \note   执行该方法后线程会阻塞并释放锁,一直等待条件变量.
 */
void MutexCond::wait()
{
    pthread_cond_wait(&m_cond,&(m_lock->m_mutex));
}
/**
 *  \brief  满足条件变量,通知等待者
 *  \note   none
 */
void MutexCond::meet()
{
    pthread_cond_signal(&m_cond);
}
