/******************************************************************************
*******************************************************************************/
#ifndef __THREAD_POOL_H__
#define __THREAD_POOL_H__
#include "Thread.h"
#include "Mutex.h"
#include <iostream>
#include <vector>
using namespace std;

class ThreadPool;

/**
 *  \file   ThreadPool.h   
 *  \class  Runnable
 *  \brief  线程运行体	
 */
class Runnable{
public:
    Runnable();
    virtual ~Runnable();
    virtual void run()=0;
    bool isRunning();
private:
    friend class ThreadPool;
    bool m_isRunning;
};

/**
 *  \file   ThreadPool.h   
 *  \class  ThreadPool
 *  \brief  线程池
 */
class ThreadPool{
public:
    static ThreadPool* getInstance()
    {
        static ThreadPool instance;
        return &instance;
    }
    ~ThreadPool();
    bool init(int maxThreadCount);
    bool start(Runnable* runnable,int priority=0);
    bool cancel(Runnable* runnable);
    int maxThreadCount();
    int idleThreadCount();
private:
    ThreadPool();
    void execRunnable(int index);
    static void* threadEntry(void *arg);
private:
    bool m_initFlag;
    MutexLock m_vectLock;
    vector<Runnable*> m_threadVect;
    int m_maxThreadCount;
    int m_usedThreadCount;
};


#endif
