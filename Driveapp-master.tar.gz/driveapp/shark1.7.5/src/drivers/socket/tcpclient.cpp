﻿#include "tcpclient.h"
#include "app_globl.h"
#include "Utils.h"
#include "Tracer.h"
nTcp_Client::nTcp_Client()
{
    is_ok = false;
    m_reConnect = false;
    m_param = NULL;
    p_fun = NULL;
    fd_client = -1;
    p_rcvThread = 0;

}

nTcp_Client::~nTcp_Client()
{
    nTcp_Close();
}

bool nTcp_Client::nTcp_SetParam(char *ip,int port)
{
    int on = 1;
    int sndsize,rcvsize;
    sndsize = BUFFER_SEND_SIZE;
    rcvsize = BUFFER_RECV_SIZE+1;//size add+1
    fd_client = socket(AF_INET,SOCK_STREAM,0);
    if(fd_client == -1)
    {
        wlog(WIS_ERROR,"nTCp ->Error \n");
        printf("nTCp ->Error \n");
        return false;
    }

    bzero(&l_server,sizeof(l_server));
    l_server.sin_family = AF_INET;
    l_server.sin_port = htons(port);
    //inet_pton(AF_INET,ip,&l_server.sin_addr);
    if(0 == inet_aton(ip,&l_server.sin_addr))
    {
        wlog(WIS_ERROR,"nTcp->Error Net not connect! \n");
        return false;
    }

    setsockopt(fd_client, SOL_SOCKET, SO_SNDBUF, &sndsize, sizeof(int));
    setsockopt(fd_client, SOL_SOCKET, SO_RCVBUF, &rcvsize, sizeof(int));
    setsockopt(fd_client, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));
    linger m_sLinger;
    m_sLinger.l_onoff=0;//(在closesocket()调用,但是还有数据没发送完毕的时候容许逗留)
    // 如果m_sLinger.l_onoff=0;未发送完，不允许逗留;
    m_sLinger.l_linger=5;//(容许逗留的时间为5秒)
    setsockopt(fd_client,SOL_SOCKET,SO_LINGER,(const char*)&m_sLinger,sizeof(linger));

    return true;
}

bool nTcp_Client::nTcp_Connect()
{
    wlog(WIS_INFO,"nTcp :Will Connect Server!\n");

    if(connect(fd_client,(struct sockaddr *)&l_server,sizeof(l_server)) < 0)
    {
        wlog(WIS_ERROR,"nTcp->Error Connect Error!");
        nTcp_Close();
        return false;
    }
    wlog(WIS_INFO,"nTcp: Connected!");
    return true;
}

void * nTcp_Client::nTcp_WatchMan(void *param)
{
    nTcp_Client *p = (nTcp_Client *) param;

    while (true)
    {
        if(netStatus.net_state != 0)
        {
            p->is_ok = false;
            p->m_reConnect = false;
            TcpLinkConnectFlag=0;
            TRACE_INFO("\n联网断开!\n");
            //            p->nTcp_Close();
        }
        if(!p->m_reConnect)
        {
            p->nTcp_SetParam(p->m_ServerIP, p->m_Port);
            if(p->nTcp_Connect())
            {
                p->is_ok = true;
                pthread_create(&p->p_rcvThread,0,p->nTcp_RcvThread,param);
                TcpLinkConnectFlag=1;
                p->m_reConnect = true;
                //  wlog(WIS_INFO,"nTcp Connect Server OK!");
            }
            else
            {
                if(p->p_rcvThread) {
                    pthread_join(p->p_rcvThread, 0);
                    p->p_rcvThread = 0;
                }
                TcpLinkConnectFlag=0;
                p->nTcp_Close();
                TRACE_INFO("\nTCP链路断开!\n");
            }
        }
        sleep(2);
    }
}
bool nTcp_Client::nTcp_LinkServer(char *ip,int port,Recv_callback b_fun,int sync,void *param)
{
    int l;
    memset(m_ServerIP,0,sizeof(m_ServerIP));
    l = strlen(ip) > sizeof(m_ServerIP) ? sizeof(m_ServerIP):strlen(ip);
    memcpy(m_ServerIP,ip,l);
    m_Port = port;
    m_param = param;
    if(sync == 1)
    {
        wlog(WIS_INFO,"nTcp->Info nTcp work mode = 1 \n");
        {
            p_fun = b_fun;
            pthread_create(&p_watchThread,0,nTcp_WatchMan,this);
            return true;
        }
    }
    else
    {
        wlog(WIS_INFO,"nTcp->Info nTcp work mode = 0 \n");
        if(nTcp_SetParam(ip,port))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

void * nTcp_Client::nTcp_RcvThread(void *param)
{
    char buff[MAX_NTCP_BUFFER];
    int len;
    nTcp_Client *p = (nTcp_Client *)param;
    wlog(WIS_INFO,"nTcp Thread is Runing!");
    while (p->is_ok)
    {
        memset(buff,0,MAX_NTCP_BUFFER);
        len = p->nTcp_Recv(buff,MAX_NTCP_BUFFER,500);
        if(len >0)
        {
            if(p->p_fun != NULL)
            {
                p->p_fun(buff,len,p->m_param);    // call back up uplayer
            }
        }
        else if (len ==0)
        {
            continue;
        }
        else
        {
            p->is_ok = false;
            p->m_reConnect = false;
            p->nTcp_Close();
            IsAuthority = 0;
            wlog(WIS_INFO,"get other data!!!");
        }
    }
}

int nTcp_Client::nTcp_Recv(char *buff, int l_buff, long timeout)
{
    int ret;
    int len;
    struct timeval	tv;
    tv.tv_sec = timeout /1000;
    tv.tv_usec = (timeout%1000) *1000;          // tv is NULL will block,
    if(!is_ok)
    {
        wlog(WIS_ERROR," nTcp->Error can not read! \n");
        return -1;
    }
    len = sizeof(l_remote);
    FD_ZERO(&fdset);
    FD_SET(fd_client,&fdset);
    ret = select(fd_client+1, &fdset, NULL, NULL, &tv);
    switch(ret)
    {
    case -1:
        wlog(WIS_ERROR,"nTcp->Error,nTcp lost Server!");
        return -1;
    case 0:
        //is_ok = false;
        break;
    default:
        if(FD_ISSET(fd_client, &fdset) >0)
        {
            //return recvfrom(fd_client, buff, l_buff, 0,(struct sockaddr *)&l_remote,&len);
            ret = recv(fd_client,buff,l_buff,0);
            if(ret == 0)
            {
                return -1;
            }
            Utils::LogSave("TcpGetdata.txt","TCPGetData:",buff,l_buff);
            return ret;
        }
        else
            break;
    }

    return 0;
}


int nTcp_Client::nTcp_Send(char *buff, int l_buff)
{
    if(!is_ok) return -1;

    send(fd_client,buff,l_buff,0);
    Utils::LogSave("Senddata.txt","SendData:",buff,l_buff);
    return 0;
}

void nTcp_Client::nTcp_Close()
{
    //if(!is_ok) return;
    if(fd_client != -1) {
        //        shutdown(fd_client,SHUT_RDWR);
        close(fd_client);
        fd_client = -1;
    }
}
