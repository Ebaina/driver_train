﻿#ifndef UDPUTILS_H
#define UDPUTILS_H
#include "Socket.h"
#include  <string>
typedef struct MSG
{
    char mark;     /* 固定值 $ */
    int  length;   /* 消息体长度 */
    int  cmdid;    /* 消息体命令 */
}__attribute__((packed, aligned(1)))MSG;

typedef struct Context4G
{
    int sockfd;
    int isRunning;
    int netstatus;
}__attribute__((packed, aligned(1))) Context4G;

#define TARGET_PORT 20000
#define SOCKET_PORT 20001
#define ID_NETSTATUS   0x01

class UdpUtils
{

public:
    UdpUtils();
    ~UdpUtils();

    pthread_t idSocket;


    int requestNetStatus();

    int udpnet_init();

    int createSocket();

    int destroySocket(int sockfd);

    int sendDatas(int sockfd, const void* buffer, int len);

    int recvDatas(int sockfd, void* buffer, int len, int timeout);

    void getNetStatus(int status);

    void processMsg();

private:
    char recvBuffer[20];
    char sendBuffer[1024];
    int bytesRead;
};
#endif // UDPUTILS_H
