﻿#include "udputils.h"
#include  <string>
#include  "Tracer.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
#include "app_globl.h"

static uint32_t getSystemCTS()
{
    struct timespec tp;
    clock_gettime(CLOCK_MONOTONIC, &tp);
    return (uint32_t)tp.tv_sec * 1000 + (uint32_t)tp.tv_nsec / 1000000;

}

static void* callback(void* arg)
{//回调函数
    ((UdpUtils*)arg)->processMsg();   //调用成员函数
    return NULL;
}

UdpUtils::UdpUtils()
{

}
UdpUtils::~UdpUtils()
{
      destroySocket(c4g_info.sockfd);
}

int UdpUtils::udpnet_init()
{ 
    c4g_info.isRunning = 1;
    c4g_info.netstatus = NET_STATE_OFFLINE;
    c4g_info.sockfd = createSocket();
    int result = pthread_create(&idSocket, NULL,callback, this);
    if(result != 0)
    {
        printf("pthread_create idSocket failed\n");
        return -1;
    }
//    pthread_join(idSocket, NULL);
//    destroySocket(c4g_info.sockfd);
}

int UdpUtils::requestNetStatus()
{
    MSG *msg = (MSG*)sendBuffer;
    msg->cmdid = ID_NETSTATUS;
    msg->mark = '$';
    msg->length = 0;
    if(c4g_info.sockfd == -1)
        return -1;
    struct sockaddr_in in;
    memset(&in, 0, sizeof(struct sockaddr_in));
    in.sin_family = AF_INET;
    in.sin_port = htons(TARGET_PORT);
    in.sin_addr.s_addr = inet_addr("127.0.0.1");//127.0.0.1
//    Tracer::getInstance()->printHex(1,"发送数据：",sendBuffer,10);
    return  sendto(c4g_info.sockfd, sendBuffer, sizeof(*msg), 0, (struct sockaddr*)&in, sizeof(in));
}

int UdpUtils::createSocket()
{
    int flags;
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sockfd<0) {
        printf("create socket failed\n");
        return -1;
    }

    flags = fcntl(sockfd,F_GETFL,0);
    flags |= O_NONBLOCK;
    fcntl(sockfd, F_SETFL, flags);
    struct sockaddr_in in;
    memset(&in, 0, sizeof(in));
    in.sin_family = AF_INET;
    in.sin_port = htons(SOCKET_PORT);
    in.sin_addr.s_addr = inet_addr("127.0.0.1");

    int result = bind(sockfd, (struct sockaddr *)&in, sizeof(in));
    if(result !=0) {
        printf("bind socket failed\n");
        return -1;
    }
    return sockfd;
}

int UdpUtils::destroySocket(int sockfd)
{
    close(sockfd);
    return 0;
}

void  UdpUtils::processMsg()
{
    int msgHeadLen  = sizeof(MSG);
    MSG *msg = (MSG*)recvBuffer;
    bytesRead = 0;
    int msg_len = msgHeadLen + 1;
    while(c4g_info.isRunning)
    {
        int bytesToRead  = recvDatas(c4g_info.sockfd, recvBuffer+bytesRead, msg_len-bytesRead, 3000);
        bytesRead += bytesToRead;
//        Tracer::getInstance()->printHex(1,"数据：",recvBuffer,bytesToRead);
//        TRACE_ERR_CLASS("信号信息:%d===bytesRead:%d======msg_len:%d\n",msg->cmdid,bytesRead,msg_len);
        if(bytesRead >= msg_len)
        {
            if(msg->mark != '$')
            {
                printf("Get wrong msg");
                bytesRead = 0 ;
                continue;
            }
//            if(bytesToRead >= msg->length)
//            TRACE_INFO("网络状态为:%d\n",recvBuffer[msgHeadLen]);
//            TRACE_INFO("XIAOXITI   :%d\n",msg->length);
//            TRACE_INFO("DUDAO DE    :%d\n",bytesRead);
//            for(int i=0;i<(bytesRead+1);i++)
//            {
//                printf("%02x",recvBuffer[i]);
//            }

            switch (msg->cmdid)
            {
            case ID_NETSTATUS:
                getNetStatus(recvBuffer[msgHeadLen]);
                memset(recvBuffer,0,sizeof(recvBuffer));
                break;
            default:
                break;
            }
        }
        bytesRead = 0;
    }
}

int UdpUtils::recvDatas(int sockfd, void* buffer, int len, int timeout)
{
    if(sockfd == -1)
        return -1;
    if(len ==0)
        return 0;

    int ret;
    int bytesToRead = 0;
    struct timeval stTimeout, *pTimeout = 0;
    fd_set readfd;

    uint32_t timeWaits = getSystemCTS() + timeout;
    if(timeout != -1) {
        stTimeout.tv_sec = timeout / 1000;
        stTimeout.tv_usec = (timeout % 1000) * 1000;
        pTimeout = &stTimeout;

    }
    FD_ZERO(&readfd);
    FD_SET(sockfd, &readfd);
    ret = select(sockfd + 1, &readfd, NULL, NULL, pTimeout);
    if (ret == 0) {
        return 0;
    }
    else if (ret > 0 && FD_ISSET(sockfd, &readfd))
    {
        uint32_t currenttimes;
        do {
            currenttimes = getSystemCTS();
            ret = recvfrom(sockfd, buffer + bytesToRead, len - bytesToRead, 0, NULL, NULL);
//            Tracer::getInstance()->printHex(1,"原始数据1",(char *)buffer,ret);
            if(ret <0){
                if( errno == EAGAIN) {
                    usleep(10*1000);
                    continue;
                }
                else {
                    fprintf(stderr,"errno = %d\n",errno);
                    return -1;
                }
            }
             bytesToRead += ret;
//             Tracer::getInstance()->printHex(1,"原始数据：",(char *)buffer,ret);
            if(bytesToRead>= len)
                return bytesToRead;
        }while(currenttimes <timeWaits);
    }
    else {
        fprintf(stderr,"errno = %d\n", errno);
        return -1;
    }
    return bytesToRead;
}

void UdpUtils::getNetStatus(int status)
{
    if( status == 1)
    {
        IsAuthority=0;    // ping check 并不安全，不能这么用
        netStatus.net_state = NET_STATE_OFFLINE;
        TRACE_RED("net is offline\n");
    }
    else if(status == 0)
    {
        netStatus.net_state = NET_STATE_ONLINE;
//        TRACE_RED("ping  OK!\n");
    }
    else if(status == 2)
    {
        netStatus.net_state = NET_STATE_CONNECTING;
        TRACE_RED("net is connecting\n");
    }
}
