﻿#include "n232.h"

static tagUARTParam UartParam =
{ "/dev/ttyS4", 9600, 8, 'N', 1, FLOW_CONTROL_NONE };

n232::n232()
{
    m232Open = false;
}

n232::~n232()
{

}

bool n232::n232_Open(tagUARTParam& param)
{
   m232Open = false;
   m232Open = open(param);
   if(!m232Open)
   {
        printf("open 232 error! \n");
   }
   else
   {
       sem_init(&mLock,0,1);
   }
   return m232Open;
}

void n232::n232_Close()
{
    if(m232Open)
    {
        close();
    }
    sem_destroy(&mLock);
}

int n232::n232_CmdSend(char *buf, int len_buf, char *outbuf, int len_out, int timeout)
{
    //串口未打开
    unsigned long currentms =0;
    int pos = 0;
    unsigned int count = 50;
    int len = 0;
    char Rbuf[512];
    int  RMini = 0;
    if(!m232Open) return -1;
    sem_wait(&mLock);
    memset(Rbuf,0,sizeof(Rbuf));
    RMini = len_out > 512 ? 512 : len_out;
    printf("Rmini = %d,len = %d",RMini,len_buf);
    send(buf,len_buf,100);
    currentms = get_tick_count() + timeout;
    printf("Current time ++++++ = %ld\n",currentms);
    do
    {
         len = recv(&Rbuf[pos],512-pos,100);

         if(len > 0)
         {
             pos += len;
         }
         if(pos >= RMini)
         {
           pos = RMini;
           break;
         }
         if(count-- <= 0) break;
    }while(get_tick_count() < currentms);
    printf("Current time ------- %ld pos = %d \n",get_tick_count(),pos);
    if(pos > 0)
    {
        memcpy(outbuf,Rbuf,pos);
    }
    sem_post(&mLock);
    return pos;
}
