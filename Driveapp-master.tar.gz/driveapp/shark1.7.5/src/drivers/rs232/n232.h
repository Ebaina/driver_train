﻿#ifndef N232_H
#define N232_H

#include "uart.h"
#include "public.h"
#include <semaphore.h>

class n232 : public CUART
{
public:
        n232();
    ~n232();
    /*
        函数说明: 打开，关闭232串口
        参数说明: tagUARTParam 串口参数
        返回值:
                 bool： true成功 ，false失败
    */
    bool n232_Open(tagUARTParam& param);
    void n232_Close();

    /*
        函数说明: 232串口收发
        参数说明: buf：发送数据，len_buf：发送数据长度，outbuf：返回数据，len_out返回数据长度
                 timeout：完成一次232操作的超时等待时间
        返回值:
                 bool： true成功 ，false失败
    */
    int n232_CmdSend(char *buf,int len_buf,char *outbuf,int len_out,int timeout);
private:
    sem_t  mLock;
    bool   m232Open;
};


#endif // N232_H
