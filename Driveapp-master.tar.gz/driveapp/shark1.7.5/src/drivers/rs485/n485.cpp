﻿#include "n485.h"

static tagUARTParam UartParam =
{ "/dev/ttyS7", 9600, 8, 'N', 1, FLOW_CONTROL_NONE };

N485_UART::N485_UART()
{
    m485Open = false;
}

N485_UART::~N485_UART()
{

}

bool N485_UART::N485_Open(tagUARTParam& param)
{
   m485Open = false;
   m485Open = open(param);
   if(!m485Open)
   {
        printf("open 485 error! \n");
   }
   else
   {
       sem_init(&mLock,0,1);
   }
   return m485Open;
}

void N485_UART::N485_Close()
{
    if(m485Open)
    {
        close();
    }
    sem_destroy(&mLock);
}

int N485_UART::N485_CmdSend(char *buf, int len_buf, char *outbuf, int len_out, int timeout)
{
    //串口未打开
    char str_gpio[64];
    FILE *fp;
    sprintf(str_gpio,"/sys/class/gpio/gpio234/value");
    if ((fp = fopen(str_gpio, "rb+")) == NULL) {
        printf("Cannot open enable file.\n");
        exit(1);
    }
    fprintf(fp, "1"); //拉高  PH10口

    unsigned long currentms =0;
    int pos = 0;
    unsigned int count = 50;
    int len = 0;
    char Rbuf[512];
    int  RMini = 0;
    if(!m485Open) return -1;
    sem_wait(&mLock);
    memset(Rbuf,0,sizeof(Rbuf));
    RMini = len_out > 512 ? 512 : len_out;
    printf("Rmini = %d,len = %d",RMini,len_buf);
    send(buf,len_buf,100);

    fprintf(fp,"0");  //拉低 PF13口
    fclose(fp);

    currentms = get_tick_count() + timeout;
    printf("Current time ++++++ = %ld\n",currentms);
    do
    {
         len = recv(&Rbuf[pos],512-pos,100);

         if(len > 0)
         {
             pos += len;
         }
         if(pos >= RMini)
         {
           pos = RMini;
           break;
         }
         if(count-- <= 0) break;
    }while(get_tick_count() < currentms);
    printf("Current time ------- %ld pos = %d \n",get_tick_count(),pos);
    if(pos > 0)
    {
        memcpy(outbuf,Rbuf,pos);
    }
    sem_post(&mLock);

    return pos;
}
