﻿#ifndef N485_H
#define N485_H
#include "uart.h"
#include "public.h"
#include <semaphore.h>

class N485_UART : public CUART
{
public:
    N485_UART();
    ~N485_UART();
    /*
        函数说明: 打开，关闭485串口
        参数说明: tagUARTParam 串口参数
        返回值:
                 bool： true成功 ，false失败
    */
    bool N485_Open(tagUARTParam& param);
    void N485_Close();

    /*
        函数说明: 485串口收发
        参数说明: buf：发送数据，len_buf：发送数据长度，outbuf：返回数据，len_out返回数据长度
                 timeout：完成一次485操作的超时等待时间
        返回值:
                 bool： true成功 ，false失败
    */
    int N485_CmdSend(char *buf,int len_buf,char *outbuf,int len_out,int timeout);
private:
    sem_t  mLock;
    bool   m485Open;
};

#endif // TEST_H

