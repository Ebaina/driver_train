
#include <iostream>
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <iostream>
#include <cstdlib>
#include "SYDevice.h"
#include "SYProtocol.h"
#include "test.h"
using namespace std;
#define DEV_ADDR 0xffffffff
extern int TestData();

int main()
{
    module_init();
    read_moudelNum();
  //  int b;
    printf("*****************************\n");
    printf("* 1.Entry  2.Search  3.Exit *\n");
    printf("*****************************\n");
    int a;
    scanf("%d",&a);
    switch(a)
    {
        case 1:
        entry();
        break;
        case 2:
        search();
        break;
        case 3:
        printf("moudle exit\n");
        return 0;
        break;
    }
    return 0;
}

