﻿#ifndef _TEST_H_
#define _TEST_H_
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <cstdlib>
#include "SYDevice.h"
#include "SYProtocol.h"
using namespace std;
#define DEV_ADDR 0xffffffff
extern int TestData();
int module_init();
int entry();
int search();
int read_moudelNum();
int EntryFromFile();
int EntryFromData(unsigned char  * indata,int length);
void reset_finger();
#endif
