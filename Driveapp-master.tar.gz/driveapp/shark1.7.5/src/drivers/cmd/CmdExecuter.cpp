﻿/******************************************************************************
*******************************************************************************/

#include <iostream>
#include "Tracer.h"
#include "CmdExecuter.h"
#include <stdlib.h>
#include <stdio.h>
#include<string.h>

/**
 *  \brief  执行命令并取得命令输出字符串.
 *  \param  cmd 命令字符串.
 *  \param  result 命令输出缓存.
 *  \param  len 命令输出缓存长度.
 *  \return 成功返回STATUS_OK,失败返回STATUS_ERROR.
 */
int CmdExecuter::execute(std::string cmd, char * result, int len)
{
	int ret;
	FILE* fp=NULL;
	fp=popen(cmd.c_str(),"r");
	if (NULL==fp)
	{
        TRACE_ERR("CmdExecuter::execute(%s), popen failed.\n",cmd.c_str());
		return STATUS_ERROR;
	}

	/* 读取命令执行结果 */
	memset(result,0,len);
	ret=fread(result, 1, len, fp);
	if (ret<=0)
	{
        TRACE_ERR("CmdExecuter::execute(%s),fread error,len=%d,ret=%d.\n",cmd.c_str(),len,ret);
	}
	result[len-1]=0;
	//TRACE_TEXT("%s",result);
	pclose(fp);
	return (ret>0)?(STATUS_OK):(STATUS_ERROR);
}

int CmdExecuter::executeNoResult(std::string cmd)
{
    FILE* fp=NULL;
    fp=popen(cmd.c_str(),"r");
    if (NULL==fp)
    {
        TRACE_ERR("CmdExecuter::execute(%s), popen failed.\n",cmd.c_str());
        return STATUS_ERROR;
    }

    pclose(fp);
    return STATUS_OK;
}
