﻿#include "uart.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include "public.h"
char str111[256];
static tagUARTParam UartParam =
{ "/dev/ttyS8", 9600, 8, 'N', 1, FLOW_CONTROL_NONE };
CUART mUartItem;
char tts_rcv[10];

//void reset_tts()
//{
//    char str_gpio[64];
//    FILE *fp;
//    sprintf(str_gpio,"/sys/class/gpio/gpio173/value");
//    if ((fp = fopen(str_gpio, "rb+")) == NULL) {
//        printf("Cannot open enable file.\n");
//        exit(1);
//    }
//    fprintf(fp, "0"); //拉低  PF13口
//    usleep(50000);
//    fprintf(fp,"1");  //拉高 PF13口
//    fclose(fp);
//}
char status_tts()//读取TTS状态
{
    char str_gpio[64];
    FILE *fp;
    char sta_tts[2];
    sprintf(str_gpio,"/sys/class/gpio/gpio173/value");
    if ((fp = fopen(str_gpio, "r")) == NULL) {
        printf("Cannot open enable file.\n");
        exit(1);
    }
    fread(sta_tts,1,1,fp); //拉低  PF13口
    fclose(fp);
    return  sta_tts[0];
}
void uart_init()
{
    mUartItem.open(UartParam);
}
void Package_data1( char * message,int length)
{
    uart_init();
    char data[1024];
    int i;
    data[0]=0xFD;
    data[1]=0x00;
    data[2]=0x01;
    for(i=0;i<length;i++)
    {
        data[i+3]=message[i];
    }
    mUartItem.send(data,length+3,10);
}
void Package_data(char *  messge,int length )
{
    char data[1024];
    int i;
    data[0]=0xFD;
    int templength=0;
    templength=length+2;

    data[1]=templength>>8;
    data[2]=templength;
    data[3]=0x01;
    data[4]=0x01;
    for(i=0;i<length;i++)
    {
        data[i+5]=messge[i];
    }
//    for(i=0;i<length+5;i++)
//    {
//        printf("%X",data[i]);
//    }
//    printf("\n");
    mUartItem.send(data,length+5,10);
}

int WakeUP()
{
    char   messge[1]={0xFF};
    Package_data1(messge,1);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int Power_save()
{
    char message[1]={0x88};
    Package_data1(message,1);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int Status_inquiry()
{
    char message[1]={0x21};
    Package_data1(message,1);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else if(tts_rcv[0]=0x4E)
    {
        return 2;
    }
    else if(tts_rcv[0]=0x4F)
    {
        return 3;
    }
    else
    {
        return 0;
    }
}

int Woman_voice()
{
    char message[4]={0x5B,0x6D,0x33,0x5D};
    Package_data(message,4);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int Man_voice()
{
    char message[5]={0x5B,0x6D,0X35,0X31,0X5D};
    Package_data(message,5);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int time_out()
{
    char message[1]={0x03};
    Package_data1(message,1);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int continue_voice()
{
    char message[1]={0x04};
    Package_data1(message,1);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int Stop()
{
    char message[1]={0x02};
    Package_data1(message,1);
    mUartItem.recv(tts_rcv,1,1000);
    if(tts_rcv[0]=0x41)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int volume(int volume)
{
    if(volume>10)
    {
        printf("Error vloume\n");
        return 0;
    }
    else if(volume==10)
    {
        char message[5]={0x5B,0x76,0x31,0x30,0x5D};
        Package_data(message,5);
        return 1;
    }
    else
    {
        short cvolume=volume+48;
        char message[4]={0x5B,0x76,(unsigned char)cvolume,0x5D};
        Package_data(message,4);
        mUartItem.recv(tts_rcv,1,10);
        if(tts_rcv[0]=0x41)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}

 int pacing(short pacing)
 {
     if(pacing>10)
     {
         printf("Error pacing\n");
         return 0;
     }
     else if(pacing==10)
     {
         char message[5]={0x5B,0x73,0x31,0x30,0x5D};
         Package_data(message,5);
         return 1;
     }
     short cpacing=pacing+48;
     char message[4]={0x5B,0x73,(unsigned char)cpacing,0x5D};
     Package_data(message,4);
     mUartItem.recv(tts_rcv,1,1000);
     if(tts_rcv[0]=0x41)
     {
         return 1;
     }
     else
     {
         return 0;
     }
 }

 int tone(short tone)
 {
     if(tone>10)
     {
         printf("Error pacing\n");
         return 0;
     }
     else if(tone==10)
     {
         char message[5]={0x5B,0x74,0x31,0x30,0x5D};
         Package_data(message,5);
         return 1;
     }
     short ctone=tone+48;
     char message[4]={0x5B,0x74,(unsigned char)ctone,0x5D};
     Package_data(message,4);
     mUartItem.recv(tts_rcv,1,1000);
     if(tts_rcv[0]=0x41)
     {
         return 1;
     }
     else
     {
         return 0;
     }
 }
int  Send_Voice(char * data  ,int length){


    //char message[4]={0xC4,0xE3,0xBA,0xC3};
    Package_data(data,length);
    mUartItem.recv(tts_rcv,1,10);
     printf("TTS Recive in \n");
    if(tts_rcv[0]=0x41)
    {
         printf("TTS Recive:%x\n",tts_rcv[0]);
        return 1;
    }
    else if(tts_rcv[0]=0x45)
    {
        return 0;
    }

}
int voice_start()
 {
       char message[4]={0xC4,0xE3,0xBA,0xC3};
       Package_data(message,4);
       mUartItem.recv(tts_rcv,1,10);
        printf("TTS Recive in \n");
       if(tts_rcv[0]=0x41)
       {
            printf("TTS Recive:%x\n",tts_rcv[0]);
           return 1;
       }
       else if(tts_rcv[0]=0x45)
       {
           return 0;
       }
 }

