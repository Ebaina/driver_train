﻿#ifndef TTS_H
#define TTS_H
char status_tts();//读取TTS状态
void Package_data1( char * message,int length);
void Package_data(char *  messge,int length );
void uart_init();
void reset_tts();
int WakeUP();
int Power_save();
int Status_inquiry();
int Woman_voice();
int Man_voice();
int time_out();
int continue_voice();
int Stop();
int volume(int volume);
int pacing(short pacing);
int tone(short tone);
int voice_start();
int Send_Voice(char * data  ,int length);
#endif 

