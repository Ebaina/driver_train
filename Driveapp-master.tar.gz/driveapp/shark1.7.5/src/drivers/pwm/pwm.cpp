﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <unistd.h>
char pwm_light_str[64];
char pwm_light_buf[10];
void enable_pwm(void)
{
    FILE *fp;
    sprintf(pwm_light_str,"/sys/devices/platform/nuc970-pwm.0/pwm/pwmchip0/pwm0/enable");
    if ((fp = fopen(pwm_light_str, "rb+")) == NULL) {
        printf("Cannot open enable file.\n");
        exit(1);
    }
    fprintf(fp, "1"); //enable PWM
    fclose(fp);
}

void set_pwm_period(int period)
{
    FILE *fp;
    sprintf(pwm_light_buf,"%d",period);
    sprintf(pwm_light_str,"/sys/devices/platform/nuc970-pwm.0/pwm/pwmchip0/pwm0/period");
    if ((fp = fopen(pwm_light_str, "rb+")) == NULL) {
        printf("Cannot open period file.\n");
        exit(1);
    }
    fprintf(fp,pwm_light_buf);
    fclose(fp);
}

void set_pwm_duty_cycle(int duty_cycle)
{
    FILE *fp;
    sprintf(pwm_light_buf,"%d",duty_cycle);
    sprintf(pwm_light_str,"/sys/devices/platform/nuc970-pwm.0/pwm/pwmchip0/pwm0/duty_cycle");
    if ((fp = fopen(pwm_light_str, "rb+")) == NULL) {
        printf("Cannot open duty_cycle file.\n");
        exit(1);
    }
    fprintf(fp, pwm_light_buf);
    fclose(fp);
}


