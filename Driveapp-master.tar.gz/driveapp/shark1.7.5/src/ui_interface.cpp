﻿#include "ui_interface.h"
#include "Utils.h"
#include "app_globl.h"
#include "ui_structs.h"
#include "cmd_pipe.h"
#include "communicatestm32.h"
#include "gps_recv.h"
#include "src/module/dial/dial.h"
#include "Timer.h"
#include "pwm.h"
#include "studytimedb.h"
#include "photosave.h"
#include "offlinesave.h"
#include "public.h"
#include "rtcutils.h"
#include "ttsutils.h"
#include "displayinterface.h"
#include <QDateTime>
#include "Directory.h"
#include"Tracer.h"
#include  "photogetutils.h"
#include "offlinesave.h"
#include<iostream>
#include<sstream>
#include "CmdExecuter.h"
#include "verupdate.h"
#include "udputils.h"
#include "timerupload.h"
#include "SqliteWrapper.h"
#include "postutils.h"
#include "gpsdataoperate.h"
using  namespace TRAIN_VOICE  ;
CommunicateStm32 commucate32;
stmobile_net_setting mobile_param;
GPS_recv  gps;
UdpUtils udp_getnetstatus;
void para_get();
void dir_check();
void page_check();
WIS_UI::LoginInterface *g_loginHandler;
class CTimerDisplay:public CTimerProtocol{
public:
    CTimerDisplay(WIS_UI::DisplayInterface *displayHandler)
    {
        /* 创建定时器 */
        dispalyspeedtimer=new CTimer(0x16,this);
        this->displayHandler=displayHandler;
    }
    int minflag = 0;
    void AddSpeedShow()
    {
        minflag++;
        udp_getnetstatus.requestNetStatus();   //获取网络状态
        //        minmea_sentence_rmc rmc_frame = *(GpsDataOperate::getInstance()->getData());
        //        if(rmc_frame.valid==true){
        displayHandler->updateTrainSpeed(positionReport_up.carspeed);
        //            Utils::updateWholeClockFromGps(rmc_frame);
        //        }else{
        //            displayHandler->updateTrainSpeed(0);
        //        }
        displayHandler->updateDirection(positionReport_up.direction);
        displayHandler->updateCurrentTrainDistance((unsigned int)(MainGetDistance/1000));
        displayHandler->updateTrainingMinutes(Trainminutes);
        if(minflag >= 20)
        {
            minflag = 0;
            if((StartTrainFlag == 1)&&(remaining_min > 0))
            {
                Trainminutes++;
                displayHandler->updateTrainingMinutes(Trainminutes);
            }
            char para_buff[32]={0};
            sprintf(para_buff,"%d",Trainminutes);
            Configuration_pageflag_set("pagepara:trainmin",para_buff);
            memset(para_buff,0,sizeof(para_buff));
            sprintf(para_buff,"%.2f",MainGetDistance);
            Configuration_pageflag_set("pagepara:maindistance",para_buff);
            memset(para_buff,0,sizeof(para_buff));
            sprintf(para_buff,"%d",remaining_min);
            Configuration_pageflag_set("pagepara:remaining_min",para_buff);
            memset(para_buff,0,sizeof(para_buff));
        }
        usleep(100);
    }

    void startTest()
    {
        /* 启用定时器 */
        dispalyspeedtimer->start(3, TIME_UNIT_SECOND, ctimer_selector(CTimerDisplay::AddSpeedShow));
    }
    void stopTest()
    {
        /* 停止定时器 */
        dispalyspeedtimer->stop();
        sleep(5);
    }
private:
    WIS_UI::DisplayInterface *displayHandler;
    CTimer* dispalyspeedtimer;
};


class CTimerStatus:public CTimerProtocol{
public:
    CTimerStatus(WIS_UI::StatusReportInterface *reportHandler)
    {
        /* 创建定时器 */
        hearttimer=new CTimer(0x01,this);
        this->reportHandler=reportHandler;
    }
    int netflag = 0;
    void onTimer02()
    {
        int signal_level;
        if(TcpLinkConnectFlag == 1)
        {
            if(netflag == 0)
            {
                string url1 = "http://api.driving.1dianxueche.com/app/v2/index/updateVersion?type=5&clientOs=3&clientVersion=1.0.0";
                //               "http://http://wechat.daopeng365.com/app/v1/index/updateVersion?type=5&clientOs=3&clientVersion=1.0.0";
                //                string tempversion1 = (char *)terminal_control_para_info.firmwareversion;
                //                url1.append(tempversion1);
                verUpdate::getInstance()->httpGetVersion(url1);
                sleep(1);
                string url2 = "http://api.driving.1dianxueche.com/app/v2/index/updateVersion?type=4&clientOs=3&clientVersion=1.0.0";
                verUpdate::getInstance()->httpGetVersionNET(url2);
                sleep(1);
                string url3 = "http://api.driving.1dianxueche.com/app/v2/index/updateVersion?type=6&clientOs=3&clientVersion=1.0.0";
                verUpdate::getInstance()->httpGetVersionSTM32(url3);
                File  *filename;
                if(!(filename->isExist("/user/prikey.pem")))
                {
                    string url4 = "http://wechat.daopeng365.com/driving_dev/device/key?";
                    verUpdate::getInstance()->httpGetCodeKey(url4);
                }
                netflag++;
            }
        }

        if(netStatus.net_state == 0)
        {
            signal_level = get_4g_signal_quality();
            this->reportHandler->updateNetState(UI_HEADER::RS_YES);
        }
        else if(netStatus.net_state != 0)
        {
            this->reportHandler->updateNetState(UI_HEADER::RS_NO);
        }
        g_loginHandler->updateNetAckState(netStatus.net_state);

        minmea_sentence_rmc *gp;
        gp= GpsDataOperate::getInstance()->getData2();
        if( (gp!=NULL)&&(gp->valid==true))
        {
            this->reportHandler->updateLocatedState(UI_HEADER::RS_YES);
            this->reportHandler->updateGNSSFaultState(UI_HEADER::RS_NO);
        }else{
            this->reportHandler->updateLocatedState(UI_HEADER::RS_NO);
            this->reportHandler->updateGNSSFaultState(UI_HEADER::RS_YES);
        }

        if(signal_level > -1)
            if((signal_level>0)&&(signal_level<10)){
                this->reportHandler->updateMobileSignal(1);
                // printf("signal level = 1\n");
            }
        if((signal_level>9)&&(signal_level<20)){
            this->reportHandler->updateMobileSignal(2);
            // printf("signal show = 1\n");
        }
        if((signal_level>19)&&(signal_level<26)){
            this->reportHandler->updateMobileSignal(3);
            // printf("signal show = 3\n");
        }
        if((signal_level>25)&&(signal_level<40)){
            this->reportHandler->updateMobileSignal(4);
            // printf("signal show = 4\n");
        }
        if(signal_level==99){
            this->reportHandler->updateMobileSignal(0);
            // printf("signal show = 0\n");
        }

        if((0 == check_video0_status())||(0 == check_video1_status()))
        {
            this->reportHandler->updateCameraFaultState(UI_HEADER::RS_NO);
        }else{
            this->reportHandler->updateCameraFaultState(UI_HEADER::RS_YES);
        }
        if((TcpLinkConnectFlag == 0)||(netStatus.net_state == 1))
        {
            this->reportHandler->updateNetToPlateState(UI_HEADER::RS_NO);
        }
        else if((TcpLinkConnectFlag == 1)&&(IsAuthority == 1))
        {
            this->reportHandler->updateNetToPlateState(UI_HEADER::RS_YES);
        }
        int speed = positionReport_up.carspeed;
        //        TRACE_INFO("最高车速是:%d\n",videolisten_info.High_Speed);
        //        TRACE_INFO("车速是:%d\n",speed);
        if(speed < 220)
        {
            if(speed > videolisten_info.High_Speed )
            {
                this->reportHandler->updateSpeedAlertState(UI_HEADER::RS_YES);
            }
            else
            {
                this->reportHandler->updateSpeedAlertState(UI_HEADER::RS_NO);
            }
        }

        if(UpdateFlag == 0)
        {
            this->reportHandler->updateVersionState(UI_HEADER::RS_NO);
        }
        else if(UpdateFlag == 1)
        {
            this->reportHandler->updateVersionState(UI_HEADER::RS_YES);
        }
        else if(UpdateFlag == 2)
        {
            this->reportHandler->updateVersionState(2);
            UpdateFlag = 0;
        }
        //        this->reportHandler->updateUrgentAlertState(1);
        //        this->reportHandler->updateTiredDriveState(1);
        //        this->reportHandler->updatePowerFaultState(1);
        //        this->reportHandler->updateTTSFaultState(1);
        //        this->reportHandler->updateCarFaultState(UI_HEADER::RS_YES);
        usleep(100);

    }
    void startTest()
    {
        /* 启用定时器 */
        hearttimer->start(3, TIME_UNIT_SECOND, ctimer_selector(CTimerStatus::onTimer02));
    }
    void stopTest()
    {
        /* 停止定时器 */
        hearttimer->stop();
        sleep(10);
    }
private:
    WIS_UI::StatusReportInterface *reportHandler;
    CTimer* hearttimer;
};

Ui_Interface::Ui_Interface()
{

}

void Ui_Interface::setLoginHandler(WIS_UI::LoginInterface *handler)
{
    g_loginHandler = handler;
}
//temp debug
void Ui_Interface::reset_loginstate(){
    IsCoachLogin=0;
    IsLearnerLogin=0;
}


void Ui_Interface::do_init_net()
{
    wlog_init((char*)&LOG_PATH);

    /*配置文件读取*/
    dictionary *ini;
    const char *str;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    if(ini == NULL)
    {
        fprintf(stderr,"can not open %s","parameters.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(ini,stderr);                                   //save ini to stderr

    Isregister = iniparser_getint(ini,"para:RegisterFlag",-1);
    net_info.Server_TCP_Port = iniparser_getint(ini,"para:Server_TCP_Port",-1);                                               //TCP端口获取
    str =  iniparser_getstring(ini,"para:Mainserver_IP","null");
    const char *devNum;
    const char *devicekeychar;
    devNum=iniparser_getstring(ini,"devicedata:deviceid","null");
    devicekeychar=iniparser_getstring(ini,"devicedata:devicekey","null");
    TRACE_HEX("加密串",devicekeychar,512); //   printHex
    Keyencode =QString(QLatin1String(devicekeychar)).toStdString();
    QString MaindevNumstring=QString(devNum);
    Device_Num=MaindevNumstring.toStdString();
    TRACE_CYAN("\n设备号：\n" );
    cout<<Device_Num<<endl;
    const char *httpstr;
    httpstr=iniparser_getstring(ini,"para:http_url","null");      //IP地址获取
    Ispageflag = iniparser_getint(ini,"devicedata:pageflag",-1);
    if(Ispageflag < 0)
    {
        Ispageflag = 0;
    }
    else if(Ispageflag == 1)
    {
        IsCoachLogin = 1;
    }
    else if(Ispageflag == 2)
    {
        IsCoachLogin = 1;
        IsLearnerLogin = 1;
    }

    int httpportin;
    httpportin=iniparser_getint(ini,"para:http_port",-1);
    QString Mainhttp_urltring=QString( httpstr);
    http_url=Mainhttp_urltring.toStdString();
    http_port=  QString::number(httpportin,10).toStdString();
    memcpy(net_info.Mainserver_IP,str,strlen(str));
    phone_num =  iniparser_getstring(ini,"para:phonenum","null");                          //手机号获取
    char  * Mainserver_IPTemp=(   char  *)net_info.Mainserver_IP;
    appcon.do_init_net(Mainserver_IPTemp,net_info.Server_TCP_Port);

    para_get();                          //获取参数
    appcon.do_init_cmd();

    SqliteWrapper::getInstance()->open("/mnt/mmcblk0p1/SendMessageInfo.db");
    StudyTimeDb::getInstance()->initDatabase();
    OfflineSave::getInstance()->initDatabase();
    Photosave::getInstance()->initDatabase();

    gps.init_gps();
    commucate32.setloginInterface(g_loginHandler);
    commucate32.Init_Data();
    udp_getnetstatus.udpnet_init();                             //UDP初始化
    netStatus.net_state = 2;
    uart_init();
    module_init();                          //指纹模块初始化
    //    enable_pwm();                               //屏幕亮度的控制使能
    TimerUpload::getInstance()->Init_Data();                       //通信平台数据初始化
    TimerUpload::getInstance()->startTest();
    other_info.Lightness = 10;
    volume(10);
    Woman_voice();
    usleep(1000);
    TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::WELCOM_FIRST);

    mobile_param.nettype = iniparser_getint(ini,"dial_param:nettype",0);
    TRACE_INFO("mobile_param.nettype= %d\n", mobile_param.nettype);

    mobile_param.dial_num =  (char *)iniparser_getstring(ini,"dial_param:dialnum","null");
    TRACE_INFO("mobile_param.dial_num= %s\n", mobile_param.dial_num);

    mobile_param.passwd =  (char *)iniparser_getstring(ini,"dial_param:passwd","null");
    TRACE_INFO("mobile_param.passwd= %s\n", mobile_param.passwd);

    mobile_param.apn =  (char *)iniparser_getstring(ini,"dial_param:apn","null");
    TRACE_INFO("mobile_param.apn= %s\n", mobile_param.apn);

    mobile_param.dial_port =  iniparser_getint(ini,"dial_param:dial_port", 0);
    TRACE_INFO("mobile_param.dial_port= %d\n", mobile_param.dial_port);

    mobile_param.status_port =  iniparser_getint(ini,"dial_param:status_port", 0);
    TRACE_INFO("mobile_param.status_port= %d\n", mobile_param.status_port);

    dir_check();
    page_check();


}  //初始化网关

void Ui_Interface::do_init_cmd()
{
    //    appcon.do_init_cmd();
} //初始化cmd,cmdpp

//UI 注册状态 是否注册 false  true;
int Ui_Interface::register_Status()
{
    return Isregister;
}

int Ui_Interface::pageflag_Status()
{
    return  Ispageflag;
}
//UI 调用 获取网络配置信息
UI_NetMainSet Ui_Interface::get_active_Plartform_Address(){

    UI_NetMainSet netMainSet;
    memcpy(&netMainSet.Mainserver_IP[0],(char *)&net_info.Mainserver_IP[0],sizeof(net_info.Mainserver_IP));
    netMainSet.Server_TCP_Port=net_info.Server_TCP_Port;
    memcpy(&netMainSet.phonenum[0],(char *)phone_num.c_str(),phone_num.length());
    memcpy(&netMainSet.Backupserver_IP[0],(char *)&net_info.Backupserver_IP[0],sizeof(net_info.Backupserver_IP));
    net_info.Server_UDP_Port = net_info.Server_TCP_Port;
    //     netMainSet.Server_UDP_Port = net_info.Server_UDP_Port;
    return netMainSet;
}

//UI 调用 设置网络配置信息
int  Ui_Interface::set_active_Plartform_Address(UI_NetMainSet netMainSet){

    char para_buff[40]={0};
    memcpy(&net_info.Mainserver_IP[0],(char *)&netMainSet.Mainserver_IP[0],sizeof(netMainSet.Mainserver_IP));
    memcpy(para_buff ,(char*)net_info.Mainserver_IP,sizeof(net_info.Mainserver_IP));
    Configuration_parameter_set("para:mainserver_ip",para_buff);
    memset(para_buff,0,sizeof(net_info.Mainserver_IP));

    memcpy(&net_info.Backupserver_IP[0],(char *)&netMainSet.Backupserver_IP[0],sizeof(netMainSet.Backupserver_IP));
    memcpy(para_buff ,(char*)net_info.Backupserver_IP,sizeof(net_info.Backupserver_IP));
    Configuration_parameter_set("para:backupserver_ip",para_buff);
    memset(para_buff,0,sizeof(net_info.Backupserver_IP));

    memcpy(&para_buff[0],(char *)&netMainSet.phonenum[0],sizeof(netMainSet.phonenum));
    Configuration_parameter_set("para:phonenum",para_buff);
    phone_num =  Utils::code2string(para_buff,sizeof(netMainSet.phonenum));
    memset(para_buff,0,sizeof(netMainSet.phonenum));

    net_info.Server_TCP_Port=netMainSet.Server_TCP_Port;
    sprintf(para_buff,"%d",net_info.Server_TCP_Port);
    Configuration_parameter_set("para:server_tcp_port",para_buff);
    memset(para_buff,0,sizeof(net_info.Server_TCP_Port));

    //    net_info.Server_UDP_Port=netMainSet.Server_UDP_Port;
    //    sprintf(para_buff,"%d",net_info.Server_UDP_Port);
    //    Configuration_parameter_set("para:server_udp_port",para_buff);
    //    memset(para_buff,0,sizeof(net_info.Server_UDP_Port));

    return  1;
}

int Ui_Interface::is_Coach_Login(WIS_UI::LoginInterface *loginHandler){
    //    loginHandler->updateCoachLoginAckState(IsCoachLogin);
    // printf("coachLogin!");
    return   IsCoachLogin;
} //是否有教练登陆信息
int Ui_Interface::is_Learner_Login(WIS_UI::LoginInterface *loginHandler){
    //    loginHandler->updateLearnerLoginAckState(IsLearnerLogin);
    //    printf("learnerLogin!");
    return  IsLearnerLogin;
}//是否有学员登陆信息

//是否有教练照片信息
int Ui_Interface::is_Coach_Pic()
{
    Directory dir;
    if(dir.isExist("/mnt/mmcblk0p1/")==false)
    {
        IsMainCoachPhotoPathFlag=0;
    }
    return   IsMainCoachPhotoPathFlag;
}

//是否有学员照片信息
int Ui_Interface::is_Learner_Pic()
{
    Directory dir;
    if(dir.isExist("/mnt/mmcblk0p1/")==false)
    {
        IsMainStudentPhotoPathFlag=0;
    }
    return IsMainStudentPhotoPathFlag;
}

//课程信息选择
void Ui_Interface::set_subjectID(int value)
{
    subjectcode = value;
    subjectID.clear();
    std::string s;
    TRACE_GREEN("课程类型码：%d \n",value);
    std::string car_type=stm32_card::getInstance()->GetCarType(studentcardinfo.card_info.traintype);
    subjectID.append("1");
    subjectID.append(car_type);
    std::stringstream ss11;
    ss11<<value;
    ss11>>s;
    if(value < 20)
    {
        subjectID.append("2");              //科目二
        subjectID.append(s);
    }
    else if(value > 20)
    {
        subjectID.append("3");            //科目三
        subjectID.append(s);
    }
    subjectID.append("0000");
    // printf("课程类型码：%s\n",subjectID.c_str());
}

void ChangeHexDataMain11(string data, unsigned char * out )
{
    char *offset;
    for(int i=0;i<data.size()/2;i++)
    {
        int data1  =   strtol(data.substr(2*i,2).c_str(), &offset, 16);
        out[i]=   (unsigned char)(data1) ;
    }
}

void Ui_Interface::do_register(UI_StRegInfo mInfo, WIS_UI::SettingInterface *settingHandler){

    char para_buff[40]={0};
    sreginfo.m_Province=mInfo.m_Province;
    sprintf(para_buff,"%d",sreginfo.m_Province);
    Configuration_parameter_set("para:province_id",para_buff);
    memset(para_buff,0,sizeof(sreginfo.m_Province));

    sreginfo.m_town=mInfo.m_town;
    sprintf(para_buff,"%d",sreginfo.m_town);
    Configuration_parameter_set("para:city_id",para_buff);
    memset(para_buff,0,sizeof(sreginfo.m_town));

    memcpy(&sreginfo. m_manufacturerID[0],(char *)&mInfo.m_manufacturerID[0],sizeof(mInfo.m_manufacturerID));
    memcpy(para_buff ,(char*)sreginfo. m_manufacturerID,sizeof(sreginfo. m_manufacturerID));
    Configuration_parameter_set("control:manufactorid",para_buff);
    memset(para_buff,0,sizeof(sreginfo. m_manufacturerID));   //制造商ID

    memcpy(&sreginfo. m_DeviceType[0],(char *)&mInfo.m_DeviceType[0],sizeof(mInfo.m_DeviceType));
    memcpy(para_buff ,(char*)sreginfo. m_DeviceType,sizeof(sreginfo. m_DeviceType));
    Configuration_parameter_set("control:devicetype",para_buff);
    memset(para_buff,0,sizeof(sreginfo. m_DeviceType));   //终端型号

    memcpy(&sreginfo. m_DeviceSN[0],(char *)&mInfo.m_DeviceSN[0],sizeof(mInfo.m_DeviceSN));
    memcpy(para_buff ,(char*)sreginfo. m_DeviceSN,sizeof(sreginfo. m_DeviceSN));
    Configuration_parameter_set("control:devicesn",para_buff);
    memset(para_buff,0,sizeof(sreginfo. m_DeviceSN));    //计时终端出厂序列号

    memcpy(&sreginfo. m_IMEI[0],(char *)&mInfo.m_IMEI[0],sizeof(mInfo.m_IMEI));
    memcpy(para_buff ,(char*)sreginfo. m_IMEI,sizeof(sreginfo. m_IMEI));
    Configuration_parameter_set("devicedata:imei",para_buff);
    memset(para_buff,0,sizeof(sreginfo. m_IMEI));     //imei

    sreginfo.m_CarPlateColor=mInfo.m_CarPlateColor;
    sprintf(para_buff,"%d",sreginfo.m_CarPlateColor);
    Configuration_parameter_set("para:plate_color",para_buff);
    memset(para_buff,0,sizeof(sreginfo.m_CarPlateColor));     //车牌颜色

    memcpy(&sreginfo. m_CarNumber[0],(char *)&mInfo.m_CarNumber[0],sizeof(mInfo.m_CarNumber));
    string car_number;
    car_number = Utils::code2string(( const char *)sreginfo. m_CarNumber,sizeof(mInfo.m_CarNumber)-1);
    memcpy(para_buff ,(char*)car_number.c_str(),car_number.length());
    Configuration_parameter_set("para:motor_plate",para_buff);
    memset(para_buff,0,sizeof(sreginfo. m_CarNumber));        //车牌标识


    appcon.do_register(sreginfo);

    settingHandler->updateRegisterAckState(UI_HEADER::REG_S1);
    sleep(1);
    settingHandler->updateRegisterAckState(UI_HEADER::REG_S2);
    sleep(1);
    settingHandler->updateRegisterAckState(UI_HEADER::REG_S3);
    sleep(1);
    settingHandler->updateRegisterAckState(UI_HEADER::REG_S4);
    sleep(1);
    settingHandler->updateRegisterAckState(UI_HEADER::REG_S6);
    sleep(1);
    settingHandler->updateRegisterAckState(UI_HEADER::REG_S7);
    sleep(1);
    settingHandler->updateRegisterAckState(UI_HEADER::REG_S8);

    dictionary *ini;
    ini = iniparser_load("/user/src/script/parameters.ini");
    if(iniparser_set(ini,"para:RegisterFlag","1") == 0);
    {
        // printf("set OK!\n");
    }

    Isregister=1;
    sleep(2);
}//      0100

void Ui_Interface::do_unregister(WIS_UI::SettingInterface *settingHandler)
{
    appcon.do_unregister();
    dictionary *ini;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    FILE *fp;
    fp = fopen("/user/src/script/parameters.ini", "w+");
    if (!fp) {
        // printf("open failed\n");
        /* */;
        fclose(fp);
    }
    int register_return = 1;
    register_return = iniparser_set(ini,"para:registerflag","0");
    if(register_return == 0)
    {
        // printf("写入成功\n");
        Isregister=0;
        iniparser_dump_ini(ini, fp);
    }
    fclose(fp);

    settingHandler->updateUnRegisterAckState(1);

}//注销  0003

void Ui_Interface:: open_swipe(){//刷卡使能标志
    RfcardReadFlag=1;
    // printf("EnableReadRFCard!");
}
void Ui_Interface:: close_swipe(){//刷卡使能标志
    RfcardReadFlag=0;
    // printf("DisableReadRFCard!");
}
//开启登出刷卡权限
void Ui_Interface::open_logout_swipe()
{
    RfcardlogoutFlag=1;
    // printf("EnableLogoutRFCard!");
}
//关闭登出刷卡权限
void Ui_Interface::close_logout_swipe()
{
    RfcardlogoutFlag=0;
    // printf("DisableLogoutRFCard!");
}
void Ui_Interface::reboot_system()
{
    Configuration_parameter_set("devicedata:pageflag","0");
    system("rm -rf /user/src/script/pageflag.ini");
    usleep(100000);
    system("rm -rf  /mnt/mmcblk0p1/SendMessageInfo.db");
    usleep(100000);
    system("rm -rf  /user/prikey.pem");
    usleep(100000);
    system("killall  DriveApp");
    sleep(1);
}

void Ui_Interface::register_statusReportHandler(WIS_UI::StatusReportInterface *reportHandler)
{
    reportHandler->updateLocatedState(0);
    CTimerStatus* test = new CTimerStatus(reportHandler);
    test->startTest();
}



/***main display info***/
UI_MainShowInfo  Ui_Interface:: get_main_display_info()
{
    UI_MainShowInfo  ui_MainShowInfo;
    memset(ui_MainShowInfo.Coach_name,0x00,32);
    memset(ui_MainShowInfo.Leaner_name,0x00,32);
    memcpy(&ui_MainShowInfo.Coach_name[0],(char*)&coachcardinfo.card_info.name[0],32);
    memcpy(&ui_MainShowInfo.Leaner_name[0],(char*)&studentcardinfo.card_info.name[0],32);
    //    ui_MainShowInfo. Coach_stars=4;     //教练星级
    ui_MainShowInfo.Totaltime = learner_login_info.maintraintime;  //总培训学时
    ui_MainShowInfo.TrainSubject = subjectcode;     //训练科目
    ui_MainShowInfo.finishtime=learner_login_info.finishtime;//19	当前培训部分已完成学时	WORD	单位：min
    ui_MainShowInfo.finishmile=learner_login_info.finishmile;//23	当前培训部分已完成里程	WORD	单位：1/10km
    return ui_MainShowInfo;

}


/*record  display info*/
UI_Learner_record Ui_Interface::get_record_info()
{
    UI_Learner_record ui_record_info;
    memset(ui_record_info.Leaner_name,0x00,32);
    memcpy(&ui_record_info.Leaner_name[0],(char*)&studentcardinfo.card_info.name[0],32);
    memset(ui_record_info.learnerid,0x00,16);
    memcpy(&ui_record_info.learnerid[0],(char*)&studentcardinfo.card_info.uniformID[0],16);
    memset(ui_record_info.coachid,0x00,16);
    memcpy(&ui_record_info.coachid[0],(char*)&coachcardinfo.card_info.uniformID[0],16);
    ui_record_info.lesson_id =  TrainLessonId ;
    memset(ui_record_info.record_time,0x00,16);
    QString timeStr = QDateTime::currentDateTime().toString(WIS_DATETIME_FORMAT_SHARK);
    memcpy(&ui_record_info.record_time[0],(char *)timeStr.toLatin1().data(),32);
    ui_record_info.subjectId = subjectcode;
    ui_record_info.max_speed = 60;
    ui_record_info.milage = (short)MainGetDistance;
    return ui_record_info;
}

/* photo name info*/
UI_CoachPhotonameSet Ui_Interface::get_coachphotoname_info()
{

    UI_CoachPhotonameSet ui_photoname;
    std::string  buff;
    if(netStatus.net_state == 0)
    {
        buff =   PhotoGetUtils::getInstance()->getCoachPath(Device_Num,QString((char*)coachcardinfo.card_info.uniformID).toStdString());
        if(buff.length()>16)
        {
            IsMainCoachPhotoPathFlag=1;
        }
        else
        {
            IsMainCoachPhotoPathFlag=0;
        }
    }
    else
    {
        IsMainCoachPhotoPathFlag=0;
    }
    memset(ui_photoname.CoachPhoto,0x00,20);
    memcpy(ui_photoname.CoachPhoto,(char*)buff.c_str(),sizeof(ui_photoname.CoachPhoto));
    return ui_photoname;
}

UI_LearnerPhotonameSet Ui_Interface::get_learnerphotoname_info()
{
    UI_LearnerPhotonameSet ui_photoname;
    std::string  buff;
    if(netStatus.net_state == 0)
    {
        buff =  PhotoGetUtils::getInstance()->getStudentPath(Device_Num,QString((char*)studentcardinfo.card_info.uniformID).toStdString());
        if(buff.length()>16)
        {
            IsMainStudentPhotoPathFlag=1;
        }else
        {
            IsMainStudentPhotoPathFlag=0;
        }
    }
    else
    {
        IsMainStudentPhotoPathFlag=0;
    }
    memset(ui_photoname.LearnerPhoto,0x00,20);
    memcpy(ui_photoname.LearnerPhoto,(char*)buff.c_str(), sizeof(ui_photoname.LearnerPhoto));
    return ui_photoname;
}

/***start train***/
void Ui_Interface:: start_train()
{
    if((coachSuccess_flag == 1)&&(stuSuccess_flag == 1))
    {
        StartTrainFlag=1;
        TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::TARIN_START);
        TimerUpload::getInstance()->stopTest();
        TimerUpload::getInstance()->startTest();
    }
    else if(coachSuccess_flag == 0)
    {
        TtsUtils:: getInstance()->sendVoice("教练登入，平台无反馈，请重新登入");
    }
    else if(stuSuccess_flag == 0)
    {
        TtsUtils:: getInstance()->sendVoice("学员登入，平台无反馈，请重新登入");
    }

}

/***pause train***/
void Ui_Interface::  pause_train()
{
    TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::TARIN_PASUE);
    StartTrainFlag=0;
}

/***stop train***/
void Ui_Interface::   stop_train(){
    TtsUtils:: getInstance()->sendVoiceStatus(TRAIN_VOICE::TARIN_STOP);
    StartTrainFlag=0;
}

/***设置音量 ***/
void Ui_Interface::  set_volume(int value)
{
    volume(value);
    char Initdata[12]={0x01, 0x01 ,0x20 ,0x73 ,0x6F ,0x75 ,0x6E ,0x64 ,0x31 ,0x32 ,0x33 ,0x20};
    usleep(1000);
    Send_Voice(Initdata,12);
}

/***获取音量***/
int Ui_Interface:: get_volume()
{
    return 5;
}

/***设置亮度***/
void Ui_Interface::   set_light(int value)
{
    //     set_pwm_period(300000);
    //     set_pwm_duty_cycle(30000*value);
    other_info.Lightness = value;
}

/***获取亮度***/
int  Ui_Interface::  get_light()
{
    return  other_info.Lightness;
}

/***设置通信参数: true: set success; false: set failed***/
bool  Ui_Interface::  set_commun_params(UI_CommunicateMainSet comPara)
{
    char para_buff[40]={0};

    commu_info.Client_Heartbeat_Sec=comPara.Client_Heartbeat_Sec;
    sprintf(para_buff,"%d",commu_info.Client_Heartbeat_Sec);
    Configuration_parameter_set("para:client_heartbeat_sec",para_buff);
    memset(para_buff,0,sizeof(commu_info.Client_Heartbeat_Sec));

    commu_info.SMS_Reply_Sec=comPara.SMS_Reply_Sec;
    sprintf(para_buff,"%d",commu_info.SMS_Reply_Sec);
    Configuration_parameter_set("para:sms_reply_sec",para_buff);
    memset(para_buff,0,sizeof(commu_info.SMS_Reply_Sec));

    commu_info.SMS_Retransmission=comPara.SMS_Retransmission;
    sprintf(para_buff,"%d",commu_info.SMS_Retransmission);
    Configuration_parameter_set("para:sms_retransmission",para_buff);
    memset(para_buff,0,sizeof(commu_info.SMS_Retransmission));

    commu_info.Tcp_Reply_Sec=comPara.Tcp_Reply_Sec;
    sprintf(para_buff,"%d",commu_info.Tcp_Reply_Sec);
    Configuration_parameter_set("para:tcp_reply_sec",para_buff);
    memset(para_buff,0,sizeof(commu_info.Tcp_Reply_Sec));

    commu_info.Tcp_Retransmission=comPara.Tcp_Retransmission;
    sprintf(para_buff,"%d",commu_info.Tcp_Retransmission);
    Configuration_parameter_set("para:tcp_retransmission",para_buff);
    memset(para_buff,0,sizeof(commu_info.Tcp_Retransmission));

    commu_info.Udp_Reply_Sec=comPara.Udp_Reply_Sec;
    sprintf(para_buff,"%d",commu_info.Udp_Reply_Sec);
    Configuration_parameter_set("para:udp_reply_sec",para_buff);
    memset(para_buff,0,sizeof(commu_info.Udp_Reply_Sec));

    commu_info.Udp_Retransmission=comPara.Udp_Retransmission;
    sprintf(para_buff,"%d",commu_info.Udp_Retransmission);
    Configuration_parameter_set("para:udp_retransmission",para_buff);
    memset(para_buff,0,sizeof(commu_info.Udp_Retransmission));

    return 1;
}

/***获取通信参数***/
UI_CommunicateMainSet  Ui_Interface::  get_commun_params()
{
    UI_CommunicateMainSet communicateMainSet;

    communicateMainSet.Client_Heartbeat_Sec = commu_info.Client_Heartbeat_Sec;
    communicateMainSet.SMS_Reply_Sec = commu_info.SMS_Reply_Sec ;
    communicateMainSet.SMS_Retransmission = commu_info.SMS_Retransmission ;
    communicateMainSet.Tcp_Reply_Sec   = commu_info.Tcp_Reply_Sec;
    communicateMainSet.Tcp_Retransmission = commu_info.Tcp_Retransmission;
    communicateMainSet.Udp_Reply_Sec = commu_info.Udp_Reply_Sec;
    communicateMainSet.Udp_Retransmission = commu_info.Udp_Retransmission;

    return communicateMainSet;
}


/***设置网络参数: true: set success; false: set failed***/
bool  Ui_Interface::  set_net_params(UI_NetSet netSet)
{
    char para_buff[40]={0};
    memcpy(&net_info.Mainserver_APN[0],(char *)&netSet.Mainserver_APN[0],sizeof(netSet.Mainserver_APN));
    memcpy(para_buff ,(char*)net_info.Mainserver_APN,sizeof(net_info.Mainserver_IP));
    Configuration_parameter_set("para:mainserver_apn",para_buff);
    memset(para_buff,0,sizeof(net_info.Mainserver_APN));

    memcpy(&net_info.Mainserver_User[0],(char *)&netSet.Mainserver_User[0],sizeof(netSet.Mainserver_User));
    memcpy(para_buff ,(char*)net_info.Mainserver_User,sizeof(net_info.Mainserver_User));
    Configuration_parameter_set("para:mainserver_user",para_buff);
    memset(para_buff,0,sizeof(net_info.Mainserver_User));

    memcpy(&net_info.Mainserver_Password[0],(char *)&netSet.Mainserver_Password[0],sizeof(netSet.Mainserver_Password));
    memcpy(para_buff ,(char*)net_info.Mainserver_Password,sizeof(net_info.Mainserver_Password));
    Configuration_parameter_set("para:mainserver_password",para_buff);
    memset(para_buff,0,sizeof(net_info.Mainserver_Password));

    memcpy(&net_info.Mainserver_IP[0],(char *)&netSet.Mainserver_IP[0],sizeof(netSet.Mainserver_IP));
    memcpy(para_buff ,(char*)net_info.Mainserver_IP,sizeof(net_info.Mainserver_IP));
    Configuration_parameter_set("para:mainserver_ip",para_buff);
    memset(para_buff,0,sizeof(net_info.Mainserver_IP));

    memcpy(&net_info.Backupserver_APN[0],(char *)&netSet.Backupserver_APN[0],sizeof(netSet.Backupserver_APN));
    memcpy(para_buff ,(char*)net_info.Backupserver_APN,sizeof(net_info.Backupserver_APN));
    Configuration_parameter_set("para:backupserver_apn",para_buff);
    memset(para_buff,0,sizeof(net_info.Backupserver_APN));

    memcpy(&net_info.Backupserver_User[0],(char *)&netSet.Backupserver_User[0],sizeof(netSet.Backupserver_User));
    memcpy(para_buff ,(char*)net_info.Backupserver_User,sizeof(net_info.Backupserver_User));
    Configuration_parameter_set("para:backupserver_user",para_buff);
    memset(para_buff,0,sizeof(net_info.Backupserver_User));

    memcpy(&net_info.Backupserver_Password[0],(char *)&netSet.Backupserver_Password[0],sizeof(netSet.Backupserver_Password));
    memcpy(para_buff ,(char*)net_info.Backupserver_Password,sizeof(net_info.Backupserver_Password));
    Configuration_parameter_set("para:backupserver_password",para_buff);
    memset(para_buff,0,sizeof(net_info.Backupserver_Password));

    memcpy(&net_info.Backupserver_IP[0],(char *)&netSet.Backupserver_IP[0],sizeof(netSet.Backupserver_IP));
    memcpy(para_buff ,(char*)net_info.Backupserver_IP,sizeof(net_info.Backupserver_IP));
    Configuration_parameter_set("para:backupserver_ip",para_buff);
    memset(para_buff,0,sizeof(net_info.Backupserver_IP));

    net_info.Server_TCP_Port=netSet.Server_TCP_Port;
    sprintf(para_buff,"%d",net_info.Server_TCP_Port);
    Configuration_parameter_set("para:server_tcp_port",para_buff);
    memset(para_buff,0,sizeof(net_info.Server_TCP_Port));

    net_info.Server_UDP_Port=netSet.Server_UDP_Port;
    sprintf(para_buff,"%d",net_info.Server_UDP_Port);
    Configuration_parameter_set("para:server_udp_port",para_buff);
    memset(para_buff,0,sizeof(net_info.Server_UDP_Port));

    return 1;

}

/***获取网络参数***/
UI_NetSet  Ui_Interface::  get_net_params()
{
    UI_NetSet netset;
    memcpy(&netset.Mainserver_APN[0],(char *)&net_info.Mainserver_APN[0],sizeof(net_info.Mainserver_APN));
    memcpy(&netset.Mainserver_User[0],(char *)&net_info.Mainserver_User[0],sizeof(net_info.Mainserver_User));
    memcpy(&netset.Mainserver_Password[0],(char *)&net_info.Mainserver_Password[0],sizeof(net_info.Mainserver_Password));
    memcpy(&netset.Mainserver_IP[0],(char *)&net_info.Mainserver_IP[0],sizeof(net_info.Mainserver_IP));
    memcpy(&netset.Backupserver_APN[0],(char *)&net_info.Backupserver_APN[0],sizeof(net_info.Backupserver_APN));
    memcpy(&netset.Backupserver_User[0],(char *)&net_info.Backupserver_User[0],sizeof(net_info.Backupserver_User));
    memcpy(&netset.Backupserver_Password[0],(char *)&net_info.Backupserver_Password[0],sizeof(net_info.Backupserver_Password));
    memcpy(&netset.Backupserver_IP[0],(char *)&net_info.Backupserver_IP[0],sizeof(net_info.Backupserver_IP));
    netset.Server_TCP_Port=net_info.Server_TCP_Port;
    netset.Server_UDP_Port=net_info.Server_UDP_Port;

    return netset;
}

/***设置汇报参数: true: set success; false: set failed***/
bool  Ui_Interface::  set_report_params(UI_ReportMainSet reportSet)
{
    char para_buff[40]={0};
    report_info.Location_Report_Way=reportSet.Location_Report_Way;
    sprintf(para_buff,"%d",report_info.Location_Report_Way);
    Configuration_parameter_set("para:location_report_way",para_buff);
    memset(para_buff,0,sizeof(report_info.Location_Report_Way));

    report_info.Location_Report_Status=reportSet.Location_Report_Status;
    sprintf(para_buff,"%d",report_info.Location_Report_Status);
    Configuration_parameter_set("para:location_report_status",para_buff);
    memset(para_buff,0,sizeof(report_info.Location_Report_Status));

    report_info.Dri_Unlisted_Time_Report=reportSet.Dri_Unlisted_Time_Report;
    sprintf(para_buff,"%d",report_info.Dri_Unlisted_Time_Report);
    Configuration_parameter_set("para:dri_unlisted_time_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Dri_Unlisted_Time_Report));

    report_info.Dormant_Time_Report=reportSet.Dormant_Time_Report;
    sprintf(para_buff,"%d",report_info.Dormant_Time_Report);
    Configuration_parameter_set("para:dormant_time_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Dormant_Time_Report));

    report_info.Emergency_Alarm_Time_Report=reportSet.Emergency_Alarm_Time_Report;
    sprintf(para_buff,"%d",report_info.Emergency_Alarm_Time_Report);
    Configuration_parameter_set("para:emergency_alarm_time_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Emergency_Alarm_Time_Report));

    report_info.Default_Time_Report=reportSet.Default_Time_Report;
    sprintf(para_buff,"%d",report_info.Default_Time_Report);
    Configuration_parameter_set("para:default_time_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Default_Time_Report));

    report_info.Default_Distance_Report=reportSet.Default_Distance_Report;
    sprintf(para_buff,"%d",report_info.Default_Distance_Report);
    Configuration_parameter_set("para:default_distance_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Default_Distance_Report));

    report_info.Dri_Unlisted_Distance_Report=reportSet.Dri_Unlisted_Distance_Report;
    sprintf(para_buff,"%d",report_info.Dri_Unlisted_Distance_Report);
    Configuration_parameter_set("para:dri_unlisted_distance_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Dri_Unlisted_Distance_Report));

    report_info.Dormant_Distance_Report=reportSet.Dormant_Distance_Report;
    sprintf(para_buff,"%d",report_info.Dormant_Distance_Report);
    Configuration_parameter_set("para:dormant_distance_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Dormant_Distance_Report));

    report_info.Emergency_Alarm_Distance_Report=reportSet.Emergency_Alarm_Distance_Report;
    sprintf(para_buff,"%d",report_info.Emergency_Alarm_Distance_Report);
    Configuration_parameter_set("para:emergency_alarm_distance_report",para_buff);
    memset(para_buff,0,sizeof(report_info.Emergency_Alarm_Distance_Report));

    report_info.Inflection_Point=reportSet.Inflection_Point;
    sprintf(para_buff,"%d",report_info.Inflection_Point);
    Configuration_parameter_set("para:inflection_point",para_buff);
    memset(para_buff,0,sizeof(report_info.Inflection_Point));

    return 1;
}

/***获取汇报参数***/
UI_ReportMainSet  Ui_Interface::  get_report_params()
{

    UI_ReportMainSet reportset;
    reportset.Default_Distance_Report=report_info.Default_Distance_Report;
    reportset.Default_Time_Report=report_info.Default_Time_Report;
    reportset.Dormant_Distance_Report=report_info.Dormant_Distance_Report;
    reportset.Dormant_Time_Report=report_info.Dormant_Time_Report;
    reportset.Dri_Unlisted_Distance_Report=report_info.Dri_Unlisted_Distance_Report;
    reportset.Dri_Unlisted_Time_Report=report_info.Dri_Unlisted_Time_Report;
    reportset.Emergency_Alarm_Distance_Report=report_info.Emergency_Alarm_Distance_Report;
    reportset.Emergency_Alarm_Time_Report=report_info.Emergency_Alarm_Time_Report;
    reportset.Inflection_Point=report_info.Inflection_Point;
    reportset.Location_Report_Status=report_info.Location_Report_Status;
    reportset.Location_Report_Way=report_info.Location_Report_Way;
    return reportset;
}

/***设置监控参数***/
bool Ui_Interface:: set_listen_params(UI_ListenMainSet listenSet)
{
    char para_buff[40]={0};
    memcpy(&monitor_info.Monitoring_Platform_Phone[0],(char *)&listenSet.Monitoring_Platform_Phone[0],sizeof(listenSet.Monitoring_Platform_Phone));
    memcpy(para_buff ,(char*)monitor_info.Monitoring_Platform_Phone,sizeof(monitor_info.Monitoring_Platform_Phone));
    Configuration_parameter_set("para:monitoring_platform_phone",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Monitoring_Platform_Phone));

    memcpy(&monitor_info.Reset_Phone[0],(char *)&listenSet.Reset_Phone[0],sizeof(listenSet.Reset_Phone));
    memcpy(para_buff ,(char*)monitor_info.Reset_Phone,sizeof(monitor_info.Reset_Phone));
    Configuration_parameter_set("para:reset_phone",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Reset_Phone));

    memcpy(&monitor_info.Factory_Reset_Phone[0],(char *)&listenSet.Factory_Reset_Phone[0],sizeof(listenSet.Factory_Reset_Phone));
    memcpy(para_buff ,(char*)monitor_info.Factory_Reset_Phone,sizeof(monitor_info.Factory_Reset_Phone));
    Configuration_parameter_set("para:factory_reset_phone",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Factory_Reset_Phone));

    memcpy(&monitor_info.Monitoring_Platform_SMS_Phone[0],(char *)&listenSet.Monitoring_Platform_SMS_Phone[0],sizeof(listenSet.Monitoring_Platform_SMS_Phone));
    memcpy(para_buff ,(char*)monitor_info.Monitoring_Platform_SMS_Phone,sizeof(monitor_info.Monitoring_Platform_SMS_Phone));
    Configuration_parameter_set("para:monitoring_platform_sms_phone",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Monitoring_Platform_SMS_Phone));

    memcpy(&monitor_info.Receiving_SMS_Alarm[0],(char *)&listenSet.Receiving_SMS_Alarm[0],sizeof(listenSet.Receiving_SMS_Alarm));
    memcpy(para_buff ,(char*)monitor_info.Receiving_SMS_Alarm,sizeof(monitor_info.Receiving_SMS_Alarm));
    Configuration_parameter_set("para:receiving_sms_alarm",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Receiving_SMS_Alarm));

    monitor_info.Terminal_Phone_Way=listenSet.Terminal_Phone_Way;
    sprintf(para_buff,"%d",monitor_info.Terminal_Phone_Way);
    Configuration_parameter_set("para:terminal_phone_way",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Terminal_Phone_Way));

    monitor_info.Phone_Time=listenSet.Phone_Time;
    sprintf(para_buff,"%d",monitor_info.Phone_Time);
    Configuration_parameter_set("para:phone_time",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Phone_Time));

    monitor_info.Phone_Time_Month=listenSet.Phone_Time_Month;
    sprintf(para_buff,"%d",monitor_info.Phone_Time_Month);
    Configuration_parameter_set("para:phone_time_month",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Phone_Time_Month));

    memcpy(&monitor_info.Monitor_Phone[0],(char *)&listenSet.Monitor_Phone[0],sizeof(listenSet.Monitor_Phone));
    memcpy(para_buff ,(char*)monitor_info.Monitor_Phone,sizeof(monitor_info.Monitor_Phone));
    Configuration_parameter_set("para:monitor_phone",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Monitor_Phone));

    memcpy(&monitor_info.Monitor_Platform_Text_Phone[0],(char *)&listenSet.Monitor_Platform_Text_Phone[0],sizeof(listenSet.Monitor_Platform_Text_Phone));
    memcpy(para_buff ,(char*)monitor_info.Monitor_Platform_Text_Phone,sizeof(monitor_info.Monitor_Platform_Text_Phone));
    Configuration_parameter_set("para:monitor_platform_text_phone",para_buff);
    memset(para_buff,0,sizeof(monitor_info.Monitor_Platform_Text_Phone));

    return 1;
}

/***获取监控参数***/
UI_ListenMainSet Ui_Interface::get_listen_params()
{
    UI_ListenMainSet monitorset;
    memcpy(&monitorset.Monitoring_Platform_Phone[0],(char *)&monitor_info.Monitoring_Platform_Phone[0],sizeof(monitor_info.Monitoring_Platform_Phone));
    memcpy(&monitorset.Reset_Phone[0],(char *)&monitor_info.Reset_Phone[0],sizeof(monitor_info.Reset_Phone));
    memcpy(&monitorset.Factory_Reset_Phone[0],(char *)&monitor_info.Factory_Reset_Phone[0],sizeof(monitor_info.Factory_Reset_Phone));
    memcpy(&monitorset.Monitoring_Platform_SMS_Phone[0],(char *)&monitor_info.Monitoring_Platform_SMS_Phone[0],sizeof(monitor_info.Monitoring_Platform_SMS_Phone));
    memcpy(&monitorset.Receiving_SMS_Alarm[0],(char *)&monitor_info.Receiving_SMS_Alarm[0],sizeof(monitor_info.Receiving_SMS_Alarm));
    monitorset.Terminal_Phone_Way=monitor_info.Terminal_Phone_Way;
    monitorset.Phone_Time=monitor_info.Phone_Time;
    monitorset.Phone_Time_Month=monitor_info.Phone_Time_Month;
    memcpy(&monitorset.Monitor_Phone[0],(char *)&monitor_info.Monitor_Phone[0],sizeof(monitor_info.Monitor_Phone));
    memcpy(&monitorset.Monitor_Platform_Text_Phone[0],(char *)&monitor_info.Monitor_Platform_Text_Phone[0],sizeof(monitor_info.Monitor_Platform_Text_Phone));

    return monitorset;
}

/***设置摄像与门限参数***/
bool Ui_Interface::set_view_thres_params(UI_ViewthresholdMainSet viewThresSet)
{
    char para_buff[40]={0};

    videolisten_info.Alarm_Shield_Byte=viewThresSet.Alarm_Shield_Byte;
    sprintf(para_buff,"%d",videolisten_info.Alarm_Shield_Byte);
    Configuration_parameter_set("para:alarm_shield_byte",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Alarm_Shield_Byte));

    videolisten_info.Alarm_Send_SMS_Text=viewThresSet.Alarm_Send_SMS_Text;
    sprintf(para_buff,"%d",videolisten_info.Alarm_Send_SMS_Text);
    Configuration_parameter_set("para:alarm_send_sms_text",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Alarm_Send_SMS_Text));

    videolisten_info.Alarm_Picture_Switch=viewThresSet.Alarm_Picture_Switch;
    sprintf(para_buff,"%d",videolisten_info.Alarm_Picture_Switch);
    Configuration_parameter_set("para:alarm_picture_switch",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Alarm_Picture_Switch));

    videolisten_info.Alarm_Picture_Save=viewThresSet.Alarm_Picture_Save;
    sprintf(para_buff,"%d",videolisten_info.Alarm_Picture_Save);
    Configuration_parameter_set("para:alarm_picture_save",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Alarm_Picture_Save));

    videolisten_info.Key_Identification=viewThresSet.Key_Identification;
    sprintf(para_buff,"%d",videolisten_info.Key_Identification);
    Configuration_parameter_set("para:key_identification",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Key_Identification));

    videolisten_info.High_Speed=viewThresSet.High_Speed;
    sprintf(para_buff,"%d",videolisten_info.High_Speed);
    Configuration_parameter_set("para:high_speed",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.High_Speed));

    videolisten_info.OverSpeed_Time=viewThresSet.OverSpeed_Time;
    sprintf(para_buff,"%d",videolisten_info.OverSpeed_Time);
    Configuration_parameter_set("para:overspeed_time",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.OverSpeed_Time));

    videolisten_info.Continue_Dri_Time=viewThresSet.Continue_Dri_Time;
    sprintf(para_buff,"%d",videolisten_info.Continue_Dri_Time);
    Configuration_parameter_set("para:continue_dri_time",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Continue_Dri_Time));

    videolisten_info.Day_Dri_Time=viewThresSet.Day_Dri_Time;
    sprintf(para_buff,"%d",videolisten_info.Day_Dri_Time);
    Configuration_parameter_set("para:day_dri_time",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Day_Dri_Time));

    videolisten_info.Mini_Reset_Time=viewThresSet.Mini_Reset_Time;
    sprintf(para_buff,"%d",videolisten_info.Mini_Reset_Time);
    Configuration_parameter_set("para:mini_reset_time",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Mini_Reset_Time));

    videolisten_info.Max_Park_Time=viewThresSet.Max_Park_Time;
    sprintf(para_buff,"%d",videolisten_info.Max_Park_Time);
    Configuration_parameter_set("para:max_park_time",para_buff);
    memset(para_buff,0,sizeof(videolisten_info.Max_Park_Time));

    return 1;

}

/***获取摄像与门限参数***/
UI_ViewthresholdMainSet Ui_Interface::get_view_thres_params()
{
    UI_ViewthresholdMainSet videolistenset;

    videolistenset.Alarm_Shield_Byte=videolisten_info.Alarm_Shield_Byte;
    videolistenset.Alarm_Send_SMS_Text=videolisten_info.Alarm_Send_SMS_Text;
    videolistenset.Alarm_Picture_Switch=videolisten_info.Alarm_Picture_Switch;
    videolistenset.Alarm_Picture_Save=videolisten_info.Alarm_Picture_Save;
    videolistenset.Key_Identification=videolisten_info.Key_Identification;
    videolistenset.High_Speed=videolisten_info.High_Speed;
    videolistenset.OverSpeed_Time=videolisten_info.OverSpeed_Time;
    videolistenset.Continue_Dri_Time=videolisten_info.Continue_Dri_Time;
    videolistenset.Day_Dri_Time=videolisten_info.Day_Dri_Time;
    videolistenset.Mini_Reset_Time=videolisten_info.Mini_Reset_Time;
    videolistenset.Max_Park_Time=videolisten_info.Max_Park_Time;

    return videolistenset;

}

/***设置其他参数***/
bool Ui_Interface::set_others_params(UI_OtherMainSet otherSet)
{
    char para_buff[40]={0};
    other_info.Picture=otherSet.Picture;
    sprintf(para_buff,"%d",other_info.Picture);
    Configuration_parameter_set("para:picture",para_buff);
    memset(para_buff,0,sizeof(other_info.Picture));

    other_info.Lightness=otherSet.Lightness;
    sprintf(para_buff,"%d",other_info.Lightness);
    Configuration_parameter_set("para:lightness",para_buff);
    memset(para_buff,0,sizeof(other_info.Lightness));

    other_info.Contrast=otherSet.Contrast;
    sprintf(para_buff,"%d",other_info.Contrast);
    Configuration_parameter_set("para:contrast",para_buff);
    memset(para_buff,0,sizeof(other_info.Contrast));

    other_info.Saturation=otherSet.Saturation;
    sprintf(para_buff,"%d",other_info.Saturation);
    Configuration_parameter_set("para:saturation",para_buff);
    memset(para_buff,0,sizeof(other_info.Saturation));

    other_info.Chroma=otherSet.Chroma;
    sprintf(para_buff,"%d",other_info.Chroma);
    Configuration_parameter_set("para:chroma",para_buff);
    memset(para_buff,0,sizeof(other_info.Chroma));

    other_info.Car_Meilage=otherSet.Car_Meilage;
    sprintf(para_buff,"%d",other_info.Car_Meilage);
    Configuration_parameter_set("para:car_meilage",para_buff);
    memset(para_buff,0,sizeof(other_info.Car_Meilage));

    other_info.Province_ID=otherSet.Province_ID;
    sprintf(para_buff,"%d",other_info.Province_ID);
    Configuration_parameter_set("para:province_id",para_buff);
    memset(para_buff,0,sizeof(other_info.Province_ID));

    other_info.City_ID=otherSet.City_ID;
    sprintf(para_buff,"%d",other_info.City_ID);
    Configuration_parameter_set("para:city_id",para_buff);
    memset(para_buff,0,sizeof(other_info.City_ID));

    //        memcpy(&other_info.Motor_Plate[0],(char *)&otherSet.Motor_Plate[0],sizeof(otherSet.Motor_Plate));
    //        memcpy(para_buff ,(char*)other_info.Motor_Plate,sizeof(other_info.Motor_Plate));
    //        Configuration_parameter_set("para:motor_plate",para_buff);
    //        memset(para_buff,0,sizeof(other_info.Motor_Plate));

    other_info.Plate_Color=otherSet.Plate_Color;
    sprintf(para_buff,"%d",other_info.Plate_Color);
    Configuration_parameter_set("para:plate_color",para_buff);
    memset(para_buff,0,sizeof(other_info.Plate_Color));

    other_info.Impulse_Ratio=otherSet.Impulse_Ratio;
    sprintf(para_buff,"%d",other_info.Impulse_Ratio);
    Configuration_parameter_set("para:impulse_ratio",para_buff);
    memset(para_buff,0,sizeof(other_info.Impulse_Ratio));

    return 1;
}

/***获取其他参数***/
UI_OtherMainSet Ui_Interface::get_others_params()
{
    UI_OtherMainSet otherset;

    otherset.Picture=other_info.Picture;
    otherset.Lightness=other_info.Lightness;
    otherset.Contrast=other_info.Contrast;
    otherset.Saturation=other_info.Saturation;
    otherset.Chroma=other_info.Chroma;
    otherset.Car_Meilage=other_info.Car_Meilage;
    otherset.Province_ID=other_info.Province_ID;
    otherset.City_ID=other_info.City_ID;
    memcpy(&otherset.Motor_Plate[0],(char *)&other_info.Motor_Plate[0],sizeof(other_info.Motor_Plate));
    otherset.Plate_Color=other_info.Plate_Color;
    otherset.Impulse_Ratio=other_info.Impulse_Ratio;

    return otherset;
}


/***设置视频参数***/
bool Ui_Interface::set_video_params(UI_VideoInfo videoSet)
{
    char para_buff[40]={0};
    mobile_param.nettype=(int)videoSet.nettype;
    sprintf(para_buff,"%d",mobile_param.nettype);
    Configuration_parameter_set("dial_param:nettype",para_buff);
    memset(para_buff,0,40);

    //    memset(mobile_param.apn,0,sizeof(mobile_param.apn));
    //    memcpy(&mobile_param.apn[0],(char *)&videoSet.apn[0],sizeof(videoSet.apn));
    memcpy(para_buff ,(char*)videoSet.apn,sizeof(videoSet.apn));
    Configuration_parameter_set("dial_param:apn",para_buff);
    memset(para_buff,0,40);

    memset(mobile_param.dial_num,0,sizeof(mobile_param.dial_num));
    memcpy(&mobile_param.dial_num[0],(char *)&videoSet.dialnum[0],sizeof(videoSet.dialnum));
    memcpy(para_buff ,(char*)mobile_param.dial_num,sizeof(mobile_param.dial_num));
    Configuration_parameter_set("dial_param:dialnum",para_buff);
    memset(para_buff,0,40);

    memset(mobile_param.passwd,0,sizeof(mobile_param.passwd));
    memcpy(&mobile_param.passwd[0],(char *)&videoSet.passwd[0],sizeof(videoSet.passwd));
    memcpy(para_buff ,(char*)mobile_param.passwd,sizeof(mobile_param.passwd));
    Configuration_parameter_set("dial_param:passwd",para_buff);
    memset(para_buff,0,40);

    mobile_param.dial_port=(int)videoSet.dial_port;
    sprintf(para_buff,"%d",mobile_param.dial_port);
    Configuration_parameter_set("dial_param:dial_port",para_buff);
    memset(para_buff,0,40);

    mobile_param.status_port=(int)videoSet.status_port;
    sprintf(para_buff,"%d",mobile_param.status_port);
    Configuration_parameter_set("dial_param:status_port",para_buff);
    memset(para_buff,0,40);

    return 1;
}

/***获取视频参数***/
UI_VideoInfo Ui_Interface::get_video_params()
{
    UI_VideoInfo  videoSet;
    videoSet.nettype = mobile_param.nettype;
    mobile_param.apn  = "unim2m.njm2mapn";
    memcpy((char *)&videoSet.apn[0],(char *)mobile_param.apn,strlen(mobile_param.apn));
    memcpy((char *)&videoSet.dialnum[0],(char *)mobile_param.dial_num,strlen(mobile_param.dial_num));
    memcpy((char *)&videoSet.passwd[0],(char *)mobile_param.passwd,strlen(mobile_param.passwd));
    videoSet.dial_port = mobile_param.dial_port;
    videoSet.status_port = mobile_param.status_port;
    return videoSet;
}


//支付
/***请求本次消费时间和金额：这里你们应该只是发出请求，具体数据值应该是回调***/
/***不能是耗时操作，耗时操作应该放在子线程中，在子线程中回调结果给我***/
bool Ui_Interface::request_train_time_and_cost(){}

/***请求刷卡支付：这里你们应该只是触发刷卡开关***/
bool Ui_Interface::request_poscard_pay()
{}

/***请求取消刷卡支付：这里你们应该只是关闭刷卡开关***/
bool Ui_Interface::request_cancel_poscard_pay()
{}

/***请求二维码支付数据***/
UI_TrainTimeCost Ui_Interface::request_qrcode_data()
{
    UI_TrainTimeCost  traincostdata;
    double postpay;
    if(subjectcode < 20)
    {
        postpay = Trainminutes*(POSTutils::getInstance()->postTwo);
    }
    else if(subjectcode >= 20)
    {
        postpay = Trainminutes*(POSTutils::getInstance()->postThree);
    }
    traincostdata.trainTime = Trainminutes;
    traincostdata.trainCost = postpay;
    memset(traincostdata.learnerid,0x00,20);
    memcpy(&traincostdata.learnerid[0],(char*)&studentcardinfo.card_info.uniformID[0],16);
    memset(traincostdata.devicenum,0x00,20);
    memcpy(&traincostdata.devicenum[0],(char *)Device_Num.c_str(),Device_Num.size());
    memset(traincostdata.subjcode,0x00,20);
    memcpy(&traincostdata.subjcode[0],(char *)subjectID.c_str(),subjectID.size());
    traincostdata.fee_count = Trainminutes;
    traincostdata.classid = TrainLessonId;
    return traincostdata;
}

/***请求二取消维码支付***/
bool Ui_Interface::request_cancel_qrcode_pay(){}

/***获取支付方式***/
int  Ui_Interface:: get_paytype()
{
    return  POSTutils::getInstance()->pay_type;
}


//注册显示模块回调指针
void Ui_Interface:: register_display_handler(WIS_UI::DisplayInterface *displayHandler)
{
    CTimerDisplay* test = new CTimerDisplay(displayHandler);
    test->startTest();
}

void para_get()
{
    /*配置文件读取*/
    dictionary *ini;
    const char *str;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    if(ini == NULL)
    {
        fprintf(stderr,"can not open %s","parameters.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(ini,stderr);                                   //save ini to stderr

    commu_info.Client_Heartbeat_Sec  = iniparser_getint(ini,"para:client_heartbeat_sec",-1);
    commu_info.SMS_Reply_Sec  = iniparser_getint(ini,"para:sms_reply_sec",-1);
    commu_info.SMS_Retransmission  = iniparser_getint(ini,"para:sms_retransmission",-1);
    commu_info.Tcp_Reply_Sec  = iniparser_getint(ini,"para:tcp_reply_sec",-1);
    commu_info.Tcp_Retransmission  = iniparser_getint(ini,"para:tcp_retransmission",-1);
    commu_info.Udp_Reply_Sec  = iniparser_getint(ini,"para:udp_reply_sec",-1);
    commu_info.Udp_Retransmission  = iniparser_getint(ini,"para:udp_retransmission",-1);

    str =  iniparser_getstring(ini,"para:mainserver_apn","null");
    memcpy(net_info.Mainserver_APN,str,strlen(str));

    str =  iniparser_getstring(ini,"para:mainserver_user","null");
    memcpy(net_info.Mainserver_User,str,strlen(str));

    str =  iniparser_getstring(ini,"para:mainserver_password","null");
    memcpy(net_info.Mainserver_Password,str,strlen(str));

    str =  iniparser_getstring(ini,"para:backupserver_apn","null");
    memcpy(net_info.Backupserver_APN,str,strlen(str));

    str =  iniparser_getstring(ini,"para:backupserver_ip","null");
    memcpy(net_info.Backupserver_IP,str,strlen(str));

    str =  iniparser_getstring(ini,"para:Backupserver_User","null");
    memcpy(net_info.Backupserver_User,str,strlen(str));

    str =  iniparser_getstring(ini,"para:backupserver_password","null");
    memcpy(net_info.Backupserver_Password,str,strlen(str));

    net_info.Server_UDP_Port  = iniparser_getint(ini,"para:server_udp_port",-1);

    report_info.Location_Report_Way  = iniparser_getint(ini,"para:location_report_way",-1);
    report_info.Location_Report_Status  = iniparser_getint(ini,"para:location_report_status",-1);
    report_info.Dri_Unlisted_Time_Report  = iniparser_getint(ini,"para:dri_unlisted_time_report",-1);
    report_info.Dormant_Time_Report  = iniparser_getint(ini,"para:dormant_time_report",-1);
    report_info.Emergency_Alarm_Time_Report  = iniparser_getint(ini,"para:emergency_alarm_time_report",-1);
    report_info.Default_Time_Report  = iniparser_getint(ini,"para:default_time_report",-1);
    report_info.Default_Distance_Report  = iniparser_getint(ini,"para:default_distance_report",-1);
    report_info.Dri_Unlisted_Distance_Report  = iniparser_getint(ini,"para:dri_unlisted_distance_report",-1);
    report_info.Dormant_Distance_Report  = iniparser_getint(ini,"para:dormant_distance_report",-1);
    report_info.Emergency_Alarm_Distance_Report  = iniparser_getint(ini,"para:emergency_alarm_distance_report",-1);
    report_info.Inflection_Point  = iniparser_getint(ini,"para:Inflection_Point",-1);

    str =  iniparser_getstring(ini,"para:monitoring_platform_phone","null");
    memcpy(monitor_info.Monitoring_Platform_Phone,str,strlen(str));

    str =  iniparser_getstring(ini,"para:reset_phone","null");
    memcpy(monitor_info.Reset_Phone,str,strlen(str));

    str =  iniparser_getstring(ini,"para:factory_reset_phone","null");
    memcpy(monitor_info.Factory_Reset_Phone,str,strlen(str));

    str =  iniparser_getstring(ini,"para:monitoring_platform_sms_phone","null");
    memcpy(monitor_info.Monitoring_Platform_SMS_Phone,str,strlen(str));

    str =  iniparser_getstring(ini,"para:receiving_sms_alarm","null");
    memcpy(monitor_info.Receiving_SMS_Alarm,str,strlen(str));
    monitor_info.Terminal_Phone_Way  = iniparser_getint(ini,"para:terminal_phone_way",-1);
    monitor_info.Phone_Time  = iniparser_getint(ini,"para:phone_time",-1);
    monitor_info.Phone_Time_Month  = iniparser_getint(ini,"para:phone_time_month",-1);

    str =  iniparser_getstring(ini,"para:monitor_phone","null");
    memcpy(monitor_info.Monitor_Phone,str,strlen(str));

    str =  iniparser_getstring(ini,"para:monitor_platform_text_phone","null");
    memcpy(monitor_info.Monitor_Platform_Text_Phone,str,strlen(str));

    videolisten_info.Alarm_Shield_Byte  = iniparser_getint(ini,"para:alarm_shield_byte",-1);
    videolisten_info.Alarm_Send_SMS_Text  = iniparser_getint(ini,"para:alarm_send_sms_text",-1);
    videolisten_info.Alarm_Picture_Switch  = iniparser_getint(ini,"para:alarm_picture_switch",-1);
    videolisten_info.Alarm_Picture_Save  = iniparser_getint(ini,"para:alarm_picture_save",-1);
    videolisten_info.Key_Identification  = iniparser_getint(ini,"para:key_identification",-1);
    videolisten_info.High_Speed  = iniparser_getint(ini,"para:high_speed",-1);
    videolisten_info.OverSpeed_Time  = iniparser_getint(ini,"para:overspeed_time",-1);
    videolisten_info.Continue_Dri_Time  = iniparser_getint(ini,"para:continue_dri_time",-1);
    videolisten_info.Day_Dri_Time  = iniparser_getint(ini,"para:day_dri_time",-1);
    videolisten_info.Mini_Reset_Time  = iniparser_getint(ini,"para:mini_reset_time",-1);
    videolisten_info.Max_Park_Time  = iniparser_getint(ini,"para:max_park_time",-1);

    other_info.Picture  = iniparser_getint(ini,"para:picture",-1);
    other_info.Lightness  = iniparser_getint(ini,"para:lightness",-1);
    other_info.Contrast  = iniparser_getint(ini,"para:contrast",-1);
    other_info.Saturation  = iniparser_getint(ini,"para:saturation",-1);
    other_info.Chroma  = iniparser_getint(ini,"para:chroma",-1);
    other_info.Car_Meilage  = iniparser_getint(ini,"para:car_meilage",-1);
    other_info.Province_ID  = iniparser_getint(ini,"para:province_id",-1);
    other_info.City_ID  = iniparser_getint(ini,"para:city_id",-1);

    str =  iniparser_getstring(ini,"para:motor_plate","null");
    memcpy(other_info.Motor_Plate,str,strlen(str));

    other_info.Plate_Color  = iniparser_getint(ini,"para:plate_color",-1);
    other_info.Impulse_Ratio  = iniparser_getint(ini,"para:impulse_ratio",-1);

    str =  iniparser_getstring(ini,"control:firmwareversion","null");
    memcpy(terminal_control_para_info.firmwareversion,str,strlen(str));

    str =  iniparser_getstring(ini,"control:netversion","null");
    memcpy(updateversion.netversion,str,strlen(str));

    str =  iniparser_getstring(ini,"control:stmversion","null");
    memcpy(updateversion.stmversion,str,strlen(str));

    appdata_setinfo.setdataspacetime  = iniparser_getint(ini,"app_data:setdataspacetime",-1);
    appdata_setinfo.uploadphotoset  = iniparser_getint(ini,"app_data:uploadphotoset",-1);
    appdata_setinfo.isreadaddcontent  = iniparser_getint(ini,"app_data:isreadaddcontent",-1);
    appdata_setinfo.misfireenddelaytime  = iniparser_getint(ini,"app_data:misfireenddelaytime",-1);
    appdata_setinfo.misfireupgnssspace  = iniparser_getint(ini,"app_data:misfireupgnssspace",-1);
    appdata_setinfo.misfirecoachlogoutdelaytime  = iniparser_getint(ini,"app_data:misfirecoachlogoutdelaytime",-1);
    appdata_setinfo.recheckidentitytime  = iniparser_getint(ini,"app_data:recheckidentitytime",-1);
    appdata_setinfo.coachcrosstech  = iniparser_getint(ini,"app_data:coachcrosstech",-1);
    appdata_setinfo.learnercrosslearn  = iniparser_getint(ini,"app_data:learnercrosslearn",-1);
    appdata_setinfo.ackspacetime  = iniparser_getint(ini,"app_data:ackspacetime",-1);

    if(Ispageflag > 0)
    {
        /*配置文件读取*/
        dictionary *iniflag;
        const char *str;
        iniflag = iniparser_load("/user/src/script/pageflag.ini");     //parser the file
        if(iniflag == NULL)
        {
            fprintf(stderr,"can not open %s","parameters.ini");
            exit(EXIT_FAILURE);
        }
        iniparser_dump(iniflag,stderr);                                   //save ini to stderr

        str =  iniparser_getstring(iniflag,"pagepara:cocardno","null");
        memcpy(coachcardinfo.card_info.cardno,str,strlen(str));

        str =  iniparser_getstring(iniflag,"pagepara:coname","null");
        string coname ;
        coname = str;
        Utils::string2code(coname,(char *)coachcardinfo.card_info.name,sizeof(coachcardinfo.card_info.name));

        str =  iniparser_getstring(iniflag,"pagepara:couniformid","null");
        memcpy(coachcardinfo.card_info.uniformID,str,strlen(str));

        str =  iniparser_getstring(iniflag,"pagepara:coidcard","null");
        memcpy(coachcardinfo.card_info.idcard,str,strlen(str));

        coachcardinfo.card_info.traintype = iniparser_getint(iniflag,"pagepara:cotraintype",-1);

        str =  iniparser_getstring(iniflag,"pagepara:cofingerprint","null");
        string cofinger ;
        cofinger = str;
        Utils::string2code(cofinger,(char *)coachcardinfo.card_info.fingerprint,sizeof(coachcardinfo.card_info.fingerprint));

        coachcardinfo.card_info.lesson2value  = iniparser_getint(iniflag,"pagepara:colesson2value",-1);
        coachcardinfo.card_info.lesson3value  = iniparser_getint(iniflag,"pagepara:colesson3value",-1);

        str =  iniparser_getstring(iniflag,"pagepara:stucardno","null");
        memcpy(studentcardinfo.card_info.cardno,str,strlen(str));

        str =  iniparser_getstring(iniflag,"pagepara:stuname","null");
        string stuname ;
        stuname = str;
        Utils::string2code(stuname,(char *)studentcardinfo.card_info.name,sizeof(studentcardinfo.card_info.name));

        str =  iniparser_getstring(iniflag,"pagepara:stuuniformid","null");
        memcpy(studentcardinfo.card_info.uniformID,str,strlen(str));

        str =  iniparser_getstring(iniflag,"pagepara:stuidcard","null");
        memcpy(studentcardinfo.card_info.idcard,str,strlen(str));

        studentcardinfo.card_info.traintype  = iniparser_getint(iniflag,"pagepara:stutraintype",-1);

        str =  iniparser_getstring(iniflag,"pagepara:stufingerprint","null");
        string stufinger ;
        stufinger = str;
        Utils::string2code(stufinger,(char *)studentcardinfo.card_info.fingerprint,sizeof(studentcardinfo.card_info.fingerprint));

        studentcardinfo.card_info.lesson2value  = iniparser_getint(iniflag,"pagepara:stulesson2value",-1);
        studentcardinfo.card_info.lesson3value  = iniparser_getint(iniflag,"pagepara:stulesson3value",-1);
        learner_login_info.maintraintime  = iniparser_getint(iniflag,"pagepara:maintraintime",-1);
        learner_login_info.finishtime  = iniparser_getint(iniflag,"pagepara:finishtime",-1);
        learner_login_info.maintrainmile  = iniparser_getint(iniflag,"pagepara:maintrainmile",-1);
        learner_login_info.finishmile  = iniparser_getint(iniflag,"pagepara:finishmile",-1);
        TrainLessonId  = iniparser_getint(iniflag,"pagepara:stutrainlessonid",-1);
        Trainminutes = iniparser_getint(iniflag,"pagepara:trainmin",-1);
        if(Trainminutes < 0)
            Trainminutes = 0;
        remaining_min = iniparser_getint(iniflag,"pagepara:remaining_min",-1);
        if(remaining_min < 0)
            remaining_min = 0;
        MainGetDistance  = iniparser_getdouble(iniflag,"pagepara:maindistance",-1);
        subjectcode =  iniparser_getint(iniflag,"pagepara:lessonID",-1);

        str =  iniparser_getstring(iniflag,"pagepara:cardno","null");
        POSTutils::getInstance()->cardnumber = str;
        POSTutils::getInstance()->pay_type  = iniparser_getint(iniflag,"pagepara:paytype",-1);
        POSTutils::getInstance()->postTwo  = iniparser_getdouble(iniflag,"pagepara:postwo",-1);
        POSTutils::getInstance()->postThree  = iniparser_getdouble(iniflag,"pagepara:posthree",-1);
    }
    if(Ispageflag == 1)
    {
        Trainminutes = 0;
        MainGetDistance = 0;
    }
}


void dir_check()
{
    Directory dir;
    string a= "\"";
    string a1 = "\\";
    string b = "find /mnt/mmcblk0p1/ -mtime +15 -name "+a+"*.jpg"+a+" -exec rm -rf {} "+a1+";";
    string c = "find /mnt/mmcblk0p1/Log -mtime +15 -name "+a+"*.txt"+a+" -exec rm -rf {} "+a1+";";
    if(dir.isExist("/mnt/mmcblk0p1/")==true)
    {
        if(dir.isExist("/mnt/mmcblk0p1/headphoto")!=true)
        {
            int  flag1= system("mkdir   \"/mnt/mmcblk0p1/headphoto\" ");
            TRACE_CYAN("\n文件夹创建成功：%d\n",flag1);
        }
        else
        {
            TRACE_CYAN("\n文件夹已经存在\n" );
        }
        CmdExecuter::getInstance()->executeNoResult(b);
        CmdExecuter::getInstance()->executeNoResult(c);
    }
    else
    {
        TRACE_CYAN("\n文件夹不存在  \n" );
    }
}

void page_check()
{
    File *fp;
    string pathnema= "/user/src/script/pageflag.ini";
    bool flage= fp->isExist(pathnema.c_str());
    if (!flage)
    {
        TRACE_CYAN("pageflag.ini  is not exsit\n");
        FILE *fp;
        fp = fopen("/user/src/script/pageflag.ini", "w+");
        dictionary *inipage;
        inipage = iniparser_load("/user/src/script/pageflag.ini");     //parser the file
        if(inipage == NULL)
        {
            fprintf(stderr,"can not open %s","pageflag.ini");
            exit(EXIT_FAILURE);
        }
        int register_return = iniparser_set(inipage,"pagepara",NULL);
        if(register_return == 0)
        {
            printf("写入成功\n");
            iniparser_dump_ini(inipage, fp);
            fclose(fp);
        }
        else
        {
            printf("写入失败\n");
            fclose(fp);
        }
    }
    else
    {
        TRACE_CYAN("pageflag.ini  is exsit\n");
    }
}
