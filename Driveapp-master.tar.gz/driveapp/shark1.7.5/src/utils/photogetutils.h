﻿#ifndef PHOTOGETUTILS_H
#define PHOTOGETUTILS_H
#include <string>
#include "HttpClient.h"
namespace PhotoType {
enum ROLETYPE{
   coach=0, student=1
};
}
class PhotoGetUtils
{
public:
    PhotoGetUtils();
    ~PhotoGetUtils();

    static PhotoGetUtils* getInstance()
    {
        static PhotoGetUtils instance;
        return &instance;
    }
    std::string httpPostDownLoad(std::string url1,std::string url2,std::string filepath,std::string namenum);
    std::string downLoadPhotoPath(std::string devnum,std::string namenum,int roletype);//终端号和教练或者学员编号
    std::string fileParseData(std::string devnum,std::string namenum,int roletype);
    std::string getCoachPath(std::string devnum,std::string namenum);//终端号和教练或者学员编号
    std::string getStudentPath(std::string devnum,std::string namenum);//终端号和教练或者学员编号
};

#endif // PHOTOGETUTILS_H
