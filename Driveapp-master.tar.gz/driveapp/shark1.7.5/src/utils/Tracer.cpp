/******************************************************************************

*******************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h> 
#include <string.h>
#include <errno.h>

#include "Tracer.h"
#include "File.h"

/***********************************************
 * 使用Tracer时必须注意:
 * 最大打印长度设为1024,由MAX_PRINT_LEN决定.
 * 如果超出此长度,print函数会异常退出
 ************************************************/
#define  MAX_PRINT_LEN  		100480

Tracer::Tracer():
m_traceLevel(TRACE_LEVEL_INFO),
m_traceEnble(true),
//m_property(NULL),
m_reloadInterval(-1)
{
}

Tracer::~Tracer()
{
    m_mainThread.cancel();
}

/**
 *  \brief  调试信息打印
 *  \param  printLevel 打印级别
 *  \param  format 格式化字串
 *  \return void
 *  \note   none
 */
void Tracer::print(int level,const char* format,...)
{
    char buf[MAX_PRINT_LEN];
    va_list argp;
    va_start(argp,format);
	
	if ((!m_traceEnble) ||
		(m_traceLevel > level) ||		/* 当前级别大于要打印级别 */
		(m_traceLevel > TRACE_LEVEL_REL))	/* 当前级别大于或等于最高可打印级别 */
	{
 		return;
	}
    write(fileno(stdout),buf,vsprintf(buf,format,argp));
	va_end(argp);
}

/**
 *  \brief  调低打印级别,打印更多信息
 *  \param  void
 *  \return void
 *  \note   none
 */
void Tracer::printMore()
{
	if (m_traceEnble &&
  	 	(m_traceLevel > TRACE_LEVEL_DBG))
  	{
		m_traceLevel--;
	}
  	printf("Trace Level[%d]-enable=%d\n",m_traceLevel,m_traceEnble);
}

/**
 *  \brief  调高打印级别,打印更少信息
 *  \param  void
 *  \return void
 *  \note   none
 */
void Tracer::printLess()
{
	if (m_traceEnble && 
		(m_traceLevel <= TRACE_LEVEL_REL))
    {
    	m_traceLevel++;
	}
  	printf("Trace Level[%d]-enable=%d\n",m_traceLevel,m_traceEnble);
}

/**
 *  \brief  设置打印级别
 *  \param  level 打印级别
 *  \return void
 *  \note   none
 */
void Tracer::setLevel(int level)
{
    if (level<0 || level>TRACE_LEVEL_REL)
    {
        return;
    }
	m_traceLevel=level;
}

/**
 *  \brief  返回当前打印级别
 *  \param  void
 *  \return it 当前打印级别
 *  \note   none
 */
int Tracer::getLevel()
{
	return m_traceLevel;
}

/**
 *  \brief  打印调试使能
 *  \param  enable 是否使能
 *  \return void
 *  \note   none
 */
void Tracer::setEnable(bool enable)
{
	m_traceEnble=enable;
}

/**
 *  \brief  当前打印时间
 *  \param  void
 *  \return char* 当前时间字符串
 *  \note   none
 */
char* Tracer::currentTime()
{
	time_t timep;
	time(&timep);
	return ctime(&timep);
}

/**
 *  \brief  调试时间桩开始
 *  \param  void
 *  \return void
 *  \note   none
 */
void Tracer::traceTimerBegin()
{
	gettimeofday(&m_startTime,NULL);
}

/**
 *  \brief  调试时间桩结束
 *  \param  void
 *  \return void
 *  \note   none
 */
void Tracer::traceTimerEnd()
{
	gettimeofday(&m_endTime,NULL);
}

/**
 *  \brief  打印调试时间桩的间隔
 *  \param  void
 *  \return void
 *  \note   none
 */
void Tracer::tracetimerDuration()
{
	int sec=m_endTime.tv_sec-m_startTime.tv_sec;
	int usec=m_endTime.tv_usec-m_startTime.tv_usec;
	if(sec<0)
	{
		return;
	}
	if(usec<0)
	{
		sec-=1;
		usec+=1000000;
	}
	printf("Trace duration : %ds.%03dms\n",sec,usec/1000);
	return ;
}

/**
 *  \brief  以16进制字串的格式打印数据
 *  \param  print_level 打印级别
 *  \param  buf 要打印的内存块地址
 *  \param  len 要打印的内存块长度
 *  \return void
 *  \note   none
 */
void Tracer::printHex(int level,const char* tag,const char* buf,int len)
{
	if ((!m_traceEnble) ||
    //	(level < m_traceLevel) ||
        NULL==tag &&
        NULL==buf ||
		len <=0)
    {
        TRACE_ERR("\n信息失败\n");
     	return;
    }
    TRACE_INFO("<HEX:%s>(%d)-[",tag,len);
	for(int i=0;i<len;i++)
	{
        TRACE_INFO("%02x",(unsigned char)(*(buf+i)));
	}
    TRACE_INFO("]\n");
}
    
void Tracer::run()
{
    while(1)
    {
        if (m_reloadInterval>0)
        {
            sleep(m_reloadInterval);
            {
                AutoLock lock(&m_propMutex);
//                if (m_property!=NULL)
//                {
//                    int level = (*m_property)["level"].toInt();
//                    if (m_traceLevel!=level) setLevel(level);
//                }
            }
        }
        else
        {
            sleep(1);
        }
    }
}
