#ifndef RTCUTILS_H
#define RTCUTILS_H
#include <stdio.h>        // for printf()
#include <sys/time.h>    // for gettimeofday()
#include <unistd.h>        // for sleep()
#include <string>
#include "RtcFacade.h"
class RtcUtils
{
public:
    RtcUtils();
    static RtcUtils* getInstance()
    {
        static RtcUtils instance;
        return &instance;
    }
    int getUtcTimeSeconds(void);
    int getUtcTimeMiliSeconds(void);
    int getUtcTime2CharArray(char * outdata );
    std:: string  getUtcTime2String(char * outdata );

    int getDayMinutes(RtcTime_S rtc);

};

#endif // RTCUTILS_H
