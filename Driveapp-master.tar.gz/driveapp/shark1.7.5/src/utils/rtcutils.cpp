﻿#include "rtcutils.h"
#include <stdio.h>        // for printf()
#include <sys/time.h>    // for gettimeofday()
#include <unistd.h>        // for sleep()
#include<time.h>
#include <string>
RtcUtils::RtcUtils()
{

}
int RtcUtils:: getUtcTimeSeconds(void){// 秒数

      struct timeval start;
     gettimeofday( &start, NULL );
//     printf("start : %d.%d\n", start.tv_sec, start.tv_usec);
       return   start.tv_sec;
}
int RtcUtils:: getUtcTimeMiliSeconds(void)//微秒数
{

   struct timeval start;  struct tm *p;
   gettimeofday( &start, NULL );
   time_t timep;
   time(&timep);
   p=localtime(&timep);
   timep = mktime(p);
    return   timep;

}
int RtcUtils:: getUtcTime2CharArray(char * outdata){
int tv_sec=    getUtcTimeMiliSeconds();
outdata[0]=(char) tv_sec>>24;
outdata[1]=(char) tv_sec>>16;
outdata[2]=(char) tv_sec>>8;
outdata[3]=(char) tv_sec ;
    return   sizeof(outdata);
}


std:: string RtcUtils:: getUtcTime2String(char * outdata ){
std::string datastr;
    int tv_sec=    getUtcTimeMiliSeconds();
outdata[0]=(char) tv_sec>>24;
outdata[1]=(char) tv_sec>>16;
outdata[2]=(char) tv_sec>>8;
outdata[3]=(char) tv_sec ;
//datastr.append(outdata[0]);
    return   datastr;
}


int RtcUtils::  getDayMinutes(RtcTime_S rtc){//获取当天分钟数

    RtcFacade::getInstance()->readTime(rtc);
    return (( rtc.m_hour *60)+rtc.m_minute);

}



void GetRealTime(unsigned char * outdata,int length){

//          RtcTime_S rtc;
//     int leng;
//                std::stringstream yearr;
//                std::stringstream monthr;
//                std::stringstream dayr;
//                std::stringstream hourr;
//                std::stringstream minuter;
//                std::stringstream secondr;
//                std::string years ;
//              std::string months ;
//              std::string days ;
//              std::string hours ;
//              std::string minutes ;
//              std::string seconds ;

//              std::string months1 ;
//              std::string days1 ;
//              std::string hours1 ;
//              std::string minutes1 ;
//              std::string seconds1 ;


//                RtcFacade::getInstance()->readTime(rtc);
//                RtcFacade::getInstance()->showTime(rtc);
//                yearr<<17;
//                yearr>>years;
//                monthr<<rtc.m_month;
//                monthr>>months;
//                dayr<<rtc.m_date;
//                dayr>>days;
//                hourr<<rtc.m_hour;
//                hourr>>hours;
//                minuter<<rtc.m_minute;
//                minuter>>minutes;
//                secondr<<rtc.m_second;
//                secondr>>seconds;


//                months1    =changehex( months);
//                days1      =changehex( days );
//                hours1     =changehex( hours );
//                minutes1   =changehex( minutes);
//                seconds1   =changehex( seconds);

//         std::string maintime;

//         switch(length){
//         case 1:
//            maintime.append(seconds1);
//             break;
//         case 2:
//             maintime.append(months1);
//             maintime.append(days1);
//           break;

//         case 3:
//             maintime.append(hours1 );
//             maintime.append(minutes1);
//             maintime.append(seconds1);

//           break;
//         case 4:
//             maintime.append(days1 );
//             maintime.append(hours1 );
//             maintime.append(minutes1);
//             maintime.append(seconds1);

//           break;

//         case 5:
//             maintime.append(months1);
//             maintime.append(days1 );
//             maintime.append(hours1 );
//             maintime.append(minutes1);
//             maintime.append(seconds1);

//           break;
//         case 6:
//             maintime.append(years);
//             maintime.append(months1);
//             maintime.append(days1 );
//             maintime.append(hours1 );
//             maintime.append(minutes1);
//             maintime.append(seconds1);

//           break;

//         }

//          unsigned char* sssa= (unsigned char*)maintime.c_str();
//         leng=  fun_char2bcd(sssa,outdata,maintime.length());

//     return leng;
//    }


}


