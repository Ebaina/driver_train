﻿#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>
//#include <crypto/evp/evp_locl.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include "rsa_op.h"
#include  <rsa.h>
#include <QByteArray>
#include <QString>
#include <cassert>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/pkcs12.h>
#include "Tracer.h"
#include "sha256.h"
RsaOperater::RsaOperater()
{

}

RsaOperater::~RsaOperater()
{

}

string RsaOperater::Basic64Encode(const unsigned char *str, int bytes)
{
    std::string _encode_result;
    const unsigned char * current;
    current = str;
    while(bytes > 2) {
        _encode_result += _base64_table[current[0] >> 2];
        _encode_result += _base64_table[((current[0] & 0x03) << 4) + (current[1] >> 4)];
        _encode_result += _base64_table[((current[1] & 0x0f) << 2) + (current[2] >> 6)];
        _encode_result += _base64_table[current[2] & 0x3f];

        current += 3;
        bytes -= 3;
    }
    if(bytes > 0)
    {
        _encode_result += _base64_table[current[0] >> 2];
        if(bytes%3 == 1) {
            _encode_result += _base64_table[(current[0] & 0x03) << 4];
            _encode_result += "==";
        } else if(bytes%3 == 2) {
            _encode_result += _base64_table[((current[0] & 0x03) << 4) + (current[1] >> 4)];
            _encode_result += _base64_table[(current[1] & 0x0f) << 2];
            _encode_result += "=";
        }
    }
    return _encode_result;
}

int RsaOperater::Base64Decode(const char *input, int length, bool with_new_line, char *out)
{
    BIO * b64 = NULL;
    BIO * bmem = NULL;
    int len2;
    b64 = BIO_new(BIO_f_base64());
    if(!with_new_line) {
        BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    }
    bmem = BIO_new_mem_buf(input, length);
    bmem = BIO_push(b64, bmem);
    len2=  BIO_read(bmem, out, length);
    BIO_free_all(bmem);
    return len2;
}


int RsaOperater:: writePrivateKeyFileFromPkcs12(std::string cadata,std::string password ){
    if (cadata.empty() || password.empty())
    {
        assert(false);
        return 0;
    }
    FILE            *fp;
    PKCS12    *p12=NULL;
    unsigned char  *p;
    int   ret;
    STACK_OF(PKCS7) *p7s;
    STACK_OF(PKCS12_SAFEBAG) *bags;
    BIO    *bp;
    X509    *cert=NULL;
    STACK_OF(X509)*ca=NULL;
    char *data2=new  char[4000];
    int len= this-> Base64Decode(cadata.c_str(),cadata.length(),false,data2);
    EVP_PKEY    *pkey=NULL;
    OpenSSL_add_all_algorithms();
    bp=BIO_new(BIO_s_file());
    BIO_set_fp(bp,stdout,BIO_NOCLOSE);
    p=( unsigned  char *)data2;
    const unsigned char * tp1=(const unsigned  char *)data2;
    d2i_PKCS12(&p12, & tp1 ,len);
    ret=PKCS12_parse(p12,password.c_str(),&pkey,&cert,&ca);
    p=(unsigned char *)data2;
    len=i2d_PrivateKey(pkey,&p);
    std::string  strPublicKey;
    strPublicKey=Basic64Encode((const unsigned char *)data2,len);
    int nPublicKeyLen = strPublicKey.size();      //strPublicKey为base64编码的公钥字符串
    for(int i = 64; i < nPublicKeyLen; i+=64)
    {
        if(strPublicKey[i] != '\n')
        {
            strPublicKey.insert(i, "\n");
        }
        i++;
    }
    strPublicKey.insert(0, "-----BEGIN RSA PRIVATE KEY-----\n");
    strPublicKey.append("\n-----END RSA PRIVATE KEY-----\n");
    fp=fopen("/user/prikey.pem","wb");
    fwrite(strPublicKey.c_str(),1,strPublicKey.length(),fp);
    fclose(fp);
    PKCS12_free(p12);
    BIO_free(bp);
    X509_free(cert);
    delete [] data2;
    pkey->pkey.rsa;
    TRACE_CYAN("写入成功"  );
    if(ret==1){
        return STATUS_OK;
    }else{
        return STATUS_ERROR;
    }
}

int RsaOperater::writePrivateKeyFileFromPkcs12(const char *cadata, int len1, const char *password, int len2)
{


    FILE            *fp;
    PKCS12    *p12=NULL;
    unsigned char  *p;
    int   ret;
    STACK_OF(PKCS7) *p7s;
    STACK_OF(PKCS12_SAFEBAG) *bags;
    BIO    *bp;
    X509    *cert=NULL;
    STACK_OF(X509)*ca=NULL;
    char *data2=new  char[4000];
    int len= this-> Base64Decode(cadata,len1,false,data2);
    EVP_PKEY    *pkey=NULL;
    OpenSSL_add_all_algorithms();
    bp=BIO_new(BIO_s_file());
    BIO_set_fp(bp,stdout,BIO_NOCLOSE);
    p=( unsigned  char *)data2;
    const unsigned char * tp1=(const unsigned  char *)data2;
    d2i_PKCS12(&p12, & tp1 ,len);
    ret=PKCS12_parse(p12,password,&pkey,&cert,&ca);
    p=(unsigned char *)data2;
    len=i2d_PrivateKey(pkey,&p);
    std::string  strPublicKey;
    strPublicKey=Basic64Encode((const unsigned char *)data2,len);
    int nPublicKeyLen = strPublicKey.size();      //strPublicKey为base64编码的公钥字符串
    for(int i = 64; i < nPublicKeyLen; i+=64)
    {
        if(strPublicKey[i] != '\n')
        {
            strPublicKey.insert(i, "\n");
        }
        i++;
    }
    strPublicKey.insert(0, "-----BEGIN RSA PRIVATE KEY-----\n");
    strPublicKey.append("\n-----END RSA PRIVATE KEY-----\n");
    fp=fopen("/user/prikey.pem","wb");
    fwrite(strPublicKey.c_str(),1,strPublicKey.length(),fp);
    fclose(fp);
    PKCS12_free(p12);
    BIO_free(bp);
    X509_free(cert);
    delete [] data2;
    pkey->pkey.rsa;
    TRACE_CYAN("写入成功"  );
    if(ret==1){
        return STATUS_OK;
    }else{
        return STATUS_ERROR;
    }
}

RSA *RsaOperater::getPrivateKeyFromPkcs12(string cadata, string password)
{
    PKCS12    *p12=NULL;RSA * rsakey=NULL;
    unsigned char  *p;
    int   ret;
    STACK_OF(PKCS7) *p7s;
    STACK_OF(PKCS12_SAFEBAG) *bags;
    BIO    *bp;
    X509    *cert=NULL;
    STACK_OF(X509)*ca=NULL;
    char *data2=new  char[4000];
    int len= this-> Base64Decode(cadata.c_str(),cadata.length(),false,data2);
    EVP_PKEY    *pkey=NULL;
    OpenSSL_add_all_algorithms();
    bp=BIO_new(BIO_s_file());
    BIO_set_fp(bp,stdout,BIO_NOCLOSE);
    p=( unsigned  char *)data2;
    const unsigned char * tp1=(const unsigned  char *)data2;
    d2i_PKCS12(&p12, & tp1 ,len);
    ret=PKCS12_parse(p12,password.c_str(),&pkey,&cert,&ca);
    p=(unsigned char *)data2;
    len=i2d_PrivateKey(pkey,&p);
    rsakey=pkey->pkey.rsa;
    //    std::string  strPublicKey;
    //    strPublicKey=Basic64Encode((const unsigned char *)data2,len);
    //    int nPublicKeyLen = strPublicKey.size();      //strPublicKey为base64编码的公钥字符串
    //    for(int i = 64; i < nPublicKeyLen; i+=64)
    //    {
    //        if(strPublicKey[i] != '\n')
    //        {
    //            strPublicKey.insert(i, "\n");
    //        }
    //        i++;
    //    }
    //    strPublicKey.insert(0, "-----BEGIN RSA PRIVATE KEY-----\n");
    //    strPublicKey.append("\n-----END RSA PRIVATE KEY-----\n");
    PKCS12_free(p12);
    BIO_free(bp);
    X509_free(cert);
    delete [] data2;
    pkey->pkey.rsa;
    if(ret==1){
        return rsakey;
    }else{
        return NULL;
    }
}

RSA *RsaOperater::getRsakeyFromFile(const string &strPemFileName)
{

    if (strPemFileName.empty() )
    {
        assert(false);
        return NULL;
    }
    RSA* pRSAPublicKey= NULL;
    BIO *key = NULL;
    key = BIO_new(BIO_s_file());
    BIO_read_filename(key, strPemFileName.c_str());
    pRSAPublicKey=PEM_read_bio_RSAPrivateKey(key, NULL, NULL, NULL);
    return pRSAPublicKey;
}

std::string RsaOperater::DecodeRSAKeyFile( const std::string& strPemFileName, const std::string& strData )
{
    if (strPemFileName.empty() || strData.empty())
    {
        assert(false);
        return "";
    }
    std::string strRet;
    RSA* pRSAPublicKey= NULL;
    BIO *key = NULL;
    key = BIO_new(BIO_s_file());
    BIO_read_filename(key, strPemFileName.c_str());
    pRSAPublicKey=PEM_read_bio_RSAPrivateKey(key, NULL, NULL, NULL);
    int nLen = RSA_size(pRSAPublicKey);
    char* pDecode = new char[nLen+1];
    int ret = RSA_public_decrypt(strData.length(), (const unsigned char*)strData.c_str(), (unsigned char*)pDecode, pRSAPublicKey, RSA_PKCS1_PADDING);
    if(ret >= 0)
    {
        strRet = std::string((char*)pDecode, ret);
    }
    delete [] pDecode;
    RSA_free(pRSAPublicKey);
    CRYPTO_cleanup_all_ex_data();
    return strRet;
}

std::string RsaOperater:: EncodeRSAKeyFile( const std::string& strPemFileName, const std::string& strData )
{
    if (strPemFileName.empty() || strData.empty())
    {
        assert(false);
        return "";
    }
    char *hash1=new char[65];
    int len1= Sha256::getInstance()->hashData((char *)strData.c_str(), strData.size() ,hash1);
    std::string strRet;
    RSA* pRSAPublicKey= NULL;
    BIO *key = NULL;
    key = BIO_new(BIO_s_file());
    BIO_read_filename(key, strPemFileName.c_str());
    pRSAPublicKey=PEM_read_bio_RSAPrivateKey(key, NULL, NULL, NULL);
    int nLen = RSA_size(pRSAPublicKey);
    char* pEncode = new char[nLen + 1];
    int ret =  RSA_private_encrypt(len1,(unsigned char *)hash1,(unsigned char*)pEncode,pRSAPublicKey,RSA_PKCS1_PADDING);
    if (ret >= 0)
    {
        strRet = std::string(pEncode, ret);
    }
    delete[] pEncode;
    delete[] hash1;
    RSA_free(pRSAPublicKey);
    CRYPTO_cleanup_all_ex_data();
    return strRet;
}

int RsaOperater::EncodeRSAKeyFileChar(const string &strPemFileName, const char *strData, int len ,char *outData)
{
    if (strPemFileName.empty()||(len==0 ) )
    {
        assert(false);
        return 0;
    }
//    TRACE_CYAN("\nstrPemFileName:%s len = %d\n",strPemFileName.c_str(), len);
    char *hash1=new char[65];
    int len1= Sha256::getInstance()->hashData((char *)strData, len ,hash1);
    RSA* pRSAPublicKey= NULL;
    BIO *key = NULL;
    key = BIO_new(BIO_s_file());
    if(key==NULL) {
        TRACE_CYAN("\nBIO_new IS Null \n");
        return -1;
    }
    BIO_read_filename(key, strPemFileName.c_str());
    pRSAPublicKey = PEM_read_bio_RSAPrivateKey(key, NULL, NULL, NULL);
    int nLen = RSA_size(pRSAPublicKey);
    char* pEncode = new char[nLen + 1];
    int ret =  RSA_private_encrypt(len1,(unsigned char *)hash1,(unsigned char*)pEncode,pRSAPublicKey,RSA_PKCS1_PADDING);
    memcpy(outData,pEncode,ret);//

    delete[] pEncode;
    delete[] hash1;
    RSA_free(pRSAPublicKey);
    CRYPTO_cleanup_all_ex_data();
    return ret;
}

string RsaOperater::decodeData(RSA *rsa, const string &strData)
{
    std::string strRet;
    int nLen = RSA_size(rsa);
    char* pDecode = new char[nLen+1];
    int ret = RSA_public_decrypt(strData.length(), (const unsigned char*)strData.c_str(), (unsigned char*)pDecode, rsa, RSA_PKCS1_PADDING);
    if(ret >= 0)
    {
        strRet = std::string((char*)pDecode, ret);
    }
    delete [] pDecode;
    CRYPTO_cleanup_all_ex_data();
    return strRet;
}

string RsaOperater::encodeDataString(RSA *rsa, const string &strData)
{     char *hash1=new char[65];
      int len1= Sha256::getInstance()->hashData((char *)strData.c_str(), strData.size() ,hash1);
        std::string strRet;
          int nLen = RSA_size(rsa);
            char* pEncode = new char[nLen + 1];
              int ret =  RSA_private_encrypt(len1,(unsigned char *)hash1,(unsigned char*)pEncode,rsa,RSA_PKCS1_PADDING);
                if (ret >= 0)
                {
                    strRet = std::string(pEncode, ret);
                }
                delete[] pEncode;
                  delete[] hash1;
                  CRYPTO_cleanup_all_ex_data();
                    return strRet;
}

string RsaOperater::encodeDataCharArray(RSA *rsa, const char *strData, int len)
{
    char *hash1=new char[65];
    int len1= Sha256::getInstance()->hashData((char *)strData , len ,hash1);
    std::string strRet;
    int nLen = RSA_size(rsa);
    char* pEncode = new char[nLen + 1];
    int ret =  RSA_private_encrypt(len1,(unsigned char *)hash1,(unsigned char*)pEncode,rsa,RSA_PKCS1_PADDING);
    if (ret >= 0)
    {
        strRet = std::string(pEncode, ret);
    }
    delete[] pEncode;
    delete[] hash1;
    CRYPTO_cleanup_all_ex_data();
    return strRet;
}

string RsaOperater::terminalSign(RSA *key, std::string &data, long timestamp)
{            std::string strRet;
             char data1[8];
                      char * data2=new char[250];
                               int len = this-> longtoBE(timestamp,data1);
                                        memcpy(data2,(char *)data.c_str(),data.length());
                                                 memcpy(&data2[data.length()],(char *)data1,len);
                                                          strRet=  this->encodeDataCharArray(key,data2,len+data.length());
                                                                   delete[] data2;
                                                                   return strRet;
}

string RsaOperater::ltos(long l)
{
    ostringstream os;
    os<<l;
    string result;
    istringstream is(os.str());
    is>>result;
    return result;
}

int   RsaOperater::longtoBE(long data,char * out )
{
    std::string  ts = ltos(data);
    if (ts.length() >= 13){
        char  buffer[8];
        buffer[0] = (char)(data >> 56);
        buffer[1] = (char)(data >> 48);
        buffer[2] = (char)(data >> 40);
        buffer[3] = (char)(data >> 32);
        buffer[4] = (char)(data >> 24);
        buffer[5] = (char)(data >> 16);
        buffer[6] = (char)(data >>  8);
        buffer[7] = (char)(data >>  0);
        memcpy(out,buffer,8);
        return 8;
    }else{
        char  buffer1[4];
        buffer1[0] = (char)(data >> 24);
        buffer1[1] = (char)(data >> 16);
        buffer1[2] = (char)(data >> 8);
        buffer1[3] = (char)(data >> 0);
        memcpy(out,buffer1,4);
        return 4;
    }

}
