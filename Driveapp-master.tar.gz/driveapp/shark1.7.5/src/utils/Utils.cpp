﻿/******************************************************************************
*******************************************************************************/
#include "Utils.h"
#include "Tracer.h"
#include "sstream"
#include "Directory.h"
#include <stdlib.h>
#include <QString>
#include <stdio.h>
#include <time.h>
#include <QFileInfo>
#include <sys/time.h>
#include <ctype.h>
#include "File.h"
#include<QPainter>
#include <QFont>
#include <QImage>
#include <QPen>
#include <string>
#include <QFile>
#include <QDateTime>
#include <QTime>
#include "app_globl.h"
#include "CmdExecuter.h"
#include "gpsdataoperate.h"
/**
 *  \brief  生成一个随机数
 *  \param  max 最大取值
 *  \return 返回随机数
 *  \note   生成一个0~max之间的随机数
 */
int Utils::random(int max)
{
    if (max<=0)
    {
        max = RAND_MAX;
    }
    struct timeval current;
    unsigned seed;
    gettimeofday(&current,NULL);
    seed = current.tv_sec+current.tv_usec;
    srand((unsigned)seed);
    return rand()%max;
}

/**
 *  \brief  判断主机是大端还是小端字节序
 *  \param  void
 *  \return 大端字节序返回true,小端字节序返回false
 *  \note   小端模式是数字的低位在低地址,大端模式是高位在低地址
 *			0x1234				---数值
 *			[0x34][0x12]---小端模式中内存存储(计算机逻辑,低地址放低位)
 *			[0x12][0x34]---大端模式中内存存储(更符合人类思维习惯)
 */
bool Utils::isBigEndian(void)
{
    union tmp_u
    {
        sint32 a;
        uint8  b;
    }tmp;
    tmp.a=0x01;
    return (tmp.b)?false:true;
}

/**
 *  \brief  将数字转换成小端字节序
 *  \param  value 16位宽的数字
 *  \return 返回转换后的数字
 *  \note   none
 */
uint16 Utils::host2LitEndian(uint16 value)
{
    uint8 size=2;
    char buf[2]={0};
    while(size>0)
    {
        *(buf+2-size) = value%256;
        value = value>>8;
        size--;
    }
    return *(uint16*)buf;
}

/**
 *  \brief  将数字转换成小端字节序
 *  \param  value 32位宽的数字
 *  \return 返回转换后的数字
 *  \note   none
 */
uint32 Utils::host2LitEndian(uint32 value)
{
    uint8 size=4;
    char buf[4]={0};
    while(size>0)
    {
        *(buf+4-size) = value%256;
        value = value>>8;
        size--;
    }
    return *(uint32*)buf;
}

/**
 *  \brief  将数字转换成大端字节序
 *  \param  value 16位宽的数字
 *  \return 返回转换后的数字
 *  \note   none
 */
uint16 Utils::host2BigEndian(uint16 value)
{
    uint8 size=2;
    char buf[2]={0};
    while(size>0)
    {
        *(buf+size-1) = value%256;
        value = value>>8;
        size--;
    }
    return *(uint16*)buf;;
}

/**
 *  \brief  将数字转换成大端字节序
 *  \param  value 32位宽的数字
 *  \return 返回转换后的数字
 *  \note   none
 */
uint32 Utils::host2BigEndian(uint32 value)
{
    uint8 size=4;
    char buf[4]={0};
    while(size>0)
    {
        *(buf+size-1) = value%256;
        value = value>>8;
        size--;
    }
    return *(uint32*)buf;
}

/**
 *  \brief  unicode编码转换为utf8编码的字符串
 *  \param  unicode 字符编码
 *  \param  utfcode 转换后的UTF8编码缓冲区(最少6字节)
 *  \return 返回转换后的字符,转换失败时返回空字符
 *  \note   none
 */
std::string Utils::unicodeOneToUtf8String(uint32 unicode)
{
    int utflen=0;
    char utf8code[7]={0};

    unicode=host2LitEndian(unicode);

    if ( unicode <= 0x0000007F )
    {
        // * U-00000000 - U-0000007F:  0xxxxxxx
        utf8code[0]     = (unicode & 0x7F);
        utflen = 1;
    }
    else if ( unicode >= 0x00000080 && unicode <= 0x000007FF )
    {
        // * U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
        utf8code[1] = (unicode & 0x3F) | 0x80;
        utf8code[0] = ((unicode >> 6) & 0x1F) | 0xC0;
        utflen = 2;
    }
    else if ( unicode >= 0x00000800 && unicode <= 0x0000FFFF )
    {
        // * U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx
        utf8code[2] = (unicode & 0x3F) | 0x80;
        utf8code[1] = ((unicode >>  6) & 0x3F) | 0x80;
        utf8code[0] = ((unicode >> 12) & 0x0F) | 0xE0;
        utflen = 3;
    }
    else if ( unicode >= 0x00010000 && unicode <= 0x001FFFFF )
    {
        // * U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
        utf8code[3] = (unicode & 0x3F) | 0x80;
        utf8code[2] = ((unicode >>  6) & 0x3F) | 0x80;
        utf8code[1] = ((unicode >> 12) & 0x3F) | 0x80;
        utf8code[0] = ((unicode >> 18) & 0x07) | 0xF0;
        utflen = 4;
    }
    else if ( unicode >= 0x00200000 && unicode <= 0x03FFFFFF )
    {
        // * U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
        utf8code[4] = (unicode & 0x3F) | 0x80;
        utf8code[3] = ((unicode >>  6) & 0x3F) | 0x80;
        utf8code[2] = ((unicode >> 12) & 0x3F) | 0x80;
        utf8code[1] = ((unicode >> 18) & 0x3F) | 0x80;
        utf8code[0] = ((unicode >> 24) & 0x03) | 0xF8;
        utflen = 5;
    }
    else if ( unicode >= 0x04000000 && unicode <= 0x7FFFFFFF )
    {
        // * U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
        utf8code[5] = (unicode & 0x3F) | 0x80;
        utf8code[4] = ((unicode >>  6) & 0x3F) | 0x80;
        utf8code[3] = ((unicode >> 12) & 0x3F) | 0x80;
        utf8code[2] = ((unicode >> 18) & 0x3F) | 0x80;
        utf8code[1] = ((unicode >> 24) & 0x3F) | 0x80;
        utf8code[0] = ((unicode >> 30) & 0x01) | 0xFC;
        utflen = 6;
    }
    std::string utf8str = utf8code;
    return utf8str;

}
/**
 *  \brief  utf8编码转换为unicode编码的字符串
 *  \param  utfcode UTF8编码(1~6字节)
 *  \return 成功返回unicode编码,失败返回0
 *  \note   none
 */
uint32 Utils::utf8OneToUnicode(const char* utf8code)
{
    // b1 表示UTF-8编码的高字节, b2 表示次高字节, ...
    uint8 b1, b2, b3, b4, b5, b6;

    uint8 utfbytes=0;
    uint8 tmp=utf8code[0];
    while((tmp&0x80)!=0)
    {
        utfbytes++;
        tmp = tmp<<1;
    }

    uint32 unicode = 0x0;
    uint8 *unibuf = (uint8*)&unicode;
    switch (utfbytes)
    {
    case 0:
        unibuf[0] = utf8code[0];
        break;
    case 2:
        b1 = utf8code[0];
        b2 = utf8code[1];
        if ((b2&0xE0) != 0x80)
        {
            return 0;
        }
        unibuf[0] = (b1<<6) + (b2&0x3F);
        unibuf[1] = (b1>>2)&0x07;
        break;
    case 3:
        b1 = utf8code[0];
        b2 = utf8code[1];
        b3 = utf8code[2];
        if (((b2&0xC0) != 0x80) ||
                ((b3&0xC0) != 0x80))
        {
            return 0;
        }
        unibuf[0] = (b2<<6) + (b3&0x3F);
        unibuf[1] = (b1<<4) + ((b2>>2)&0x0F);
        break;
    case 4:
        b1 = utf8code[0];
        b2 = utf8code[1];
        b3 = utf8code[2];
        b4 = utf8code[3];
        if (((b2&0xC0) != 0x80) ||
                ((b3&0xC0) != 0x80)  ||
                ((b4&0xC0) != 0x80))
        {
            return 0;
        }
        unibuf[0] = (b3<<6) + (b4&0x3F);
        unibuf[1] = (b2<<4) + ((b3>>2)&0x0F);
        unibuf[2] = ((b1<<2)&0x1C)  + ((b2>>4)&0x03);
        break;
    case 5:
        b1 = utf8code[0];
        b2 = utf8code[1];
        b3 = utf8code[2];
        b4 = utf8code[3];
        b5 = utf8code[4];
        if (((b2 & 0xC0) != 0x80) ||
                ((b3 & 0xC0) != 0x80)  ||
                ((b4 & 0xC0) != 0x80) || ((b5 & 0xC0) != 0x80) )
        {
            return 0;
        }
        unibuf[0] = (b4<<6) + (b5&0x3F);
        unibuf[1] = (b3<<4) + ((b4>>2)&0x0F);
        unibuf[2] = (b2<<2) + ((b3>>4)&0x03);
        unibuf[3] = (b1<<6);
        break;
    case 6:
        b1 = utf8code[0];
        b2 = utf8code[1];
        b3 = utf8code[2];
        b4 = utf8code[3];
        b5 = utf8code[4];
        b6 = utf8code[5];
        if (((b2&0xC0) != 0x80) ||
                ((b3&0xC0) != 0x80) ||
                ((b4&0xC0) != 0x80) ||
                ((b5&0xC0) != 0x80) ||
                ((b6&0xC0) != 0x80) )
        {
            return 0;
        }
        unibuf[0] = (b5<< 6) + (b6 & 0x3F);
        unibuf[1] = (b5<< 4) + ((b6 >> 2)&0x0F);
        unibuf[2] = (b3<< 2) + ((b4 >> 4)&0x03);
        unibuf[3] = ((b1<<6)&0x40) + (b2&0x3F);
        break;
    default:
        return 0;
        break;
    }
    return unicode;
}
/**
 *  \brief  将字符串转换为小写
 *  \param  str 源字符串
 *  \return 返回转换好的字符串
 *  \note   none
 */
std::string Utils::toLower(const char* str)
{
    std::string ret="";
    int i=0;
    char ch = *(str+i);
    while(ch!=0)
    {
        ret.append(1,(char)tolower(ch));
        ch = *(str+(++i));
    }
    return ret;
}
/**
 *  \brief  将字符串转换为大写
 *  \param  str 源字符串
 *  \return 返回转换好的字符串
 *  \note   none
 */
std::string Utils::toUpper(const char* str)
{
    std::string ret="";
    int i=0;
    char ch = *(str+i);
    while(ch!=0)
    {
        ret.append(1,(char)toupper(ch));
        ch = *(str+(++i));
    }
    return ret;
}

/**
 *  \brief  查找start开始与end结束的字符串
 *  \param  source 源字串
 *  \param  start 开始字串
 *  \param  end 结束字串
 *  \return 返回找到的字符串
 *  \note   none
 */
std::string Utils::findString(const string& source, const string& start, const string& end)
{
    std::string restStr;
    uint32 startPos,endPos;
    /* 找出匹配关键字 */
    startPos = source.find(start,0);
    if (startPos==string::npos)
    {
        TRACE_DEBUG("Utils::findString,no start[%s]...\n",start.c_str());
        return "";
    }

    endPos = source.find(end,1);
    if (endPos==string::npos)
    {
        TRACE_DEBUG("Utils::findString,no end[%s]...\n",end.c_str());
        return "";
    }

    return source.substr(startPos,endPos-startPos+end.size());
}

/**
 *  \brief  查找匹配字段
 *  \param  source 源字串
 *  \param  pattern 匹配字串
 *  \param  before 匹配字串之前的字串
 *  \param  after 匹配字串之后的字串
 *  \return 返回找到的字符串
 *  \note   none
 */
string Utils::findString(const string& source, const string& pattern, const string& before, const string& after)
{
    std::string restStr;
    uint32 startPos,endPos;
    /* 找出匹配关键字 */
    startPos = source.find(pattern,0);
    if (startPos==string::npos)
    {
        TRACE_DEBUG("Utils::findString,no pattern[%s]...\n",pattern.c_str());
        return "";
    }

    /* 从匹配关键字开始查找字符串 */
    restStr = source.substr(startPos);
    startPos = restStr.find(before,0);
    if (startPos==string::npos)
    {
        TRACE_DEBUG("Utils::findString,no before[%s]...\n",before.c_str());
        return "";
    }
    /* 跳过before字串 */
    startPos += before.size();
    endPos = restStr.find(after,startPos);
    if (endPos==string::npos)
    {
        TRACE_DEBUG("Utils::findString,no after[%s]...\n",after.c_str());
        return "";
    }
    /* 截取before与after之间的字串 */
    return restStr.substr(startPos,endPos-startPos);
}
/**
 *  \brief  从字符串头部去除trimch包含的字符,直至遇到非trimch字符为止
 *  \param  source 源字串
 *  \return 返回trim后得到的字符串
 *  \note   例:result = trimBeginWith(" 0001234","0 ");//result="1234"
 */
string Utils::trimBeginWith(const string& source,const string& trimch)
{
    std::string result;
    int len=source.size();
    int trimLen = trimch.size();
    int i=0;
    while(i<len)
    {
        int j;
        for(j=0;j<trimLen;j++)
        {
            if (source[i]==trimch[j])
            {
                break;
            }
        }
        if (j==trimLen)
        {
            result=source.substr(i);
            break;
        }
        i++;
    }
    return result;
}
/**
 *  \brief  去除字符串首尾两端的不可见字符
 *  \param  source 源字串
 *  \return 返回trim后得到的字符串
 *  \note   none
 */
std::string Utils::trimEndingBlank(const string& source)
{
    std::string result;
    int len=source.size();
    int i=0;
    while(i<len)
    {
        if (source[i]>32)
        {
            result=source.substr(i);
            break;
        }
        i++;
    }
    len = result.size();
    i=0;
    while(i<len)
    {
        if (result[len-1-i]>32)
        {
            result=result.substr(0,len-i);
            break;
        }
        i++;
    }
    return result;
}

/**
 *  \brief  去除字符串中所有不可见字符
 *  \param  source 源字串
 *  \return 返回trim后得到的字符串
 *  \note   none
 */
std::string Utils::trimAllBlank(const string& source)
{
    int i=0;
    int len=source.size();
    std::string result="";
    while(i<len)
    {
        if (source[i]>32)
        {
            result.append(1,source[i]);
        }
        i++;
    }
    return result;
}

/**
 *  \brief  分割字符串
 *  \param  source 源字串
 *  \return 返回分割后的字串数组
 *  \note   分割从startFlag后到endFlag之前的字串,分割符为cutFlag
 */
vector<string> Utils::cutString(const string& source,const string& startFlag,const string& endFlag,const string& cutFlag)
{
    vector<string> vecResult;
    int startPos = source.find(startFlag) + startFlag.length();
    int endPos = source.find(endFlag);

    if (source.empty())
    {
        return vecResult;
    }
    if (endPos != string::npos && endPos <= startPos)
    {
        return vecResult;
    }
    if (cutFlag.empty())
    {
        return vecResult;
    }

    string subStr;
    int subPosEnd;
    while (endPos != string::npos && endPos > startPos || endPos == string::npos)
    {
        subPosEnd = source.find(cutFlag, startPos);
        if (subPosEnd == string::npos)
        {
            if (endPos != string::npos)
                vecResult.push_back(source.substr(startPos, endPos-startPos));
            else
                vecResult.push_back(source.substr(startPos));
            break;
        }
        vecResult.push_back(source.substr(startPos, subPosEnd-startPos));
        startPos = subPosEnd + cutFlag.length();
    }
    return vecResult;
}
/**
 *  \brief  获取匹配次数
 *  \param  source 源字串
 *  \param  pattern 匹配字串
 *  \return 返回匹配次数
 *  \note   none
 */
int Utils::stringPatternCount(const string& source, const string& pattern)
{
    int atFind=0;
    int i =0;
    if(source.empty() || pattern.empty())
    {
        return 0;
    }
    while(1)
    {
        atFind = source.find(pattern,atFind);
        if(atFind!=string::npos)
        {
            atFind += pattern.size();
            i++;
        }
        else
        {
            break;
        }
    }
    return i;
}

/**
 *  \brief  ASCII码转换为数字
 *  \param  ch ASCII码字符
 *  \return ch对应的数字
 *  \note   字符'0'~'9'转换后为数字0~9,'a'~'f'或'A'~'F'转换后为10~16,其余返回值为-1
 */
sint8 Utils::ascii2digital(char ch)
{
    if(ch>='a' && ch <='f')
    {
        return (ch-'a'+0x0A);
    }
    else if(ch>='A' && ch <='F')
    {
        return (ch-'A'+0x0A);
    }
    else if(ch>='0' && ch<='9')
    {
        return (ch-'0');
    }
    else
    {
        return -1;
    }
}

char Utils:: digitHexToASCII(unsigned char  data_hex)
{
    char  ASCII_Data;
    ASCII_Data=data_hex & 0x0F;
    if(ASCII_Data<10)
        ASCII_Data=ASCII_Data+0x30; //‘0--9’
    else
        ASCII_Data=ASCII_Data+0x37;       //‘A--F’
    return ASCII_Data;
}
/**
 *  \brief  数字转换为ASCII码
 *  \param  val 数字
 *  \return 数字对应的ASCII码字符
 *  \note   数字0~9转成字符'0'~'9',数字10~16转成'A'~'F',其余返回值为0,为字符串结束符
 */
char Utils::digital2ascii(uint8 val)
{
    if(val>=0 && val<=9)
    {
        return (val+'0');
    }
    else if(val>=0x0A && val<=0x0F)
    {
        return (val-0x0A+'A');
    }
    else
    {
        return 0;
    }
}

int Utils::hex2Ascii(char *val, int len, char *data)
{
    if(len%2==0){
        int temp=len/2;
        Tracer::getInstance()->printHex(1,"d",val,len);
        TRACE_ERR("  Hex Data!\n");
        for(int i=0;i<temp;i++){
            data[i]=((Utils::digitHexToASCII(val[2*i])<<4)&0xf) |((Utils::digitHexToASCII(val[2*i+1]) )&0xf) ;//<<4|val[2*i+1]
            TRACE_ERR("%02x",data[i]);
        }
        TRACE_ERR(" \n");
        return temp;
    }
    else{
        TRACE_ERR("Error Hex Data!\n");
        return STATUS_ERROR;
    }
}

void Utils::formatString(QString &org   )
{
    int n=2; const QChar &ch=QChar(' ');
    int size= org.size();
    int space= qRound(size*1.0/n+0.5)-1;
    if(space<=0)
        return;
    for(int i=0,pos=n;i<space;++i,pos+=(n+1))
    {
        org.insert(pos,ch);
    }
}

QByteArray Utils::hexStringtoByteArray(QString hex)
{
    QByteArray ret;
    hex=hex.trimmed();
    formatString(hex );
    QStringList sl=hex.split(" ");
    foreach(QString s,sl)
    {
        if(!s.isEmpty())
            ret.append((char)s.toInt(0,16)&0xFF);
    }
    return ret;
}


/**
 *  \brief  字符串转为编码
 *  \param  codestr 待转换字符创
 *  \param  codebuf 转换好的编码缓存
 *  \param  len 缓存大小
 *  \return 成功返回code的长度,失败返回STATUS_ERROR
 *  \note   "0041001F"  ==>[0x00][0x41][0x00][0x1F]
 */
int Utils::string2code(const std::string codestr,char* codebuf,int len)
{
    int i;
    if (codestr.empty() ||
            NULL==codebuf)
    {
        TRACE_ERR("Utils::string2code parameter error.\n");
        return STATUS_ERROR;
    }
    if (len < codestr.size()/2)
    {
        TRACE_ERR("Utils::string2code buf len(%d) error.\n",len);
        return STATUS_ERROR;
    }

    for(i=0; i<codestr.size()/2; i++)
    {
        sint8 a,b;
        a=Utils::ascii2digital(codestr[2*i]);
        b=Utils::ascii2digital(codestr[2*i+1]);
        if(-1==a || -1==b)
        {
            TRACE_ERR("Utils::string2code code string error.\n");
            return STATUS_ERROR;
        }
        codebuf[i]=(a<<4)+b;
    }
    return i+1;
}

/**
 *  \brief  编码转为字符串
 *  \param  codebuf 待转换的编码缓存
 *  \param  len 缓存大小
 *  \return 成功返回转换后的字符串,失败返回空字符串
 *  \note   [0x00][0x41][0x00][0x1F]==>"0041001F"
 */
std::string Utils::code2string(const char* codebuf,int len)
{
    if (codebuf==NULL || len<=0)
    {
        TRACE_ERR("Utils::code2string parameter error.\n");
        return "";
    }

    std::string codestr="";
    for(int i=0; i<len; i++)
    {
        char code[3]={0};
        code[0] = Utils::digital2ascii((codebuf[i]>>4)&0x0F);
        code[1] = Utils::digital2ascii(codebuf[i]&0x0F);
        if (0==code[0] || 0==code[1])
        {
            TRACE_ERR("Utils::code2string unicode error.\n");
            return "";
        }
        codestr += code;
    }
    return codestr;
}
/**
 *  \brief  位反转
 *  \param
 *  \return 返回结果
 *  \note
 */
uint16 Utils::bitsReverse(uint16 ref, uint8 bits)
{
    uint16 value = 0;
    for (uint16 i=1; i<(bits+1); i++)
    {
        if (ref&0x01)
        {
            value |= 1 << (bits - i);
        }
        ref >>= 1;
    }
    return value;
}
/**
 *  \brief  将文件路径去掉
 *  \param  filePath 文件全路径
 *  \return 返回文件名
 *  \note
 */
string Utils::trimFilePath(const char* filePath)
{
    const char* pNameBegin = filePath + strlen(filePath);
    do
    {
        if (*pNameBegin == '\\' || *pNameBegin == '/')
        {
            pNameBegin++;
            break;
        }
        if (pNameBegin == filePath)
        {
            break;
        }
        pNameBegin--;
    } while (1);
    return string(pNameBegin);
}
/**
 *  \brief  算术计算函数
 *  \param  expression 算术表达式,支持整数的加减乘除及括号
 *  \return 返回计算结果
 *  \note
 */
int Utils::eval(const char* expression)
{
    return 0;
}






/**
 *  \brief  日志保存
 *  \param  filepath   路径
 *  \param  tag   标签
 *  \param  data   数据
 *  \param  length   数据长度
 *  \return 返回计算结果
 *  \note
 */
int  TrunkFile(void){
    Directory dir;

    if(dir.isExist("/mnt/mmcblk0p1/")==true){

        if(dir.isExist("/mnt/mmcblk0p1/Log")!=true){
            int  flag1= system("mkdir   \"/mnt/mmcblk0p1/Log\" ");
            TRACE_CYAN("\n文件夹创建成功：%d\n",flag1);
            return 1;
        }
    }
    else{
        return 0;
    }
}
#define CFILE_MAXSIZE		(100 * 1024)
#define CFILE_NUM			4

int Utils::LogSave(std::string filename,std::string tag,const char*   data,int length){
    std::string filepath;
    filepath = "/tmp/"+filename;
    File* file = new  File(filepath, IO_MODE_RDAPPEND_ORNEW);
    QString timeStr = QDateTime::currentDateTime().toString(WIS_DATETIME_FORMAT_WHOLE);
    std::string datawhole;
    datawhole.append("\n[ 时间：");
    datawhole.append(timeStr.toStdString());
    datawhole.append("  (");
    datawhole.append(tag+" 长度：("+Utils::intToString(length) );
    datawhole.append(")]:[");
    std::string MainPhotodata=code2string(data,length);
    datawhole.append(MainPhotodata);
    datawhole.append("]\n");
    file->writeData(datawhole.c_str(),datawhole.size());
    if(file->getSize()>CFILE_MAXSIZE)
    {
        std::string cmd_file;
        std::string rm_file;
        if( TrunkFile())
        {
            RtcTime_S  rtcTime;
            RtcFacade::getInstance()->readTime(rtcTime);
            cmd_file = "cat "  +filepath;
            cmd_file.append(" >> /mnt/mmcblk0p1/Log/");
            cmd_file.append(intToString(rtcTime.m_month));
            cmd_file.append(intToString(rtcTime.m_date));
            cmd_file.append(filename);
            //               system(cmd_file.c_str());
            CmdExecuter::executeNoResult(cmd_file);
            rm_file = "rm "+filepath;
            //               system(rm_file.c_str());
            CmdExecuter::executeNoResult(rm_file);
        }
        else
        {
            rm_file = "rm "+filepath;
            //            system(rm_file.c_str());
            CmdExecuter::executeNoResult(rm_file);
        }
    }
    file->close();
    delete  file;

}


int Utils::LogSaveFlag(std::string filename,std::string tag){
    std::string filepath;
    filepath = "/tmp/"+filename;
    File* file = new  File(filepath, IO_MODE_RDAPPEND_ORNEW);
    QString timeStr = QDateTime::currentDateTime().toString(WIS_DATETIME_FORMAT_WHOLE);
    std::string datawhole;
    datawhole.append("\n[ 时间：");
    datawhole.append(timeStr.toStdString());
    datawhole.append("  (");
    datawhole.append(tag);
    datawhole.append(")]:[");
    // std::string MainPhotodata=code2string(data,length);
    //  datawhole.append(MainPhotodata);
    datawhole.append("]\n");
    file->writeData(datawhole.c_str(),datawhole.size());
    if(file->getSize()>CFILE_MAXSIZE)
    {
        std::string cmd_file;
        std::string rm_file;
        if( TrunkFile())
        {
            RtcTime_S  rtcTime;
            RtcFacade::getInstance()->readTime(rtcTime);
            cmd_file = "cat "  +filepath;
            cmd_file.append(" >> /mnt/mmcblk0p1/Log/");
            cmd_file.append(intToString(rtcTime.m_month));
            cmd_file.append(intToString(rtcTime.m_date));
            cmd_file.append(filename);
            //            system(cmd_file.c_str());
            CmdExecuter::executeNoResult(cmd_file);
            rm_file = "rm "+filepath;
            //            system(rm_file.c_str());
            CmdExecuter::executeNoResult(rm_file);
        }
        else
        {
            rm_file = "rm "+filepath;
            //            system(rm_file.c_str());
            CmdExecuter::executeNoResult(rm_file);
        }
    }
    file->close();
    delete  file;
}


//字符串分割
vector< string> Utils::splitString( string str, string pattern)
{
    vector<string> ret;
    if(pattern.empty()) return ret;
    size_t start=0,index=str.find_first_of(pattern,0);
    while(index!=str.npos)
    {
        if(start!=index)
            ret.push_back(str.substr(start,index-start));
        start=index+1;
        index=str.find_first_of(pattern,start);
    }
    if(!str.substr(start).empty())
        ret.push_back(str.substr(start));
    return ret;
}

//int转string
std::string Utils::intToString(const int &int_temp)
{
    std::string  string_temp;
    stringstream stream;
    stream<<int_temp;
    string_temp=stream.str();   //此处也可以用 stream>>string_temp
    return string_temp;
}

string Utils::longToString(const long &long_temp)
{
    std::string  string_temp;
    stringstream stream;
    stream<<long_temp;
    string_temp=stream.str();   //此处也可以用 stream>>string_temp
    return string_temp;
}

string Utils::doubleToString(const int &double_temp)
{
    std::string  string_temp;
    stringstream stream;
    stream<<double_temp;
    string_temp=stream.str();   //此处也可以用 stream>>string_temp
    return string_temp;

}

string Utils::shortToString(const short &short_temp)
{
    std::string  string_temp;
    stringstream stream;
    stream<<short_temp;
    string_temp=stream.str();   //此处也可以用 stream>>string_temp
    return string_temp;
}

string Utils::unsignedShortToString(const unsigned short &unsignedshort_temp)
{
    std::string  string_temp;
    //    stringstream stream;
    string_temp=std::to_string(unsignedshort_temp);   //此处也可以用 stream>>string_temp
    return string_temp;
}

string Utils::unsignedCharToString(const unsigned char unsignedchar_temp)
{
    std::string  string_temp;
    int da=(int)unsignedchar_temp;
    string_temp= Utils::intToString(da);
    return string_temp;
}

string Utils::boolToString(const bool bool_temp)
{
    std::string  string_temp;
    stringstream stream;
    stream<<bool_temp;
    string_temp=stream.str();   //此处也可以用 stream>>string_temp
    return string_temp;
}

string Utils::getCurrentTime()
{
    QDateTime current_date_time = QDateTime::currentDateTime();
    QString  current_date = current_date_time.toString("yyyy-MM-dd hh:mm:ss");
    return current_date.toStdString();
}
void Utils::packageRtcGps(char *gnssdata )
{
    //    int status=0;
    //    BIT_SET(status,12)=1;//
    gnssdata[0]=0x00;
    gnssdata[1]=0x00;
    gnssdata[2]=0x00;
    gnssdata[3]=0x00;//报警标识
    gnssdata[4]=0x00;
    gnssdata[5]=0x00;
    gnssdata[6]=0x00;
    gnssdata[7]=0x02;//状态
    gnssdata[8]=Mainlantitude>>24;
    gnssdata[9]=Mainlantitude>>16;
    gnssdata[10]=Mainlantitude>>8;
    gnssdata[11]=Mainlantitude;//纬度
    //1E96721
    gnssdata[12]=Mainlontitude>>24;
    gnssdata[13]=Mainlontitude>>16;
    gnssdata[14]=Mainlontitude>>8;
    gnssdata[15]=Mainlontitude;//经度

    gnssdata[16]=(char)((MainSpeed*10)>>8);
    gnssdata[17]=(char)(MainSpeed*10);//行驶记录速度
    gnssdata[18]=(positionReport_up.carspeed*10)>>8;
    gnssdata[19]=(positionReport_up.carspeed*10);//卫星定位速度
    int direction=  positionReport_up.direction/100;
    gnssdata[20]=(direction)>>8;
    gnssdata[21]=(direction);//方向
    GMT8_Time   gtime;
    RtcTime_S  rtcTime;
    RtcFacade::getInstance()->readTime(rtcTime);
    gtime.year=rtcTime.m_year;
    gtime.month=rtcTime.m_month;
    gtime.day=rtcTime.m_date;
    gtime.hour=rtcTime.m_hour;
    gtime.minute=rtcTime.m_minute;
    gtime.second=rtcTime.m_second;
    TRACE_CYAN("方向角度：%d\n",(positionReport_up.direction/100));
    Utils::time2BCD(gtime,(char *)&gnssdata[22],6);
    gnssdata[28]=0x05;
    gnssdata[29]=0x02;
    gnssdata[30]=(wis_u8)(MainRpm>>8);
    gnssdata[31]=(wis_u8)(MainRpm);

}

void Utils::packageRtcGpsFoTrainRecord(char *gnssdata, string time, int index)
{
    gnssdata[0]=0x00;
    gnssdata[1]=0x00;
    gnssdata[2]=0x00;
    gnssdata[3]=0x00;//报警标识
    gnssdata[4]=0x00;
    gnssdata[5]=0x00;
    gnssdata[6]=0x00;
    gnssdata[7]=0x02;//状态
    gnssdata[8]=Mainlantitude>>24;
    gnssdata[9]=Mainlantitude>>16;
    gnssdata[10]=Mainlantitude>>8;
    gnssdata[11]=Mainlantitude;//纬度
    //1E96721
    gnssdata[12]=Mainlontitude>>24;
    gnssdata[13]=Mainlontitude>>16;
    gnssdata[14]=Mainlontitude>>8;
    gnssdata[15]=Mainlontitude;//经度

    gnssdata[16]=(char)((MainSpeed*10)>>8);
    gnssdata[17]=(char)(MainSpeed*10);//行驶记录速度
    gnssdata[18]=(positionReport_up.carspeed*10)>>8;
    gnssdata[19]=(positionReport_up.carspeed*10);//卫星定位速度
    gnssdata[20]=(positionReport_up.direction/100)>>8;
    gnssdata[21]=(positionReport_up.direction/100);//方向

    GMT8_Time   gtime;
    QDateTime qdate=  Utils::getBeforMinitues2Qdate(time,index);
    Utils::printString(PrintLevel::INFO,"学时记录GPS时间："+qdate.toString("yyyy-MM-dd hh:mm:ss").toStdString());
    gtime.year=qdate.date().year();
    gtime.month=qdate.date().month();
    gtime.day=qdate.date().day();
    gtime.hour=qdate.time().hour();
    gtime.minute=qdate.time().minute();
    gtime.second=qdate.time().second();
    Utils::time2BCD(gtime,(char *)&gnssdata[22],6);


}
void Utils::packageGps(char *gnssdata )
{
    gnssdata[0]=0x00;
    gnssdata[1]=0x00;
    gnssdata[2]=0x00;
    gnssdata[3]=0x00;//报警标识
    gnssdata[4]=0x00;
    gnssdata[5]=0x00;
    gnssdata[6]=0x00;
    gnssdata[7]=0x00;//状态
    gnssdata[8]=Mainlantitude>>24;
    gnssdata[9]=Mainlantitude>>16;
    gnssdata[10]=Mainlantitude>>8;
    gnssdata[11]=Mainlantitude;//纬度
    //1E96721
    gnssdata[12]=Mainlontitude>>24;
    gnssdata[13]=Mainlontitude>>16;
    gnssdata[14]=Mainlontitude>>8;
    gnssdata[15]=Mainlontitude;//经度

    gnssdata[16]=(MainSpeed*10)>>8;
    gnssdata[17]=(MainSpeed*10);//行驶记录速度
    gnssdata[18]=(positionReport_up.carspeed*10)>>8;
    gnssdata[19]=(positionReport_up.carspeed*10);//卫星定位速度
    gnssdata[20]=(positionReport_up.direction/100)>>8;
    gnssdata[21]=(positionReport_up.direction/100);//方向

    GMT8_Time   gtime;
    minmea_sentence_rmc *gp;
    gp= GpsDataOperate::getInstance()->getData();
    gtime.year=gp->date.year;   //rmc_frame.date.year
    gtime.month=gp->date.month;
    gtime.day=gp->date.day;
    gtime.hour=gp->time.hours;
    gtime.minute=gp->time.minutes;
    gtime.second=gp->time.seconds;
    Utils::UTC2GMT8(gtime);
    Utils::time2BCD(gtime,(char *)&gnssdata[22],6);
}
string Utils::changeBcdData2Time(const char *bcd, int len)
{
    std::string temp;
    if(len==7){
        temp=Utils::code2string(bcd,len);
        //:2017-06-15 18:14:43
        TRACE_ERR("hex:%s",temp.c_str());
        std::string time ;
        time.append("20");
        time.append(temp.substr(0,2));
        time.append("-");
        time.append(temp.substr(2,2));
        time.append("-");
        time.append(temp.substr(4,2));
        time.append(" ");
        time.append(temp.substr(6,2));
        time.append(":");
        time.append(temp.substr(8,2));
        time.append(":");
        time.append(temp.substr(10,2));
        return time;
    }
    if(len==5){
        temp=Utils::code2string(bcd,len);
        //:2017-06-15 18:14:43 0718090038
        TRACE_ERR("hex:%s",temp.c_str());
        string time1 ;
        time1.append("20");
        time1.append("17");
        time1.append("-");
        time1.append(temp.substr(0,2));
        time1.append("-");
        time1.append(temp.substr(2,2));
        time1.append(" ");
        time1.append(temp.substr(4,2));
        time1.append(":");
        time1.append(temp.substr(6,2));
        time1.append(":");
        time1.append(temp.substr(8,2));
        return time1;
    }
    else
    {
        return "2017-00-00 00:00:00";
    }
}

/**************************
***filename ：照片路径
*** typeMan  0教练  1学员
*** speed  车子速度
*** X  经度，Y 维度
***************************/
//static ImageCallback  g_callback = 0;
//static void *g_opaque = 0;
//bool Utils::  addTextIntoImage(const QString &filename, int typeMan, int speed, double x, double y)
//{

//    if(g_callback) {
//        UI_PhotoAddWater water;
//        water.gpsspeed = speed;
//        water.lantitude = x;
//        water.lontitude = y;
//        water.roletype = typeMan;
//        water.photopath = filename.toStdString();
//        TRACE_INFO("\naddTextIntoImage\n");
//        g_callback(&water,g_opaque);
//    }
//}

//void Utils::registerWaterCallback(ImageCallback cb, void *opaque)
//{
//    g_opaque = opaque;
//    g_callback = cb;
//}



//UTC转北京时间
void  Utils::UTC2GMT8(   GMT8_Time &time)
{
    time.hour += 8;

    if(time.month==1||time.month==3||time.month==5||time.month==7||time.month==8||time.month==10||time.month==12)//1,3,5,7,8,9,12月每月为31天
    {
        if(time.hour >= 24)
        {
            time.hour -= 24;time.day += 1;//如果超过24小时，减去24小时，后再加上一天
            if(time.day > 31){time.day -= 31;time.month += 1;}//如果超过31一天，减去31天，后加上一个月
        }
    }
    else if(time.month==4||time.month==6||time.month==9||time.month==11)//4，6，9，11月每月为30天
    {
        if(time.hour >= 24)
        {
            time.hour -= 24;time.day += 1;//如果超过24小时，减去24小时，后再加上一天
            if(time.day > 30){time.day -= 30;time.month += 1;}//如果超过30一天，减去30天，后加上一个月
        }
    }
    else//剩下为2月，闰年为29天，平年为28天
    {
        if(time.hour >= 24)
        {
            time.hour -= 24;time.day += 1;
            if((time.year%400 == 0)||(time.year%4 == 0 && time.year%100 != 0))//判断是否为闰年，年号能被400整除或年号能被4整除，而不能被100整除为闰年
            {if(time.day > 29){time.day -= 29;time.month += 1;}}//为闰年
            else{if(time.day > 28){time.day -= 28;time.month += 1;}}//为平年
        }
    }

}

int Utils::DectoBCD(int Dec, char *Bcd, int length)
{
    int i;
    int temp;
    for (i = length - 1; i >= 0; i--)
    {
        temp = Dec % 100;
        Bcd[i] = ((temp / 10) << 4) + ((temp % 10) & 0x0F);
        Dec /= 100;
    }
    return 0;

}

int Utils::time2BCD(GMT8_Time &time, char *Bcd, int length)
{
    if(length==6){

        Utils::DectoBCD(time.year,&Bcd[0],1 );
        Utils::DectoBCD(time.month,&Bcd[1],1);
        Utils::DectoBCD(time.day,&Bcd[2],1);
        Utils::DectoBCD(time.hour,&Bcd[3],1);
        Utils::DectoBCD(time.minute,&Bcd[4],1);
        Utils::DectoBCD(time.second,&Bcd[5],1);
        return length;
    }
    else{

        return  STATUS_ERROR;
    }

}
/*两个字符转换成一个字符，长度为原来的1/2*/
void Utils::Hex2Char(char *szHex, unsigned char *rch)
{
    int i;
    for(i=0; i<2; i++)
    {
        if(*(szHex + i) >='0' && *(szHex + i) <= '9')
            *rch = (*rch << 4) + (*(szHex + i) - '0');
        else if(*(szHex + i) >='a' && *(szHex + i) <= 'f')
            *rch = (*rch << 4) + (*(szHex + i) - 'a' + 10);
        else
            break;
    }
}


/*十六进制char* 转 Binary char*函数*/
int  Utils::HexStr2CharStr( char *pszHexStr, int iSize,  char *pucCharStr)
{
    int i;
    unsigned char ch;
    if (iSize%2 != 0) return 0;
    for(i=0; i<iSize/2; i++)
    {
        Hex2Char(pszHexStr+2*i, &ch);
        pucCharStr[i] = ch;
    }
    return iSize/2;
}

void Utils::printCurrentTime()
{   RtcTime_S rtcTime;
    RtcFacade::getInstance()->readTime(rtcTime);
    //    TRACE_IF("时间戳");
    //    TRACE_INFO ("%d.%d.%d-%d:%d:%d\n", rtcTime.m_year, rtcTime.m_month, rtcTime.m_date, rtcTime.m_hour, rtcTime.m_minute, rtcTime.m_second);
    RtcFacade::getInstance()->showTime(rtcTime);
}

int Utils::updatefromGps( RtcTime_S& rtcTime)
{
    GMT8_Time   gtime;
    minmea_sentence_rmc  *rmc_temp=  (GpsDataOperate::getInstance()->getData());

    gtime.year=rmc_temp->date.year;
    gtime.month=rmc_temp->date.month;
    gtime.day=rmc_temp->date.day;
    gtime.hour=rmc_temp->time.hours;
    gtime.minute=rmc_temp->time.minutes;
    gtime.second=rmc_temp->time.seconds;
    Utils::UTC2GMT8(  gtime);
    if(gtime.year>2000){
        rtcTime.m_year= gtime.year;}
    else{
        rtcTime.m_year= gtime.year+2000;
    }
    rtcTime.m_month=gtime.month;
    rtcTime.m_date=gtime.day;
    rtcTime.m_hour=gtime.hour ;
    rtcTime.m_minute=gtime.minute;
    rtcTime.m_second=gtime.second;
}

int Utils::UpdateSysClock(RtcTime_S& rtcTime)
{
    TRACE_INFO("\n更新RTC时间\n");
    int status= RtcFacade::getInstance()->writeTime(rtcTime);
    TRACE_INFO("\n更新系统时间\n");
    CmdExecuter::getInstance()->executeNoResult("hwclock -s");//hwclock –s
    sleep(1);
    TRACE_INFO("\n系统授时完成！\n");
    return status;
}

int updateTimeflag=0;
int Utils::updateWholeClockFromGps(minmea_sentence_rmc &rmc_temp)
{
    if(updateTimeflag==0){
        if(rmc_temp.valid==true){
            RtcTime_S  rtcTime;
            Utils::updatefromGps(rtcTime);
            Utils::UpdateSysClock(rtcTime);
            updateTimeflag=0xff;
        }
    }
}



void Utils::printString(int level, string str )
{
    switch(level){
    case PrintLevel::REL: //TRACE_REL("\n" );
        TRACE_REL("%s",str.c_str());TRACE_REL("\n" );
        break;
    case PrintLevel::DEBUG: //TRACE_DEBUG("\n" );
        TRACE_DEBUG("%s",str.c_str());TRACE_DEBUG("\n" );
        break;
    case PrintLevel::INFO:
        TRACE_INFO("%s",str.c_str());TRACE_INFO("\n" );
        break;
    case PrintLevel::ERR:
        TRACE_ERR("%s",str.c_str());TRACE_ERR("\n" );
        break;
    default:
        TRACE_INFO("%s",str.c_str());TRACE_INFO("\n" );
        break;
    }
}

string Utils::rtc2String(RtcTime_S &rtcTime)
{
    string da;
    da.append(std::to_string(rtcTime.m_year));
    da.append(" ");
    da.append(std::to_string(rtcTime.m_month));
    da.append("-");
    da.append(std::to_string(rtcTime.m_date));
    da.append(" ");
    da.append(std::to_string(rtcTime.m_hour));
    da.append(":");
    da.append(std::to_string(rtcTime.m_minute));
    da.append(":");
    da.append(std::to_string(rtcTime.m_second));
    return da;
}

string Utils::getBeforMinitues(std::string time,int minute)
{
    QDateTime time_new = QDateTime::fromString(QString::fromStdString(time), "yyyy-MM-dd hh:mm:ss");
    QString BeforeDaystr=time_new.addSecs(minute*60).toString("yyyy-MM-dd hh:mm:ss");//获取前一天时间
    return BeforeDaystr.toStdString();
}

QDateTime Utils::getBeforMinitues2Qdate(string time, int minute)
{
    QDateTime time_new =QDateTime::fromString(QString::fromStdString(time), "yyyy-MM-dd hh:mm:ss");
    return time_new.addSecs(minute*60);
}


string Utils::getBeforDay(int day)//
{
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString BeforeDaystr=time.addDays(-day).toString("yyyyMMdd");//获取前一天时间
    return BeforeDaystr.toStdString();
}

string Utils::getBeforMonth(int month)
{
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString BeforeDaystr=time.addMonths(-month).toString("yyyyMM");//获取前一天时间
    return BeforeDaystr.toStdString();
}
string Utils::deletPhotoBeforMoth(int start,int month)//start保存几天的，之前day的删除
{
    for(int i=start;i<month+start;i++)
    {
        std::string  photodel ;
        photodel=Utils::getBeforMonth(i);
        std::string exestr="rm -rf /mnt/mmcblk0p1/"+photodel+"*.jpg";
        Utils::printString(PrintLevel::INFO,"删除照片:"+ exestr);
        //         system(exestr.c_str());//
        //          CmdExecuter::getInstance()->executeNoResult( exestr);//
        QFile::remove(QString::fromStdString( photodel));
        Utils::printString(PrintLevel::INFO,"删除照片"+std::to_string(i)+" "+photodel);
        usleep(10000);
    }
}

string Utils::deletPhotoBeforDay(int start,int day)//start保存几天的，之前day的删除
{
    for(int i=start;i<=day+start;i++)
    {
        std::string  photodel ;
        photodel=Utils::getBeforDay(i);
        CmdExecuter::getInstance()->executeNoResult("rm /mnt/mmcblk0p1/"+photodel+"*.jpg");//
        Utils::printString(PrintLevel::INFO,"删除照片"+std::to_string(i)+" "+photodel);
        usleep(10000);
    }
}

void Utils::setGTimeAddSeconds(std::string &time,GMT8_Time &gtime,int data)
{
    QDateTime time1 =  QDateTime::fromString(QString::fromStdString(time), "yyyy-MM-dd hh:mm:ss");//获取系统现在的时间
    QDateTime time2=time1.addSecs(data) ;//获取前一天时间
    gtime.year=time2.date().year();
    gtime.month=time2.date().month();
    gtime.day=time2.date().day();
    gtime.hour=time2.time().hour();
    gtime.minute=time2.time().minute();
    gtime.second=time2.time().second();

}

string Utils::getPhotoNumFromTime(string &time)
{
    std::string str;
    QDateTime rtcTime =  QDateTime::fromString(QString::fromStdString(time), "yyyy-MM-dd hh:mm:ss");//获取系统现在的时间
    char buf[64]={0};
    sprintf(buf,"%02d%02d%02d%02d%02d", rtcTime.date().month(), rtcTime.date().day(), rtcTime.time().hour(), rtcTime.time().minute(), rtcTime.time().second() );
    str=buf;
    return str;
}

int Utils::countMinutes(string start, string stop)
{
    int data=  Utils::countSenconds(  start,   stop)/60;
    return data;    // 结果为Minutes
}

int Utils::countSenconds(string start, string stop)
{
    // 从字符串转换为毫秒（需完整的年月日时分秒）

    QDateTime startTime =  QDateTime::fromString(QString::fromStdString(start), "yyyy-MM-dd hh:mm:ss") ;
    QDateTime endTime =    QDateTime::fromString(QString::fromStdString(stop), "yyyy-MM-dd hh:mm:ss") ;
    return   startTime.secsTo(endTime)   ;    // 结果为S

}
void Utils::addBitValue(unsigned int &value, int index)
{
    unsigned int pos = 1 <<index;
    value |= pos;                // 111111﻿

}
void Utils::removeBitValue(unsigned int &value, int index)
{
    unsigned  int pos = 0 << index;
    value |= pos;                // 111111﻿
}

void Utils::addBitValueShort(unsigned short &value, int index)
{
    unsigned short  pos = 1 << index;
    value |= pos;
}

void Utils::removeBitValueShort(unsigned short &value, int index)
{
    unsigned short  pos = 0 << index;
    value |= pos;
}


