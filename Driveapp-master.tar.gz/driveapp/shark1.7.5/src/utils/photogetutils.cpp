﻿#include "photogetutils.h"
#include"JSONData.h"
#include <QByteArray>
#include <QImage>
#include <QString>
#include<Tracer.h>
#include"app_globl.h"
PhotoGetUtils::PhotoGetUtils()
{

}
PhotoGetUtils::~PhotoGetUtils()
{

}
std::string PhotoGetUtils:: httpPostDownLoad(std::string url1,std::string url2,std::string filepath,std::string namenum){
    HttpClient* client = new HttpClient();
    std::string pathname;
    File* file = new  File(filepath, IO_MODE_REWR_ORNEW);
    int flag= client->httpPost(url1,url2,file,6000);
    TRACE_RED("照片路径：\n");
    cout<<url1<<endl;
    cout<<url2<<endl;
    if(flag==0){
        file->close();
        JSONData json;
        JSONNode* rootNode= json.initWithContentOfFile(filepath);
        if(rootNode!=NULL)
        {
            JSONNode  node2 = (*rootNode)["errorcode"] ;
            int erorflag=9;
            erorflag=node2.toInt();
            TRACE_RED("errorcode:%d\n",node2.toInt());
            if(erorflag==0){
                JSONNode node = (*rootNode)["data"]["fileName"];
                QByteArray tempArray = QByteArray::fromBase64(QByteArray(node.toString().c_str() ));
                QImage qimagedata=QImage::fromData(tempArray,"JPEG");
                pathname.append(namenum);
                pathname.append(".jpg");
                qimagedata.save("/mnt/mmcblk0p1/headphoto/"+QString::fromStdString(pathname),"JPEG");
                delete file ;
                delete client ;
            }
        }
        else
        {
            pathname.clear();delete client ; delete file ;
        }

    }
    return pathname;
}


std::string PhotoGetUtils:: downLoadPhotoPath(std::string devnum,std::string namenum,int roletype) //终端号和教练或者学员编号
{
    std::string pathname;
//    TRACE_CYAN("\nIP地址：\n");
//    QString Mainserver_IPstring=QString((char * )net_info.Mainserver_IP);
//    cout<<Mainserver_IPstring.toStdString()<<endl;
    std::string url1="http://api.driving.1dianxueche.com/driving";              //"http://"+Mainserver_IPstring.toStdString();
    std::string url2;
    QString pathnema=QString::fromStdString( "/mnt/mmcblk0p1/headphoto/"+namenum+".jpg");
    File  *file;
    bool flage= file->isExist(pathnema.toLatin1().data());
    if(flage==true)
    {
        pathname.append(namenum+".jpg");//照片已经存在，无需下载
        TRACE_CYAN("\n照片已经存在，无需下载\n");  //照片已经存在，无需下载
    }
    else
    {
        //        url1.append(":");
        //        url1.append(http_port);//8080
        //        url1.append("/");
        //        url1.append(http_url);
        switch(roletype)
        {
        case 0:
            url1.append("/tcpimgs/coach?") ;           //  /v1/drving
            url2.append("coachNum=");
            url2.append( namenum);
            url2.append("&devnum=");
            url2.append(devnum);
            pathname=httpPostDownLoad(url1,url2,"/tmp/coach.dat",namenum);
            break;
        case 1:
            url1.append( "/tcpimgs/student?") ;    // /v1/drving
            url2.append("stuNum=");
            url2.append(namenum);
            url2.append("&devnum=");
            url2.append(devnum);
            pathname=httpPostDownLoad(url1,url2,"/tmp/student.dat",namenum);
            break;
        }
    }
    return  pathname;
}
std::string PhotoGetUtils:: getCoachPath(std::string devnum,std::string namenum) //终端号和教练或者学员编号
{
    std::string pathname;
    pathname=downLoadPhotoPath(devnum,namenum,PhotoType::coach);
    if(pathname.length()>16){
        IsMainCoachPhotoPathFlag=1;
        TRACE_CYAN("\n教练照片标志:%d\n",IsMainCoachPhotoPathFlag);
    }else{
        IsMainCoachPhotoPathFlag=0;
        TRACE_CYAN("\n教练照片标志:%d\n",IsMainCoachPhotoPathFlag);
    }
    TRACE_CYAN("\n教练照片路径：\n");
    cout<<pathname<<endl;
    return  pathname;
}
std::string PhotoGetUtils:: getStudentPath(std::string devnum,std::string namenum) //终端号和教练或者学员编号
{
    std::string pathname;
    pathname=downLoadPhotoPath(devnum,namenum,PhotoType::student);
    if(pathname.length()>16){
        IsMainStudentPhotoPathFlag=1;
        TRACE_CYAN("\n学员照片标志：:%d\n",IsMainCoachPhotoPathFlag);
    }else{
        IsMainStudentPhotoPathFlag=0;
        TRACE_CYAN("\n学员照片标志：:%d\n",IsMainCoachPhotoPathFlag);
    }

    TRACE_CYAN("\n学员照片路径：\n");
    cout<<pathname<<endl;
    return  pathname;
}
