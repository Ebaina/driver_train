﻿#include "public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <sys/time.h>
#include <string>
#include "RtcFacade.h"
#include <string>
#include<iostream>
#include<sstream>
#include"app_globl.h"
wis_u8	dataHead[2] ={0xAA,0xBB};
wis_u8	dataRear[2] ={0x99,0xFF};
char CRC8Table[]={
    0, 94, 188, 226, 97, 63, 221, 131, 194, 156, 126, 32, 163, 253, 31, 65,
    157, 195, 33, 127, 252, 162, 64, 30, 95, 1, 227, 189, 62, 96, 130, 220,
    35, 125, 159, 193, 66, 28, 254, 160, 225, 191, 93, 3, 128, 222, 60, 98,
    190, 224, 2, 92, 223, 129, 99, 61, 124, 34, 192, 158, 29, 67, 161, 255,
    70, 24, 250, 164, 39, 121, 155, 197, 132, 218, 56, 102, 229, 187, 89, 7,
    219, 133, 103, 57, 186, 228, 6, 88, 25, 71, 165, 251, 120, 38, 196, 154,
    101, 59, 217, 135, 4, 90, 184, 230, 167, 249, 27, 69, 198, 152, 122, 36,
    248, 166, 68, 26, 153, 199, 37, 123, 58, 100, 134, 216, 91, 5, 231, 185,
    140, 210, 48, 110, 237, 179, 81, 15, 78, 16, 242, 172, 47, 113, 147, 205,
    17, 79, 173, 243, 112, 46, 204, 146, 211, 141, 111, 49, 178, 236, 14, 80,
    175, 241, 19, 77, 206, 144, 114, 44, 109, 51, 209, 143, 12, 82, 176, 238,
    50, 108, 142, 208, 83, 13, 239, 177, 240, 174, 76, 18, 145, 207, 45, 115,
    202, 148, 118, 40, 171, 245, 23, 73, 8, 86, 180, 234, 105, 55, 213, 139,
    87, 9, 235, 181, 54, 104, 138, 212, 149, 203, 41, 119, 244, 170, 72, 22,
    233, 183, 85, 11, 136, 214, 52, 106, 43, 117, 151, 201, 74, 20, 246, 168,
    116, 42, 200, 150, 21, 75, 169, 247, 182, 232, 10, 84, 215, 137, 107, 53
};


unsigned long get_tick_count()
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC,&ts);

    return(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

long get_timestamp()
{
    time_t timestamp;
    time(&timestamp);
    return timestamp;
}

int fun_char2bcd(unsigned char *src,unsigned char *dest,int len)
{

    unsigned char  byteHigh = 0x00;
    unsigned char  byteLow  = 0x00;
    int dstLen = len/2; //如果是奇数个，3/2=1
    int srcIndex = 0;
    for (int bytesIndex = 0; bytesIndex < dstLen; ++bytesIndex)
    {
        srcIndex = bytesIndex*2;
        byteHigh = src[srcIndex] - '0';
        byteLow = src[srcIndex+1] - '0';
        dest[bytesIndex] = (byteHigh<<4) | byteLow;
    }

    if (len > dstLen*2) // 奇数个
    {
        dest[dstLen] = (src[len-1]-'0') << 4;
    }
    return dstLen;
}

void ChangeHexData(string data, unsigned char * out ){

    for(int i=0;i<data.size()/2;i++)
    {
        int jji=(atoi(data.substr(2*i,1).c_str() ) <<4 )| (atoi(data.substr(2*i+1,1).c_str() )   ) ;
        out[i]=   (unsigned char)(jji) ;
    }
}

void Test_tool(unsigned char *data,int i,unsigned char value)
{

    for(int j=0;j<i;j++){

        data[j]=value;
    }
}

QString  uc_to_qs(unsigned char *buf,int len)
{
    QString str;
    for(int i=0;i<len;i++)
    {
        str+=QString::number(buf[i],16);
        //     str.append(QString::number(buf[i]&0xFF,16));
    }
    return str.trimmed().toUpper();
}
char CRC8_Table(char *p, int counter)//CRC8校验
{
    unsigned char  u8Crc8 = 0;

    for( ; counter > 0; counter--){
        u8Crc8 = CRC8Table[u8Crc8 ^ *p];
        p++;
    }
    return(u8Crc8);

}
bool  Get_CheckRcv(char *data,  int rcvSize)
{

    if	(   (data[0] != dataHead[0])				//数据头格式校验
            ||    (data[1] != dataHead[1])
            ||	(rcvSize < 6)							//数据长度校验
            ||	(rcvSize >= 1024)
            ||	(data[rcvSize - 2] != dataRear[0])	//数据尾格式校验
            ||	(data[rcvSize - 1] != dataRear[1])
            )
    {         TRACE_INFO("\ndata1:[\n");
        for(int j=0;j<rcvSize;j++){
            TRACE_INFO("%02x",data[j]);
        }
        TRACE_INFO("\n]\n");
        return  false;
    }
    else
    {
        wis_u16 size;
        size = ((wis_u16)data[2]<<8) | data[3];
        //         TRACE_INFO("\nsize:%d\n",size);
        if(size != rcvSize){
            TRACE_INFO("\n:[\n");
            for(int j=0;j<rcvSize;j++){
                TRACE_INFO("%02x",data[j]);
            }
            TRACE_INFO("\n]\n");
            return false;
        }else{
            char crcdata=CRC8_Table(&(data[6]),size-9);
            if(data[size-3]==crcdata){
                return true;
            }else{
                return false;
            }

        }

    }

}
std::string changehex( std::string instr ){

    std::string temui;
    int leng=instr.size();
    if(leng!=2){
        for(int y=0;y<2-leng;y++){

            temui.append("0");

        } temui.append(instr);
    }else{

        temui.append(instr);

    }
    return temui;
}
int  getmaintime(RtcTime_S rtc,unsigned char * outdata){

    int leng;

    //        std::string yestring ;
    std::stringstream yearr;
    std::stringstream monthr;
    std::stringstream dayr;
    std::stringstream hourr;
    std::stringstream minuter;
    std::stringstream secondr;
    std::string years ;
    std::string months ;
    std::string days ;
    std::string hours ;
    std::string minutes ;
    std::string seconds ;

    std::string months1 ;
    std::string days1 ;
    std::string hours1 ;
    std::string minutes1 ;
    std::string seconds1 ;


    RtcFacade::getInstance()->readTime(rtc);
    //    RtcFacade::getInstance()->showTime(rtc);
    yearr<<17;
    yearr>>years;
    monthr<<rtc.m_month;
    monthr>>months;
    dayr<<rtc.m_date;
    dayr>>days;
    hourr<<rtc.m_hour;
    hourr>>hours;
    minuter<<rtc.m_minute;
    minuter>>minutes;
    secondr<<rtc.m_second;
    secondr>>seconds;


    months1    =changehex( months);
    days1      =changehex( days );
    hours1     =changehex( hours );
    minutes1   =changehex( minutes);
    seconds1   =changehex( seconds);

    std::string maintime;
    maintime.append(years);
    maintime.append(months1);
    maintime.append(days1 );
    maintime.append(hours1 );
    maintime.append(minutes1);
    maintime.append(seconds1);

    unsigned char* sssa= (unsigned char*)maintime.c_str();
    leng=  fun_char2bcd(sssa,outdata,maintime.length());

    return leng;
}
int  getmaintime3char(RtcTime_S rtc,unsigned char * outdata,int length){

    int leng;

    //        std::string yestring ;
    std::stringstream yearr;
    std::stringstream monthr;
    std::stringstream dayr;
    std::stringstream hourr;
    std::stringstream minuter;
    std::stringstream secondr;
    std::string years ;
    std::string months ;
    std::string days ;
    std::string hours ;
    std::string minutes ;
    std::string seconds ;

    std::string months1 ;
    std::string days1 ;
    std::string hours1 ;
    std::string minutes1 ;
    std::string seconds1 ;


    RtcFacade::getInstance()->readTime(rtc);
    //    RtcFacade::getInstance()->showTime(rtc);
    yearr<<17;
    yearr>>years;
    monthr<<rtc.m_month;
    monthr>>months;
    dayr<<rtc.m_date;
    dayr>>days;
    hourr<<rtc.m_hour;
    hourr>>hours;
    minuter<<rtc.m_minute;
    minuter>>minutes;
    secondr<<rtc.m_second;
    secondr>>seconds;


    months1    =changehex( months);
    days1         =changehex( days );
    hours1       =changehex( hours );
    minutes1   =changehex( minutes);
    seconds1   =changehex( seconds);

    std::string maintime;
    //    maintime.append(years);
    //    maintime.append(months1);
    //     maintime.append(days1 );


    switch(length){
    case 1:
        maintime.append(seconds1);
        break;
    case 2:
        maintime.append(months1);
        maintime.append(days1);
        break;

    case 3:
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;
    case 4:
        maintime.append(days1 );
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;

    case 5:
        maintime.append(months1);
        maintime.append(days1 );
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;
    case 6:
        maintime.append(years);
        maintime.append(months1);
        maintime.append(days1 );
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;

    }


    unsigned char* sssa= (unsigned char*)maintime.c_str();
    leng=  fun_char2bcd(sssa,outdata,maintime.length());

    return leng;
}
std::string  getmaintime3string(RtcTime_S rtc,int length){

    int leng;

    //        std::string yestring ;
    std::stringstream yearr;
    std::stringstream monthr;
    std::stringstream dayr;
    std::stringstream hourr;
    std::stringstream minuter;
    std::stringstream secondr;
    std::string years ;
    std::string months ;
    std::string days ;
    std::string hours ;
    std::string minutes ;
    std::string seconds ;

    std::string months1 ;
    std::string days1 ;
    std::string hours1 ;
    std::string minutes1 ;
    std::string seconds1 ;


    RtcFacade::getInstance()->readTime(rtc);
    //    RtcFacade::getInstance()->showTime(rtc);
    yearr<<17;
    yearr>>years;
    monthr<<rtc.m_month;
    monthr>>months;
    dayr<<rtc.m_date;
    dayr>>days;
    hourr<<rtc.m_hour;
    hourr>>hours;
    minuter<<rtc.m_minute;
    minuter>>minutes;
    secondr<<rtc.m_second;
    secondr>>seconds;


    months1    =changehex( months);
    days1      =changehex( days );
    hours1     =changehex( hours );
    minutes1   =changehex( minutes);
    seconds1   =changehex( seconds);

    std::string maintime;
    //    maintime.append(years);
    //    maintime.append(months1);
    //     maintime.append(days1 );



    switch(length){
    case 1:
        maintime.append(seconds1);
        break;
    case 2:
        maintime.append(months1);
        maintime.append(days1);
        break;

    case 3:
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;
    case 4:
        maintime.append(days1 );
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;

    case 5:
        maintime.append(months1);
        maintime.append(days1 );
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;
    case 6:
        maintime.append(years);
        maintime.append(months1);
        maintime.append(days1 );
        maintime.append(hours1 );
        maintime.append(minutes1);
        maintime.append(seconds1);

        break;

    }

    return maintime;
}

int hexCharToInt1(char c)
{
    if (c >= '0' && c <= '9') return (c - '0');
    if (c >= 'A' && c <= 'F') return (c - 'A' + 10);
    if (c >= 'a' && c <= 'f') return (c - 'a' + 10);
    return 0;
}
void ChangeHexStr2Char(string data, unsigned char * out ){

    int sz = data.length();
    for (int i=0 ; i <sz ; i+=2) {
        out[i/2] = (unsigned char) ((hexCharToInt1(data.at(i)) << 4)  | hexCharToInt1(data.at(i+1)));
    }
}


int Configuration_parameter_set(char  *str_para_name , char  *str_para)
{
    dictionary *ini;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    FILE *fp;
    fp = fopen("/user/src/script/parameters.ini", "w+");
    if (!fp) {
        printf("open failed\n");
        fclose(fp);
    }
    int register_return = 1;
    register_return = iniparser_set(ini,str_para_name,str_para);
    if(register_return == 0)
    {
        printf("写入成功\n");
        iniparser_dump_ini(ini, fp);
        fclose(fp);
        return 1;
    }
    else
    {
        printf("写入失败\n");
        fclose(fp);
        return 0;
    }
}

int Configuration_pageflag_set(char  *str_para_name , char  *str_para)
{
    dictionary *ini;
    ini = iniparser_load("/user/src/script/pageflag.ini");     //parser the file
    FILE *fp;
    fp = fopen("/user/src/script/pageflag.ini", "w+");
    if (!fp)
    {
        printf("open failed\n");
        fclose(fp);
    }
    int register_return = 1;
    register_return = iniparser_set(ini,str_para_name,str_para);
    if(register_return == 0)
    {
        printf("写入成功\n");
        iniparser_dump_ini(ini, fp);
        fclose(fp);
        return 1;
    }
    else
    {
        printf("写入失败\n");
        fclose(fp);
        return 0;
    }
}

double rad(double d)
{
    double PIVALUE = 3.1415926535898;
    return d * PIVALUE / 180.0;
}

double GetDistance(double StartLat,double StartLong,double EndLat,double EndLong)
//double GetDistance(double fLati1, double fLong1, double fLati2, double fLong2)
{
    double fPhimean,fdLambda,fdPhi,fAlpha,fRho,fNu,fR,fz,fTemp,Distance;//,Bearing;
    double D2R  = 0.017453;
    double a  = 6378137.0;
    double e2  = 0.006739496742337;

    fdLambda = (StartLong - EndLong) * D2R;
    fdPhi = (StartLat - EndLat) * D2R;
    fPhimean = ((StartLat + EndLat) / 2.0) * D2R;
    fTemp = 1 - e2 * (pow(sin(fPhimean),2));
    fRho = (a * (1 - e2)) / pow(fTemp, 1.5);
    fNu = a / (sqrt(1 - e2 * (sin(fPhimean) * sin(fPhimean))));
    fz = sqrt(pow(sin(fdPhi/2.0),2)+cos(EndLat*D2R)*cos(StartLat*D2R)*pow(sin(fdLambda/2.0),2)) ;
    fz = 2 * asin(fz);
    fAlpha = cos(EndLat * D2R) * sin(fdLambda) * 1 / sin(fz);
    fAlpha = asin(fAlpha);
    fR = (fRho * fNu) / ((fRho * pow(sin(fAlpha),2)) + (fNu * pow(cos(fAlpha),2)));
    Distance = (fz * fR);


    //     const float EARTH_RADIUS = 6378.137;
    //     double radLat1 = rad(fLati1);
    //     double radLat2 = rad(fLati2);
    //     double a = radLat1 - radLat2;
    //     double b = rad(fLong1) - rad(fLong2);
    //     double s = 2 * asin(sqrt(pow(sin(a/2),2) + cos(radLat1)*cos(radLat2)*pow(sin(b/2),2)));
    //     s = s * EARTH_RADIUS;
    //     s = (double)(s * 10000000) / 10000;
    //     return s;

    return Distance;
}


/******************************************8
* 计算两个经纬度之间的距离
* 返回值 ：以米为单位的值
* StartLat: 维度×1000000  单位 度
* StartLong 经度×1000000  单位 度
*******************************************/
double  changedatalan(unsigned int data){

    double temp_du = (data/1000000);
    double temp_fen = ((data%1000000)/600000.00);
    return   temp_du+temp_fen;
    //暂时里程: 0纬度1: 31584945.000000经度1: 118448167.000000纬度2: 118448167.000000经度2: 118448167.00

}


double Distance(unsigned int StartLat,unsigned int StartLong,unsigned int EndLat,unsigned int EndLong)
{
    double x1,y1,x2,y2;

    x1 = (double)changedatalan(StartLat);
    y1 = (double)changedatalan(StartLong) ;
    x2 = (double)changedatalan(EndLat) ;
    y2 = (double)changedatalan(EndLong) ;

    //    TRACE_RED("lecheng %lf\n",GetDistance(x1,y1,x2,y2));
    return ( GetDistance(x1,y1,x2,y2) );
}
