﻿#include "taskschedulerthread.h"

// Task implements
TaskSchedulerThread::Task::Task(void)
{
}

TaskSchedulerThread::Task::~Task(void)
{
}

void TaskSchedulerThread::Task::execute(void)
{

}

bool TaskSchedulerThread::Task::isNull(void) const
{
    return false;
}

bool TaskSchedulerThread::NullTask::isNull(void) const
{
    return true;
}

TaskSchedulerThread::AsyncTask::AsyncTask(const std::function<void()>& caller)
    : fCaller(caller)
{

}

TaskSchedulerThread::AsyncTask::AsyncTask(const std::function<void ()> &caller, const std::function<void ()> &clear)
    : fCaller(caller)
    , fClear(clear)

{

}

TaskSchedulerThread::AsyncTask::~AsyncTask()
{
    if(fClear)
        fClear();

}

void TaskSchedulerThread::AsyncTask::execute()
{
    fCaller();
}

TaskSchedulerThread::TaskQueue::TaskQueue(void)
{
    sem_init(&_sem, 0, 0);
}

TaskSchedulerThread::TaskQueue::~TaskQueue(void)
{
    clear();
    sem_destroy(&_sem);
}

void TaskSchedulerThread::TaskQueue::push(Task* task)
{
    _mutex.lock();
    _tasks.push(task);
    _mutex.unlock();
    sem_post(&_sem);
}

TaskSchedulerThread::Task* TaskSchedulerThread::TaskQueue::pop(void)
{
    sem_wait(&_sem);
    _mutex.lock();
    Task* task = _tasks.front();
    _tasks.pop();
    _mutex.unlock();
    return task;
}

void TaskSchedulerThread::TaskQueue::clear(void)
{
    while (!_tasks.empty()) {
        Task* task = _tasks.front();
        _tasks.pop();
        delete task;
    }
}


TaskSchedulerThread::TaskSchedulerThread()
    : _exitLoop(false)
    , _tasks(new TaskQueue())
    , _thread(std::bind(&TaskSchedulerThread::worker, this))
{
}

TaskSchedulerThread::~TaskSchedulerThread(void)
{
    _exitLoop = 0;
    _thread.join();
    delete _tasks;
}

TaskSchedulerThread::TaskQueue& TaskSchedulerThread::tasks(void) const
{
    return *_tasks;
}

void TaskSchedulerThread::worker(void)
{
    while (!_exitLoop)
    {
        Task* task = _tasks->pop();
        if (!task)
            break;
//    printf("flag loop 1 %d\n",_exitLoop);
        if (task->isNull()) {
            delete task;
            break;
        }
        try {
            task->execute();
        }
        catch (...) {

        }
        delete task;
    }

//    printf("flag loop 2 %d\n",_exitLoop);
    if (!_exitLoop)
        _exitLoop = true;
}


