#include "stringutils.h"
using namespace std;
StringUtils::StringUtils()
{




}
bool StringUtils:: isEmpty(std::string strdata)// 判断是否为空
{

     if((strdata.size()==0)||(strdata.empty())){

     }




}

std::string  StringUtils::  char2HexString(char * indata,int length) //char指针转十六进制字符串
{
        std::string outString(indata,length);
        return outString;
}
std::string  StringUtils::  char2String(char * indata,int length) //char转字符串
{
     std::string outString=indata;

     return outString;

}

std::string StringUtils::   toLowerCase(std::string instring)//转小写
{
    std::string outString;
    transform(instring.begin(), instring.end(), outString.begin(), (int (*)(int))tolower);
    return  outString;
}
std::string StringUtils::  toUpperCase(std::string instring)//转大写
{
     std::string outString;
     transform(instring.begin(), instring.end(), outString.begin(), (int (*)(int))toupper);
     return  outString;
}



void StringUtils:: hexString2CharArray (string hexdata, unsigned char * out )
{
    for(int i=0;i<hexdata.size()/2;i++)
    {
        int jji=(atoi(hexdata.substr(2*i,1).c_str() ) <<4 )| (atoi(hexdata.substr(2*i+1,1).c_str() )   ) ;
        out[i]=   (unsigned char)(jji) ;
    }
}


//std::string StringUtils::   toLong(long l)//long
//{
//    ostringstream os;
//    os<<l;
//    string result;
//    istringstream is(os.str());
//    is>>result;
//    return result;
//}

int StringUtils:: toInt(string str)//转int
{
    int result;
//    istringstream is(str);
//    is >> result;
    return result;
}
float StringUtils:: toFloat(string str)//转float
{
       float result;
//       istringstream is(str);
//       is >> result;
       return result;
}














