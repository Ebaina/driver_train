﻿#include "postutils.h"
#include "HttpClient.h"
#include "Tracer.h"
#include"JSONData.h"
#include <QString>
#include "app_globl.h"
#include "CmdExecuter.h"
#include "Utils.h"
#include "ttsutils.h"

string office_plate = "http://api.driving.1dianxueche.com/driving/";  //正式平台
string test_plate = "http://wechat.daopeng365.com/driving_dev/";   //测试平台

POSTutils::POSTutils()
{

}

POSTutils::~POSTutils()
{

}

std::string POSTutils:: httpPostPAY(std::string namenum,int paytype)
{
    HttpClient* client = new HttpClient();
    std::string urlname;
    std::string url;
    char para_buff[5] = {0};
    url.append("devNum=");
    url.append(Device_Num);
    url.append("&stuNum=");
    url.append(namenum);
    url.append("&classId=");
    url.append(Utils::intToString(TrainLessonId));
    url.append("&payType=");
    url.append(Utils::intToString(paytype));
    url.append("&subjCode=");
    url.append(subjectID);
    urlname = test_plate +"order/create?";        //链接拼接
    File* file = new  File("/tmp/postpay.data", IO_MODE_REWR_ORNEW);
    int flag= client->httpPost(urlname,url,file,6000);
    TRACE_RED("文件路径：\n");
    cout<<urlname<<endl;
    cout<<url<<endl;
    file->close();
    if(flag==0)
    {
        JSONData json;
        JSONNode* rootNode = json.initWithContentOfFile("/tmp/postpay.data");
        if(rootNode != NULL)
        {
            JSONNode node2 = (*rootNode)["errorcode"] ;
            int erorflag=9;
            erorflag=node2.toInt();
            TRACE_RED("errorcode:%d\n",node2.toInt());
            if(erorflag == 0)
            {
                JSONNode orderid = (*rootNode)["data"]["orderId"];
                JSONNode subTwo = (*rootNode)["data"]["subjectTwo"];
                JSONNode subThree = (*rootNode)["data"]["subjectThree"];
                orderidcode = orderid.toString();
                postTwo = subTwo.toDouble();
                postThree = subThree.toDouble();
//             TRACE_RED("orderid:%d\n",orderid.toString().c_str());
            }

            sprintf(para_buff,"%lf",postTwo);
            Configuration_pageflag_set("pagepara:postwo",para_buff);
            memset(para_buff,0,sizeof(para_buff));
            sprintf(para_buff,"%lf",postThree);
            Configuration_pageflag_set("pagepara:posthree",para_buff);
            memset(para_buff,0,sizeof(para_buff));
        }
    }
    delete file ;
    delete client ;
    return 0;
}


std::string POSTutils:: downLoadGET(std::string devnum,std::string namenum)
{
    HttpClient* client = new HttpClient();
    File* filename = new  File("/tmp/postget.data", IO_MODE_REWR_ORNEW);
    int flag;
    string urlname;
    char para_buff[32]={0};
    urlname= test_plate +"classhour?";                           //链接拼接
    urlname.append("stuNum=");
    urlname.append( namenum);
    urlname.append("&devNum=");
    urlname.append(devnum);
    flag = client->httpGet(urlname,filename,6000);
    TRACE_RED("文件路径：\n");
    cout<<urlname<<endl;
    cout<<filename<<endl;
    filename->close();
    if(flag==0)
    {
        JSONData json;
        JSONNode* rootNode= json.initWithContentOfFile("/tmp/postget.data");
        if(rootNode != NULL)
        {
            JSONNode  node2 = (*rootNode)["errorcode"] ;
            int erorflag = 9;
            erorflag=node2.toInt();
            TRACE_RED("errorcode:%d\n",erorflag);
            if(erorflag == 0)
            {
                JSONNode totalclasshourtwo = (*rootNode)["data"]["payTotalTwo"];
                JSONNode totalclasshourthree = (*rootNode)["data"]["payTotalThree"];
                JSONNode nopay = (*rootNode)["data"]["noPayOrder"];
                JSONNode classhourtwo = (*rootNode)["data"]["hasStudyTwo"];
                JSONNode classhourthree = (*rootNode)["data"]["hasStudyThree"];
                JSONNode cardno = (*rootNode)["data"]["cardNo"];
                JSONNode paytype = (*rootNode)["data"]["payType"];

                nopay_info = nopay.toBool();
                cardnumber = cardno.toString();
                pay_type = paytype.toInt();

                TRACE_RED("totalClassHourTwo:%d\n",totalclasshourtwo.toInt());
                TRACE_RED("totalClassHourThree:%d\n",totalclasshourthree.toInt());
                TRACE_RED("noPay:%d\n",nopay_info);
                TRACE_RED("classHourTwo:%d\n",classhourtwo.toInt());
                TRACE_RED("classHourThree:%d\n",classhourthree.toInt());
                TRACE_RED("cardNo:%s\n",cardno.toString().c_str());
                TRACE_RED("payType:%d\n",pay_type);
//                if(subjectcode < 20)
//                {
//                    remaining_min = totalclasshourtwo.toInt() - classhourtwo.toInt();
//                    if(remaining_min <= 0)
//                    {
//                            TtsUtils::getInstance()->sendVoice("科目二学时已满，请进行科目三训练");
//                    }
//                }
//                else if(subjectcode > 20)
//                {
//                    remaining_min = totalclasshourthree.toInt() - classhourthree.toInt();
//                    if(remaining_min <= 0)
//                    {
//                            TtsUtils::getInstance()->sendVoice("科目三学时已满");
//                    }
//                }
                remaining_min = totalclasshourtwo.toInt() + totalclasshourthree.toInt()  - classhourtwo.toInt() - classhourthree.toInt();
                if(remaining_min <=0 )
                {
                    TtsUtils::getInstance()->sendVoice("剩余学时为零，请充值");
                }
                char a[11] = {0};
                memcpy(a,studentcardinfo.card_info.cardno,10);
                string cardnum  = a;
                TRACE_CYAN("卡号为:%s\n",cardnum.c_str());
                if(cardnumber.compare(cardnum) == 0)
                {
                    sprintf(para_buff,"%d",remaining_min);
                    Configuration_pageflag_set("pagepara:remaining_min",para_buff);
                    memset(para_buff,0,sizeof(para_buff));

                    memcpy(para_buff,cardnumber.c_str(),cardnumber.length());
                    Configuration_pageflag_set("pagepara:cardno",para_buff);
                    memset(para_buff,0,sizeof(para_buff));

                    sprintf(para_buff,"%d",pay_type);
                    Configuration_pageflag_set("pagepara:paytype",para_buff);
                    memset(para_buff,0,sizeof(para_buff));

                    httpPostPAY(studentcardinfo.card_info.uniformID,2);
                }
                else
                {
                    TtsUtils::getInstance()->sendVoice("该卡不匹配，学时为零，禁止使用");
                    remaining_min = 0;
                }

            }
        }
    }
    delete filename ;
    delete client ;
    return  0;
}


std::string POSTutils:: httpPutPAY(std::string namenum)
{
    HttpClient* client = new HttpClient();
    std::string urlname;
    std::string url;
    std::string orderid;
    orderid = Device_Num+"_"+Utils::intToString(TrainLessonId);
    TRACE_RED("orderid:%s\n",orderid.c_str());
    url.append("devNum=");
    url.append(Device_Num);
    url.append("&stuNum=");
    url.append(namenum);
    url.append("&orderId=");
    url.append(orderid);
    url.append("&feeCount=");
    url.append(Utils::intToString(Trainminutes));
    url.append("&project=");
    if(subjectcode < 20)
    {
        url.append("2");              //科目二
    }
    else if(subjectcode >= 20)
    {
        url.append("3");            //科目三
    }
    urlname = test_plate +"order/balance?";        //链接拼接
    File* file = new  File("/tmp/postput.data", IO_MODE_REWR_ORNEW);
    int flag= client->httpPost(urlname,url,file,6000);
    TRACE_RED("文件路径：\n");
    cout<<urlname<<endl;
    cout<<url<<endl;
    file->close();
    if(flag==0)
    {
        JSONData json;
        JSONNode* rootNode= json.initWithContentOfFile("/tmp/postput.data");
        if(rootNode!=NULL)
        {
            JSONNode  node2 = (*rootNode)["errorcode"] ;
            int erorflag=9;
            erorflag=node2.toInt();
            TRACE_RED("errorcode:%d\n",node2.toInt());
            if(erorflag==0)
            {
                TRACE_RED("上传成功!!!\n");
            }
        }
    }
    else
    {
        char para_buff[150]={0};
        memcpy(para_buff ,(char*)urlname.c_str(),urlname.length());
        Configuration_pageflag_set("pagepara:urladress",para_buff);
        memset(para_buff,0,150);
        memcpy(para_buff ,(char*)url.c_str(),url.length());
        Configuration_pageflag_set("pagepara:urlpara",para_buff);
        memset(para_buff,0,150);
    }
    delete file ;
    delete client ;
    return 0;
}
