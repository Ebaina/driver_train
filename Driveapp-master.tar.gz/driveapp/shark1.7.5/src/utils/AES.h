#if !defined(AFX_AES_H__6BDD3760_BDE8_4C42_85EE_6F7A434B81C4__INCLUDED_)
#define AFX_AES_H__6BDD3760_BDE8_4C42_85EE_6F7A434B81C4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class AES  
{
public:
    AES(char* key);
	virtual ~AES();
    char* Cipher(char* input);
    char* InvCipher(char* input);
	void* Cipher(void* input, int length=0);
	void* InvCipher(void* input, int length);

private:
    char Sbox[256];
    char InvSbox[256];
    char w[11][4][4];

    void KeyExpansion(char* key, char w[][4][4]);
    char FFmul(char a, char b);

    void SubBytes(char state[][4]);
    void ShiftRows(char state[][4]);
    void MixColumns(char state[][4]);
    void AddRoundKey(char state[][4], char k[][4]);

    void InvSubBytes(char state[][4]);
    void InvShiftRows(char state[][4]);
    void InvMixColumns(char state[][4]);
};

#endif // !defined(AFX_AES_H__6BDD3760_BDE8_4C42_85EE_6F7A434B81C4__INCLUDED_)
