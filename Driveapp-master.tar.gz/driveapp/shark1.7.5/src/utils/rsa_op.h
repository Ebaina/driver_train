﻿#ifndef RSA_OP_H
#define RSA_OP_H
#include "string"
#include "rsa.h"
using namespace std;
// 公钥指数

class RsaOperater
{
public:
    RsaOperater();
    ~RsaOperater();
    static RsaOperater* getInstance()
    {
        static RsaOperater instance;
        return &instance;
    }



    //base64加密
   std::string  Basic64Encode(const unsigned char * str,int bytes) ;
   //base 64解密
   int  Base64Decode(const char * input, int length, bool with_new_line,char* out);

   //从CA证书里面获取RSA密钥，并写入文件
   int  writePrivateKeyFileFromPkcs12(std::string cadata,std::string password );

   int  writePrivateKeyFileFromPkcs12(const char * cadata,int len1,const char * password,int len2 );

   RSA*  getPrivateKeyFromPkcs12(std::string cadata,std::string password );
   RSA*  getRsakeyFromFile(const std::string& strPemFileName);

   std::string  DecodeRSAKeyFile( const std::string& strPemFileName, const std::string& strData );
   std::string  EncodeRSAKeyFile( const std::string& strPemFileName, const std::string& strData );

  int   EncodeRSAKeyFileChar( const std::string& strPemFileName, const char * strData,  int len, char * outData);

   std::string  decodeData(  RSA* rsa, const std::string& strData );
   std::string  encodeDataString(  RSA* rsa, const std::string& strData );
   std::string  encodeDataCharArray(  RSA* rsa, const char * strData,int len );


   std::string  terminalSign ( RSA* key,std::string &data, long timestamp) ;

private :
    std::string _base64_table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    string ltos(long l);
    int   longtoBE(long in,char* out);

 };
#endif

