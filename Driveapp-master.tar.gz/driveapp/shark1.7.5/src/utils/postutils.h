﻿#ifndef POSTUTILS_H
#define POSTUTILS_H
#include <stdio.h>
#include <stdlib.h>
#include  <string.h>
#include <vector>
#include "cmd.h"

using namespace std;

class POSTutils
{
public:
    POSTutils();
    ~POSTutils();

    static POSTutils* getInstance()
    {
        static POSTutils instance;
        return &instance;
    }

    std::string httpPostPAY(std::string namenum,int paytype);
    std::string downLoadGET(std::string devnum,std::string namenum);
    std::string httpPutPAY(std::string namenum);

public:
    int nopay_info;
    int pay_type;
    double  postTwo;
    double  postThree;
    std::string cardnumber;
    std::string orderidcode;
};

#endif // POSTUTILS_H
