#ifndef SHA256_H
#define SHA256_H

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <vector>
#include <sstream>
#include <bitset>
#include <iomanip>
#include <new>
using namespace std;

class Sha256 {
    public:
        Sha256();
        static Sha256 * getInstance()
        {
            static Sha256  instance;
            return &instance;
        }
        Sha256(char* msg, unsigned int size, unsigned int numBits);
        ~Sha256();
        int hashData(char* msg, unsigned int size,char * data);
        int getNumberOfHashedBytes();

    protected:
        char* message;			// ptr to begining of initial message
        string msgString;		// initial message in string
        int messageSize;		// number of bytes/chars in initial message
        int messageBitLength;		// initial message bit length
        unsigned int numBitsToHash;     // number of bits to hash a given message
        int numBytesToHash;
        unsigned char* preProcessedMsg;	// ptr to begining of pre-processed message
        int   numTotBits;			// number of bits in preProcessedMsg
        char  output[32];		// final hashed message
        void  pre_processing();
        void   processIn512Chunks( );

};
#endif // SHA256_H
