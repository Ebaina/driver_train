#ifndef STRINGUTILS_H
#define STRINGUTILS_H
#include <cctype>
#include <algorithm>
#include <string>
#include <iostream>
using namespace std;
class StringUtils
{
public:
    StringUtils();
    static StringUtils* getInstance()
    {
        static StringUtils instance;
        return &instance;
    }
    ~StringUtils();
   bool isEmpty(std::string strdata);// 判断是否为空
   std::string   char2HexString(char * indata,int length);//char转十六进制字符串
   std::string   char2String(char * indata,int length);//char转字符串
   std::string   toLowerCase( std::string instring);//转小写
   std::string   toUpperCase( std::string instring);//转大写
   int   toInt(string str);//转int
   void  hexString2CharArray(string hexdata, unsigned char * out );
   float  toFloat(string str);//转float

};

#endif // STRINGUTILS_H
