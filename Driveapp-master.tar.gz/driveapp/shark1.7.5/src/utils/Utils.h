﻿/******************************************************************************
 * This file is part of libemb.
 *
 * libemb is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * libemb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with libemb.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Project: Embedme
 * Author : FergusZeng
 * Email  : cblock@126.com
 * git	  : https://git.oschina.net/cblock/embedme
 * Copyright 2014 @ ShenZhen ,China
*******************************************************************************/
#ifndef __UTILS_H__
#define __UTILS_H__

#include "stdtype.h"
#include <iostream>
#include <vector>
#include <QString>
#include <QDateTime>
#include "ui_structs.h"
#include "RtcFacade.h"
#include "minmea.h"
using namespace std;
typedef struct UTC_Time {
    int day;
    int month;
    int year;
    int hour;
    int minute;
    int second;
    int microsecond;
}UTC_Time;

namespace PrintLevel {
enum LEVEL{
   REL=0,INFO=1,DEBUG=2,ERR=3
};
}


typedef struct GMT8_Time {
    int day;
    int month;
    int year;
    int hour;
    int minute;
    int second;
    int microsecond;
} GMT8_Time;

/**
 *  \file   Utils.h
 *  \class  Utils
 *  \brief  工具类
 */
class Utils{
public:
    static int random(int max);
    static bool isBigEndian(void);
    static uint16 host2LitEndian(uint16 value);
    static uint32 host2LitEndian(uint32 value);
    static uint16 host2BigEndian(uint16 value);
    static uint32 host2BigEndian(uint32 value);
    static string unicodeOneToUtf8String(uint32 unicode);
    static uint32 utf8OneToUnicode(const char* utf8code);
    static string toLower(const char* str);
    static string toUpper(const char* str);
    static string findString(const string& source, const string& start, const string& end);
    static string findString(const string& source, const string& pattern, const string& before, const string& after);
    static string trimBeginWith(const string& source,const string& trimch);
    static string trimEndingBlank(const string& source);
    static string trimAllBlank(const string& source);
    static vector<string> cutString(const string& source,const string& startFlag,const string& stopFlag,const string& cutFlag);
    static int stringPatternCount(const string& source, const string& pattern);
    static sint8 ascii2digital(char ch);
    static char digital2ascii(uint8 val);
    static char   digitHexToASCII(unsigned char  data_hex);
    static int hex2Ascii(char  *val,int len,char * data);
    static int ascii2Hex(char  *val,int len,char * data);
    static  QByteArray  hexStringtoByteArray(QString hex);
     static  void  formatString(QString &org  );

    static int string2code(const string codestr,char* codebuf,int len);
    static string code2string(const char* codebuf,int len);
    static uint16 bitsReverse(uint16 value, uint8 bits);
    static string trimFilePath(const char* filePath);
    static int eval(const char* expression);
    static int  LogSave(std::string filepath,std::string tag,const char*   data,int length);
    static int  LogSaveFlag(std::string filepath,std::string tag);
    static  vector< string> splitString( string str, string pattern);
    static std::string  intToString(const int &int_temp );
    static std::string  longToString(const long &long_temp );
    static std::string  doubleToString(const int &double_temp );
    static std::string  shortToString(const short &short_temp );
    static std::string  unsignedShortToString(const unsigned short &unsignedshort_temp );
    static std::string  unsignedCharToString(const    unsigned char   unsignedchar_temp );
    static std::string  boolToString(const   bool  bool_temp );
    static std::string  getCurrentTime(void);
    static void  packageGps(char *gnssdata );
    static std::string  changeBcdData2Time(const char *bcd, int len);//bcd
//    static bool  addTextIntoImage(const QString &filename, int typeMan, int speed, double x, double y);
//    static void registerWaterCallback(ImageCallback cb, void *opaque);
    static void UTC2GMT8(   GMT8_Time &time);
    static void  packageRtcGps(char *gnssdata );

    static void  packageRtcGpsFoTrainRecord(char *gnssdata,std::string time,int index );


    static int DectoBCD(int Dec,   char *Bcd, int length)  ;
    static int time2BCD( GMT8_Time &time,   char *Bcd, int length)  ;
    static void Hex2Char(char *szHex, unsigned char *rch);
    static int HexStr2CharStr( char *pszHexStr, int iSize,  char *pucCharStr);

    static void printCurrentTime(void);
    static int updatefromGps(RtcTime_S& rtcTime  );
    static int UpdateSysClock(RtcTime_S& rtcTime);
    static int updateWholeClockFromGps(minmea_sentence_rmc &rmc_temp );

    static void printString(int level,std::string str);
    static std::string rtc2String(RtcTime_S& rtcTime);

    static std::string  getBeforMinitues(std::string time,int minute);
    static QDateTime  getBeforMinitues2Qdate(std::string time,int minute);

    static std::string  getBeforDay(int day);
    static std::string  getBeforMonth(int month);
    static string  deletPhotoBeforMoth(int start, int month);
    static std::string  deletPhotoBeforDay(int start,int day);
    static void setGTimeAddSeconds(std::string &time,GMT8_Time &gtime,int data);
    static string getPhotoNumFromTime(string &time);

    static int  countMinutes(string start,string stop);
    static int  countSenconds(string start,string stop);
    static void addBitValue(unsigned int &value, int index);
    static void removeBitValue(unsigned int &value, int index);
    static void addBitValueShort(unsigned short &value, int index);
    static void removeBitValueShort(unsigned short &value, int index);

};
#endif
