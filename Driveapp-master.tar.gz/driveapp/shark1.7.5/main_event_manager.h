#ifndef MAIN_EVENT_MANAGER_H
#define MAIN_EVENT_MANAGER_H
#include "Event.h"
#include "app_globl.h"
class  AckReciceEventListioner{

public :
    static AckReciceEventListioner* getInstance()
    {
        static AckReciceEventListioner instance;
        return &instance;
    }
    AckReciceEventListioner();
    ~AckReciceEventListioner();
    void handleEvent(stRecvCmdPiPe  strrevCmdpip);
};

//class  AckSendEvent:  public  EventCenter{

//public:
//    AckSendEvent();
//     ~AckSendEvent();
//   // void SendPostEvent(Event  &evt );

//};


#endif // MAIN_EVENT_MANAGER_H
