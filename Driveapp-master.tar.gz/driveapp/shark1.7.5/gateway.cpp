﻿#include "gateway.h"
#include "public.h"
#include "cmdbeatheart.h"
#include "ManagerExe.h"
#include "dictionary.h"
#include "iniparser.h"
#include "Utils.h"
void sp_gateway::Data_Proc(char *buf, int len,void *param)
{
    sp_gateway * p = (sp_gateway *)param;
//    Utils::LogSave("/tmp/TcpGateWaydata.txt","GetData:",buf,len);
    p->WriteFifo(buf,len);  //网关数据存到FIFO中
}

int sp_gateway::sp_gateway_register(char *setid,char *sn,char *usr,char *ps)
{
    return 0;
}

int sp_gateway::ini_net( char *ip, int n )
{

    if(nTcp_LinkServer(ip,n,Data_Proc,1,this))
    {
        sp_gateway_register("11","22","33","44");
    }
}

void sp_gateway::int_cmd_list()
{

}

