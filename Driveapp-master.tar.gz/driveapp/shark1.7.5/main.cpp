﻿#include <QApplication>
#include <QTextCodec>
#include <stdio.h>
#include <stdlib.h>
#include "photogetutils.h"
#include <string.h>
#include <assert.h>
#include"curl/curl.h"
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <iostream>
#include "uart.h"
#include<QString>
#include<QDebug>
#include "HttpClient.h"
#include "public.h"
#include "clog.h"
#include "Socket.h"
#include "Timer.h"
#include "Event.h"
#include "RtcFacade.h"
#include "MsgQueue.h"
#include "Thread.h"
#include "gateway.h"
#include "DataBase.h"
#include "SqliteWrapper.h"
#include "iniparser.h"
#include "dictionary.h"
#include "app_globl.h"
#include <QWSServer>
#include "communicatestm32.h"
#include "gps_recv.h"
#include <string>
#include <openssl/pem.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/pkcs12.h>
#include "n485.h"
#include "n232.h"
#include "rsa_op.h"
#include <rsa.h>
#include "rtcutils.h"
#include "ui_interface.h"
#include "wisbase64.h"
#include "ttsutils.h"
#include "snap.h"
#include "JSONData.h"
#include "checkvideo.h"
#include "photodb.h"
#include "studytimedb.h"
#include <QByteArray>
#include <QBuffer>
#include <QImage>
#include <QPixmap>
#include <sstream>
#include <QtPlugin>
#include "offlinesave.h"
#include "timerupload.h"
using namespace std;
bool is_open;
char Ble_buf[512];
//Communicateplatform  communicateplatform1;
GPS_recv  gps1;
N485_UART   n485_uart;
n232     n232_uart;
extern stmobile_net_setting mobile_param;

#define SNAPSHOT 1
#define OTHER 0
#define NETWORK 0
#define PHOTOSQLDEMO 0
#define STUDYTIMEDEMO 0
#define PHOTOSQLDEMO 0
QByteArray  Image_To_Base64(QString ImgPath)
{
    QImage image(ImgPath);
    QByteArray ba;
    ;

    QBuffer buf(&ba);
   image.save(&buf,"PNG",20);
//     printf("daxiao:%d",buf.size());
//      image.save(&buf, extension.toLatin1().data());
    QByteArray hexed = ba.toBase64();
    buf.close();
    return hexed;
}
void  Base64_To_Image(QByteArray bytearray,QString SavePath)
{
    QByteArray Ret_bytearray;
    Ret_bytearray = QByteArray::fromBase64(bytearray);
    QBuffer buffer(&Ret_bytearray);
    buffer.open(QIODevice::WriteOnly);
    QPixmap imageresult;
    imageresult.loadFromData(Ret_bytearray);
    if(SavePath != "")
    {
        qDebug() <<"save" ;
        imageresult.save(SavePath);


    }
   // return imageresult;
}

static tagUARTParam Uart_Param =
{ "/dev/ttyS1", 115200, 8, 'N', 1, FLOW_CONTROL_NONE };
static tagUARTParam UartParam7 =
{ "/dev/ttyS7", 9600, 8, 'N', 1, FLOW_CONTROL_NONE };
unsigned char valueToHexCh( int value)
{
    unsigned char  result = '\0';
    if(value >= 0 && value <= 9){
        result = (unsigned char )(value + 48); //48为ascii编码的‘0’字符编码值
    }
    else if(value >= 10 && value <= 15){
        result = (unsigned char )(value - 10 + 65); //减去10则找出其在16进制的偏移量，65为ascii的'A'的字符编码值
    }
    else{
        ;
    }

    return result;
}
void ChangeHexData123(string data,   char * out ){


    for(int i=0;i<data.size()/2;i++)
    {

        int jji=(atoi(data.substr(2*i,1).c_str() ) <<4 )| (atoi(data.substr(2*i+1,1).c_str() )   ) ;
        out[i]=   (  char)(jji) ;
        //        |
        //
        //     printf("Send:%02x\n",out[i]);
    }
}
EVP_PKEY* open_private_key(const char *keyfile){
    EVP_PKEY* key = NULL;
    RSA *rsa = NULL;
    OpenSSL_add_all_algorithms();
    BIO *bp = NULL;
    bp = BIO_new_file(keyfile, "rb");
    if (NULL == bp)
    {
        printf("open_private_key bio file new error!\n");

        return NULL;
    }
   //PEM_read_bio_RSAPublicKey
    rsa = PEM_read_bio_RSAPrivateKey(bp, NULL, NULL, NULL);
    if (rsa == NULL)
    {
        printf("open_private_key failed to PEM_read_bio_RSAPrivateKey!\n");
        BIO_free(bp);
        RSA_free(rsa);
        return NULL;
    }

//	printf("open_private_key success to PEM_read_bio_RSAPrivateKey!\n");
    key = EVP_PKEY_new();
    if (NULL == key)
    {
        printf("open_private_key EVP_PKEY_new failed\n");
        RSA_free(rsa);
        return NULL;
    }
    EVP_PKEY_assign_RSA(key, rsa);
    return key;
}
//私钥不带密码
int rsa_key_decrypt(EVP_PKEY *key, const unsigned char *enc_data, size_t enc_data_len,
    unsigned char *orig_data, size_t &orig_data_len)
{
    EVP_PKEY_CTX *ctx = NULL;
    OpenSSL_add_all_ciphers();

    ctx = EVP_PKEY_CTX_new(key, NULL);
    if (NULL == ctx)
    {
        printf("ras_prikey_decryptfailed to open ctx.\n");
        EVP_PKEY_free(key);
        return -1;
    }

    if (EVP_PKEY_decrypt_init(ctx) <= 0)
    {
        printf("ras_prikey_decryptfailed to EVP_PKEY_decrypt_init.\n");
        EVP_PKEY_free(key);
        return -1;
    }

    if (EVP_PKEY_decrypt(ctx,
        orig_data,
        &orig_data_len,
        enc_data,
        enc_data_len) <= 0)
    {
        printf("ras_prikey_decryptfailed to EVP_PKEY_decrypt.\n");
        EVP_PKEY_CTX_free(ctx);
        EVP_PKEY_free(key);
        return -1;
    }
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_free(key);
    return 0;

}
void parseCert1(X509* x509)
{
    cout <<"--------------------" << endl;
    BIO *bio_out = BIO_new_fp(stdout, BIO_NOCLOSE);
    //PEM_write_bio_X509(bio_out, x509);//STD OUT the PEM
    X509_print(bio_out, x509);//STD OUT the details
    //X509_print_ex(bio_out, x509, XN_FLAG_COMPAT, X509_FLAG_COMPAT);//STD OUT the details
    BIO_free(bio_out);
}
char * Base64Decode(char* input, int length, bool with_new_line );
char * Base64Decode(char * input, int length, bool with_new_line)
{
    BIO * b64 = NULL;
    BIO * bmem = NULL;
    char * buffer = (char *)malloc(length);
    memset(buffer, 0, length);

    b64 = BIO_new(BIO_f_base64());
    if(!with_new_line) {
        BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    }
    bmem = BIO_new_mem_buf(input, length);
    bmem = BIO_push(b64, bmem);
    BIO_read(bmem, buffer, length);

    BIO_free_all(bmem);

    return buffer;
}
void ChangeHexData1(string data, unsigned char * out ){


    for(int i=0;i<data.size()/2;i++)
    {
        int jji=(atoi(data.substr(2*i,1).c_str() ) <<4 )| (atoi(data.substr(2*i+1,1).c_str() )   ) ;
        out[i]=   (unsigned char)(jji) ;
        //     printf("Send:%02x\n",out[i]);
    }
}

int main(int argc, char *argv[])
{
//#if PHOTOSQLDEMO
//    int i;
//    int findNum = 0;

//    //第一个参数是数据库最大存储条数，第二个参数是最大查询信息的条数
//    p_db.initDatabase(10, 100);
//    p_db.createPhotoTable(NULL,NULL,NULL,NULL);

//    //第一个参数是照片名，长度18个字节的字符串，第二个参数是照片类型
//    //第三个参数是通道号，第四个参数是入库时间，值为照片名去掉 .jpg 部分，类型为unsigned long long int
//    p_db.photoInfoInsert("'20170308182813.jpg'", 1, 0, 20170308182813);
//    p_db.photoInfoInsert("'20170308182814.jpg'", 2, 0, 20170308182814);
//    p_db.photoInfoInsert("'20170308182815.jpg'", 3, 0, 20170308182815);
//    p_db.photoInfoInsert("'20170308182816.jpg'", 4, 0, 20170308182816);
//    p_db.printInfo();
//    p_db.startWatchThread();

//    //查询照片，第一个参数是起始时间，第二个参数是结束时间，类型为unsigned long long int
//    //函数返回值是查询到的照片数量
//    findNum = p_db.findPhotoBytime(20170308182814, 20170308182815);

//    //通过容器取出查找到的照片名称
//    for(i=0; i<findNum; i++)
//    {
//        cout<< "vector==" << p_db.sql_result_vect[i] << endl;
//    }
//#endif

//#if STUDYTIMEDEMO
//    int i;
//    studytimedb timedb;
//    int findNum;
//    //第一个参数是数据库最大存储条数，第二个参数是最大查询信息的条数
//    timedb.initDatabase(100,100);
//    timedb.createStudyTimeTable();
//    for(i=0; i<5; i++)
//    {
//        //第一个参数是数据类型，第二个参数是报文长度
//        //第三个参数是报文内容，第四个参数是报文是否有效
//        timedb.studyInfoInsert(i, 5, "'abcde'", 1);
//        usleep(500000);
//    }
//    //通过message_type 查找 message_content
//    //函数返回值是查询到的信息数量
//    findNum = timedb.findInfoByType(5);
////    timedb.findInfoByTime(NULL, NULL);
//    //通过容器取出查找到的报文内容
//    for(i=0; i<findNum; i++)
//    {
//        cout << "vector===" << timedb.sql_study_info_vect[i] << endl;
//    }
//    timedb.startWatchThread();
//    timedb.printInfo();
//    while(1)
//    {
//        sleep(1);
//    }
//#endif




//#if OTHER
//    char * Keycode ="MIIKLQIBAzCCCfcGCSqGSIb3DQEHAaCCCegEggnkMIIJ4DCCCdwGCSqGSIb3DQEHAaCCCc0EggnJMIIJxTCCBHwGCyqGSIb3DQEMCgEDoIIEDjCCBAoGCiqGSIb3DQEJFgGgggP6BIID9jCCA/IwggLaoAMCAQICBgFZGypDUjANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwJDTjERMA8GA1UECh4IVv1OpE/hkBoxDDAKBgNVBAsTA1BLSTEzMDEGA1UEAx4qAE8AcABlAHIAYQB0AGkAbwBuACAAQwBBACAAZgBvAHIAIFb9TqRP4ZAaMB4XDTE2MTIyMDA3Mzc1MVoXDTI2MTIxODA3Mzc1MVowQTELMAkGA1UEBhMCQ04xFTATBgNVBAoeDIuhZfZ+yHrvi8FOZjEbMBkGA1UEAxMSeHcxNDY1NzY2ODUwNDQ1Njc4MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhLqvjgGGTVGOYb6sNxn5k8gRieXRa7h6N74tJQRRsVMldzLnSr1zZmpqKXw0IadXjNd5uJVFJzFbVBmzGDdUS4kRcIsBOZYXuVmbD2v0FGjmDXxXnlKDhpaMHLA89gu7zbiOp/WxKMOJ3CP8kh9rxkJg3BsGejS07t4iigLk9aNqGaIMJF1iBAe0M50wxQKaZaxv8WIiBwihw73gQWLa6mK2A8syjbltBsix1yIBkDLlcQSBcAAI5cdh+bZWO0t2Hjew9p/z7zY3XRaD+ltNJvjXht6cRK223SsppCD8j+kkT+CY6+RzjEvVxmwTvtpNsvD2nUn9hc08IpWRGpRNkwIDAQABo4HNMIHKMB8GA1UdIwQYMBaAFFyqjorSazJMB8Bjazw0/H5+sq57MB0GA1UdDgQWBBTQszak3sgZka11Q3stI2pscbXrHjBdBgNVHR8EVjBUMFKgUKBOpEwwSjEXMBUGA1UEAx4OAEMAUgBMADEAMAAwADAxDzANBgNVBAseBgBDAFIATDERMA8GA1UECh4IVv1OpE/hkBoxCzAJBgNVBAYTAkNOMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgD4MBEGCWCGSAGG+EIBAQQEAwIAoDANBgkqhkiG9w0BAQsFAAOCAQEAD0G9SoLXAQ8XKZ5G6An/ewBVvnJi49BZ10DT9t5YGLcXaEBm0qV8pEI6WV2zIVMDSiu6GWLutWs6ieTZvZysTioZZnIx4yCyzB53gk2H3ug+qAXe0Fjbtc2o3H8Z2ruIGGkT0ysJfqi4j4RtdqhpghT657rmhBvfGCZhqWrW1pNR9a9ECwZKL5jndVQrFbtIjpK4NnOcZ21MBw1Es/XEV6qmQuvnSHnNc55pR6LS0UznQ2rTJFObz7Cc/vQRdkmG3biA8G8qx13KFSNnLiTg90Hm7/x5hCkeRy6ML3oURjYlK4rZ6pEqIodBmxaE+FafPBTZ8G4+eVy/MIe/EHDOPTFbMBkGCSqGSIb3DQEJFDEMHgoAQQBMAEkAQQBTMD4GCSqGSIb3DQEJFTExBC83NyBmNyA1MyAxMyA4YiAzZCAxZSBiNSBhNiBiYSAzNSAyYyA1YSBkOCBjNCBkYzCCBUEGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBBjAOBAgIY7yJVgn36QICBAAEggTIDnTvcn+WU5dUU/3KenqfGxKbFR/NAq/hwOd2jQXoYOxPWxetf/QMoXsxdfPE8ZNN1pTJzuLPKWrDfiuorO6JtGGAYLZe7rGLkFrIG0fRk/ZtosNSuRjmvRtqVioikSxhwCPFrAOyFxK4+I8WhjYI7QKKqywtXhuPbSO7EYRxJs1bV8gqZJxdCVNi7m3gj/cZFscNOBKWZMnKq3ZPG/XRKZ7CoeH8wjaKskYiKWhZvPoYs4E7A8NVMdh/IbVgTM1YTvl6AMpuRevlz0apjNY6miQ4c5RFHArMQYCioAOj9YL9xS6QxTtT27Ge3Ut4bjC7VUU8RkAqrV2Eg/fMXIfQOzoB0qQTLZELCkRtf+YUqjWd94BrMpnEGJ1076YEb/PbRltKv25joN4f2CKjOibUTZ1+MQ03F1xmkgugasCAAbKh4TTcqsdb0kk/arx+X1wyapXy8EzPCsOa2qqxTM7+aiH5HMMIdOgLmPxf1R77vtkhlC4X1bhK3AqtWZ8UM7uMXgpQ4rBpJVdtsako1lD0p50zWHENr8d6v06y6857YNYGH71rQh6K0Rbcw+9iF1YVfg8rp+ggHTmJyJhElUfxb4ogvxOu+izeBFBgiJaYeMStL85IurKrtg1BpCxdqzMBmpPPVh03g7iC6qFUhXJSD5CsMyVE0w71NT/LaDEgeSRma6E2j/ScNcZzM17tRPKa/hKK0eJfRnLaQfRyM2aobJiD9Nn6zsXAhzzIDKHBuBhKlsK9OOoBb5LbT18mENxvjMDOSTk2sX6muwHVm0uy1qcAEidWOKhPpkyhnJyKOjD4VHeBo0ueSVDXBU71xoaCrKKtD0dZWOLgZqm+yfgk/nMsoCZIVKh8OcyRIxYGagfxqc4ncZMWUiOnKdBoBfGzqZByH0aMwBQK/iNd8qk9uZMLBRM8FisMPTj5cE6hxkI0VZ59spEssp/bzi4tLcd2jGEQCP65wvaWHbAwbF7Tyuq9JCktfMP8tE8X2iPQbkToABJ8rO5m78lKUZOcAXaDhTNHQuiwaQtT4FHj1f0wJyXYIoDbsfgXtvjxFLxKjUyJynvaThPTKBRVU+WczwAXYC6iNSxFlURVwstC6rFx4G+D9jPLw4eXX3z30/cUYqbzKJ5oPKLusCPBnXQLJ42n+gaaEfZtbiwoxZ19liQuFwtaViyRFtugzfnIdr46Shd2luCTPihnfASmDUmAogzzLtFbz7gvHAUxcY+KUvjU7j9xJ4AzpAszeLHyPmIGInOjR2F/s6VA5IJZsLLb1AscoReb4NDiwSjkkWr7g0MZ7nIgTRt7ltbzNGksS1M7QJOYvOYJg+/nmOynpV3njBaKzbBnlHuX0YSXiEJfxz9fM+4DbClbE3CAZEU/FcYlRmfEv06pt+ip1pHhVrUkJmaWaSdXRWVpwpVPNuAfEJVqKD5NVEsf+ZV+PThak1GGQsRXDx17CI6vRtWgmP0w2oIPv09CtF38TkHdPrwp9lo6xALo85oR/8v9KSo9H/5XraQBBqYjTxIN20qwcM6A2TiSJvPUh6XVzILLmBEdW99WlfkOstStbPfRMx/PzLaAnKqp3UuIDa6lEPeRkVT/MKG18Mx3EU1MMEvKX9gGe9FCoygO6/6R9JhJMUAwPgYJKoZIhvcNAQkVMTEELzc3IGY3IDUzIDEzIDhiIDNkIDFlIGI1IGE2IGJhIDM1IDJjIDVhIGQ4IGM0IGRjMC0wITAJBgUrDgMCGgUABBQxUC34Z6Gv3mQ9KasYv5nTPWheFgQIW0sWRRMstPA=/IwggLaoAMCAQICBgFZGypDUjANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwJDTjERMA8GA1UECh4IVv1OpE/hkBoxDDAKBgNVBAsTA1BLSTEzMDEGA1UEAx4qAE8AcABlAHIAYQB0AGkAbwBuACAAQwBBACAAZgBvAHIAIFb9TqRP4ZAaMB4XDTE2MTIyMDA3Mzc1MVoXDTI2MTIxODA3Mzc1MVowQTELMAkGA1UEBhMCQ04xFTATBgNVBAoeDIuhZfZ+yHrvi8FOZjEbMBkGA1UEAxMSeHcxNDY1NzY2ODUwNDQ1Njc4MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhLqvjgGGTVGOYb6sNxn5k8gRieXRa7h6N74tJQRRsVMldzLnSr1zZmpqKXw0IadXjNd5uJVFJzFbVBmzGDdUS4kRcIsBOZYXuVmbD2v0FGjmDXxXnlKDhpaMHLA89gu7zbiOp/WxKMOJ3CP8kh9rxkJg3BsGejS07t4iigLk9aNqGaIMJF1iBAe0M50wxQKaZaxv8WIiBwihw73gQWLa6mK2A8syjbltBsix1yIBkDLlcQSBcAAI5cdh+bZWO0t2Hjew9p/z7zY3XRaD+ltNJvjXht6cRK223SsppCD8j+kkT+CY6+RzjEvVxmwTvtpNsvD2nUn9hc08IpWRGpRNkwIDAQABo4HNMIHKMB8GA1UdIwQYMBaAFFyqjorSazJMB8Bjazw0/H5+sq57MB0GA1UdDgQWBBTQszak3sgZka11Q3stI2pscbXrHjBdBgNVHR8EVjBUMFKgUKBOpEwwSjEXMBUGA1UEAx4OAEMAUgBMADEAMAAwADAxDzANBgNVBAseBgBDAFIATDERMA8GA1UECh4IVv1OpE/hkBoxCzAJBgNVBAYTAkNOMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgD4MBEGCWCGSAGG+EIBAQQEAwIAoDANBgkqhkiG9w0BAQsFAAOCAQEAD0G9SoLXAQ8XKZ5G6An/ewBVvnJi49BZ10DT9t5YGLcXaEBm0qV8pEI6WV2zIVMDSiu6GWLutWs6ieTZvZysTioZZnIx4yCyzB53gk2H3ug+qAXe0Fjbtc2o3H8Z2ruIGGkT0ysJfqi4j4RtdqhpghT657rmhBvfGCZhqWrW1pNR9a9ECwZKL5jndVQrFbtIjpK4NnOcZ21MBw1Es/XEV6qmQuvnSHnNc55pR6LS0UznQ2rTJFObz7Cc/vQRdkmG3biA8G8qx13KFSNnLiTg90Hm7/x5hCkeRy6ML3oURjYlK4rZ6pEqIodBmxaE+FafPBTZ8G4+eVy/MIe/EHDOPTFbMBkGCSqGSIb3DQEJFDEMHgoAQQBMAEkAQQBTMD4GCSqGSIb3DQEJFTExBC83NyBmNyA1MyAxMyA4YiAzZCAxZSBiNSBhNiBiYSAzNSAyYyA1YSBkOCBjNCBkYzCCBUEGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBBjAOBAgIY7yJVgn36QICBAAEggTIDnTvcn+WU5dUU/3KenqfGxKbFR/NAq/hwOd2jQXoYOxPWxetf/QMoXsxdfPE8ZNN1pTJzuLPKWrDfiuorO6JtGGAYLZe7rGLkFrIG0fRk/ZtosNSuRjmvRtqVioikSxhwCPFrAOyFxK4+I8WhjYI7QKKqywtXhuPbSO7EYRxJs1bV8gqZJxdCVNi7m3gj/cZFscNOBKWZMnKq3ZPG/XRKZ7CoeH8wjaKskYiKWhZvPoYs4E7A8NVMdh/IbVgTM1YTvl6AMpuRevlz0apjNY6miQ4c5RFHArMQYCioAOj9YL9xS6QxTtT27Ge3Ut4bjC7VUU8RkAqrV2Eg/fMXIfQOzoB0qQTLZELCkRtf+YUqjWd94BrMpnEGJ1076YEb/PbRltKv25joN4f2CKjOibUTZ1+MQ03F1xmkgugasCAAbKh4TTcqsdb0kk/arx+X1wyapXy8EzPCsOa2qqxTM7+aiH5HMMIdOgLmPxf1R77vtkhlC4X1bhK3AqtWZ8UM7uMXgpQ4rBpJVdtsako1lD0p50zWHENr8d6v06y6857YNYGH71rQh6K0Rbcw+9iF1YVfg8rp+ggHTmJyJhElUfxb4ogvxOu+izeBFBgiJaYeMStL85IurKrtg1BpCxdqzMBmpPPVh03g7iC6qFUhXJSD5CsMyVE0w71NT/LaDEgeSRma6E2j/ScNcZzM17tRPKa/hKK0eJfRnLaQfRyM2aobJiD9Nn6zsXAhzzIDKHBuBhKlsK9OOoBb5LbT18mENxvjMDOSTk2sX6muwHVm0uy1qcAEidWOKhPpkyhnJyKOjD4VHeBo0ueSVDXBU71xoaCrKKtD0dZWOLgZqm+yfgk/nMsoCZIVKh8OcyRIxYGagfxqc4ncZMWUiOnKdBoBfGzqZByH0aMwBQK/iNd8qk9uZMLBRM8FisMPTj5cE6hxkI0VZ59spEssp/bzi4tLcd2jGEQCP65wvaWHbAwbF7Tyuq9JCktfMP8tE8X2iPQbkToABJ8rO5m78lKUZOcAXaDhTNHQuiwaQtT4FHj1f0wJyXYIoDbsfgXtvjxFLxKjUyJynvaThPTKBRVU+WczwAXYC6iNSxFlURVwstC6rFx4G+D9jPLw4eXX3z30/cUYqbzKJ5oPKLusCPBnXQLJ42n+gaaEfZtbiwoxZ19liQuFwtaViyRFtugzfnIdr46Shd2luCTPihnfASmDUmAogzzLtFbz7gvHAUxcY+KUvjU7j9xJ4AzpAszeLHyPmIGInOjR2F/s6VA5IJZsLLb1AscoReb4NDiwSjkkWr7g0MZ7nIgTRt7ltbzNGksS1M7QJOYvOYJg+/nmOynpV3njBaKzbBnlHuX0YSXiEJfxz9fM+4DbClbE3CAZEU/FcYlRmfEv06pt+ip1pHhVrUkJmaWaSdXRWVpwpVPNuAfEJVqKD5NVEsf+ZV+PThak1GGQsRXDx17CI6vRtWgmP0w2oIPv09CtF38TkHdPrwp9lo6xALo85oR/8v9KSo9H/5XraQBBqYjTxIN20qwcM6A2TiSJvPUh6XVzILLmBEdW99WlfkOstStbPfRMx/PzLaAnKqp3UuIDa6lEPeRkVT/MKG18Mx3EU1MMEvKX9gGe9FCoygO6/6R9JhJMUAwPgYJKoZIhvcNAQkVMTEELzc3IGY3IDUzIDEzIDhiIDNkIDFlIGI1IGE2IGJhIDM1IDJjIDVhIGQ4IGM0IGRjMC0wITAJBgUrDgMCGgUABBQxUC34Z6Gv3mQ9KasYv5nTPWheFgQIW0sWRRMstPA=";

//    FILE                     *fp;

//        PKCS12                *p12=NULL;


//        unsigned char buf[10000],*p;

//        int                         len,i1,num,j1,count,ret;

//        STACK_OF(PKCS7) *p7s;

//        STACK_OF(PKCS12_SAFEBAG) *bags;

//        PKCS12_SAFEBAG      *bag;

//        PBEPARAM           *pbe=0;

//        BIO                      *bp;

//        char               pass[100];

//        int                         passlen;

//        X509                    *cert=NULL;

//        STACK_OF(X509)*ca=NULL;

//        EVP_PKEY            *pkey=NULL;
//            char * bujj;
//         bujj=Base64Decode(Keycode,3480,false);
//        fp=fopen("1.pfx","rb");
//        printf("i %d : \n",str(buffff));
//        printf("input password : \n");

//        for(int ju=0;ju<3480;ju++){

//            printf("%02x",bujj[ju]);

//        }
//        printf("]");

//        len=fread(buf,1,10000,fp);

//         fclose(fp);
//         TRACE_INFO("标注1：[\n");
//       for(int j=0;j< 2609 ;j++){
//         TRACE_INFO("%02x",bujj[j]);
//       }
//       TRACE_INFO("]\n");


//        OpenSSL_add_all_algorithms();

//        bp=BIO_new(BIO_s_file());

//        BIO_set_fp(bp,stdout,BIO_NOCLOSE);

//        p=( unsigned  char *)bujj;
//        const unsigned char * jio=(unsigned  char *)bujj;;

//        d2i_PKCS12(&p12, &jio,3480);



//         ret=PKCS12_parse(p12,"PtjMJt+bMXbL",&pkey,&cert,&ca);
////ca->stack_st_X509
////         EVP_PKEY *  jkss;
////           jkss= d2i_PrivateKey(1, EVP_PKEY **a, const unsigned char **pp,  123);
////         p=(unsigned char *)bujj;

////         len=i2d_PrivateKey(pkey,&p);

////         fp=fopen("prikey.cer","wb");

////         fwrite(bujj,1,len,fp);

////         fclose(fp);

//          char * outdata1=new   char(700);
//           std::string outdata2="31323334";
////         int lengg;
////          unsigned char *   &origin_text;
//parseCert1(cert);
//              char  * ji;
//      ChangeHexData123(outdata2,outdata1);
////               ;
////  EVP_PKEY *pri_key;
////         EVP_PKEY_encrypt(pkey->pkey.rsa,(const unsigned char *) outdata1,   sizeof(outdata1),( unsigned char *)outdata2.c_str(), 4);
//         std:: string dat= RsaOperater::instance()->  PrivateRSAKeyEncode(pkey->pkey.rsa,(const char *)"1234");
// //      std:: string dat1=    base64_encode((const  unsigned char *)dat.c_str(),dat.size());//,dat.size()


// //      //  cout << "three: " << dat.c_str() << endl;
//           TRACE_INFO("标注：[\n");
//         for(int j=0;j< dat.size() ;j++){
//           TRACE_INFO("%02x",dat.c_str()[j]);
//         }
//         TRACE_INFO("]\n");


////         /* 私钥写入文件 */
//       QApplication app( argc, argv );


//       QByteArray byte = Image_To_Base64("/1.png");

//         TRACE_INFO("标注：[\n");
//         for(int j=0;j< byte.size() ;j++){
//            TRACE_INFO("%02x",byte.data()[j]);
//          }
//          TRACE_INFO("]\n");

//     HttpClient client;
//     std::string url="http://openapi.baidu.com/public/2.0/translate/dict/simple?client_id=";
//     url += "faEkfGvdVpwjeQGms6HqzHaQ";
//     url += "&q=";
//     url += word;
//     url +="&from=en&to=zh";
//     File* file = new File("/ss/baidudict.cache",IO_MODE_REWR_ORNEW);
//     client.httpGet(url,file);
//     delete file;

//     JSONData json;
//     JSONNode* rootNode=json.initWithContentOfFile("/tmp/baidudict.cache");
//     std::string out=json.serialize();
//     TRACE_CYAN("%s\n",out.c_str());

//    Base64_To_Image(byte,"/234.png");




//    app.exit(0);


//       return app.exec();


//                           unsigned char        *der;



//                           X509                           *x;

//                           BIO                             *in;

//                           X509_ALGOR                     *md;

//                           PKCS7_SIGNER_INFO*si;

//                       RSA*  priRsa;

//                           FILE * fp;
//                            std::string  path="prikey.pem";
//                           const char *   path_1=( const char * )path.c_str();
//                             if((fp=fopen(path_1,"r"))==NULL)
//                             {
//                                TRACE_INFO("cant open the file");

//                               }

//                           else{
//                                 fseek( fp , 0 , SEEK_END );
//                                 int file_size;
//                                 file_size = ftell( fp );
//                                 TRACE_INFO( "%d" , file_size );
//                                 char *tmp;
//                                 fseek( fp , 0 , SEEK_SET);
//                                 tmp =  (char *)malloc( file_size * sizeof( char ) );
//                                 fread( tmp , file_size , sizeof(char) , fp);
//                                  //      //  cout << "three: " << dat.c_str() << endl;
//                                            TRACE_INFO("\n标注22：[\n");
//                                          for(int j=0;j< file_size ;j++){
//                                            TRACE_INFO("%02x",tmp[j]);
//                                          }
//                                          TRACE_INFO("]\n");






//          std:: string dasda="1234";


//          unsigned char *Pt = (unsigned char *)tmp;
//          const unsigned char * ptyu=( const unsigned char *)Pt;

// priRsa=   d2i_RSAPrivateKey(NULL, &ptyu , file_size  );


//            std:: string dat= RsaOperater::instance()->  PrivateRSAKeyEncode(priRsa,(const char *)dasda.c_str());



//                 TRACE_INFO("标注：[\n");
//              for(int j=0;j< dat.size() ;j++){
//                TRACE_INFO("%02x",dat.c_str()[j]);
//              }
//              TRACE_INFO("]\n");
//                              }



//                           in=BIO_new_file("prikey.cer","r");


//                           x=PEM_read_bio_X509(in,NULL,NULL,NULL);

//                           sk_X509_push(p7->d.sign->cert,x);

//                           md=X509_ALGOR_new();

//                           md->algorithm=OBJ_nid2obj(NID_md5);

//                           sk_X509_ALGOR_push(p7->d.sign->md_algs,md);

//           parseCert1(x);





////parseCert1(cert);
//// printf("\n长度：%ld\n", pkey->pkey.rsa->version) ;

// unsigned char *orig_data ;  std:: string dasda1="1234";
//              printf("version : %d\n",ASN1_INTEGER_get(p12->version));
//const unsigned char *  encode;
//const unsigned char * daj=(const unsigned char * )dasda1.c_str();
// EVP_PKEY* pkeydata=open_private_key("prikey.cer");
//rsa_key_decrypt(pkeydata,daj,4, orig_data,512)
//    wlog_init((char*)&LOG_PATH);

//    /*配置文件读取*/
//    dictionary *ini;
//    const char *str;
//    char *ip;
//    int n =0;
//    ini = iniparser_load("src/script/parameters.ini");     //parser the file
//    if(ini == NULL)
//    {
//        fprintf(stderr,"can not open %s","example.ini");
//        exit(EXIT_FAILURE);
//    }
//    printf("dictionary obj:\n");
//    iniparser_dump(ini,stderr);                                   //save ini to stderr

//    printf("\n%s:\n",iniparser_getsecname(ini,0));             //get section name
//    net_info.Server_TCP_Port = iniparser_getint(ini,"para:Server_TCP_Port",-1);                                               //TCP端口获取
//    printf("port : %d\n", net_info.Server_TCP_Port);
//    str =  iniparser_getstring(ini,"para:Mainserver_IP","null");                                   //IP地址获取
//    printf("ip : %s\n",str);
//    memcpy(net_info.Mainserver_IP,str,sizeof(str));



//    phone_num =  iniparser_getstring(ini,"para:phonenum","null");                          //手机号获取
//    printf("phone : %s\n",phone_num.c_str());
//    char  * Mainserver_IPTemp=(   char  *)net_info.Mainserver_IP;
//    appcon.do_init_net("139.196.234.16",18083);                                           //网络初始化
//    appcon.do_init_cmd();                                               //命令字初始化
//    wlog_exit();
//    uart_init();
//    acksendEvent.addEventListener(&ackreciceEvent);   //命令事件的获取
//    Event  env2=Event(0x0001,"1234",4);
//    acksendEvent.postEvent(env2);


//    communicateplatform1.Init_Data();                     //通信平台数据初始化
//    gps1.init_gps();                                                       // gps数据初始化
//    communicateplatform1.StartSendHeart();          //心跳信息


    //    commucate32.Init_Data();                                             //stm32数据初始化
    //    module_init();                          //指纹模块初始化
    //    read_moudelNum();                //读取指纹模块编号
    //    entry();                               //  指纹录入
    //    search();                             //  指纹比对
//    stRegInfo mInfo;
//    mInfo.m_CarNumber;
//    string hex1="3130303932";
//    string hex2="4335303030000000000000000000000000000000";
//    string hex3="36303030303930";
//    string hex4="333535303939303438313233343536";
//    string hex5="CBD54135353133D1A7";

//    mInfo. m_Province=0x0B00;  //省
//    mInfo. m_town=0x6E00;      //县域
//    ChangeHexData1(hex1  , mInfo. m_manufacturerID);  //制造商ID
//    ChangeHexData1(hex2  ,  mInfo. m_DeviceType) ;     //终端类型
//    ChangeHexData1(hex3  ,   mInfo.m_DeviceSN );        //设备SN
//    ChangeHexData1(hex4  ,  mInfo. m_IMEI);          //IMEI
//    mInfo.m_CarPlateColor=0x02;    //车牌颜色
//    ChangeHexData1(hex5  , mInfo.m_CarNumber);     //车牌标识


//    appcon.do_register(mInfo);


//    unsigned char in[128]={
//        0x22,0x91,0x03,0xA5,0xE3,0x12,0x0F,0x2D,0x28,0x62,0x09,0x11,0x76,0xAA,0x2B,0xD4,
//        0xE2,0x4D,0x69,0xE7,0xEE,0xF7,0xB9,0x19,0x5C,0x91,0xEA,0x00,0x88,0xAE,0xCF,0xF4,
//        0x7E,0xDF,0xA0,0xBE,0xEF,0x7C,0x39,0x1D,0xF3,0xB0,0x5F,0x71,0x7D,0xCC,0x06,0xFF,
//        0xC8,0xEE,0xFF,0x90,0xBA,0x14,0x21,0x2B,0x8A,0x52,0xAD,0x48,0xB3,0x32,0x77,0xB2,
//        0xE2,0x30,0xD4,0x0B,0x3E,0x76,0xDC,0x59,0x77,0x89,0x26,0xF1,0xD8,0x73,0x9E,0x10,
//        0x6C,0xD7,0x41,0xDE,0x06,0xA7,0x42,0x3D,0xFB,0xA2,0x5E,0x02,0xF1,0x2E,0x54,0x3D,
//        0x13,0xD1,0xB4,0x71,0x80,0x65,0x26,0x02,0x49,0x81,0xB7,0xD2,0x6B,0x4B,0xF6,0xE5,
//        0x55,0x86,0x04,0xCC,0xC2,0x89,0xF5,0x9E,0x8A,0x80,0x2F,0x45,0xFB,0x3D,0x9E,0x67,
//    };

//    RSA *r;
//    BIO *bio = NULL;
//    RSA *rsa = NULL;
//    string pubKey="111111";

    //            string pubKey(bstr_t);
    //            char *chPublicKey = const_cast<char *>(pubKey.c_str());
    //        if ((bio = BIO_new_mem_buf(chPublicKey, -1)) == NULL)       //从字符串读取RSA公钥
    //        {
    //           // cout << "BIO_new_mem_buf failed!" << endl;
    //        }
    //        rsa = PEM_read_bio_RSA_PUBKEY(bio, NULL, NULL, NULL);   //从bio结构中得到rsa结构

    //    //准备输出的加密数据结构
    //    flen =  RSA_size(r);
    //    encData =  (unsigned char *)malloc(flen);
    //    memset(encData, 0, flen);
    //    ret =  RSA_public_encrypt(flen, in, encData, r,  RSA_NO_PADDING);
    //    if(ret < 0)
    //    {
    //        printf("\nerrp!\n");
    //        //return 0;
    //    }
//    while(1){
//        sleep(1);
//    }


//    char in_buf[20]="1234546";
//    int buf_len = 7;
//    char out_buf[20];
//    int out_len;
//    n485_uart.N485_Open(UartParam7);
//    n485_uart.N485_CmdSend(in_buf,buf_len,out_buf,out_len,10);
//    n485_uart.N485_Close();
//    return 0;

//int yu=RtcUtils::getInstance()->getUtcTimeMiliSeconds();
//TRACE_INFO("秒：%d\n",yu);

//char data[4];
//  QString sy;
//    sy.append("杜辉");
//    char* str  =new char (8);
//int dize=TtsUtils::getInstance()->ToUnicode(sy,str);
//  qDebug()<<"s:"<<dize;
//QByteArray encodedString1=das.toLatin1();
//TRACE_INFO("\n");
// for(int jj=0;jj<dize;jj++){
//  TRACE_INFO("%02x",str[jj]);
// }
// TRACE_INFO("\n");
// cout<<photonum_coach<<endl;
//RtcTime_S  rtc;


//unsigned char datatest[20];


// std::string hgss=getmaintime3string(rtc ,5);


// TRACE_INFO("\n秒：[%d]\n",y);
//for(int ji=0;ji<10;ji++){

//TRACE_INFO(" %02x",datatest[ji]);


//}
//TRACE_INFO("\n]\n" );

// std::string photonum_coach  =getmaintime3string(rtc,5);
// cout<<photonum_coach<<endl;

//#endif



//     HttpClient* client = new HttpClient();
//     File* file = new  File("test.python", IO_MODE_RDAPPEND_ORNEW);
////    std::string url="http://139.196.234.16:9007/driving_dev/v1/drving/tcpimgs?stuNum=6406180471611162&coachNum=6150223349161433";

// std::string url1="http://139.196.234.16:9007/driving_dev/v1/drving/tcpimgs/coach?";
// std::string url2="coachNum=6150223349161433&devnum=9624363527544550";


//    client->httpPost(url1,url2,file);
////       delete file;
//FILE * pFile;
////         new  File("123.jpg", IO_MODE_RDAPPEND_ORNEW);
//      JSONData json;
//     JSONNode* rootNode= json.initWithContentOfFile("test.python");
//     JSONNode node = (*rootNode)["data"]["fileName"];


//  QByteArray tempArray = QByteArray::fromBase64(QByteArray(node.toString().c_str() ));
//  QImage qimagedata=QImage::fromData(tempArray,"JPEG");
//  qimagedata.save("456.jpg","JPEG");


//     PhotoGetUtils::getInstance()->getCoachPath("9624363527544550","6150223349161433");

//  for(int y=0;y<node.toString().size();y++)
// {
//      TRACE_ERR("%s",node.toString().c_str());
////}
//   TRACE_ERR("\n");

//  fwrite ( const void * ptr, size_t size, size_t count, FILE * stream );

//  if((pFile = fopen ("123.jpg", "wb"))==NULL)
//      {
//        printf("cant open the file");
//        exit(0);
//    }

//  fwrite( tempArray.data() ,sizeof(char), tempArray.size()  , pFile);

//   fclose (pFile);

//qimagedata.load("test1.jpg");


//  QBuffer buffer(&tempArray);
//  buffer.open(QIODevice::WriteOnly);


//  qimagedata.save("/tmp/test1.jpg");




//  TRACE_YELLOW("fileName:%s\n",getdata.c_str());

//   QImage  qim ;
//   qim.loadFromData(
//    JSONData json;
//    //JSONNode* rootNode=json.initWithContentOfFile("test.json");
//    const char* jsonString = "{\"data\":[{\"type\":2,\"number\":\"6406180471611162\",\"fileName\":\"123\"},{\"type\":1,\"number\":\"6150223349161433\",\"fileName\":\"345\"}],\"message\":null,\"errorcode\":0}";
//    JSONNode* rootNode = json.initWithDataString(jsonString);
//    JSONNode node = (*rootNode)["data"]["type"]["number"]["fileName"];

////    node = (*rootNode)["data"].isArrayNode();


//    TRACE_YELLOW("---oid:%d\n",node["data"].isArrayNode());

//    TRACE_YELLOW("errorcode:%s\n",node.toString().c_str());
//    node = (*rootNode)["data"]["oid"];
//    TRACE_YELLOW("oid:%d\n",node.toInt());
//    node = (*rootNode)["object"].toNode();
//    TRACE_YELLOW("---oid:%d\n",node["oid"].toInt());




//#if NETWORK

//    #if 1
//     dictionary *ini;
//     const char *str;
//     char *ip;
//     int n =0;
//     ini = iniparser_load("/src/script/parameters.ini");     //parser the file
//     if(ini == NULL)
//     {
//         fprintf(stderr,"can not open %s","example.ini");
//         exit(EXIT_FAILURE);
//     }
//     printf("dictionary obj:\n");
//     iniparser_dump(ini,stderr);

//    mobile_param.nettype = iniparser_getint(ini,"dial_param:nettype",0);
//    printf("mobile_param.nettype= %d\n", mobile_param.nettype);

//    mobile_param.dial_num =  (char *)iniparser_getstring(ini,"dial_param:dialnum","null");
//    printf("mobile_param.dial_num= %s\n", mobile_param.dial_num);

//    mobile_param.passwd =  (char *)iniparser_getstring(ini,"dial_param:passwd","null");
//    printf("mobile_param.passwd= %s\n", mobile_param.passwd);

//    mobile_param.apn =  (char *)iniparser_getstring(ini,"dial_param:apn","null");
//    printf("mobile_param.apn= %s\n", mobile_param.apn);

//    mobile_param.dial_port =  iniparser_getint(ini,"dial_param:dial_port", 0);
//    printf("mobile_param.dial_port= %d\n", mobile_param.dial_port);

//    mobile_param.status_port =  iniparser_getint(ini,"dial_param:status_port", 0);
//    printf("mobile_param.status_port= %d\n", mobile_param.status_port);
//    #endif

//    #if 0
//    while(1)
//    {
//        int signal_level;
//        signal_level = get_4g_signal_quality();
//        if(signal_level > -1)
//            printf("signal level = %d\n", signal_level);
//        sleep(1);
//        printf("...\n");
//    }
//    #endif

//    #if 1
//    pthread_create(&net_4g_tID, NULL, dial_manage, NULL);
//    pthread_join(net_4g_tID, NULL);
//    #endif
//#endif


#if 0
    module_init();                     //指纹模块初始化   //后面加卡数据
    int Tempcount;
    int fingerscore;
    unsigned char datatest[200];
    std::string finger="0301621f8100fffee01ec00e800680068002800280028002800280028002800280028006800ec01e000000000000000000000000000000003e0b15be210beb7e4f92821e4497425e6917da3e1e982c9e3b1bc27e60ae9b1e3633031e45bc849e5ebfc4f630c3d95e338debdf13126b973614ec9f641fda7f2d21965f69a5857f3a27d85f3025c25c2737c19c2db8983c21a815321ca8abb23eaf1bb23b2d84135bb7da334f1b03385019985954b64316533499d70000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
    unsigned char tresfinger[512];
    ChangeHexStr2Char(finger,tresfinger);
    while(1)
    {
        if( PSDownChar(DEV_ADDR,CHAR_BUFFER_A,&tresfinger[0],512)==PS_OK) {
            printf("\指纹加载成功\n");
            Delay(1000);
            printf("Search: Please Repress finger......\n");
            Tempcount=0;
            while((PSGetImage(DEV_ADDR)==PS_NO_FINGER))
            {
                if(DEVICE_USB==0)
                    PSReadInfo(DEV_ADDR,1,datatest);
                Delay(200000);
                Tempcount++;
                if(Tempcount >= 25 )
                {
                    if(PSCloseDevice()==1)
                    {
                        printf("Close device ok!\n");
                    }
                    reset_finger();
                    module_init();                     //指纹模块初始化   //后面加卡数据
                    break;
                }
            }

            if(PSGenChar(DEV_ADDR,CHAR_BUFFER_B)!=PS_OK)
            {
                printf("Gen Char fail!\n");
            }
        }
        else
        {
            if(PSCloseDevice()==1)
            {
                printf("Close device FFok!\n");
            }
            reset_finger();
            module_init();                     //指纹模块初始化   //后面加卡数据
        }

        if(PSMatch(DEV_ADDR,&fingerscore)==0)
        {
            TRACE_INFO("指纹验证成功\n");
        }
        else
        {
            TRACE_INFO("指纹验证失败\n");
        }
        sleep(2);
        TRACE_INFO("again\n");
    }


#endif



#if 0
    int fd = open("/sys/class/gpio/gpio262/value", O_RDWR);
    if(fd <0) {
        printf("open gpio262 failed\n");
        return -1;
    }
    char buffer[2] = {0,1};
    const char *high = "1";
    const char *low = "0";
    int ret = write(fd,low,strlen(low));
    printf("ret = %d\n",ret);
    if(ret < 0)
    {
        perror("error:");
    }
    sleep(10);
    printf("we will write 1\n");
    ret = write(fd,high,strlen(high) );
    printf("ret1 = %d\n",ret);

    close(fd);
#endif

#if 0
    char name[20];

    memset(name, 0, sizeof(name));
    if(exe_dev0_snap_pics(name) != 0)
        printf("snap failed\n");
    printf("name = %s\n", name);

    memset(name, 0, sizeof(name));
    exe_dev0_snap_pics(name);
    printf("name = %s\n", name);
#endif

#if 0
    vector<stSendCmdPiPe*> sendpipe;
    OfflineSave::getInstance()->selectMessageBySendStatus(0,sendpipe);
    vector<stSendCmdPiPe*>::iterator it= sendpipe.begin();
    if(it != sendpipe.end())
    {
        stSendCmdPiPe *sedndata = *it;
        if(sedndata)
        {
            sedndata->ts_isoffline=true;//离线数据
            m_CmdProcessTask.Send_OneCmd(*sedndata,3,true);
            OfflineSave::getInstance()->deleteMessageByTime(sedndata->ts_sendtime);
            delete [] sedndata->ts_content;
        }
    }
    sendpipe.clear();
#endif

#if 1
    GPS_recv  gps;
    sp_gateway *m_appGateway;
    /*配置文件读取*/
    dictionary *ini;
    const char *str;
    ini = iniparser_load("/user/src/script/parameters.ini");     //parser the file
    if(ini == NULL)
    {
        fprintf(stderr,"can not open %s","parameters.ini");
        exit(EXIT_FAILURE);
    }
    iniparser_dump(ini,stderr);                                   //save ini to stderr

    Isregister = iniparser_getint(ini,"para:RegisterFlag",-1);
    net_info.Server_TCP_Port = iniparser_getint(ini,"para:Server_TCP_Port",-1);                                               //TCP端口获取
    str =  iniparser_getstring(ini,"para:Mainserver_IP","null");
    const char *devNum;
    const char *devicekeychar;
    devNum=iniparser_getstring(ini,"devicedata:deviceid","null");
    devicekeychar=iniparser_getstring(ini,"devicedata:devicekey","null");
    TRACE_HEX("加密串",devicekeychar,512); //   printHex
    Keyencode =QString(QLatin1String(devicekeychar)).toStdString();
    QString MaindevNumstring=QString(devNum);
    //IP地址获取

    Device_Num=MaindevNumstring.toStdString();
    TRACE_CYAN("\n设备号：\n" );
    cout<<Device_Num<<endl;
    const char *httpstr;
    gps.init_gps();
    httpstr=iniparser_getstring(ini,"para:http_url","null");

    int httpportin;
    httpportin=iniparser_getint(ini,"para:http_port",-1);
    QString Mainhttp_urltring=QString( httpstr);
    http_url=Mainhttp_urltring.toStdString();
    http_port=  QString::number(httpportin,10).toStdString();
    memcpy(net_info.Mainserver_IP,str,strlen(str));
    phone_num =  iniparser_getstring(ini,"para:phonenum","null");                          //手机号获取

    net_info.Server_TCP_Port = 10083;
    appcon.do_init_net("139.196.234.16",net_info.Server_TCP_Port );
//    TimerUpload::getInstance()->Init_Data();                       //通信平台数据初始化
//    TimerUpload::getInstance()->startTest();
//    gps.init_gps();
//    commucate32.setloginInterface(g_loginHandler);
    appcon.do_init_cmd();
    string coachin = "7E800900005B000001391390090300003C130101000000013634383837333431383139323530383400000040343538353332373536353331383632323332313138313139393330343330353937314331000000000000000001E1936E07104E65000000000000170808095952447E";
    string stuin = "7E8009000060000001391390090300003C1302010000000436343838373334313831393235303834000000453834313633353733353534323336373334353835333237353635333138363232121211000059898B9C000000000000000001E1936C07104E6A000000000000170808100004CA7E";
    string locationin = "7E800200001C00000139139009036A543C000000000000000201E1936D07104E68000000000000170808095901467E";
    string learin = "7E800900008D00000139139009036AEF3C130203000000093634383837333431383139323530383400000072363438383733343138313932353038343137303830383036303301383431363335373335353432333637333435383533323735363533313836323259898B9C10031712121100000100000000000000000000000201E1936307104E7B000000000000170808100317050200000104000000009B7E";
    while(1)
    {
        if(Isregister == 1)
        {
                shark_authority_up amInfo;
                amInfo.timestamp=htonl(0x58aaa9bd);
                ChangeHexStr2Char(Keyencode,&amInfo.encryptdata[0]);
                appcon.do_authority(amInfo);
       }
        usleep(100000);
        m_appGateway->nTcp_Send((char *)coachin.c_str(),coachin.length());
        usleep(100000);
        m_appGateway->nTcp_Send((char *)stuin.c_str(),stuin.length());
        usleep(100000);
        m_appGateway->nTcp_Send((char *)locationin.c_str(),locationin.length());
        usleep(100000);
        m_appGateway->nTcp_Send((char *)learin.c_str(),learin.length());
        usleep(100000);
    }

#endif


}


