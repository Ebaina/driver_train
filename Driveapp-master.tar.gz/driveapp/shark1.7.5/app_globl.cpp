﻿#include "app_globl.h"
#include "main_event_manager.h"
#include <QString>
#include <QDebug>
#include "src/module/dial/dial.h"
#include "stm32_card.h"
DeviceFramework appcon;
sp_gateway appGateway;
CmdPP m_CmdProcessTask;
stRegInfo sreginfo;
CoachLogin_Up coachup_info;
LearnerLogin_Up learnerup_info;
LearnerLogin_down learner_login_info;
CommunicateMainSet commu_info;
NetMainSet net_info;
ReportMainSet report_info;
ListenMainSet  monitor_info;
ViewthresholdMainSet  videolisten_info;
OtherMainSet other_info;
CommandParam terminal_control_para_info;
Searchterminalappdata_Up   appdata_setinfo;
stRegInfo_ack     regack_info;
Context4G    c4g_info;
UpdatePara updateversion;
string phone_num;
PositionReport_up  positionReport_up;
st4gNetStatus netStatus;
photodb p_db;


int coachSuccess_flag = 0;  //教练后台登入成功标志
int stuSuccess_flag = 0;      //学员后台登入成功标志
int remaining_min = 0;   //剩余学时

int forbidenflag = 0;  //禁止训练标志
int takePhototime=15;//拍照间隔

int  MainRpm=2000;
int  MainSpeed=0;
std:: string Keyencode="4684B14E64CA9FBDBB1B115B9550E4E8CA4F306B7AE822ADB0A90BC20909B70F6AEFF413A0CF6CEEBD6CE5EC1366BEE4D5E872E314D6933CBD159601D582D47C342F03B02B1827B78F0AF8182ADE54C482BE0570FA45F1FAA04B22C051DAE28D643CBBD29CC51C98F232B1E433709053C015621784E1732A7FAF1FA1C6C3DF7E05A52D2D267498D9FB8BA238FBD3BA6F8D4245C07873B7624AD7C141280078D8BBC76D822A9333915AD89D93D8B747F000CFD9D3994353DFCAC2B8AA9C7712635C8BE45D32180786E665F7ECAA2323FB874DDFBF3AF099104375D1F781212A13F93213C15A86F6B8465C09BBBC79995355B6FD7B62CDD559C614539CCDEFBA2F";

std:: string  MainCoachPhotoPath;
std:: string  MainStudentPhotoPath;

int  IsMainCoachPhotoPathFlag;
int  IsMainStudentPhotoPathFlag;

int Uploadflag=0;
wis_u8 TerminalLoginStatus ;
int   TrainRecordNum=0;//学时记录编号


int Mainlantitude;
int Mainlontitude;

int  RfcardReadFlag = 0; //1打开  0关闭
int  RfcardlogoutFlag = 0; //1打开  0关闭

int  Isregister = 0; //注册标志
int  Ispageflag = 0; //页面标志
wis_u32  subjectcode=11; //课程码

unsigned char IsAuthority=0;

int videoflag=0;
int  IsCoachLogin=0;
int  IsLearnerLogin=0;
int StartTrainFlag=0;

stm32_info coachcardinfo;
stm32_info studentcardinfo;
stm32_info admincardinfo;
int TrainLessonId=0;                      //训练课堂ID
int UpdateFlag = 0;                         //更新标志位

unsigned short  TrainCouts=0;//学时时间
int  TcpLinkConnectFlag=0; //TCP 链路 标志

int Trainminutes=0;//学时时间

double MainGetDistance = 0;//总里程
int MainStartLat = 0;//开始
int MainStartLong = 0;//开始
int MainEndLat = 0;
int MainEndLong = 0;

std::string  http_port;
std::string  http_url;
std::string  subjectID = "1212110000";                   //课程编码

std::string  Device_Num;


int RealTimeVideoStatus()
{
    if(access("/dev/video0", R_OK) == 0)
        return 1;
    else if(access("/dev/video1", R_OK) == 0)
        return 2;
    else
        return -1;
}
