#ifndef SHARKNEWLIB_H
#define SHARKNEWLIB_H


class SharkNewlib
{

public:
    SharkNewlib();
};

#endif // SHARKNEWLIB_H
