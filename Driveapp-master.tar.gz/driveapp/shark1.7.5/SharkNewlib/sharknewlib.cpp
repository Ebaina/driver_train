#include "sharknewlib.h"


SharkNewlib::SharkNewlib()
{
}
